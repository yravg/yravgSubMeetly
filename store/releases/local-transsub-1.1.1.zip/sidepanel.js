// src/lib/registry.js
var ASR_MODELS = {
  "whisper-tiny": {
    id: "onnx-community/whisper-tiny",
    label: "Whisper Tiny",
    sizeWebgpu: "~120 MB",
    sizeWasm: "~45 MB",
    note: "fastest, lowest accuracy"
  },
  "whisper-base": {
    id: "onnx-community/whisper-base",
    label: "Whisper Base",
    sizeWebgpu: "~210 MB",
    sizeWasm: "~80 MB",
    note: "recommended balance"
  },
  "whisper-small": {
    id: "onnx-community/whisper-small",
    label: "Whisper Small",
    sizeWebgpu: "~590 MB",
    sizeWasm: "~250 MB",
    note: "good accuracy, slower on WASM"
  },
  "whisper-large-v3-turbo": {
    id: "onnx-community/whisper-large-v3-turbo",
    label: "Whisper Large v3 Turbo",
    sizeWebgpu: "~565 MB",
    sizeWasm: "\u2014",
    note: "high accuracy \xB7 WebGPU only",
    webgpuOnly: true,
    dtype: { encoder_model: "q4f16", decoder_model_merged: "q4f16" }
  },
  "voxtral-mini": {
    id: "onnx-community/Voxtral-Mini-3B-2507-ONNX",
    label: "Voxtral Mini 3B",
    sizeWebgpu: "~2.7 GB",
    sizeWasm: "\u2014",
    note: "best quality \xB7 WebGPU + \u226516 GB RAM \xB7 slower",
    webgpuOnly: true,
    engine: "voxtral",
    dtype: { embed_tokens: "q4", audio_encoder: "q4f16", decoder_model_merged: "q4f16" }
  }
};
var DEFAULT_ASR = "whisper-base";
var DEFAULT_NATIVE_URL = "http://127.0.0.1:17865";
var SOURCE_LANGS = [
  ["auto", "Auto detect"],
  ["en", "English"],
  ["ja", "Japanese"],
  ["zh", "Chinese"],
  ["ko", "Korean"],
  ["de", "German"],
  ["fr", "French"],
  ["es", "Spanish"],
  ["ru", "Russian"],
  ["it", "Italian"],
  ["pt", "Portuguese"],
  ["nl", "Dutch"],
  ["pl", "Polish"],
  ["tr", "Turkish"],
  ["ar", "Arabic"],
  ["hi", "Hindi"],
  ["th", "Thai"],
  ["vi", "Vietnamese"],
  ["id", "Indonesian"],
  ["uk", "Ukrainian"]
];
var TARGET_LANGS = [
  ["en", "English"],
  ["zh", "Chinese"],
  ["de", "German"],
  ["fr", "French"],
  ["es", "Spanish"],
  ["ru", "Russian"],
  ["it", "Italian"],
  ["id", "Indonesian"],
  ["vi", "Vietnamese"],
  ["ja", "Japanese"],
  ["ko", "Korean"]
];
var MT_PAIRS = {
  "ja-en": { id: "Xenova/opus-mt-ja-en", size: "~116 MB" },
  "zh-en": { id: "Xenova/opus-mt-zh-en", size: "~120 MB" },
  "ko-en": { id: "Xenova/opus-mt-ko-en", size: "~115 MB" },
  "de-en": { id: "Xenova/opus-mt-de-en", size: "~115 MB" },
  "fr-en": { id: "Xenova/opus-mt-fr-en", size: "~115 MB" },
  "es-en": { id: "Xenova/opus-mt-es-en", size: "~115 MB" },
  "ru-en": { id: "Xenova/opus-mt-ru-en", size: "~115 MB" },
  "it-en": { id: "Xenova/opus-mt-it-en", size: "~115 MB" },
  "nl-en": { id: "Xenova/opus-mt-nl-en", size: "~115 MB" },
  "pl-en": { id: "Xenova/opus-mt-pl-en", size: "~115 MB" },
  "ar-en": { id: "Xenova/opus-mt-ar-en", size: "~115 MB" },
  "vi-en": { id: "Xenova/opus-mt-vi-en", size: "~115 MB" },
  "id-en": { id: "Xenova/opus-mt-id-en", size: "~115 MB" },
  "uk-en": { id: "Xenova/opus-mt-uk-en", size: "~115 MB" },
  "en-zh": { id: "Xenova/opus-mt-en-zh", size: "~121 MB" },
  "en-de": { id: "Xenova/opus-mt-en-de", size: "~115 MB" },
  "en-fr": { id: "Xenova/opus-mt-en-fr", size: "~115 MB" },
  "en-es": { id: "Xenova/opus-mt-en-es", size: "~115 MB" },
  "en-ru": { id: "Xenova/opus-mt-en-ru", size: "~115 MB" },
  "en-it": { id: "Xenova/opus-mt-en-it", size: "~115 MB" },
  "en-id": { id: "Xenova/opus-mt-en-id", size: "~115 MB" },
  "en-vi": { id: "Xenova/opus-mt-en-vi", size: "~115 MB" }
};
var LANG_NAMES = Object.fromEntries([...SOURCE_LANGS, ...TARGET_LANGS]);
var UI_LANGS = (() => {
  const codes = /* @__PURE__ */ new Set();
  for (const key of Object.keys(MT_PAIRS)) {
    const [src] = key.split("-");
    if (src) codes.add(src);
  }
  const nativeLabels = {
    en: "English",
    zh: "\u4E2D\u6587",
    ja: "\u65E5\u672C\u8A9E",
    ko: "\uD55C\uAD6D\uC5B4",
    de: "Deutsch",
    fr: "Fran\xE7ais",
    es: "Espa\xF1ol",
    ru: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
    it: "Italiano",
    nl: "Nederlands",
    pl: "Polski",
    ar: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
    vi: "Ti\u1EBFng Vi\u1EC7t",
    id: "Indonesia",
    uk: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430"
  };
  const preferred = ["en", "zh"];
  const rest = [...codes].filter((c) => !preferred.includes(c)).sort();
  return [...preferred.filter((c) => codes.has(c)), ...rest].map((code) => [
    code,
    nativeLabels[code] || LANG_NAMES[code] || code
  ]);
})();
function pairLabel(key) {
  const [s, t2] = key.split("-");
  return `${LANG_NAMES[s] || s} \u2192 ${LANG_NAMES[t2] || t2}`;
}
function translationPlan(src, tgt, { dualLine = false, refineTranslation = false } = {}) {
  if (!tgt || src === tgt) return { mode: "none" };
  const key = src !== "auto" && src !== "en" ? `${src}-${tgt}` : "";
  const pair = key ? MT_PAIRS[key] || null : null;
  const separateMt = dualLine || refineTranslation;
  if (pair && tgt === "en" && !separateMt) {
    return { mode: "mt", pairKey: key, pair };
  }
  if (tgt === "en" && !separateMt) return { mode: "whisper-direct" };
  if (!pair && src !== "auto" && src !== "en" && tgt !== "en") {
    const leg1 = MT_PAIRS[`${src}-en`];
    const leg2 = MT_PAIRS[`en-${tgt}`];
    if (leg1 && leg2) {
      return {
        mode: "mt",
        pairKey: key,
        pair: null,
        pivot: { leg1, leg2, leg1Key: `${src}-en`, leg2Key: `en-${tgt}` }
      };
    }
  }
  return { mode: "mt", pairKey: key, pair };
}

// src/lib/native-protocol.js
var LOCAL_HELPER_ORIGIN = "http://127.0.0.1:17865";
var NATIVE_HOST_ACTIONS = Object.freeze([
  "start",
  "stop",
  "restart",
  "status",
  "ensure_lab"
]);
function assertLocalUrl(url) {
  const u = String(url || LOCAL_HELPER_ORIGIN);
  let parsed;
  try {
    parsed = new URL(u);
  } catch {
    throw new Error("URL helper tidak valid");
  }
  const host = parsed.hostname;
  if (host !== "127.0.0.1" && host !== "localhost") {
    throw new Error("Helper hanya boleh alamat lokal (127.0.0.1 / localhost)");
  }
  return u.replace(/\/+$/, "");
}

// src/lib/native.js
function base(url) {
  return assertLocalUrl(url || DEFAULT_NATIVE_URL);
}
async function nativeHealth(url, timeoutMs = 1500) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/health`, { signal: ctrl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeShutdown(url, timeoutMs = 3e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/shutdown`, { method: "POST", signal: ctrl.signal });
    return r.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

// src/lib/native-host.js
var NATIVE_HOST_NAME = "com.localtranssub.helper";
function nativeHostSupported() {
  return typeof chrome?.runtime?.connectNative === "function";
}
function nativeHostAction(action, { timeoutMs = 45e3 } = {}) {
  return new Promise((resolve, reject) => {
    if (!nativeHostSupported()) {
      reject(new Error("Native messaging is not available in this browser"));
      return;
    }
    let settled = false;
    const finish = (fn, val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(val);
    };
    let port;
    try {
      port = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    } catch (e) {
      reject(e);
      return;
    }
    const timer = setTimeout(() => {
      try {
        port.disconnect();
      } catch {
      }
      finish(reject, new Error("Native host timed out"));
    }, timeoutMs);
    port.onMessage.addListener((msg) => {
      try {
        port.disconnect();
      } catch {
      }
      finish(resolve, msg);
    });
    port.onDisconnect.addListener(() => {
      if (settled) return;
      const err = chrome.runtime.lastError?.message;
      finish(reject, new Error(err || "Native host disconnected"));
    });
    port.postMessage({ action });
  });
}

// src/lib/transcript-cache.js
var SUBTITLE_MAX_CHARS = 84;
var SUBTITLE_LINE_CHARS = 42;
function splitSubtitleCues(lines, { maxChars = SUBTITLE_MAX_CHARS } = {}) {
  const out = [];
  for (const l of lines || []) {
    const t0 = Number(l.t0 ?? (l.t ?? 0) / 1e3) || 0;
    let t1 = Number(l.t1 ?? t0 + 3);
    if (!(t1 > t0)) t1 = t0 + 3;
    const src = (l.src || l.source || "").trim();
    const tgt = (l.tgt || l.translation || "").trim();
    const primary = tgt || src;
    if (!primary) continue;
    const chunks = chunkWords(primary, maxChars);
    const srcChunks = src && tgt && src !== tgt ? alignChunks(src, chunks.length) : null;
    const weights = chunks.map((c) => Math.max(1, c.replace(/\n/g, "").length));
    const totalW = weights.reduce((a, b) => a + b, 0);
    const dur = t1 - t0;
    let acc = 0;
    for (let i = 0; i < chunks.length; i++) {
      const start = t0 + dur * (acc / totalW);
      acc += weights[i];
      const end = i === chunks.length - 1 ? t1 : t0 + dur * (acc / totalW);
      const cueTgt = tgt ? chunks[i] : "";
      const cueSrc = srcChunks ? srcChunks[i] : tgt ? "" : chunks[i];
      out.push({
        t0: round3(start),
        t1: round3(Math.max(end, start + 0.05)),
        src: cueSrc || (tgt ? "" : chunks[i]),
        tgt: cueTgt || (!tgt ? chunks[i] : "")
      });
    }
  }
  return out;
}
function chunkWords(text, maxChars) {
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length) return [text];
  const chunks = [];
  let cur = "";
  for (const w of words) {
    const next = cur ? `${cur} ${w}` : w;
    if (next.length > maxChars && cur) {
      chunks.push(wrapCueLines(cur));
      cur = w.length > maxChars ? w.slice(0, maxChars) : w;
    } else {
      cur = next;
    }
  }
  if (cur) chunks.push(wrapCueLines(cur));
  return chunks;
}
function wrapCueLines(text) {
  if (text.length <= SUBTITLE_LINE_CHARS) return text;
  const words = text.split(/\s+/);
  let line1 = "";
  let i = 0;
  for (; i < words.length; i++) {
    const next = line1 ? `${line1} ${words[i]}` : words[i];
    if (next.length > SUBTITLE_LINE_CHARS && line1) break;
    line1 = next;
  }
  const line2 = words.slice(i).join(" ");
  return line2 ? `${line1}
${line2}` : line1;
}
function alignChunks(text, n) {
  const words = text.split(/\s+/).filter(Boolean);
  if (n <= 1) return [wrapCueLines(text)];
  if (!words.length) return Array(n).fill("");
  const chunks = [];
  const per = words.length / n;
  for (let i = 0; i < n; i++) {
    const a = Math.round(i * per);
    const b = Math.round((i + 1) * per);
    const part = words.slice(a, Math.max(b, a + (i === n - 1 ? 0 : 1))).join(" ");
    chunks.push(wrapCueLines(part || (i === n - 1 ? words.slice(a).join(" ") : "")));
  }
  if (chunks.length === n) {
    const used = chunks.join(" ").split(/\s+/).filter(Boolean).length;
    if (used < words.length) {
      chunks[n - 1] = wrapCueLines(words.slice(Math.round((n - 1) * per)).join(" "));
    }
  }
  return chunks;
}
function round3(n) {
  return Math.round(n * 1e3) / 1e3;
}
function cueBody(l, dualLine) {
  const src = (l.src || l.source || "").trim();
  const tgt = (l.tgt || l.translation || "").trim();
  if (dualLine && src && tgt && src !== tgt) return `${tgt}
${src}`;
  return tgt || src;
}
function formatSrt(lines, { url, title, dualLine } = {}) {
  const cues = [];
  if (url || title) {
    const meta = [`Local TransSub`, title && `Title: ${title}`, url && `Source: ${url}`].filter(Boolean).join("\n");
    cues.push({ t0: 0, t1: 1e-3, src: "", tgt: meta, _meta: true });
  }
  for (const l of splitSubtitleCues(lines || [])) {
    cues.push(l);
  }
  return cues.map((l, i) => {
    const t0 = l.t0 ?? 0;
    const t1 = l.t1 ?? t0 + 3;
    const text = l._meta ? l.tgt : cueBody(l, dualLine);
    return `${i + 1}
${fmtSrt(t0)} --> ${fmtSrt(t1)}
${text}
`;
  }).join("\n");
}
function formatVtt(lines, { url, title, dualLine } = {}) {
  const hdr = ["WEBVTT"];
  if (url) hdr.push(`NOTE Source: ${url}`);
  if (title) hdr.push(`NOTE Title: ${title}`);
  hdr.push("");
  const body = splitSubtitleCues(lines || []).map((l) => {
    const t0 = l.t0 ?? 0;
    const t1 = l.t1 ?? t0 + 3;
    return `${fmtVtt(t0)} --> ${fmtVtt(t1)}
${cueBody(l, dualLine)}
`;
  }).join("\n");
  return hdr.join("\n") + body;
}
function formatTxt(lines, { url, title } = {}) {
  const hdr = [];
  if (title) hdr.push(`Title: ${title}`);
  if (url) hdr.push(`Source: ${url}`);
  if (hdr.length) hdr.push("", "---", "");
  const body = (lines || []).map((l) => {
    const t0 = l.t0 ?? (l.t ?? 0) / 1e3;
    const ts = fmtVtt(t0);
    const src = l.src || l.source || "";
    const tgt = l.tgt || l.translation || "";
    if (src && tgt) return `[${ts}]
${src}
${tgt}`;
    return `[${ts}] ${tgt || src}`;
  }).join("\n\n");
  return hdr.join("\n") + body;
}
function fmtSrt(sec) {
  const ms = Math.max(0, Math.round(sec * 1e3));
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  const f = String(ms % 1e3).padStart(3, "0");
  return `${h}:${m}:${s},${f}`;
}
function fmtVtt(sec) {
  const ms = Math.max(0, Math.round(sec * 1e3));
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  const f = String(ms % 1e3).padStart(3, "0");
  return `${h}:${m}:${s}.${f}`;
}

// src/lib/export.js
var dirHandle = null;
async function loadExportDir() {
  try {
    const db = await openDb();
    const tx = db.transaction("handles", "readonly");
    const req = tx.objectStore("handles").get("exportDir");
    const handle = await reqToPromise(req);
    if (handle && await verifyPermission(handle)) {
      dirHandle = handle;
      return handle.name;
    }
  } catch {
  }
  return null;
}
async function pickExportDir() {
  if (!window.showDirectoryPicker) {
    throw new Error("Folder picker not supported in this browser");
  }
  dirHandle = await window.showDirectoryPicker({ mode: "readwrite" });
  await verifyPermission(dirHandle, true);
  const db = await openDb();
  const tx = db.transaction("handles", "readwrite");
  tx.objectStore("handles").put(dirHandle, "exportDir");
  return dirHandle.name;
}
async function clearExportDir() {
  dirHandle = null;
  try {
    const db = await openDb();
    const tx = db.transaction("handles", "readwrite");
    tx.objectStore("handles").delete("exportDir");
  } catch {
  }
}
async function saveExportFile(filename, content) {
  if (dirHandle) {
    const fh = await dirHandle.getFileHandle(filename, { create: true });
    const w = await fh.createWritable();
    await w.write(content);
    await w.close();
    return { saved: true, path: `${dirHandle.name}/${filename}` };
  }
  const url = URL.createObjectURL(new Blob([content], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5e3);
  return { saved: false, path: filename };
}
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("local-transsub", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("handles");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function reqToPromise(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function verifyPermission(handle, write = false) {
  const opts = { mode: write ? "readwrite" : "read" };
  if (await handle.queryPermission(opts) === "granted") return true;
  if (write) return await handle.requestPermission(opts) === "granted";
  return false;
}
function exportDirLabel() {
  return dirHandle?.name || null;
}

// src/lib/offline-io.js
var OFFLINE_INPUT_NAME = "offline-input";
var CHUNK_BYTES = 8 * 1024 * 1024;
var BROWSER_MAX_BYTES = 1536 * 1024 * 1024;
function needsNativeFilePath(size) {
  return size >= BROWSER_MAX_BYTES;
}
async function opfsRoot() {
  return navigator.storage.getDirectory();
}
async function stageFileToOpfs(file, onProgress) {
  const root = await opfsRoot();
  const fh = await root.getFileHandle(OFFLINE_INPUT_NAME, { create: true });
  const w = await fh.createWritable({ keepExistingData: false });
  try {
    const reader = file.stream().getReader();
    let loaded = 0;
    const total = file.size;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      await w.write(value);
      loaded += value.byteLength;
      onProgress?.(loaded, total);
    }
  } finally {
    await w.close();
  }
}

// src/lib/i18n.js
var en = {
  genTitle: "\u{1F4AC} Subtitle Generation",
  offline: "Offline",
  realtime: "Realtime",
  currentPage: "Current page",
  dropHint: "Click or drag audio/video files here",
  dropFormats: "Supports mp3, wav, m4a, mp4, webm, ogg",
  taskMode: "Task Mode",
  transcribe: "Transcribe",
  plusTranslate: "+ Translate",
  sourceLang: "Source Language",
  targetLang: "Translate To",
  startTask: "Start Task",
  endTask: "End Task",
  cancelTask: "Cancel Task",
  history: "\u{1F558} History",
  clear: "\u{1F5D1} Clear",
  noHistory: "No history yet",
  settings: "Settings",
  uiLang: "UI language",
  dlSource: "Download source",
  device: "Inference device",
  dualLine: "Show original + translation (dual line)",
  dualShort: "Dual line",
  refineLine: "Live refine translation (draft while speaking, correct at end)",
  refineShort: "Refine",
  refineNote: "Refine shows draft subtitles while you speak and corrects the final translation when the sentence ends (like smart-glasses live captioning).",
  liveOriginal: "Original",
  liveTranslation: "Translation",
  fontSize: "Subtitle font size",
  modelFiles: "Model Files",
  mtModels: "Translation models (per language pair)",
  modelHint: "Models download once and are cached locally \u2014 everything runs offline afterwards. If downloads stall, switch the download source and retry.",
  download: "Download",
  delete: "Delete",
  downloaded: "Downloaded",
  notDownloaded: "Not downloaded",
  needAsrModel: (name) => `Speech recognition needs the ${name} model \u2014 download it below or it will download automatically on start.`,
  needMtModel: (name) => `Translating ${name} needs its translation model.`,
  directNote: "Translating to English uses the speech model directly \u2014 no extra download needed.",
  needInvoke: 'Chrome blocked automatic tab capture \u2014 opening the manual picker. Or right-click the page \u2192 "Start Local TransSub on this page".',
  downloading: "Downloading",
  lines: "lines",
  cacheResume: (time, n) => `Resuming from ${time} \u2014 ${n} cached lines (no re-translation)`,
  exportFolder: "Save exports to folder",
  exportFolderNone: "Downloads (default)",
  exportFolderSet: "Folder",
  exportFolderPick: "Choose\u2026",
  exportFolderClear: "Clear",
  savedTo: (p) => `Saved to ${p}`,
  engine: "Engine",
  engineBrowser: "Browser (in-extension)",
  engineNative: "Native helper (fastest \xB7 most accurate)",
  nativeUrl: "Helper address",
  nativeOnline: (m) => `\u25CF Native helper online \u2014 ${m}`,
  nativeOffline: "\u25CB Native helper not running",
  nativeStale: "Helper running \u2014 click Restart to load latest features",
  nativeChecking: "Checking native helper\u2026",
  nativeStarting: "Starting native helper\u2026",
  nativeStopping: "Stopping native helper\u2026",
  nativeRestarting: "Restarting native helper\u2026",
  nativeStart: "Start",
  nativeStop: "Stop",
  nativeRestart: "Restart",
  nativeHostHint: "Helper offline. Click Start (needs launcher \u2014 run once: ./scripts/ensure-native.sh) or run: ./scripts/start-native.sh",
  nativeHostMissing: "Native launcher not installed. Run: ./scripts/ensure-native.sh  \u2014 or manually: cd native && ./run.sh",
  nativeNote: "Native engine: Whisper Large v3 Turbo on the Apple Silicon GPU (MLX). The helper downloads its own models on first run (~1.6 GB). Use Start/Stop above once the launcher is installed.",
  check: "Refresh",
  pickManually: "\u{1F5A5} Pick tab / window manually",
  pickHint: "In the picker choose the Chrome Tab playing the video and tick \u201CAlso share tab audio\u201D. (Window/screen with system audio isn't supported on macOS \u2014 pick a tab instead.)",
  pickHintLab: "Share a Chrome Tab (or window) and enable audio. On macOS, pick a tab \u2014 window/screen system audio is often unavailable.",
  noAudioShared: "No audio was shared. Re-open the picker and tick \u201CAlso share tab audio\u201D / \u201CShare system audio\u201D.",
  loadingModels: "Loading local AI models\u2026",
  listening: "Listening \u2014 subtitles appear on the video page",
  processing: "Processing\u2026",
  done: "Done",
  cancelled: "Cancelled",
  noTab: "Open a normal website tab to caption it.",
  pickFile: "Choose a file first.",
  stagingFile: "Copying file\u2026",
  fileReadError: "Could not read the file \u2014 try choosing it again. On macOS, grant Chrome Full Disk Access if the file is in Downloads.",
  fileTooLarge: "Files over 1.5 GB cannot be decoded in the browser. Start the native helper (Settings \u2192 Engine \u2192 Native) and install ffmpeg: brew install ffmpeg",
  stagingFilePct: (pct) => `Copying file\u2026 ${pct}%`,
  qaSamples: "CC0 test samples",
  qaSamplesHint: "Pick a language-pair sample (10\u201330s, CC0/Public Domain) and run Offline.",
  qaTest: "Test",
  qaRunSample: "Run sample",
  qaNoSample: "No CC0 sample for this pair (open lab at :8799).",
  qaLoadingSample: "Loading CC0 sample\u2026",
  notesTitle: "\u{1F4DD} Meeting notes"
};
var zh = {
  ...en,
  genTitle: "\u{1F4AC} \u5B57\u5E55\u751F\u6210",
  offline: "\u79BB\u7EBF",
  realtime: "\u5B9E\u65F6",
  currentPage: "\u5F53\u524D\u9875\u9762",
  dropHint: "\u70B9\u51FB\u6216\u62D6\u62FD\u97F3\u89C6\u9891\u6587\u4EF6\u5230\u8FD9\u91CC",
  dropFormats: "\u652F\u6301 mp3\u3001wav\u3001m4a\u3001mp4\u3001webm\u3001ogg",
  taskMode: "\u4EFB\u52A1\u6A21\u5F0F",
  transcribe: "\u8F6C\u5F55",
  plusTranslate: "+ \u7FFB\u8BD1",
  sourceLang: "\u6E90\u8BED\u8A00",
  targetLang: "\u7FFB\u8BD1\u4E3A",
  startTask: "\u5F00\u59CB\u4EFB\u52A1",
  endTask: "\u7ED3\u675F\u4EFB\u52A1",
  cancelTask: "\u53D6\u6D88\u4EFB\u52A1",
  history: "\u{1F558} \u5386\u53F2\u8BB0\u5F55",
  clear: "\u{1F5D1} \u6E05\u7A7A",
  noHistory: "\u6682\u65E0\u5386\u53F2\u8BB0\u5F55",
  settings: "\u8BBE\u7F6E",
  uiLang: "\u754C\u9762\u8BED\u8A00",
  dlSource: "\u4E0B\u8F7D\u6E90",
  device: "\u63A8\u7406\u8BBE\u5907",
  dualLine: "\u663E\u793A\u539F\u6587 + \u8BD1\u6587\uFF08\u53CC\u884C\uFF09",
  dualShort: "\u53CC\u884C",
  refineLine: "\u5B9E\u65F6\u6DA6\u8272\u7FFB\u8BD1\uFF08\u8BF4\u8BDD\u65F6\u663E\u793A\u8349\u7A3F\uFF0C\u53E5\u672B\u8BED\u4E49\u6821\u6B63\uFF09",
  refineShort: "\u6DA6\u8272",
  refineNote: "\u6DA6\u8272\u6A21\u5F0F\u5728\u8BF4\u8BDD\u8FC7\u7A0B\u4E2D\u663E\u793A\u8349\u7A3F\u5B57\u5E55\uFF0C\u53E5\u5B50\u7ED3\u675F\u540E\u6839\u636E\u5B8C\u6574\u8BED\u4E49\u6821\u6B63\u6700\u7EC8\u8BD1\u6587\uFF08\u7C7B\u4F3C\u667A\u80FD\u773C\u955C\u5B9E\u65F6\u5B57\u5E55\uFF09\u3002",
  liveOriginal: "\u539F\u6587",
  liveTranslation: "\u8BD1\u6587",
  fontSize: "\u5B57\u5E55\u5B57\u53F7",
  modelFiles: "\u6A21\u578B\u6587\u4EF6",
  mtModels: "\u7FFB\u8BD1\u6A21\u578B\uFF08\u6309\u8BED\u8A00\u5BF9\uFF09",
  modelHint: "\u6A21\u578B\u53EA\u9700\u4E0B\u8F7D\u4E00\u6B21\u5E76\u7F13\u5B58\u5728\u672C\u5730\uFF0C\u6B64\u540E\u5B8C\u5168\u79BB\u7EBF\u8FD0\u884C\u3002\u5982\u4E0B\u8F7D\u7F13\u6162\u8BF7\u5207\u6362\u4E0B\u8F7D\u6E90\u540E\u91CD\u8BD5\u3002",
  download: "\u4E0B\u8F7D",
  delete: "\u5220\u9664",
  downloaded: "\u5DF2\u4E0B\u8F7D",
  notDownloaded: "\u672A\u4E0B\u8F7D",
  needAsrModel: (name) => `\u8BED\u97F3\u8BC6\u522B\u9700\u8981 ${name} \u6A21\u578B \u2014 \u53EF\u5728\u4E0B\u65B9\u4E0B\u8F7D\uFF0C\u6216\u5F00\u59CB\u4EFB\u52A1\u65F6\u81EA\u52A8\u4E0B\u8F7D\u3002`,
  needMtModel: (name) => `\u7FFB\u8BD1 ${name} \u9700\u8981\u5148\u4E0B\u8F7D\u5BF9\u5E94\u7684\u7FFB\u8BD1\u6A21\u578B\u3002`,
  directNote: "\u7FFB\u8BD1\u4E3A\u82F1\u8BED\u65F6\u76F4\u63A5\u4F7F\u7528\u8BED\u97F3\u6A21\u578B\uFF0C\u65E0\u9700\u989D\u5916\u4E0B\u8F7D\u3002",
  check: "\u5237\u65B0",
  lines: "\u884C",
  cacheResume: (time, n) => `\u4ECE ${time} \u7EE7\u7EED \u2014 \u5DF2\u6709 ${n} \u884C\u7F13\u5B58\uFF08\u4E0D\u91CD\u590D\u7FFB\u8BD1\uFF09`,
  exportFolder: "\u5BFC\u51FA\u4FDD\u5B58\u6587\u4EF6\u5939",
  exportFolderNone: "\u9ED8\u8BA4\u4E0B\u8F7D\u4F4D\u7F6E",
  exportFolderSet: "\u6587\u4EF6\u5939",
  exportFolderPick: "\u9009\u62E9\u2026",
  exportFolderClear: "\u6E05\u9664",
  savedTo: (p) => `\u5DF2\u4FDD\u5B58\u5230 ${p}`,
  needInvoke: "Chrome \u963B\u6B62\u4E86\u81EA\u52A8\u6355\u83B7 \u2014 \u6B63\u5728\u6253\u5F00\u624B\u52A8\u9009\u62E9\u5668\u3002\u6216\u5728\u9875\u9762\u53F3\u952E \u2192 \u201C\u5728\u6B64\u9875\u9762\u542F\u52A8 Local TransSub\u201D\u3002",
  downloading: "\u4E0B\u8F7D\u4E2D",
  engine: "\u5F15\u64CE",
  engineBrowser: "\u6D4F\u89C8\u5668\uFF08\u6269\u5C55\u5185\u7F6E\uFF09",
  engineNative: "\u672C\u5730\u539F\u751F\u52A9\u624B\uFF08\u6700\u5FEB \xB7 \u6700\u51C6\u786E\uFF09",
  nativeUrl: "\u52A9\u624B\u5730\u5740",
  nativeOnline: (m) => `\u25CF \u539F\u751F\u52A9\u624B\u5728\u7EBF \u2014 ${m}`,
  nativeOffline: "\u25CB \u539F\u751F\u52A9\u624B\u672A\u8FD0\u884C",
  nativeStale: "\u52A9\u624B\u5728\u8FD0\u884C \u2014 \u8BF7\u70B9\u51FB Restart \u52A0\u8F7D\u6700\u65B0\u529F\u80FD",
  nativeChecking: "\u6B63\u5728\u68C0\u6D4B\u539F\u751F\u52A9\u624B\u2026",
  nativeStarting: "\u6B63\u5728\u542F\u52A8\u539F\u751F\u52A9\u624B\u2026",
  nativeStopping: "\u6B63\u5728\u505C\u6B62\u539F\u751F\u52A9\u624B\u2026",
  nativeRestarting: "\u6B63\u5728\u91CD\u542F\u539F\u751F\u52A9\u624B\u2026",
  nativeStart: "\u542F\u52A8",
  nativeStop: "\u505C\u6B62",
  nativeRestart: "\u91CD\u542F",
  nativeHostHint: "\u52A9\u624B\u672A\u8FD0\u884C\u3002\u70B9\u51FB Start\uFF08\u9700\u5148\u8FD0\u884C\u4E00\u6B21 ./scripts/ensure-native.sh\uFF09\u6216\u8FD0\u884C\uFF1A./scripts/start-native.sh",
  nativeHostMissing: "\u672A\u5B89\u88C5\u539F\u751F\u542F\u52A8\u5668\u3002\u8BF7\u8FD0\u884C\uFF1A./scripts/ensure-native.sh  \u2014 \u6216\u624B\u52A8\uFF1Acd native && ./run.sh",
  nativeNote: "\u539F\u751F\u5F15\u64CE\uFF1A\u5728 Apple Silicon GPU\uFF08MLX\uFF09\u4E0A\u8FD0\u884C Whisper Large v3 Turbo\u3002\u52A9\u624B\u9996\u6B21\u8FD0\u884C\u65F6\u81EA\u884C\u4E0B\u8F7D\u6A21\u578B\uFF08\u7EA6 1.6 GB\uFF09\u3002\u5B89\u88C5\u542F\u52A8\u5668\u540E\u53EF\u4F7F\u7528\u4E0A\u65B9\u542F\u52A8/\u505C\u6B62\u6309\u94AE\u3002",
  pickManually: "\u{1F5A5} \u624B\u52A8\u9009\u62E9\u6807\u7B7E\u9875 / \u7A97\u53E3",
  pickHint: "\u5728\u9009\u62E9\u5668\u4E2D\u9009\u62E9\u6B63\u5728\u64AD\u653E\u89C6\u9891\u7684 Chrome \u6807\u7B7E\u9875\uFF0C\u5E76\u52FE\u9009\u201C\u540C\u65F6\u5171\u4EAB\u6807\u7B7E\u9875\u97F3\u9891\u201D\u3002\uFF08macOS \u4E0D\u652F\u6301\u7A97\u53E3/\u5C4F\u5E55\u7684\u7CFB\u7EDF\u97F3\u9891\uFF0C\u8BF7\u9009\u62E9\u6807\u7B7E\u9875\u3002\uFF09",
  noAudioShared: "\u672A\u5171\u4EAB\u97F3\u9891\u3002\u8BF7\u91CD\u65B0\u6253\u5F00\u9009\u62E9\u5668\u5E76\u52FE\u9009\u201C\u540C\u65F6\u5171\u4EAB\u6807\u7B7E\u9875\u97F3\u9891\u201D\u3002",
  loadingModels: "\u6B63\u5728\u52A0\u8F7D\u672C\u5730 AI \u6A21\u578B\u2026",
  listening: "\u76D1\u542C\u4E2D \u2014 \u5B57\u5E55\u5C06\u663E\u793A\u5728\u89C6\u9891\u9875\u9762\u4E0A",
  processing: "\u5904\u7406\u4E2D\u2026",
  done: "\u5B8C\u6210",
  cancelled: "\u5DF2\u53D6\u6D88",
  noTab: "\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u666E\u901A\u7F51\u9875\u6807\u7B7E\u9875\u3002",
  pickFile: "\u8BF7\u5148\u9009\u62E9\u6587\u4EF6\u3002",
  stagingFile: "\u6B63\u5728\u590D\u5236\u6587\u4EF6\u2026",
  fileReadError: "\u65E0\u6CD5\u8BFB\u53D6\u6587\u4EF6 \u2014 \u8BF7\u91CD\u65B0\u9009\u62E9\u3002\u82E5\u5728 macOS \u7684\u201C\u4E0B\u8F7D\u201D\u6587\u4EF6\u5939\u4E2D\uFF0C\u8BF7\u4E3A Chrome \u6388\u4E88\u201C\u5B8C\u5168\u78C1\u76D8\u8BBF\u95EE\u6743\u9650\u201D\u3002",
  fileTooLarge: "\u8D85\u8FC7 1.5 GB \u7684\u6587\u4EF6\u65E0\u6CD5\u5728\u6D4F\u89C8\u5668\u5185\u89E3\u7801\u3002\u8BF7\u542F\u52A8\u539F\u751F\u52A9\u624B\uFF08\u8BBE\u7F6E \u2192 \u5F15\u64CE \u2192 \u539F\u751F\uFF09\u5E76\u5B89\u88C5 ffmpeg\uFF1Abrew install ffmpeg",
  stagingFilePct: (pct) => `\u6B63\u5728\u590D\u5236\u6587\u4EF6\u2026 ${pct}%`,
  qaSamples: "CC0 \u6D4B\u8BD5\u6837\u4F8B",
  qaSamplesHint: "\u9009\u62E9\u8BED\u8A00\u5BF9\u6837\u4F8B\uFF0810\u201330 \u79D2\uFF0CCC0/\u516C\u6709\u9886\u57DF\uFF09\u5E76\u5728\u79BB\u7EBF\u6A21\u5F0F\u8FD0\u884C\u3002",
  qaTest: "\u6D4B\u8BD5",
  qaRunSample: "\u8FD0\u884C\u6837\u4F8B",
  qaNoSample: "\u6B64\u8BED\u8A00\u5BF9\u6682\u65E0 CC0 \u6837\u4F8B\uFF08\u8BF7\u6253\u5F00 :8799 \u5B9E\u9A8C\u5BA4\uFF09\u3002",
  qaLoadingSample: "\u6B63\u5728\u52A0\u8F7D CC0 \u6837\u4F8B\u2026",
  notesTitle: "\u{1F4DD} \u4F1A\u8BAE\u7B14\u8BB0"
};
var I18N = {
  en,
  zh,
  ja: { ...en, uiLang: "UI\u8A00\u8A9E", offline: "\u30AA\u30D5\u30E9\u30A4\u30F3", realtime: "\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0", startTask: "\u958B\u59CB", endTask: "\u7D42\u4E86", settings: "\u8A2D\u5B9A", qaTest: "\u30C6\u30B9\u30C8", qaRunSample: "\u30B5\u30F3\u30D7\u30EB\u5B9F\u884C", qaSamples: "CC0\u30C6\u30B9\u30C8\u97F3\u58F0" },
  ko: { ...en, uiLang: "UI \uC5B8\uC5B4", offline: "\uC624\uD504\uB77C\uC778", realtime: "\uC2E4\uC2DC\uAC04", startTask: "\uC2DC\uC791", endTask: "\uC885\uB8CC", settings: "\uC124\uC815", qaTest: "\uD14C\uC2A4\uD2B8", qaRunSample: "\uC0D8\uD50C \uC2E4\uD589", qaSamples: "CC0 \uD14C\uC2A4\uD2B8 \uC0D8\uD50C" },
  de: { ...en, uiLang: "UI-Sprache", offline: "Offline", realtime: "Echtzeit", startTask: "Starten", endTask: "Beenden", settings: "Einstellungen", qaTest: "Test", qaRunSample: "Sample starten", qaSamples: "CC0-Testsamples" },
  fr: { ...en, uiLang: "Langue UI", offline: "Hors ligne", realtime: "Temps r\xE9el", startTask: "D\xE9marrer", endTask: "Arr\xEAter", settings: "Param\xE8tres", qaTest: "Tester", qaRunSample: "Lancer l\u2019\xE9chantillon", qaSamples: "\xC9chantillons CC0" },
  es: { ...en, uiLang: "Idioma UI", offline: "Sin conexi\xF3n", realtime: "Tiempo real", startTask: "Iniciar", endTask: "Finalizar", settings: "Ajustes", qaTest: "Probar", qaRunSample: "Ejecutar muestra", qaSamples: "Muestras CC0" },
  ru: { ...en, uiLang: "\u042F\u0437\u044B\u043A UI", offline: "\u041E\u0444\u043B\u0430\u0439\u043D", realtime: "\u041E\u043D\u043B\u0430\u0439\u043D", startTask: "\u0421\u0442\u0430\u0440\u0442", endTask: "\u0421\u0442\u043E\u043F", settings: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438", qaTest: "\u0422\u0435\u0441\u0442", qaRunSample: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043E\u0431\u0440\u0430\u0437\u0435\u0446", qaSamples: "CC0 \u043E\u0431\u0440\u0430\u0437\u0446\u044B" },
  it: { ...en, uiLang: "Lingua UI", offline: "Offline", realtime: "Tempo reale", startTask: "Avvia", endTask: "Termina", settings: "Impostazioni", qaTest: "Test", qaRunSample: "Esegui campione", qaSamples: "Campioni CC0" },
  nl: { ...en, uiLang: "UI-taal", offline: "Offline", realtime: "Realtime", startTask: "Start", endTask: "Stop", settings: "Instellingen", qaTest: "Test", qaRunSample: "Sample starten", qaSamples: "CC0-testsamples" },
  pl: { ...en, uiLang: "J\u0119zyk UI", offline: "Offline", realtime: "Na \u017Cywo", startTask: "Start", endTask: "Koniec", settings: "Ustawienia", qaTest: "Test", qaRunSample: "Uruchom pr\xF3bk\u0119", qaSamples: "Pr\xF3bki CC0" },
  ar: { ...en, uiLang: "\u0644\u063A\u0629 \u0627\u0644\u0648\u0627\u062C\u0647\u0629", offline: "\u062F\u0648\u0646 \u0627\u062A\u0635\u0627\u0644", realtime: "\u0645\u0628\u0627\u0634\u0631", startTask: "\u0628\u062F\u0621", endTask: "\u0625\u0646\u0647\u0627\u0621", settings: "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A", qaTest: "\u0627\u062E\u062A\u0628\u0627\u0631", qaRunSample: "\u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0639\u064A\u0646\u0629", qaSamples: "\u0639\u064A\u0646\u0627\u062A CC0" },
  vi: { ...en, uiLang: "Ng\xF4n ng\u1EEF UI", offline: "Ngo\u1EA1i tuy\u1EBFn", realtime: "Th\u1EDDi gian th\u1EF1c", startTask: "B\u1EAFt \u0111\u1EA7u", endTask: "K\u1EBFt th\xFAc", settings: "C\xE0i \u0111\u1EB7t", qaTest: "Th\u1EED", qaRunSample: "Ch\u1EA1y m\u1EABu", qaSamples: "M\u1EABu CC0" },
  id: { ...en, uiLang: "Bahasa UI", offline: "Luring", realtime: "Waktu nyata", startTask: "Mulai", endTask: "Selesai", settings: "Pengaturan", qaTest: "Uji", qaRunSample: "Jalankan sampel", qaSamples: "Sampel CC0" },
  uk: { ...en, uiLang: "\u041C\u043E\u0432\u0430 UI", offline: "\u041E\u0444\u043B\u0430\u0439\u043D", realtime: "\u041E\u043D\u043B\u0430\u0439\u043D", startTask: "\u0421\u0442\u0430\u0440\u0442", endTask: "\u0421\u0442\u043E\u043F", settings: "\u041D\u0430\u043B\u0430\u0448\u0442\u0443\u0432\u0430\u043D\u043D\u044F", qaTest: "\u0422\u0435\u0441\u0442", qaRunSample: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u0438 \u0437\u0440\u0430\u0437\u043E\u043A", qaSamples: "CC0 \u0437\u0440\u0430\u0437\u043A\u0438" }
};

// src/lib/notes-stub.js
var STUB_TRANSCRIPT = [
  {
    t0: 0,
    t1: 12,
    speaker: "Alya",
    text: "Mari kita mulai. Agenda hari ini: status rilis Local TransSub dan pembagian tindak lanjut."
  },
  {
    t0: 12,
    t1: 28,
    speaker: "Bima",
    text: "Smoke 26 sub-fitur sudah hijau. Yang masih menahan gerbang: E2E --pick, --native, dan berkas offline."
  },
  {
    t0: 28,
    t1: 45,
    speaker: "Citra",
    text: "Saya usul kita anggap draft native 500 ms sebagai target yang harus digeser ke Fase 2.1 jika belum tercapai minggu ini."
  },
  {
    t0: 45,
    t1: 62,
    speaker: "Alya",
    text: "Keputusan: rilis internal boleh jalan setelah E2E pick dan file lulus; draft latency tetap dilacak tapi tidak memblokir soft-launch."
  },
  {
    t0: 62,
    t1: 80,
    speaker: "Bima",
    text: "Action: Citra kerjakan e2e --pick besok; Bima siapkan --native; Alya update catatan rilis Jumat."
  }
];
var STUB_NOTE = {
  id: "note-demo-001",
  title: "Standup rilis Fase 1 \u2014 contoh",
  source: "transkrip contoh (lokal)",
  status: "ready",
  generatedAt: "2026-09-03T04:00:00Z",
  summary: "Tim meninjau gerbang rilis Fase 1. Smoke katalog 26 sub-fitur sudah lulus; fokus sisa adalah E2E pemilih tab, helper native, dan berkas offline. Soft-launch internal boleh setelah dua E2E itu hijau; target draft 500 ms dilacak terpisah.",
  decisions: [
    "Soft-launch internal setelah E2E --pick dan e2e-file --browser lulus.",
    "Target draft native \u2264500 ms tidak memblokir soft-launch; masuk backlog Fase 2.1."
  ],
  actions: [
    {
      id: "act-1",
      text: "Jalankan dan arsipkan hasil e2e.mjs --pick",
      owner: "Citra",
      due: "2026-09-04",
      status: "open"
    },
    {
      id: "act-2",
      text: "Verifikasi e2e.mjs --native dengan helper hidup",
      owner: "Bima",
      due: "2026-09-04",
      status: "open"
    },
    {
      id: "act-3",
      text: "Perbarui catatan rilis + gerbang mustFix",
      owner: "Alya",
      due: "2026-09-05",
      status: "open"
    }
  ],
  transcriptPreview: STUB_TRANSCRIPT.map((l) => `${l.speaker}: ${l.text}`).join("\n"),
  savedLocally: true
};
var STUB_SAVED_NOTES = [
  STUB_NOTE,
  {
    id: "note-demo-000",
    title: "Retro lab benchmark",
    source: "riwayat sesi \xB7 2026-08-22",
    status: "saved",
    generatedAt: "2026-08-22T22:10:00Z",
    summary: "Bottleneck utama di jalur fast MT; draft ASR relatif cepat di MLX.",
    decisions: ["Pertahankan mlx-whisper Large v3 Turbo sebagai default native."],
    actions: [
      {
        id: "act-r1",
        text: "Profilkan translate_refine vs fast MT",
        owner: "Bima",
        due: null,
        status: "done"
      }
    ],
    transcriptPreview: "(arsip singkat)",
    savedLocally: true
  }
];
var STUB_NOTES_STATE = {
  source: "stub",
  localStatus: (
    /** @type {NotesLocalStatus} */
    "ready"
  ),
  activeNoteId: STUB_NOTE.id,
  note: STUB_NOTE,
  saved: STUB_SAVED_NOTES,
  emptyDecisionsMessage: "Belum ada poin keputusan pada notulen ini.",
  emptyActionsMessage: "Belum ada tindak lanjut. Tambahkan setelah notulen dibuat."
};
async function loadNotesState() {
  return {
    ...STUB_NOTES_STATE,
    note: { ...STUB_NOTE },
    saved: STUB_SAVED_NOTES.map((n) => ({ ...n, actions: n.actions.map((a) => ({ ...a })) }))
  };
}
function statusLabel(status) {
  switch (status) {
    case "idle":
      return "Siaga";
    case "generating":
      return "Menyusun\u2026";
    case "ready":
      return "Siap (lokal)";
    case "saved":
      return "Tersimpan lokal";
    case "error":
      return "Gagal";
    default:
      return status;
  }
}

// src/lib/notes-schema.js
var NOTE_SCHEMA_VERSION = 1;
function createActionItem(partial = {}) {
  return {
    id: partial.id || `act-${cryptoRandom()}`,
    text: String(partial.text || "").trim(),
    owner: partial.owner == null ? null : String(partial.owner),
    due: partial.due == null ? null : String(partial.due),
    status: partial.status === "done" ? "done" : "open"
  };
}
function createMeetingNote(partial = {}) {
  return {
    id: partial.id || `note-${cryptoRandom()}`,
    title: String(partial.title || "Untitled meeting").trim(),
    source: String(partial.source || "local").trim(),
    status: partial.status || "ready",
    generatedAt: partial.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
    summary: String(partial.summary || ""),
    decisions: Array.isArray(partial.decisions) ? partial.decisions.map(String) : [],
    actions: Array.isArray(partial.actions) ? partial.actions.map((a) => createActionItem(a)) : [],
    transcriptPreview: partial.transcriptPreview ? String(partial.transcriptPreview) : "",
    savedLocally: !!partial.savedLocally,
    locale: partial.locale || "id"
  };
}
function cryptoRandom() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID().slice(0, 8);
  return Math.random().toString(36).slice(2, 10);
}
function assertMeetingNote(note) {
  if (!note || typeof note !== "object") throw new Error("note harus objek");
  const n = (
    /** @type {Record<string, unknown>} */
    note
  );
  if (typeof n.id !== "string" || !n.id) throw new Error("note.id wajib string");
  if (typeof n.title !== "string") throw new Error("note.title wajib string");
  if (!Array.isArray(n.decisions)) throw new Error("note.decisions wajib array");
  if (!Array.isArray(n.actions)) throw new Error("note.actions wajib array");
  for (const a of n.actions) {
    if (!a || typeof a !== "object") throw new Error("action invalid");
    if (typeof /** @type {any} */
    a.text !== "string") throw new Error("action.text wajib");
  }
  return createMeetingNote(n);
}
function wrapNotesStore(notes) {
  return {
    schemaVersion: NOTE_SCHEMA_VERSION,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    notes: notes.map((n) => assertMeetingNote(n))
  };
}

// src/lib/notes-export.js
function noteToMarkdown(raw) {
  const note = assertMeetingNote(raw);
  const lines = [
    `# ${note.title}`,
    "",
    `_Sumber: ${note.source}_ \xB7 _${note.generatedAt}_`,
    "",
    "## Ringkasan",
    note.summary || "_(kosong)_",
    "",
    "## Poin Keputusan",
    ...note.decisions.length ? note.decisions.map((d) => `- ${d}`) : ["_(kosong)_"],
    "",
    "## Tindak Lanjut",
    ...note.actions.length ? note.actions.map((a) => {
      const box = a.status === "done" ? "[x]" : "[ ]";
      const due = a.due ? ` (due ${a.due})` : "";
      return `- ${box} **${a.owner || "?"}** \u2014 ${a.text}${due}`;
    }) : ["_(kosong)_"],
    ""
  ];
  return lines.join("\n");
}
function noteToTxt(raw) {
  const note = assertMeetingNote(raw);
  return [
    note.title,
    `Sumber: ${note.source}`,
    `Dibuat: ${note.generatedAt}`,
    "",
    "RINGKASAN",
    note.summary || "(kosong)",
    "",
    "POIN KEPUTUSAN",
    ...note.decisions.length ? note.decisions.map((d) => `- ${d}`) : ["(kosong)"],
    "",
    "TINDAK LANJUT",
    ...note.actions.length ? note.actions.map(
      (a) => `- [${a.status}] ${a.owner || "?"} | ${a.text}${a.due ? ` | due ${a.due}` : ""}`
    ) : ["(kosong)"],
    ""
  ].join("\n");
}
function serializeNote(note, format) {
  if (format === "md" || format === "markdown") return noteToMarkdown(note);
  return noteToTxt(note);
}

// src/lib/notes-generate.js
function generateNotesFromTranscript(lines, meta = {}) {
  const texts = (lines || []).map((l) => String(l.text || l.src || l.tgt || "").trim()).filter(Boolean);
  const blob = texts.join(" ");
  const summary = texts.length === 0 ? "Transkrip kosong \u2014 tidak ada ringkasan." : texts.length <= 2 ? texts.join(" ") : `${texts[0]} \u2026 ${texts[texts.length - 1]} (${texts.length} segmen).`;
  const decisions = [];
  const decisionRe = /\b(keputusan|diputuskan|we (decided|agree)|decision)\b[:\s-]*(.+)/gi;
  let m;
  while ((m = decisionRe.exec(blob)) && decisions.length < 8) {
    const bit = (m[2] || "").trim().slice(0, 200);
    if (bit) decisions.push(bit);
  }
  const actions = [];
  const actionRe = /\b(action|tindak lanjut|todo|assign(?:ed)?(?: to)?)\b[:\s-]*([^.!?\n]{8,160})/gi;
  while ((m = actionRe.exec(blob)) && actions.length < 12) {
    const bit = (m[2] || "").trim();
    if (bit) actions.push(createActionItem({ text: bit, owner: null, due: null }));
  }
  if (!actions.length) {
    for (const l of lines || []) {
      if (/\b(will|akan|kerjakan|siapkan)\b/i.test(l.text || "") && actions.length < 5) {
        actions.push(
          createActionItem({
            text: String(l.text).slice(0, 160),
            owner: l.speaker || null,
            due: null
          })
        );
      }
    }
  }
  return createMeetingNote({
    title: meta.title || "Notulen sesi",
    source: meta.source || "transcript",
    status: "ready",
    summary,
    decisions,
    actions,
    transcriptPreview: texts.slice(0, 6).join("\n"),
    savedLocally: false,
    locale: meta.locale || "id"
  });
}

// src/lib/notes-store.js
var KEY = "meetingNotes";
async function readRaw() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) {
    return { schemaVersion: 1, updatedAt: null, notes: [] };
  }
  const { [KEY]: data } = await chrome.storage.local.get(KEY);
  if (!data || !Array.isArray(data.notes)) {
    return { schemaVersion: 1, updatedAt: null, notes: [] };
  }
  return data;
}
async function writeRaw(store) {
  if (typeof chrome === "undefined" || !chrome.storage?.local) return store;
  await chrome.storage.local.set({ [KEY]: store });
  return store;
}
async function listNotes() {
  const store = await readRaw();
  return store.notes.map((n) => assertMeetingNote(n));
}
async function saveNote(partial) {
  const note = createMeetingNote({ ...partial, savedLocally: true, status: partial.status || "saved" });
  assertMeetingNote(note);
  const prev = await listNotes();
  const next = [note, ...prev.filter((n) => n.id !== note.id)].slice(0, 50);
  await writeRaw(wrapNotesStore(next));
  return note;
}

// src/notes-panel.js
function escapeHtml(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function decisionsHtml(note, state2) {
  const decisions = note.decisions || [];
  if (!decisions.length) {
    return `<p class="notes-empty" id="notes-decisions-empty">${escapeHtml(state2.emptyDecisionsMessage)}</p>`;
  }
  return `<ul id="notes-decisions-list">${decisions.map((d) => `<li>${escapeHtml(d)}</li>`).join("")}</ul>`;
}
function actionsHtml(note, state2) {
  const actions = note.actions || [];
  if (!actions.length) {
    return `<p class="notes-empty" id="notes-actions-empty">${escapeHtml(state2.emptyActionsMessage)}</p>`;
  }
  return `<ul class="notes-actions-list" id="notes-actions-list">${actions.map(
    (a) => `
        <li data-act-id="${escapeHtml(a.id)}">
          <div class="act-text">${escapeHtml(a.text)}</div>
          <span class="act-meta">${escapeHtml(a.owner || "\u2014")}</span>
          <span class="act-meta">${escapeHtml(a.due || "tanpa tenggat")} \xB7 ${a.status}</span>
        </li>`
  ).join("")}</ul>`;
}
function renderNotesPanel(root, state2, handlers = {}) {
  const note = state2.note;
  const local = state2.localStatus || note.status;
  root.innerHTML = `
    <div class="notes-panel" data-notes-root>
      <div class="notes-status-row">
        <span class="notes-pill ${escapeHtml(local)}" id="notes-local-status" data-status="${escapeHtml(local)}">
          <span aria-hidden="true">\u25CF</span>
          ${escapeHtml(statusLabel(local))}
        </span>
        <span class="notes-meta" id="notes-source-line">
          ${note.savedLocally ? "\u{1F4E6} Tersimpan di perangkat" : "Draft lokal"} \xB7 ${escapeHtml(note.source)}
        </span>
      </div>

      <div class="notes-block">
        <h3 id="notes-title">${escapeHtml(note.title)}</h3>
        <p class="notes-meta">Dibuat ${escapeHtml(note.generatedAt || "\u2014")}</p>
      </div>

      <div class="notes-toolbar">
        <button type="button" class="btn primary" id="btn-notes-generate">
          Buat Notulen dari contoh
        </button>
        <button type="button" class="btn ghost" id="btn-notes-clear-decisions" title="Demo pesan kosong">
          Kosongkan keputusan
        </button>
        <button type="button" class="btn" id="btn-notes-export">
          Ekspor\u2026
        </button>
      </div>

      <div class="notes-block" id="notes-summary-block">
        <h3>Ringkasan</h3>
        <p id="notes-summary">${escapeHtml(note.summary)}</p>
        <details class="notes-transcript" id="notes-transcript-details">
          <summary>Transkrip contoh</summary>
          <pre id="notes-transcript-preview">${escapeHtml(note.transcriptPreview || "")}</pre>
        </details>
      </div>

      <div class="notes-block" id="notes-decisions-block">
        <h3>Poin Keputusan</h3>
        <div id="notes-decisions">${decisionsHtml(note, state2)}</div>
      </div>

      <div class="notes-block" id="notes-actions-block">
        <h3>Tindak Lanjut</h3>
        <div id="notes-actions">${actionsHtml(note, state2)}</div>
      </div>

      <div class="notes-block" id="notes-saved-block">
        <h3>Notulen tersimpan (lokal)</h3>
        <div class="notes-saved-list" id="notes-saved-list">
          ${(state2.saved || []).map(
    (n) => `
            <button type="button" class="notes-saved-item${n.id === note.id ? " active" : ""}" data-note-id="${escapeHtml(n.id)}">
              <div>
                <div class="ns-title">${escapeHtml(n.title)}</div>
                <div class="ns-meta">${escapeHtml(n.source)} \xB7 ${escapeHtml(statusLabel(n.status))}</div>
              </div>
              <span class="notes-pill ${escapeHtml(n.status)}">${n.savedLocally ? "lokal" : "draft"}</span>
            </button>`
  ).join("")}
        </div>
      </div>

      <dialog id="notes-export-dialog" class="notes-dialog">
        <form method="dialog" class="notes-dialog-body">
          <h3>Ekspor notulen</h3>
          <p class="notes-meta">Unduh sebagai teks polos atau Markdown (100% lokal).</p>
          <div class="notes-toolbar">
            <button type="submit" class="btn primary" value="txt" id="btn-export-txt">TXT</button>
            <button type="submit" class="btn primary" value="md" id="btn-export-md">Markdown</button>
            <button type="submit" class="btn ghost" value="cancel">Batal</button>
          </div>
        </form>
      </dialog>
    </div>
  `;
  root.querySelector("#btn-notes-generate")?.addEventListener("click", () => handlers.onGenerate?.());
  root.querySelector("#btn-notes-export")?.addEventListener("click", () => {
    handlers.onExport?.();
    root.querySelector("#notes-export-dialog")?.showModal();
  });
  root.querySelector("#btn-notes-clear-decisions")?.addEventListener("click", () => {
    handlers.onClearDecisions?.();
  });
  root.querySelectorAll("[data-note-id]").forEach((btn) => {
    btn.addEventListener("click", () => handlers.onSelectSaved?.(btn.getAttribute("data-note-id")));
  });
  root.querySelector("#notes-export-dialog")?.addEventListener("close", (ev) => {
    const val = (
      /** @type {HTMLDialogElement} */
      ev.target.returnValue
    );
    if (val === "txt" || val === "md") handlers.onExportFormat?.(val);
  });
}
function formatNoteExport(note, format) {
  return serializeNote(note, format === "md" ? "md" : "txt");
}
function downloadText(filename, text) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
async function mountNotesPanel(root) {
  let state2 = await loadNotesState();
  const redraw = () => {
    renderNotesPanel(root, state2, {
      onGenerate: () => {
        state2 = {
          ...state2,
          localStatus: "generating",
          note: {
            ...state2.note,
            status: "generating",
            summary: "Menyusun notulen dari transkrip contoh\u2026",
            decisions: [],
            actions: []
          }
        };
        redraw();
        setTimeout(async () => {
          const built = generateNotesFromTranscript(
            STUB_TRANSCRIPT.map((l) => ({ text: l.text, speaker: l.speaker, t0: l.t0, t1: l.t1 })),
            {
              title: "Standup rilis Fase 1 \u2014 contoh",
              source: "transkrip contoh (dibuat sekarang)"
            }
          );
          built.decisions = STUB_NOTE.decisions;
          built.actions = STUB_NOTE.actions;
          built.summary = STUB_NOTE.summary;
          built.status = "saved";
          built.savedLocally = true;
          try {
            await saveNote(built);
            const saved = await listNotes();
            state2 = {
              ...state2,
              localStatus: "saved",
              note: built,
              activeNoteId: built.id,
              saved: saved.length ? saved : [built, ...state2.saved]
            };
          } catch {
            state2 = {
              ...state2,
              localStatus: "saved",
              note: built,
              activeNoteId: built.id,
              saved: [built, ...state2.saved.filter((n) => n.id !== built.id)]
            };
          }
          redraw();
        }, 600);
      },
      onClearDecisions: () => {
        state2 = {
          ...state2,
          note: { ...state2.note, decisions: [] }
        };
        redraw();
      },
      onSelectSaved: (id) => {
        const found = state2.saved.find((n) => n.id === id);
        if (!found) return;
        state2 = {
          ...state2,
          note: { ...found },
          activeNoteId: id,
          localStatus: found.status === "saved" ? "saved" : found.status
        };
        redraw();
      },
      onExportFormat: (fmt) => {
        const safe = (state2.note.title || "notulen").replace(/[^\w\s.-]+/g, "_").slice(0, 60);
        const ext = fmt === "md" ? "md" : "txt";
        downloadText(`${safe}.${ext}`, formatNoteExport(state2.note, fmt));
      }
    });
  };
  redraw();
  return () => state2;
}

// src/lib/helper-status.js
function detectOs() {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent || "" : "";
  if (/Mac OS X|Macintosh/i.test(ua)) return "macos";
  if (/Windows/i.test(ua)) return "windows";
  if (/Linux/i.test(ua)) return "linux";
  return "unknown";
}
var OS_GUIDES = {
  macos: {
    label: "macOS",
    engine: "mlx-whisper (Apple Silicon) / faster-whisper",
    steps: [
      "Jalankan ./scripts/ensure-native.sh atau native/run.sh",
      "Pastikan Native Messaging Host com.localtranssub.helper terpasang",
      "Side Panel \u2192 Settings \u2192 Engine \u2192 Native helper"
    ]
  },
  windows: {
    label: "Windows",
    engine: "faster-whisper (CPU/CUDA)",
    steps: [
      "Install Python 3 + jalankan native\\run.sh (Git Bash) atau native\\run.bat bila ada",
      "Daftarkan Native Messaging Host untuk Chrome (manifest di native/)",
      "Buka http://127.0.0.1:17865/health \u2014 harus {ok:true}",
      "Di ekstensi pilih Engine \u2192 Native helper"
    ]
  },
  linux: {
    label: "Linux",
    engine: "faster-whisper (CPU/CUDA)",
    steps: [
      "python3 -m venv di native/ lalu ./native/run.sh",
      "Pasang host Native Messaging (JSON di ~/.config/google-chrome/NativeMessagingHosts/)",
      "Verifikasi curl -sf http://127.0.0.1:17865/health",
      "Side Panel \u2192 Native helper"
    ]
  },
  unknown: {
    label: "OS ini",
    engine: "faster-whisper atau mlx-whisper",
    steps: [
      "Ikuti README Native Helper",
      "Pastikan port 17865 menjawab /health"
    ]
  }
};
function exportBasename(title, kind) {
  const safe = String(title || "subtitles").replace(/[^\w\s.-]+/g, "_").replace(/\s+/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "").slice(0, 60) || "subtitles";
  const ext = kind === "vtt" ? "vtt" : kind === "txt" ? "txt" : "srt";
  return `${safe}.${ext}`;
}
var STUB_LARGE_FILE = {
  name: "conference-long.wav",
  sizeBytes: 2.4 * 1024 * 1024 * 1024,
  progress: 0.42,
  cancellable: true,
  status: "running"
  // idle | running | cancelled | done
};
function formatBytes(n) {
  if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(1)} GiB`;
  if (n >= 1024 ** 2) return `${(n / 1024 ** 2).toFixed(1)} MiB`;
  return `${Math.round(n / 1024)} KiB`;
}

// src/helper-status.js
function escapeHtml2(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function renderHelperStatusCard(root, opts) {
  const os = detectOs();
  const guide = OS_GUIDES[os] || OS_GUIDES.unknown;
  const online = !!opts.online;
  const health = opts.health || null;
  const engine = opts.engine || "browser";
  const task = opts.task || "transcribe";
  const mode = opts.mode || "realtime";
  const lf = opts.largeFile || STUB_LARGE_FILE;
  const pct = Math.round((lf.progress || 0) * 100);
  root.innerHTML = `
    <div class="helper-status" data-os="${escapeHtml2(os)}">
      <div class="notes-status-row">
        <span class="notes-pill ${online ? "ready" : "error"}" id="helper-conn-pill">
          ${online ? "Helper terhubung" : "Helper terputus"}
        </span>
        <span class="notes-meta">${escapeHtml2(guide.label)} \xB7 ${escapeHtml2(guide.engine)}</span>
      </div>

      <div class="helper-indicators" id="helper-mode-indicators">
        <span class="notes-pill idle">Mode: <strong>${escapeHtml2(mode)}</strong></span>
        <span class="notes-pill idle">Tugas: <strong>${escapeHtml2(task)}</strong></span>
        <span class="notes-pill idle">Mesin: <strong>${escapeHtml2(engine)}</strong></span>
        ${health ? `<span class="notes-pill ready">${escapeHtml2(health.engine || "asr")} \xB7 ${escapeHtml2((health.model || "").split("/").pop() || "")}</span>` : ""}
      </div>

      <div id="helper-disconnect-banner" class="helper-banner ${online || engine !== "native" ? "hidden" : ""}">
        <strong>Helper terputus</strong> \u2014 subtitel tab lewat mesin native tidak bisa berjalan.
        Beralih ke Browser di Settings, atau ikuti panduan ${escapeHtml2(guide.label)} di bawah.
      </div>

      <div class="notes-block">
        <h3>Panduan ${escapeHtml2(guide.label)}</h3>
        <ol class="helper-steps">
          ${guide.steps.map((s) => `<li>${escapeHtml2(s)}</li>`).join("")}
        </ol>
      </div>

      <div class="notes-block" id="helper-large-file">
        <h3>Berkas besar (contoh UI)</h3>
        <p class="notes-meta">${escapeHtml2(lf.name)} \xB7 ${formatBytes(lf.sizeBytes)}</p>
        <div class="helper-progress-track" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100">
          <div class="helper-progress-bar" style="width:${pct}%"></div>
        </div>
        <div class="notes-status-row" style="margin-top:8px">
          <span class="notes-meta" id="helper-lf-pct">${pct}% \xB7 ${escapeHtml2(lf.status)}</span>
          <button type="button" class="mini-btn" id="btn-helper-lf-cancel" ${lf.cancellable && lf.status === "running" ? "" : "disabled"}>
            Batalkan
          </button>
        </div>
      </div>

      <div class="notes-block">
        <h3>Ekspor transkrip tiruan</h3>
        <p class="notes-meta">Nama berkas seragam di Windows / Linux / macOS.</p>
        <div class="notes-toolbar">
          <button type="button" class="mini-btn" data-export-kind="srt">SRT</button>
          <button type="button" class="mini-btn" data-export-kind="vtt">VTT</button>
          <button type="button" class="mini-btn" data-export-kind="txt">TXT</button>
        </div>
        <p class="notes-meta" id="helper-export-name-hint"></p>
      </div>
    </div>
  `;
  const cues = STUB_TRANSCRIPT.map((l, i) => ({
    t0: l.t0,
    t1: l.t1,
    src: `${l.speaker}: ${l.text}`,
    tgt: `${l.speaker}: ${l.text}`
  }));
  const hint = root.querySelector("#helper-export-name-hint");
  const title = "meeting_notes_demo";
  if (hint) {
    hint.textContent = `Contoh: ${exportBasename(title, "srt")} \xB7 ${exportBasename(title, "vtt")} \xB7 ${exportBasename(title, "txt")}`;
  }
  root.querySelectorAll("[data-export-kind]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const kind = btn.getAttribute("data-export-kind");
      let body = "";
      if (kind === "srt") body = formatSrt(cues, { dualLine: false, title });
      else if (kind === "vtt") body = formatVtt(cues, { dualLine: false, title });
      else body = formatTxt(cues, { title });
      const name = exportBasename(title, kind);
      const url = URL.createObjectURL(new Blob([body], { type: "text/plain;charset=utf-8" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.click();
      URL.revokeObjectURL(url);
      if (hint) hint.textContent = `Diunduh: ${name}`;
    });
  });
  root.querySelector("#btn-helper-lf-cancel")?.addEventListener("click", () => {
    const pctEl = root.querySelector("#helper-lf-pct");
    if (pctEl) pctEl.textContent = `${pct}% \xB7 cancelled`;
    const bar = root.querySelector(".helper-progress-bar");
    if (bar) bar.style.opacity = "0.4";
    btnDisabled(root.querySelector("#btn-helper-lf-cancel"));
  });
}
function btnDisabled(el) {
  if (el) el.disabled = true;
}
function mountHelperStatusCard(root, getOpts) {
  const draw = () => renderHelperStatusCard(root, getOpts());
  draw();
  return draw;
}

// src/lib/qa-samples.js
var catalogCache = null;
var catalogTried = false;
function samplesBaseUrl() {
  try {
    const { protocol, hostname, port, pathname } = location;
    if (protocol === "http:" || protocol === "https:") {
      if (port === "8799" || hostname === "127.0.0.1" || hostname === "localhost") {
        return "/samples/";
      }
      if (pathname.includes("/test/") || pathname.endsWith("/app.html")) {
        return "/samples/";
      }
    }
  } catch {
  }
  return null;
}
async function loadSampleCatalog() {
  if (catalogTried) return catalogCache;
  catalogTried = true;
  const base2 = samplesBaseUrl();
  if (!base2) {
    catalogCache = null;
    return null;
  }
  try {
    const r = await fetch(`${base2}manifest.json`, { cache: "no-cache" });
    if (!r.ok) {
      catalogCache = null;
      return null;
    }
    const data = await r.json();
    catalogCache = {
      base: base2,
      samples: Array.isArray(data.samples) ? data.samples : []
    };
    return catalogCache;
  } catch {
    catalogCache = null;
    return null;
  }
}
function samplesForPair(catalog, pairKey) {
  if (!catalog?.samples?.length || !pairKey) return [];
  const [src, tgt] = pairKey.split("-");
  const exact = catalog.samples.filter((s) => s.src === src && s.tgt === tgt);
  if (exact.length) return exact;
  return catalog.samples.filter((s) => s.src === src);
}
function firstSampleForPair(catalog, pairKey) {
  return samplesForPair(catalog, pairKey)[0] || null;
}
async function fetchSampleFile(catalog, sample) {
  if (!catalog || !sample?.file) throw new Error("Sample unavailable");
  const url = `${catalog.base}${sample.file}`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Sample fetch failed (${r.status}): ${sample.file}`);
  const blob = await r.blob();
  const name = sample.file.split("/").pop() || `${sample.id}.mp3`;
  return new File([blob], name, { type: blob.type || "audio/mpeg" });
}

// src/sidepanel.js
var $ = (id) => document.getElementById(id);
var state = {
  mode: "realtime",
  // 'realtime' | 'offline'
  task: "translate",
  // 'transcribe' | 'translate'
  srcLang: "ja",
  tgtLang: "en",
  settings: {
    uiLang: "en",
    mirror: "huggingface",
    device: "auto",
    dualLine: false,
    refineTranslation: false,
    overlayFontSize: 24,
    asrModel: DEFAULT_ASR,
    engine: "browser",
    nativeUrl: DEFAULT_NATIVE_URL
  },
  downloaded: {},
  running: false,
  offlineRunning: false,
  offlineFile: null,
  // { name, size } once staged to OPFS
  offlineStaging: false,
  offlineLines: [],
  currentTab: null,
  qaCatalog: null
};
function t(key, ...args) {
  const v = I18N[state.settings.uiLang]?.[key] ?? I18N.en[key] ?? key;
  return typeof v === "function" ? v(...args) : v;
}
function toBG(type, data) {
  return chrome.runtime.sendMessage({ target: "bg", type, data }).catch(() => null);
}
function toOffscreen(type, data) {
  return toBG("to-offscreen", { type, data });
}
function applyI18n() {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
}
function fillSelects() {
  $("src-lang").innerHTML = SOURCE_LANGS.map(
    ([c, label]) => `<option value="${c}">${label}</option>`
  ).join("");
  $("tgt-lang").innerHTML = TARGET_LANGS.map(
    ([c, label]) => `<option value="${c}">${label}</option>`
  ).join("");
  $("src-lang").value = state.srcLang;
  $("tgt-lang").value = state.tgtLang;
}
function setMode(mode) {
  state.mode = mode;
  document.querySelectorAll("#mode-toggle button").forEach((b) => {
    b.classList.toggle("active", b.dataset.mode === mode);
  });
  $("rt-target").classList.toggle("hidden", mode !== "realtime");
  $("btn-pick").classList.toggle("hidden", mode !== "realtime");
  $("pick-hint").classList.add("hidden");
  $("off-drop").classList.toggle("hidden", mode !== "offline");
  $("off-results").classList.toggle("hidden", mode !== "offline" || state.offlineLines.length === 0);
  const qaBar = $("qa-sample-bar");
  if (qaBar) {
    qaBar.classList.toggle("hidden", mode !== "offline" || !state.qaCatalog?.samples?.length);
  }
  $("live-preview").classList.add("hidden");
  updateButtons();
  updateWarning();
  redrawHelperStatus?.();
}
function syncDualLineCheckboxes() {
  const on = !!state.settings.dualLine;
  $("dual-line-main").checked = on;
  $("dual-line").checked = on;
  updateLivePreviewLayout();
}
function syncRefineCheckboxes() {
  const on = !!state.settings.refineTranslation;
  $("refine-main").checked = on;
  $("refine").checked = on;
}
async function setRefineTranslation(on) {
  state.settings.refineTranslation = !!on;
  syncRefineCheckboxes();
  await saveSettings();
  persistLastConfig();
  updateWarning();
  await toBG("update-config", { refineTranslation: state.settings.refineTranslation });
}
function updateLivePreviewLayout() {
  const dual = !!state.settings.dualLine;
  $("live-src-box").classList.toggle("hidden", !dual);
  const srcLabel = $("live-src-box").querySelector(".live-box-label");
  const tgtLabel = $("live-tgt-box").querySelector(".live-box-label");
  if (srcLabel) srcLabel.classList.toggle("hidden", !dual);
  if (tgtLabel) tgtLabel.classList.toggle("hidden", !dual);
}
function clearLivePreview() {
  $("live-src-lines").innerHTML = "";
  $("live-tgt-lines").innerHTML = "";
  delete $("live-src-lines").dataset.interim;
  delete $("live-tgt-lines").dataset.interim;
}
async function setDualLine(on) {
  state.settings.dualLine = !!on;
  syncDualLineCheckboxes();
  await saveSettings();
  persistLastConfig();
  updateWarning();
  await toBG("update-config", { dualLine: state.settings.dualLine });
}
function setTask(task) {
  state.task = task;
  document.querySelectorAll("#task-toggle button").forEach((b) => {
    b.classList.toggle("active", b.dataset.task === task);
  });
  $("tgt-col").style.opacity = task === "translate" ? "1" : "0.4";
  $("tgt-lang").disabled = task !== "translate";
  updateWarning();
  redrawHelperStatus?.();
}
function updateWarning() {
  const el = $("model-warning");
  const cfg = currentConfig();
  const issues = [];
  const native = state.settings.engine === "native";
  if (native) {
    if (!nativeInfo) issues.push({ msg: t("nativeOffline") });
  } else if (!state.downloaded[state.settings.asrModel]) {
    const m = ASR_MODELS[state.settings.asrModel];
    issues.push({
      msg: t("needAsrModel", `${m.label} (${m.webgpuOnly || state.settings.device !== "wasm" ? m.sizeWebgpu : m.sizeWasm})`),
      key: state.settings.asrModel,
      btn: `${m.label}`
    });
  }
  let directNote = "";
  if (cfg.taskMode === "translate") {
    const plan = translationPlan(cfg.srcLang, cfg.tgtLang, {
      dualLine: cfg.dualLine,
      refineTranslation: cfg.refineTranslation
    });
    if (plan.mode === "whisper-direct") {
      directNote = `<span style="opacity:.85">${t("directNote")}</span>`;
    } else if (cfg.refineTranslation) {
      directNote = `<span style="opacity:.85">${t("refineNote")}</span>`;
    } else if (plan.mode === "mt") {
      const label = pairLabel(`${cfg.srcLang}-${cfg.tgtLang}`);
      if (plan.pivot) {
        if (!state.downloaded[plan.pivot.leg1Key]) {
          issues.push({
            msg: t("needMtModel", `${pairLabel(plan.pivot.leg1Key)} (${plan.pivot.leg1.size})`),
            key: plan.pivot.leg1Key,
            btn: pairLabel(plan.pivot.leg1Key)
          });
        }
        if (!state.downloaded[plan.pivot.leg2Key]) {
          issues.push({
            msg: t("needMtModel", `${pairLabel(plan.pivot.leg2Key)} (${plan.pivot.leg2.size})`),
            key: plan.pivot.leg2Key,
            btn: pairLabel(plan.pivot.leg2Key)
          });
        }
      } else if (!plan.pair) {
        issues.push({
          msg: `No local translation model exists for ${label}. The browser's built-in translator or native helper LLM will be tried; otherwise pick another pair.`
        });
      } else if (!state.downloaded[plan.pairKey]) {
        issues.push({
          msg: t("needMtModel", `${label} (${plan.pair.size})`),
          key: plan.pairKey,
          btn: label
        });
      }
    }
  }
  if (issues.length === 0 && !directNote) {
    el.classList.add("hidden");
    el.innerHTML = "";
    return;
  }
  const buttons = issues.filter((i) => i.key).map(
    (i) => `<button class="mini-btn dl-now" data-key="${i.key}">\u2B07 ${t("download")} \u2014 ${i.btn}</button>`
  ).join(" ");
  el.innerHTML = [issues.map((i) => i.msg).join("<br>"), buttons, directNote].filter(Boolean).join("<br>");
  el.classList.remove("hidden");
  el.querySelectorAll(".dl-now").forEach((b) => {
    b.addEventListener("click", () => startDownload(b.dataset.key));
  });
}
function persistLastConfig() {
  chrome.storage.local.set({
    lastConfig: {
      srcLang: state.srcLang,
      tgtLang: state.tgtLang,
      taskMode: state.task,
      dualLine: state.settings.dualLine,
      refineTranslation: state.settings.refineTranslation,
      asrModel: state.settings.asrModel
    }
  }).catch(() => {
  });
}
function currentConfig() {
  return {
    tabId: state.currentTab?.id,
    srcLang: state.srcLang,
    tgtLang: state.tgtLang,
    taskMode: state.task,
    dualLine: state.settings.dualLine,
    refineTranslation: state.settings.refineTranslation,
    asrModel: state.settings.asrModel
  };
}
var dlState = /* @__PURE__ */ new Map();
function labelForKey(key) {
  if (ASR_MODELS[key]) return ASR_MODELS[key].label;
  if (MT_PAIRS[key]) return pairLabel(key);
  return key;
}
function startDownload(key) {
  if (dlState.get(key) && !dlState.get(key).done) return;
  dlState.set(key, { pct: 0, loaded: 0, total: 0 });
  renderDlList();
  renderModelLists();
  toOffscreen("model-download", { key });
}
function renderDlList() {
  const host = $("dl-list");
  const entries = [...dlState.entries()];
  host.classList.toggle("hidden", entries.length === 0);
  const mb = (n) => (n / 1024 / 1024).toFixed(1);
  host.innerHTML = "";
  for (const [key, d] of entries) {
    const pct = Math.round(d.pct || 0);
    const row = document.createElement("div");
    row.className = "dl-row" + (d.done ? " done" : "");
    const detail = d.done ? "\u2713" : d.total ? `${mb(d.loaded)} / ${mb(d.total)} MB \xB7 ${pct}%` : `${pct}%`;
    row.innerHTML = `
      <div class="dl-label"><span></span><span class="pct">${detail}</span></div>
      <div class="bar"><div class="fill" style="width:${d.done ? 100 : pct}%"></div></div>`;
    row.querySelector(".dl-label span").textContent = `\u2B07 ${t("downloading")}: ${labelForKey(key)}`;
    host.appendChild(row);
  }
}
function onModelProgress(d) {
  if (!d || !d.key) return;
  const cur = dlState.get(d.key) || {};
  dlState.set(d.key, { ...cur, pct: d.pct ?? cur.pct, loaded: d.loaded ?? cur.loaded, total: d.total ?? cur.total });
  renderDlList();
  const st = document.querySelector(`.m-state[data-key="${d.key}"]`);
  if (st) st.textContent = `${Math.round(dlState.get(d.key).pct || 0)}%`;
}
async function onModelDone(d) {
  if (d.deleted) {
    dlState.delete(d.key);
  } else {
    dlState.set(d.key, { ...dlState.get(d.key) || {}, pct: 100, done: true });
    setTimeout(() => {
      dlState.delete(d.key);
      renderDlList();
    }, 2500);
  }
  renderDlList();
  await refreshDownloaded();
  renderModelLists();
  updateWarning();
}
async function refreshDownloaded() {
  const { modelsDownloaded = {} } = await chrome.storage.local.get("modelsDownloaded");
  state.downloaded = modelsDownloaded;
}
function renderUiLangToggle() {
  const host = $("ui-lang-toggle");
  if (!host) return;
  const cur = state.settings.uiLang || "en";
  if (!host.dataset.ready) {
    host.innerHTML = "";
    for (const [code, label] of UI_LANGS) {
      const opt = document.createElement("option");
      opt.value = code;
      opt.textContent = label;
      host.appendChild(opt);
    }
    host.addEventListener("change", async () => {
      state.settings.uiLang = host.value;
      await saveSettings();
      await loadSettings();
      applyI18n();
      updateWarning();
      renderHistory();
      renderQaSampleBar();
      renderModelLists();
    });
    host.dataset.ready = "1";
  }
  host.value = cur;
}
var ENGINE_OPTIONS = [
  ["browser", "engineBrowser"],
  ["native", "engineNative"]
];
function renderEngineToggle() {
  const host = $("engine-toggle");
  if (!host) return;
  const cur = state.settings.engine || "browser";
  if (!host.dataset.ready) {
    host.innerHTML = "";
    for (const [value, i18nKey] of ENGINE_OPTIONS) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.dataset.i18nKey = i18nKey;
      host.appendChild(opt);
    }
    host.addEventListener("change", async () => {
      state.settings.engine = host.value;
      await saveSettings();
      await loadSettings();
      updateWarning();
      if (state.settings.engine === "native") {
        lastNativeAutoStartMs = 0;
        labEnsureAttempted = false;
        checkNative({ allowAutoStart: true });
        if (!$("settings-modal").classList.contains("hidden")) startNativePoll();
      } else {
        stopNativePoll();
      }
    });
    host.dataset.ready = "1";
  }
  for (const opt of host.options) {
    if (opt.dataset.i18nKey) opt.textContent = t(opt.dataset.i18nKey);
  }
  host.value = ENGINE_OPTIONS.some(([v]) => v === cur) ? cur : "browser";
}
function renderQaSampleBar() {
  const bar = $("qa-sample-bar");
  const sel = $("qa-sample-select");
  if (!bar || !sel) return;
  const samples = state.qaCatalog?.samples || [];
  const show = state.mode === "offline" && samples.length > 0;
  bar.classList.toggle("hidden", !show);
  if (!samples.length) return;
  const prev = sel.value;
  sel.innerHTML = samples.map(
    (s) => `<option value="${s.id}">${s.label || s.id} (${Math.round(s.durationHint || 0)}s)</option>`
  ).join("");
  if (prev && samples.some((s) => s.id === prev)) sel.value = prev;
}
async function runQaSample(sample, { autoStart = true } = {}) {
  if (!sample || !state.qaCatalog) {
    setStatus(t("qaNoSample"), "error");
    return;
  }
  setMode("offline");
  setTask("translate");
  state.srcLang = sample.src;
  state.tgtLang = sample.tgt || "en";
  $("src-lang").value = state.srcLang;
  $("tgt-lang").value = state.tgtLang;
  updateWarning();
  persistLastConfig();
  setStatus(t("qaLoadingSample"));
  try {
    const file = await fetchSampleFile(state.qaCatalog, sample);
    await pickFile(file);
    if (autoStart && state.offlineFile && !state.offlineStaging) {
      await onStart();
    }
  } catch (e) {
    setStatus(String(e?.message || e), "error");
  }
}
function renderModelLists() {
  const asrHost = $("asr-models");
  asrHost.innerHTML = "";
  for (const [key, m] of Object.entries(ASR_MODELS)) {
    const size = m.webgpuOnly ? m.sizeWebgpu : `${m.sizeWasm} / ${m.sizeWebgpu}`;
    asrHost.appendChild(modelRow(key, m.label, `${size} \xB7 ${m.note}`));
  }
  const mtHost = $("mt-models");
  mtHost.innerHTML = "";
  for (const [key, p] of Object.entries(MT_PAIRS)) {
    mtHost.appendChild(modelRow(key, pairLabel(key), `${key} \xB7 Opus-MT \xB7 ${p.size}`, { mtPair: key }));
  }
}
function modelRow(key, name, sub, { mtPair = null } = {}) {
  const div = document.createElement("div");
  div.className = "m-item";
  const isDl = !!state.downloaded[key];
  const isActive = key === state.settings.asrModel && ASR_MODELS[key];
  const dl = dlState.get(key);
  const downloading = dl && !dl.done;
  const canTest = mtPair && state.qaCatalog && firstSampleForPair(state.qaCatalog, mtPair);
  div.innerHTML = `
    <div class="m-meta">
      <div class="m-name">${name}${isActive ? " \u2713" : ""}</div>
      <div class="m-sub">${sub}</div>
    </div>
    <span class="m-state ${isDl ? "done" : ""}" data-key="${key}">${downloading ? Math.round(dl.pct || 0) + "%" : isDl ? "\u2705" : ""}</span>
    ${canTest ? `<button class="mini-btn test-btn" data-pair="${mtPair}" title="${t("qaSamplesHint")}">${t("qaTest")}</button>` : ""}
    ${ASR_MODELS[key] && !isActive ? `<button class="mini-btn use-btn" data-key="${key}">Use</button>` : ""}
    <button class="mini-btn act-btn" data-key="${key}" ${downloading ? "disabled" : ""}>${downloading ? "\u2026" : isDl ? t("delete") : "\u2B07 " + t("download")}</button>
  `;
  div.querySelector(".act-btn").addEventListener("click", () => {
    if (state.downloaded[key]) {
      toOffscreen("model-delete", { key });
    } else {
      startDownload(key);
    }
  });
  div.querySelector(".use-btn")?.addEventListener("click", async () => {
    state.settings.asrModel = key;
    await saveSettings();
    renderModelLists();
    updateWarning();
  });
  div.querySelector(".test-btn")?.addEventListener("click", async () => {
    const pair = div.querySelector(".test-btn").dataset.pair;
    const sample = firstSampleForPair(state.qaCatalog, pair);
    $("settings-modal").classList.add("hidden");
    stopNativePoll();
    await runQaSample(sample, { autoStart: true });
  });
  return div;
}
async function loadSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  if (settings) Object.assign(state.settings, settings);
  if (!UI_LANGS.some(([c]) => c === state.settings.uiLang)) {
    state.settings.uiLang = "en";
  }
  renderUiLangToggle();
  renderEngineToggle();
  document.querySelectorAll("#mirror-toggle button").forEach(
    (b) => b.classList.toggle("active", b.dataset.mirror === state.settings.mirror)
  );
  document.querySelectorAll("#device-toggle button").forEach(
    (b) => b.classList.toggle("active", b.dataset.device === state.settings.device)
  );
  $("native-block").classList.toggle("hidden", state.settings.engine !== "native");
  $("native-url").value = state.settings.nativeUrl || DEFAULT_NATIVE_URL;
  syncDualLineCheckboxes();
  syncRefineCheckboxes();
  $("font-size").value = state.settings.overlayFontSize;
}
var nativeInfo = null;
var redrawHelperStatus = null;
var nativePollTimer = null;
var nativeBusy = false;
var lastNativeAutoStartMs = 0;
var NATIVE_AUTO_START_COOLDOWN_MS = 3e4;
var labEnsureAttempted = false;
async function tryAutoStartNative() {
  if (nativeBusy || !nativeHostSupported()) return false;
  const now = Date.now();
  if (now - lastNativeAutoStartMs < NATIVE_AUTO_START_COOLDOWN_MS) return false;
  lastNativeAutoStartMs = now;
  try {
    const res = await nativeHostAction("start", { timeoutMs: 9e4 });
    return !!res?.ok;
  } catch (e) {
    console.warn("native auto-start failed", e);
    return false;
  }
}
async function tryEnsureLab() {
  if (labEnsureAttempted || nativeBusy || !nativeHostSupported() || !nativeInfo) return;
  labEnsureAttempted = true;
  try {
    await nativeHostAction("ensure_lab", { timeoutMs: 3e4 });
  } catch (e) {
    console.warn("lab ensure failed", e);
  }
}
function setNativeUi({ running, busy, detail }) {
  const dot = $("native-status-dot");
  const st = $("native-status");
  dot.className = "status-dot " + (busy ? "busy" : running ? "on" : "off");
  st.className = "native-status " + (busy ? "" : running ? "on" : "off");
  st.textContent = detail;
  $("btn-native-start").disabled = busy || running;
  $("btn-native-stop").disabled = busy || !running;
  $("btn-native-restart").disabled = busy;
}
async function checkNative({ allowAutoStart = false } = {}) {
  if (nativeBusy) return nativeInfo;
  setNativeUi({ running: !!nativeInfo, busy: true, detail: t("nativeChecking") });
  nativeInfo = await nativeHealth(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  if (!nativeInfo && allowAutoStart) {
    const started = await tryAutoStartNative();
    if (started) nativeInfo = await nativeHealth(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  }
  if (nativeInfo) {
    const stale = nativeInfo.translate && nativeInfo.features && nativeInfo.features.translate_refine === false;
    fetch("http://127.0.0.1:7615/ingest/6dcc605f-4b08-497b-ae3f-ba4a5887e064", { method: "POST", headers: { "Content-Type": "application/json", "X-Debug-Session-Id": "89e0f7" }, body: JSON.stringify({ sessionId: "89e0f7", runId: "pre-fix", hypothesisId: "A", location: "sidepanel.js:checkNative", message: "native check result", data: { online: true, engine: nativeInfo.engine, stale, features: nativeInfo.features }, timestamp: Date.now() }) }).catch(() => {
    });
    setNativeUi({
      running: true,
      busy: false,
      detail: stale ? t("nativeStale", "Helper running \u2014 click Restart to load latest features") : t(
        "nativeOnline",
        `${nativeInfo.engine} \xB7 ${nativeInfo.model}${nativeInfo.translate ? " \xB7 +LLM translate" : ""}${nativeInfo.ffmpeg ? "" : " \xB7 \u26A0 no ffmpeg"}`
      )
    });
    tryEnsureLab();
  } else {
    fetch("http://127.0.0.1:7615/ingest/6dcc605f-4b08-497b-ae3f-ba4a5887e064", { method: "POST", headers: { "Content-Type": "application/json", "X-Debug-Session-Id": "89e0f7" }, body: JSON.stringify({ sessionId: "89e0f7", runId: "pre-fix", hypothesisId: "C", location: "sidepanel.js:checkNative", message: "native check offline", data: { url: state.settings.nativeUrl || DEFAULT_NATIVE_URL }, timestamp: Date.now() }) }).catch(() => {
    });
    setNativeUi({ running: false, busy: false, detail: t("nativeOffline") });
  }
  updateWarning();
  updateNativeHostHint();
  redrawHelperStatus?.();
  return nativeInfo;
}
function updateNativeHostHint() {
  const el = $("native-host-hint");
  if (!nativeHostSupported()) {
    el.classList.add("hidden");
    return;
  }
  el.textContent = t("nativeHostHint");
  el.classList.toggle("hidden", !!nativeInfo);
}
function startNativePoll() {
  stopNativePoll();
  nativePollTimer = setInterval(() => checkNative({ allowAutoStart: true }), 5e3);
}
function stopNativePoll() {
  if (nativePollTimer) {
    clearInterval(nativePollTimer);
    nativePollTimer = null;
  }
}
async function nativeControl(action) {
  if (nativeBusy) return;
  nativeBusy = true;
  const url = state.settings.nativeUrl || DEFAULT_NATIVE_URL;
  setNativeUi({
    running: !!nativeInfo,
    busy: true,
    detail: action === "start" ? t("nativeStarting") : action === "stop" ? t("nativeStopping") : t("nativeRestarting")
  });
  try {
    if (nativeHostSupported()) {
      fetch("http://127.0.0.1:7615/ingest/6dcc605f-4b08-497b-ae3f-ba4a5887e064", { method: "POST", headers: { "Content-Type": "application/json", "X-Debug-Session-Id": "89e0f7" }, body: JSON.stringify({ sessionId: "89e0f7", runId: "post-fix", hypothesisId: "F", location: "sidepanel.js:nativeControl", message: "native host action", data: { action }, timestamp: Date.now() }) }).catch(() => {
      });
      const res = await nativeHostAction(action, { timeoutMs: 13e4 });
      if (!res?.ok) throw new Error(res?.error || "Native host failed");
    } else if (action === "stop") {
      await nativeShutdown(url);
      await new Promise((r) => setTimeout(r, 400));
    } else {
      throw new Error(t("nativeHostMissing"));
    }
    await checkNative();
  } catch (e) {
    setNativeUi({ running: false, busy: false, detail: String(e.message || e) });
    updateNativeHostHint();
  } finally {
    nativeBusy = false;
  }
}
async function saveSettings() {
  await chrome.storage.local.set({ settings: state.settings });
}
function isLabHarness() {
  return typeof window !== "undefined" && !!window.__chromeMockStore;
}
var labMediaEl = null;
function releaseLabCapture() {
  try {
    const s = window.__ltsCaptureStream;
    if (s?.getTracks) {
      for (const track of s.getTracks()) {
        try {
          track.stop();
        } catch {
        }
      }
    }
  } catch {
  }
  window.__ltsCaptureStream = null;
  window.__ltsLabClock = null;
  if (labMediaEl) {
    try {
      labMediaEl.pause();
      labMediaEl.removeAttribute("src");
      labMediaEl.load();
      labMediaEl.remove();
    } catch {
    }
    labMediaEl = null;
  }
}
async function acquireLabDemoStream() {
  releaseLabCapture();
  let url = "/speech.wav";
  let title = "Lab demo \u2014 looping speech.wav";
  try {
    const cat = await loadSampleCatalog();
    const sample = firstSampleForPair(cat, `${state.srcLang}-${state.tgtLang}`) || firstSampleForPair(cat, `${state.srcLang}-en`) || cat?.samples?.[0];
    if (cat && sample?.file) {
      url = `${cat.base}${sample.file}`;
      title = sample.label || sample.file;
    }
  } catch {
  }
  const el = document.createElement("audio");
  el.src = url;
  el.loop = true;
  el.controls = true;
  el.crossOrigin = "anonymous";
  el.setAttribute("playsinline", "");
  el.style.cssText = "position:fixed;right:12px;bottom:12px;width:240px;z-index:40;border-radius:8px;background:#111";
  document.body.appendChild(el);
  labMediaEl = el;
  try {
    await el.play();
  } catch (e) {
    releaseLabCapture();
    throw new Error(`Lab demo audio blocked: ${e.message || e}. Click the page, then Start again.`);
  }
  const raw = typeof el.captureStream === "function" ? el.captureStream() : typeof el.mozCaptureStream === "function" ? el.mozCaptureStream() : null;
  const audioTracks = raw?.getAudioTracks?.() || [];
  if (!audioTracks.length) {
    releaseLabCapture();
    throw new Error("Could not capture audio from the lab demo clip (captureStream).");
  }
  const stream = new MediaStream(audioTracks);
  window.__ltsCaptureStream = stream;
  window.__ltsLabClock = () => labMediaEl && Number.isFinite(labMediaEl.currentTime) ? labMediaEl.currentTime : 0;
  state.currentTab = { id: 1, title, url, favIconUrl: "" };
  $("tab-title").textContent = title;
  $("tab-url").textContent = url;
  $("tab-favicon").src = chrome.runtime.getURL("icons/icon16.png");
  updateButtons();
  return stream;
}
async function acquireLabDisplayStream() {
  releaseLabCapture();
  if (!navigator.mediaDevices?.getDisplayMedia) {
    throw new Error("getDisplayMedia is unavailable in this browser.");
  }
  const display = await navigator.mediaDevices.getDisplayMedia({
    video: true,
    audio: true
  });
  const audioTracks = display.getAudioTracks();
  if (!audioTracks.length) {
    for (const track of display.getTracks()) track.stop();
    throw new Error(t("noAudioShared"));
  }
  for (const track of display.getVideoTracks()) track.stop();
  const stream = new MediaStream(audioTracks);
  const t0 = performance.now();
  window.__ltsCaptureStream = stream;
  window.__ltsLabClock = () => (performance.now() - t0) / 1e3;
  audioTracks[0].addEventListener("ended", () => {
    if (state.running) onStop();
  });
  state.currentTab = {
    id: 1,
    title: "Shared tab / window (getDisplayMedia)",
    url: location.href,
    favIconUrl: ""
  };
  $("tab-title").textContent = state.currentTab.title;
  $("tab-url").textContent = "Pick \u2192 share a tab and enable audio";
  $("tab-favicon").src = chrome.runtime.getURL("icons/icon16.png");
  updateButtons();
  return stream;
}
async function refreshTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const fallbackIcon = chrome.runtime.getURL("icons/icon16.png");
  if (tab && /^https?:/.test(tab.url || "")) {
    state.currentTab = tab;
    $("tab-title").textContent = tab.title || tab.url;
    $("tab-url").textContent = tab.url;
    $("tab-favicon").src = tab.favIconUrl || fallbackIcon;
  } else {
    state.currentTab = null;
    $("tab-title").textContent = t("noTab");
    $("tab-url").textContent = "";
    $("tab-favicon").src = fallbackIcon;
  }
  updateButtons();
}
function updateButtons() {
  const running = state.mode === "realtime" ? state.running : state.offlineRunning;
  $("btn-start").disabled = running || state.offlineStaging || (state.mode === "realtime" ? !state.currentTab : !state.offlineFile);
  $("btn-stop").disabled = !running;
  $("btn-stop").textContent = state.mode === "offline" ? t("cancelTask") : t("endTask");
}
function setStatus(text, cls = "") {
  const el = $("status-line");
  el.textContent = text;
  el.className = "status-line " + cls;
}
async function startWithStream(streamId, captureType) {
  setStatus(t("loadingModels"));
  clearLivePreview();
  $("live-preview").classList.remove("hidden");
  const res = await toBG("panel-start-realtime", {
    ...currentConfig(),
    streamId,
    captureType,
    tabTitle: state.currentTab?.title,
    tabUrl: state.currentTab?.url
  });
  if (res?.ok) {
    state.running = true;
    $("pick-hint").classList.add("hidden");
    updateButtons();
  } else if (res?.error) {
    if (isLabHarness()) releaseLabCapture();
    showCaptureError(res.error);
  }
}
function showCaptureError(message) {
  const blocked = /invoked|activeTab|not been invoked/i.test(message);
  setStatus(blocked ? t("needInvoke") : message, "error");
  if (blocked) {
    $("pick-hint").textContent = t("pickHint");
    $("pick-hint").classList.remove("hidden");
  }
}
function onPickManually() {
  if (isLabHarness()) {
    void (async () => {
      $("pick-hint").textContent = t("pickHintLab");
      $("pick-hint").classList.remove("hidden");
      try {
        setStatus(t("pickHintLab"));
        await acquireLabDisplayStream();
        await startWithStream(null, "media");
      } catch (e) {
        if (e?.name === "NotAllowedError" || /Permission denied|dismissed/i.test(String(e?.message || e))) {
          setStatus(t("cancelled"));
        } else {
          setStatus(String(e?.message || e), "error");
        }
      }
    })();
    return;
  }
  if (!chrome.desktopCapture?.chooseDesktopMedia) {
    setStatus("desktopCapture API unavailable in this browser.", "error");
    return;
  }
  $("pick-hint").textContent = t("pickHint");
  $("pick-hint").classList.remove("hidden");
  chrome.desktopCapture.chooseDesktopMedia(["tab", "window", "screen", "audio"], (streamId, opts) => {
    if (!streamId) {
      setStatus(t("cancelled"));
      return;
    }
    if (opts && opts.canRequestAudioTrack === false) {
      setStatus(t("noAudioShared"), "error");
      return;
    }
    startWithStream(streamId, "desktop");
  });
}
async function onStart() {
  if (state.mode === "realtime") {
    persistLastConfig();
    if (isLabHarness()) {
      try {
        setStatus(t("loadingModels"));
        clearLivePreview();
        $("live-preview").classList.remove("hidden");
        await acquireLabDemoStream();
        await startWithStream(null, "media");
      } catch (e) {
        releaseLabCapture();
        setStatus(String(e?.message || e), "error");
      }
      return;
    }
    if (!state.currentTab) return;
    let streamId = null;
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({
        targetTabId: state.currentTab.id
      });
    } catch (e) {
      const m = String(e?.message || e);
      if (/invoked|activeTab/i.test(m)) {
        showCaptureError(m);
        onPickManually();
        return;
      }
    }
    await startWithStream(streamId, "tab");
  } else {
    if (state.offlineStaging) {
      setStatus(t("stagingFile"));
      return;
    }
    if (!state.offlineFile) {
      setStatus(t("pickFile"), "error");
      return;
    }
    setStatus(t("processing"));
    state.offlineLines = [];
    $("off-lines").innerHTML = "";
    $("off-results").classList.remove("hidden");
    $("off-progress-text").textContent = "\u2026";
    try {
      await toBG("ensure-offscreen", {});
      toOffscreen("offline-process", {
        name: state.offlineFile.name,
        size: state.offlineFile.size,
        config: currentConfig()
      });
      state.offlineRunning = true;
      updateButtons();
    } catch (e) {
      setStatus(String(e?.message || e), "error");
    }
  }
}
async function onStop() {
  if (state.mode === "realtime") {
    await toBG("panel-stop", {});
    state.running = false;
    if (isLabHarness()) releaseLabCapture();
    setStatus("");
    updateButtons();
  } else {
    toOffscreen("offline-cancel", {});
  }
}
function wireDropzone() {
  const dz = $("off-drop");
  const input = $("off-file");
  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", () => pickFile(input.files[0]));
  dz.addEventListener("dragover", (e) => {
    e.preventDefault();
    dz.classList.add("dragover");
  });
  dz.addEventListener("dragleave", () => dz.classList.remove("dragover"));
  dz.addEventListener("drop", (e) => {
    e.preventDefault();
    dz.classList.remove("dragover");
    if (e.dataTransfer.files?.[0]) pickFile(e.dataTransfer.files[0]);
  });
}
async function stageOfflineFile(file) {
  await stageFileToOpfs(file, (loaded, total) => {
    if (!total) return;
    const pct = Math.min(100, Math.round(loaded / total * 100));
    const sizeMb = (file.size / 1024 / 1024).toFixed(1);
    $("off-filename").textContent = `${file.name} (${sizeMb} MB) \u2014 ${t("stagingFilePct", pct)}`;
  });
}
async function pickFile(file) {
  if (!file) return;
  state.offlineFile = null;
  state.offlineStaging = true;
  const sizeMb = (file.size / 1024 / 1024).toFixed(1);
  $("off-filename").textContent = `${file.name} (${sizeMb} MB) \u2014 ${t("stagingFile")}`;
  updateButtons();
  try {
    await stageOfflineFile(file);
    state.offlineFile = { name: file.name, size: file.size };
    $("off-filename").textContent = `${file.name} (${sizeMb} MB)`;
    if (needsNativeFilePath(file.size)) {
      setStatus(t("fileTooLarge"), "error");
    } else {
      setStatus("");
    }
  } catch (e) {
    state.offlineFile = null;
    const msg = String(e?.message || e);
    setStatus(/could not be read|NotReadableError/i.test(msg) ? t("fileReadError") : msg, "error");
    $("off-filename").textContent = t("dropHint");
  } finally {
    state.offlineStaging = false;
    updateButtons();
  }
}
function appendLiveLine(host, text) {
  if (!text) return;
  const div = document.createElement("div");
  div.className = "line";
  div.textContent = text;
  host.appendChild(div);
  while (host.children.length > 30) host.firstChild.remove();
  host.scrollTop = host.scrollHeight;
}
function setLiveInterim(host, text) {
  if (!text) {
    delete host.dataset.interim;
    const existing = host.querySelector(".line.interim");
    if (existing) existing.remove();
    return;
  }
  let div = host.querySelector(".line.interim");
  if (!div) {
    div = document.createElement("div");
    div.className = "line interim";
    host.appendChild(div);
  }
  div.textContent = text;
  host.dataset.interim = "1";
  host.scrollTop = host.scrollHeight;
}
function pushLive({ source, translation, interim, partial }) {
  if (interim && partial) {
    if (source) setLiveInterim($("live-src-lines"), source);
    if (translation) setLiveInterim($("live-tgt-lines"), translation);
    return;
  }
  if (interim) return;
  setLiveInterim($("live-src-lines"), "");
  setLiveInterim($("live-tgt-lines"), "");
  if (source) appendLiveLine($("live-src-lines"), source);
  if (translation) appendLiveLine($("live-tgt-lines"), translation);
}
function fmtTs(sec, srtStyle = false) {
  const ms = Math.max(0, Math.round(sec * 1e3));
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  const f = String(ms % 1e3).padStart(3, "0");
  return srtStyle ? `${h}:${m}:${s},${f}` : `${h}:${m}:${s}.${f}`;
}
function pushOfflineLine({ line, idx, total }) {
  state.offlineLines.push(line);
  const host = $("off-lines");
  const div = document.createElement("div");
  div.innerHTML = `<div class="ts">${fmtTs(line.t0)} \u2192 ${fmtTs(line.t1)}</div>`;
  if (line.src) {
    const s = document.createElement("div");
    s.className = "l-src";
    s.textContent = line.src;
    div.appendChild(s);
  }
  const tt = document.createElement("div");
  tt.className = "l-tgt";
  tt.textContent = line.tgt || line.src;
  div.appendChild(tt);
  host.appendChild(div);
  host.scrollTop = host.scrollHeight;
  $("off-progress-text").textContent = `${idx} / ${total}`;
}
function exportLines(kind) {
  const lines = state.offlineLines;
  if (!lines.length) return;
  exportSession({ lines, title: state.offlineFile?.name, url: "", kind });
}
async function exportSession({ lines, title, url, kind, dualLine }) {
  const meta = { url: url || "", title: title || "subtitles", dualLine: dualLine ?? state.settings.dualLine };
  const norm = (lines || []).map((l) => ({
    t0: l.t0 ?? 0,
    t1: l.t1 ?? l.t0 + 3,
    src: l.src || l.source || "",
    tgt: l.tgt || l.translation || ""
  }));
  let out = "";
  if (kind === "srt") out = formatSrt(norm, meta);
  else if (kind === "vtt") out = formatVtt(norm, meta);
  else out = formatTxt(norm, meta);
  const safe = exportBasename(title || "subtitles", kind).replace(/\.(srt|vtt|txt)$/i, "");
  const name = `${safe}.${kind}`;
  const res = await saveExportFile(name, out);
  if (res.saved) setStatus(t("savedTo", res.path), "ok");
}
async function renderHistory() {
  const { history = [] } = await chrome.storage.local.get("history");
  const host = $("history-list");
  host.innerHTML = "";
  if (!history.length) {
    host.innerHTML = `<div class="empty">${t("noHistory")}</div>`;
    return;
  }
  for (const h of history) {
    const div = document.createElement("div");
    div.className = "h-item";
    const when = new Date(h.ts).toLocaleString();
    const maxT = h.lines?.length ? Math.max(...h.lines.map((l) => l.t1 ?? (l.t ?? 0) / 1e3)) : 0;
    div.innerHTML = `
      <div class="h-title"></div>
      <div class="h-url"></div>
      <div class="h-meta">
        <span>${h.mode === "realtime" ? "\u{1F534}" : "\u{1F4C1}"} ${when}</span>
        <span>${h.srcLang || ""}${h.tgtLang ? " \u2192 " + h.tgtLang : ""}</span>
        <span>${h.lines?.length || 0} ${t("lines")}${maxT ? ` \xB7 ${fmtTs(maxT)}` : ""}</span>
      </div>
      <div class="h-actions">
        <button class="mini-btn h-txt">TXT</button>
        <button class="mini-btn h-srt">SRT</button>
        <button class="mini-btn h-vtt">VTT</button>
        <button class="mini-btn h-del">\u{1F5D1}</button>
      </div>`;
    div.querySelector(".h-title").textContent = h.title || "(untitled)";
    const urlEl = div.querySelector(".h-url");
    if (h.url) {
      urlEl.textContent = h.url;
    } else {
      urlEl.remove();
    }
    div.querySelector(".h-txt").addEventListener("click", (e) => {
      e.stopPropagation();
      exportHistory(h, "txt");
    });
    div.querySelector(".h-srt").addEventListener("click", (e) => {
      e.stopPropagation();
      exportHistory(h, "srt");
    });
    div.querySelector(".h-vtt").addEventListener("click", (e) => {
      e.stopPropagation();
      exportHistory(h, "vtt");
    });
    div.querySelector(".h-del").addEventListener("click", async (e) => {
      e.stopPropagation();
      await toBG("delete-history", { id: h.id, cacheKey: h.id });
      renderHistory();
    });
    host.appendChild(div);
  }
}
function exportHistory(h, kind) {
  exportSession({
    lines: h.lines || [],
    title: h.title,
    url: h.url,
    kind
  });
}
async function refreshExportFolderUi() {
  await loadExportDir();
  const label = exportDirLabel();
  $("export-folder-label").textContent = label ? `${t("exportFolderSet")}: ${label}` : t("exportFolderNone");
  $("btn-clear-export-folder").classList.toggle("hidden", !label);
}
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.target !== "panel") return;
  switch (msg.type) {
    case "state":
      state.running = !!msg.data.active;
      updateButtons();
      if (!state.running && state.mode === "realtime") setStatus("");
      break;
    case "subtitle":
      pushLive(msg.data);
      break;
    case "pipeline-status": {
      const s = msg.data?.state;
      if (s === "loading") setStatus(t("loadingModels"));
      else if (s === "listening")
        setStatus(`${t("listening")} (${msg.data.device || ""})`, "ok");
      break;
    }
    case "error":
      setStatus(msg.data?.message || "Error", "error");
      state.running = false;
      updateButtons();
      break;
    case "model-progress":
      onModelProgress(msg.data);
      break;
    case "model-done":
      onModelDone(msg.data);
      break;
    case "model-error":
      dlState.delete(msg.data?.key);
      renderDlList();
      renderModelLists();
      setStatus(`Model: ${msg.data?.message || "download failed"}`, "error");
      break;
    case "offline-line":
      pushOfflineLine(msg.data);
      break;
    case "offline-progress": {
      const d = msg.data;
      if (d.stage === "transcribe" && d.total) {
        setStatus(`${t("processing")} ${d.idx || 0}/${d.total}`);
      } else {
        setStatus(`${t("processing")} (${d.stage})`);
      }
      break;
    }
    case "offline-done":
      state.offlineRunning = false;
      setStatus(t("done"), "ok");
      updateButtons();
      renderHistory();
      break;
    case "offline-error":
      state.offlineRunning = false;
      setStatus(msg.data?.cancelled ? t("cancelled") : msg.data?.message || "Error", msg.data?.cancelled ? "" : "error");
      updateButtons();
      break;
    case "history-updated":
      renderHistory();
      break;
    case "cache-resume":
      setStatus(t("cacheResume", fmtTs(msg.data?.cacheMaxTime || 0), msg.data?.lineCount || 0), "ok");
      break;
  }
});
function wire() {
  document.querySelectorAll("#mode-toggle button").forEach(
    (b) => b.addEventListener("click", () => setMode(b.dataset.mode))
  );
  document.querySelectorAll("#task-toggle button").forEach(
    (b) => b.addEventListener("click", () => setTask(b.dataset.task))
  );
  $("src-lang").addEventListener("change", (e) => {
    state.srcLang = e.target.value;
    updateWarning();
    persistLastConfig();
  });
  $("tgt-lang").addEventListener("change", (e) => {
    state.tgtLang = e.target.value;
    updateWarning();
    persistLastConfig();
  });
  $("btn-start").addEventListener("click", onStart);
  $("btn-stop").addEventListener("click", onStop);
  $("btn-pick").addEventListener("click", onPickManually);
  $("btn-srt").addEventListener("click", () => exportLines("srt"));
  $("btn-vtt").addEventListener("click", () => exportLines("vtt"));
  $("btn-txt").addEventListener("click", () => exportLines("txt"));
  $("btn-pick-export-folder").addEventListener("click", async () => {
    try {
      await pickExportDir();
      await refreshExportFolderUi();
    } catch (e) {
      setStatus(String(e.message || e), "error");
    }
  });
  $("btn-clear-export-folder").addEventListener("click", async () => {
    await clearExportDir();
    await refreshExportFolderUi();
  });
  $("btn-settings").addEventListener("click", () => {
    $("settings-modal").classList.remove("hidden");
    lastNativeAutoStartMs = 0;
    labEnsureAttempted = false;
    checkNative({ allowAutoStart: true });
    startNativePoll();
    $("about-block").classList.add("hidden");
    renderModelLists();
  });
  $("btn-close-settings").addEventListener("click", () => {
    $("settings-modal").classList.add("hidden");
    stopNativePoll();
  });
  $("btn-about").addEventListener("click", () => {
    $("settings-modal").classList.remove("hidden");
    $("about-block").classList.remove("hidden");
    $("about-block").scrollIntoView({ behavior: "smooth" });
  });
  document.querySelectorAll("#mirror-toggle button").forEach(
    (b) => b.addEventListener("click", async () => {
      state.settings.mirror = b.dataset.mirror;
      await saveSettings();
      await loadSettings();
    })
  );
  document.querySelectorAll("#device-toggle button").forEach(
    (b) => b.addEventListener("click", async () => {
      state.settings.device = b.dataset.device;
      await saveSettings();
      await loadSettings();
      updateWarning();
    })
  );
  $("native-url").addEventListener("change", async (e) => {
    state.settings.nativeUrl = e.target.value.trim() || DEFAULT_NATIVE_URL;
    await saveSettings();
    checkNative();
  });
  $("btn-native-check").addEventListener("click", checkNative);
  $("btn-native-start").addEventListener("click", () => nativeControl("start"));
  $("btn-native-stop").addEventListener("click", () => nativeControl("stop"));
  $("btn-native-restart").addEventListener("click", () => nativeControl("restart"));
  $("dual-line-main").addEventListener("change", (e) => setDualLine(e.target.checked));
  $("dual-line").addEventListener("change", (e) => setDualLine(e.target.checked));
  $("refine-main").addEventListener("change", (e) => setRefineTranslation(e.target.checked));
  $("refine").addEventListener("change", (e) => setRefineTranslation(e.target.checked));
  $("font-size").addEventListener("change", async (e) => {
    state.settings.overlayFontSize = Number(e.target.value);
    await saveSettings();
  });
  wireDropzone();
  $("btn-qa-run")?.addEventListener("click", async () => {
    const id = $("qa-sample-select")?.value;
    const sample = state.qaCatalog?.samples?.find((s) => s.id === id);
    await runQaSample(sample, { autoStart: true });
  });
  chrome.tabs.onActivated.addListener(refreshTab);
  chrome.tabs.onUpdated.addListener((id, info) => {
    if (info.status === "complete" || info.title) refreshTab();
  });
}
async function init() {
  await loadSettings();
  wire();
  fillSelects();
  applyI18n();
  state.qaCatalog = await loadSampleCatalog();
  renderQaSampleBar();
  setMode("realtime");
  setTask("translate");
  await refreshDownloaded();
  renderModelLists();
  updateWarning();
  if (state.settings.engine === "native" || state.mode === "offline") {
    checkNative({ allowAutoStart: true });
    updateNativeHostHint();
  }
  await refreshTab();
  await refreshExportFolderUi();
  await renderHistory();
  const notesMount = $("notes-mount");
  if (notesMount) await mountNotesPanel(notesMount);
  const helperMount = $("helper-status-mount");
  if (helperMount) {
    redrawHelperStatus = mountHelperStatusCard(helperMount, () => ({
      online: !!nativeInfo,
      health: nativeInfo,
      engine: state.settings.engine || "browser",
      task: state.task,
      mode: state.mode
    }));
  }
  const s = await toBG("get-state", {});
  if (s?.active) {
    state.running = true;
    if (s.config) {
      state.srcLang = s.config.srcLang;
      state.tgtLang = s.config.tgtLang;
      state.settings.dualLine = s.config.dualLine ?? state.settings.dualLine;
      state.settings.refineTranslation = s.config.refineTranslation ?? state.settings.refineTranslation;
      $("src-lang").value = state.srcLang;
      $("tgt-lang").value = state.tgtLang;
      syncDualLineCheckboxes();
      syncRefineCheckboxes();
    }
    $("live-preview").classList.remove("hidden");
    setStatus(t("listening"), "ok");
    updateButtons();
  }
  await toBG("ensure-offscreen", {});
}
init();
