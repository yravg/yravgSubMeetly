// src/lib/transcript-cache.js
function normalizeUrl(url) {
  try {
    const u = new URL(url);
    u.hash = "";
    return u.href.replace(/\/$/, "");
  } catch {
    return url || "";
  }
}
function cacheKey(url, srcLang, tgtLang, taskMode) {
  return `${normalizeUrl(url)}|${srcLang}|${tgtLang}|${taskMode}`;
}
function maxCachedTime(lines) {
  if (!lines?.length) return 0;
  return Math.max(...lines.map((l) => l.t1 ?? l.t ?? 0));
}
function isRangeCached(lines, t0, t1, slack = 0.4) {
  if (!lines?.length) return false;
  return lines.some((l) => {
    const a = l.t0 ?? 0;
    const b = l.t1 ?? a;
    return a - slack <= t0 && b + slack >= t1;
  });
}
function mergeLine(lines, line) {
  const next = [...lines || [], line];
  next.sort((a, b) => (a.t0 ?? 0) - (b.t0 ?? 0));
  return next;
}

// src/lib/session-schema.js
var SESSION_SCHEMA_VERSION = 1;
var MAX_SESSIONS = 50;
function normalizeLine(l) {
  const t = Number(l?.t ?? (l?.t0 != null ? Math.round(l.t0 * 1e3) : 0)) || 0;
  const t1raw = l?.t1 != null ? Number(l.t1) : null;
  const t1 = t1raw == null ? t + 3e3 : t1raw < t ? Math.round(t1raw * 1e3) : Math.round(t1raw);
  return {
    t,
    t1: Math.max(t1, t + 1),
    src: String(l?.src ?? l?.source ?? ""),
    tgt: String(l?.tgt ?? l?.translation ?? "")
  };
}
function normalizeSession(entry) {
  const e = entry && typeof entry === "object" ? entry : {};
  const mode = e.mode === "offline" ? "offline" : "realtime";
  const lines = Array.isArray(e.lines) ? e.lines.map(normalizeLine) : [];
  const ts = Number(e.ts) || Date.now();
  return {
    v: SESSION_SCHEMA_VERSION,
    id: String(e.id || `s-${ts}-${Math.random().toString(36).slice(2, 8)}`),
    ts,
    mode,
    title: String(e.title || "Untitled session"),
    url: String(e.url || ""),
    srcLang: String(e.srcLang || ""),
    tgtLang: String(e.tgtLang || ""),
    lines,
    // Diturunkan, bukan disimpan ganda oleh pemanggil — supaya tidak bisa
    // berbohong terhadap isi `lines`.
    lineCount: lines.length,
    durationMs: lines.length ? Math.max(0, lines[lines.length - 1].t1 - lines[0].t) : 0
  };
}
function isCurrentSession(entry) {
  return !!entry && typeof entry === "object" && entry.v === SESSION_SCHEMA_VERSION;
}
var AUTOSAVE_INTERVAL_MS = 1e4;
function shouldAutosave({ now, lastAt, lineCount, active = true, force = false, intervalMs = AUTOSAVE_INTERVAL_MS }) {
  if (!active || !lineCount) return false;
  if (force) return true;
  return now - lastAt >= intervalMs;
}

// src/lib/session-migrate.js
function needsMigration(raw) {
  if (!Array.isArray(raw)) return !!raw;
  return raw.some((e) => !isCurrentSession(e));
}
function migrateSessions(raw) {
  const list = Array.isArray(raw) ? raw : [];
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entry of list) {
    if (!entry || typeof entry !== "object") continue;
    const s = isCurrentSession(entry) ? entry : normalizeSession(entry);
    if (seen.has(s.id)) continue;
    seen.add(s.id);
    out.push(s);
  }
  out.sort((a, b) => (b.ts || 0) - (a.ts || 0));
  return out.slice(0, MAX_SESSIONS);
}

// src/lib/translation-utils.js
var CJK = /[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]/;
function sourceText(line) {
  const src = (line?.src || line?.rawSrc || line?.source || "").trim();
  if (src) return src;
  return (line?.tgt || line?.rawTgt || line?.translation || "").trim();
}
function translationText(line) {
  return (line?.tgt || line?.rawTgt || line?.translation || "").trim();
}
function lineDirection(line, srcLang = "auto", tgtLang = "en") {
  const d = line?.dir;
  if (d && typeof d.src === "string" && d.src && typeof d.tgt === "string" && d.tgt) {
    return { srcLang: d.src, tgtLang: d.tgt };
  }
  return { srcLang, tgtLang };
}
function needsTranslation(line, srcLang = "auto", tgtLang = "en") {
  const src = sourceText(line);
  if (!src) return false;
  const tgt = translationText(line);
  if (!tgt || tgt === src) return true;
  const dir = lineDirection(line, srcLang, tgtLang);
  if (dir.tgtLang === "en" && CJK.test(tgt)) return true;
  if (dir.srcLang === "ja" && dir.tgtLang === "en" && CJK.test(tgt) && !/[A-Za-z]{2,}/.test(tgt)) {
    return true;
  }
  return false;
}
function mergeLinesByTime(...groups) {
  const map = /* @__PURE__ */ new Map();
  for (const list of groups) {
    for (const line of list || []) {
      const t0 = line.t0 ?? 0;
      const key = Math.round(t0 * 10);
      const prev = map.get(key);
      map.set(key, {
        ...prev,
        ...line,
        t0,
        t1: line.t1 ?? prev?.t1 ?? t0 + 2
      });
    }
  }
  return [...map.values()].sort((a, b) => (a.t0 ?? 0) - (b.t0 ?? 0));
}
function pickUntranslatedLines(lists, srcLang, tgtLang) {
  return mergeLinesByTime(...lists).filter((l) => needsTranslation(l, srcLang, tgtLang)).map((l) => ({
    t0: l.t0 ?? 0,
    t1: l.t1 ?? (l.t0 ?? 0) + 2,
    src: sourceText(l),
    rawSrc: sourceText(l),
    rawTgt: translationText(l),
    tgt: translationText(l),
    // carried so force-translate can pick the right direction per line
    ...l.dir ? { dir: l.dir } : {}
  })).filter((l) => l.src);
}

// src/lib/interpreter.js
function usable(code) {
  return typeof code === "string" && code !== "" && code !== "auto";
}
function normalizeInterpreter(settings, srcLang = "zh", tgtLang = "en") {
  const raw = settings && typeof settings === "object" ? settings.interpreter : null;
  const mode = raw && raw.mode === "consecutive" ? "consecutive" : "simultaneous";
  const a = usable(raw?.a) ? raw.a : usable(srcLang) ? srcLang : "";
  const b = usable(raw?.b) ? raw.b : usable(tgtLang) ? tgtLang : "";
  if (mode === "consecutive" && (!usable(a) || !usable(b) || a === b)) {
    return { mode: "simultaneous", a, b };
  }
  return { mode, a, b };
}
function isConsecutive(interpreter) {
  return interpreter?.mode === "consecutive";
}

// src/lib/native-protocol.js
var NATIVE_MESSAGING_HOST = "com.localtranssub.helper";
var LOCAL_HELPER_ORIGIN = "http://127.0.0.1:17865";
var NATIVE_HOST_ACTIONS = Object.freeze([
  "ping",
  "start",
  "stop",
  "restart",
  "status",
  "ensure_lab"
]);
var NATIVE_CONNECTION_STATES = Object.freeze([
  "connected",
  "unsupported",
  "not-installed",
  "forbidden",
  "crashed",
  "timeout",
  "error"
]);
function classifyNativeHostError(err) {
  const m = String(err?.message ?? err ?? "");
  if (!m) return "error";
  if (/forbidden|not allowed|allowed_origins/i.test(m)) return "forbidden";
  if (/not found|not registered|no such (native )?host|tidak ditemukan/i.test(m)) return "not-installed";
  if (/has exited|failed to start|exited early|terminated/i.test(m)) return "crashed";
  if (/timed out|timeout/i.test(m)) return "timeout";
  if (/not available|unavailable|unsupported/i.test(m)) return "unsupported";
  return "error";
}
function hostInstalledFromState(state) {
  if (state === "connected" || state === "crashed" || state === "forbidden") return true;
  if (state === "not-installed") return false;
  return null;
}
function assertLocalUrl(url) {
  const u = String(url || LOCAL_HELPER_ORIGIN);
  let parsed;
  try {
    parsed = new URL(u);
  } catch {
    throw new Error("URL helper tidak valid");
  }
  const host = parsed.hostname;
  if (host !== "127.0.0.1" && host !== "localhost") {
    throw new Error("Helper hanya boleh alamat lokal (127.0.0.1 / localhost)");
  }
  return u.replace(/\/+$/, "");
}

// src/lib/native-host.js
var NATIVE_HOST_NAME = "com.localtranssub.helper";
async function nativeHostConnection({ timeoutMs = 4e3 } = {}) {
  const base2 = { host: NATIVE_HOST_NAME, info: null, helperPortOpen: null, error: null };
  if (!nativeHostSupported()) {
    return { ...base2, state: "unsupported", connected: false, hostInstalled: null };
  }
  try {
    const res = await nativeHostAction("ping", { timeoutMs });
    const stale = res?.ok === false && /unknown action/i.test(String(res?.error || ""));
    return {
      ...base2,
      state: "connected",
      connected: true,
      hostInstalled: true,
      info: res?.host || null,
      helperPortOpen: typeof res?.helper_port_open === "boolean" ? res.helper_port_open : null,
      error: stale ? "host lama: aksi ping belum didukung" : null
    };
  } catch (e) {
    const state = classifyNativeHostError(e);
    return { ...base2, state, connected: false, hostInstalled: hostInstalledFromState(state), error: String(e?.message || e) };
  }
}
function nativeHostSupported() {
  return typeof chrome?.runtime?.connectNative === "function";
}
function nativeHostAction(action, { timeoutMs = 45e3 } = {}) {
  return new Promise((resolve, reject) => {
    if (!nativeHostSupported()) {
      reject(new Error("Native messaging is not available in this browser"));
      return;
    }
    let settled = false;
    const finish = (fn, val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(val);
    };
    let port;
    try {
      port = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    } catch (e) {
      reject(e);
      return;
    }
    const timer = setTimeout(() => {
      try {
        port.disconnect();
      } catch {
      }
      finish(reject, new Error("Native host timed out"));
    }, timeoutMs);
    port.onMessage.addListener((msg) => {
      try {
        port.disconnect();
      } catch {
      }
      finish(resolve, msg);
    });
    port.onDisconnect.addListener(() => {
      if (settled) return;
      const err = chrome.runtime.lastError?.message;
      finish(reject, new Error(err || "Native host disconnected"));
    });
    port.postMessage({ action });
  });
}

// src/lib/registry.js
var DEFAULT_NATIVE_URL = "http://127.0.0.1:17865";
var LANG_LABELS = {
  auto: "Auto detect",
  en: "English",
  ja: "Japanese",
  zh: "Chinese",
  ko: "Korean",
  de: "German",
  fr: "French",
  es: "Spanish",
  ru: "Russian",
  it: "Italian",
  pt: "Portuguese",
  nl: "Dutch",
  pl: "Polish",
  tr: "Turkish",
  ar: "Arabic",
  hi: "Hindi",
  th: "Thai",
  vi: "Vietnamese",
  id: "Bahasa Indonesia",
  uk: "Ukrainian"
};
function uniqueLangEntries(entries) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const [code, label] of entries) {
    if (!code || seen.has(code)) continue;
    seen.add(code);
    out.push([code, label || LANG_LABELS[code] || code]);
  }
  return out;
}
function langEntry(code) {
  return [code, LANG_LABELS[code] || code];
}
var SOURCE_LANGS = uniqueLangEntries([
  "auto",
  "en",
  "ja",
  "zh",
  "ko",
  "de",
  "fr",
  "es",
  "ru",
  "it",
  "pt",
  "nl",
  "pl",
  "tr",
  "ar",
  "hi",
  "th",
  "vi",
  "id",
  "uk"
].map(langEntry));
var TARGET_LANGS = uniqueLangEntries([
  "en",
  "zh",
  "de",
  "fr",
  "es",
  "ru",
  "it",
  "id",
  "vi",
  "ja",
  "ko"
].map(langEntry));
var MT_PAIRS = {
  "ja-en": { id: "Xenova/opus-mt-ja-en", size: "~116 MB" },
  "zh-en": { id: "Xenova/opus-mt-zh-en", size: "~120 MB" },
  "ko-en": { id: "Xenova/opus-mt-ko-en", size: "~115 MB" },
  "de-en": { id: "Xenova/opus-mt-de-en", size: "~115 MB" },
  "fr-en": { id: "Xenova/opus-mt-fr-en", size: "~115 MB" },
  "es-en": { id: "Xenova/opus-mt-es-en", size: "~115 MB" },
  "ru-en": { id: "Xenova/opus-mt-ru-en", size: "~115 MB" },
  "it-en": { id: "Xenova/opus-mt-it-en", size: "~115 MB" },
  "nl-en": { id: "Xenova/opus-mt-nl-en", size: "~115 MB" },
  "pl-en": { id: "Xenova/opus-mt-pl-en", size: "~115 MB" },
  "ar-en": { id: "Xenova/opus-mt-ar-en", size: "~115 MB" },
  "vi-en": { id: "Xenova/opus-mt-vi-en", size: "~115 MB" },
  "id-en": { id: "Xenova/opus-mt-id-en", size: "~115 MB" },
  "uk-en": { id: "Xenova/opus-mt-uk-en", size: "~115 MB" },
  "en-zh": { id: "Xenova/opus-mt-en-zh", size: "~121 MB" },
  "en-de": { id: "Xenova/opus-mt-en-de", size: "~115 MB" },
  "en-fr": { id: "Xenova/opus-mt-en-fr", size: "~115 MB" },
  "en-es": { id: "Xenova/opus-mt-en-es", size: "~115 MB" },
  "en-ru": { id: "Xenova/opus-mt-en-ru", size: "~115 MB" },
  "en-it": { id: "Xenova/opus-mt-en-it", size: "~115 MB" },
  "en-id": { id: "Xenova/opus-mt-en-id", size: "~115 MB" },
  "en-vi": { id: "Xenova/opus-mt-en-vi", size: "~115 MB" }
};
var LANG_NAMES = { ...LANG_LABELS };
var UI_LANGS = (() => {
  const codes = /* @__PURE__ */ new Set();
  for (const key of Object.keys(MT_PAIRS)) {
    const [src] = key.split("-");
    if (src) codes.add(src);
  }
  const nativeLabels = {
    en: "English",
    zh: "\u4E2D\u6587",
    ja: "\u65E5\u672C\u8A9E",
    ko: "\uD55C\uAD6D\uC5B4",
    de: "Deutsch",
    fr: "Fran\xE7ais",
    es: "Espa\xF1ol",
    ru: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
    it: "Italiano",
    nl: "Nederlands",
    pl: "Polski",
    ar: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
    vi: "Ti\u1EBFng Vi\u1EC7t",
    id: "Bahasa Indonesia",
    uk: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430"
  };
  const preferred = ["en", "zh"];
  const rest = [...codes].filter((c) => !preferred.includes(c)).sort();
  return uniqueLangEntries(
    [...preferred.filter((c) => codes.has(c)), ...rest].map((code) => [
      code,
      nativeLabels[code] || LANG_NAMES[code] || code
    ])
  );
})();

// src/lib/native.js
function base(url) {
  return assertLocalUrl(url || DEFAULT_NATIVE_URL);
}
async function nativeHealth(url, timeoutMs = 1500) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/health`, { signal: ctrl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// src/background.js
var session = {
  active: false,
  tabId: null,
  tabTitle: "",
  tabUrl: "",
  config: null,
  lines: [],
  startedAt: 0,
  videoTime: 0,
  speechStartTime: null,
  cacheKey: null,
  cachedLines: [],
  cacheMaxTime: 0
};
chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {
});
chrome.action.onClicked.addListener((tab) => {
  try {
    chrome.sidePanel?.open?.({ windowId: tab.windowId });
  } catch (e) {
    console.warn("sidePanel.open failed", e);
  }
});
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"]
  });
  if (contexts.length === 0) {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["USER_MEDIA"],
      justification: "Runs the local audio pipeline: tab-audio capture, on-device speech recognition and translation."
    });
    await new Promise((r) => setTimeout(r, 150));
  }
}
async function getSettings() {
  const { settings = {} } = await chrome.storage.local.get("settings");
  return settings;
}
async function loadTranscriptCache(key) {
  const { transcriptCache = {} } = await chrome.storage.local.get("transcriptCache");
  return transcriptCache[key] || null;
}
async function saveTranscriptCache(key, entry) {
  const { transcriptCache = {} } = await chrome.storage.local.get("transcriptCache");
  transcriptCache[key] = entry;
  await chrome.storage.local.set({ transcriptCache });
}
async function appendToTranscriptCache(key, line, meta) {
  const existing = await loadTranscriptCache(key) || {
    id: key,
    url: meta.url,
    title: meta.title,
    srcLang: meta.srcLang,
    tgtLang: meta.tgtLang,
    taskMode: meta.taskMode,
    lines: [],
    updatedAt: Date.now()
  };
  existing.lines = mergeLine(existing.lines, line);
  existing.updatedAt = Date.now();
  existing.title = meta.title || existing.title;
  await saveTranscriptCache(key, existing);
  return existing;
}
function applyDualLine({ source, translation, dualLine, taskMode }) {
  const dual = !!dualLine;
  const src = dual ? source || "" : "";
  let tgt;
  if (dual) {
    tgt = translation || "";
  } else if (taskMode === "translate") {
    tgt = translation || source || "";
  } else {
    tgt = translation || source || "";
  }
  return { source: src, translation: tgt };
}
function toPanel(type, data) {
  chrome.runtime.sendMessage({ target: "panel", type, data }).catch(() => {
  });
}
function toOffscreen(type, data) {
  chrome.runtime.sendMessage({ target: "offscreen", type, data }).catch(() => {
  });
}
function toContent(type, data) {
  if (session.tabId == null) return;
  chrome.tabs.sendMessage(session.tabId, { target: "content", type, data }).catch(() => {
  });
}
async function buildConfig(tabId, partial = {}) {
  const settings = await getSettings();
  const { lastConfig = {} } = await chrome.storage.local.get("lastConfig");
  const cfg = {
    tabId,
    srcLang: partial.srcLang ?? lastConfig.srcLang ?? "ja",
    tgtLang: partial.tgtLang ?? lastConfig.tgtLang ?? "en",
    taskMode: partial.taskMode ?? lastConfig.taskMode ?? "translate",
    dualLine: partial.dualLine ?? settings.dualLine ?? false,
    refineTranslation: partial.refineTranslation ?? settings.refineTranslation ?? false,
    asrModel: partial.asrModel ?? lastConfig.asrModel ?? settings.asrModel ?? "whisper-base",
    streamId: partial.streamId,
    captureType: partial.captureType || "tab"
  };
  const interpreter = normalizeInterpreter(settings, cfg.srcLang, cfg.tgtLang);
  if (isConsecutive(interpreter)) {
    cfg.srcLang = interpreter.a;
    cfg.tgtLang = interpreter.b;
    cfg.taskMode = "translate";
    cfg.refineTranslation = false;
  }
  cfg.interpreter = interpreter;
  return cfg;
}
async function startRealtime(partialCfg) {
  if (session.active) await stopSession("restart");
  const cfg = await buildConfig(partialCfg.tabId, partialCfg);
  const tabId = cfg.tabId;
  const tab = await chrome.tabs.get(tabId);
  if (!/^https?:/.test(tab.url || "")) {
    throw new Error("This page cannot be captured. Open a normal website tab.");
  }
  await ensureOffscreen();
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  let streamId = cfg.streamId;
  if (!streamId) {
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
    } catch (e) {
      throw new Error(
        String(e.message || e) + ' \u2014 Right-click the page \u2192 "Start yraverageSubMin on this page", or use Pick tab manually.'
      );
    }
  }
  const key = cacheKey(tab.url, cfg.srcLang, cfg.tgtLang, cfg.taskMode);
  const cached = await loadTranscriptCache(key);
  const cachedLines = cached?.lines || [];
  const cacheMax = maxCachedTime(cachedLines);
  session = {
    active: true,
    tabId,
    tabTitle: tab.title || "",
    tabUrl: tab.url || "",
    config: cfg,
    lines: [...cachedLines],
    startedAt: Date.now(),
    videoTime: 0,
    speechStartTime: null,
    cacheKey: key,
    cachedLines,
    cacheMaxTime: cacheMax
  };
  toOffscreen("start-capture", {
    streamId,
    captureType: cfg.captureType,
    config: { ...cfg, cacheMaxTime: cacheMax },
    settings: await getSettings()
  });
  toContent("session", {
    active: true,
    config: cfg,
    cacheCues: cachedLines,
    cacheMaxTime: cacheMax
  });
  toPanel("state", publicState());
  if (cacheMax > 0) {
    toPanel("cache-resume", { cacheMaxTime: cacheMax, lineCount: cachedLines.length });
  }
}
async function stopSession(reason = "user") {
  if (!session.active) return;
  toOffscreen("stop-capture", {});
  toContent("session", { active: false });
  if (session.lines.length > 0 && session.cacheKey) {
    await saveTranscriptCache(session.cacheKey, {
      id: session.cacheKey,
      url: session.tabUrl,
      title: session.tabTitle,
      srcLang: session.config?.srcLang,
      tgtLang: session.config?.tgtLang,
      taskMode: session.config?.taskMode,
      lines: session.lines,
      updatedAt: Date.now()
    });
    await autosaveSession({ force: true });
    await saveHistory({
      id: session.cacheKey,
      ts: session.startedAt,
      mode: "realtime",
      title: session.tabTitle,
      url: session.tabUrl,
      srcLang: session.config?.srcLang,
      tgtLang: session.config?.tgtLang,
      lines: session.lines
    });
  }
  session = {
    active: false,
    tabId: null,
    tabTitle: "",
    tabUrl: "",
    config: null,
    lines: [],
    startedAt: 0,
    videoTime: 0,
    speechStartTime: null,
    cacheKey: null,
    cachedLines: [],
    cacheMaxTime: 0
  };
  toPanel("state", publicState());
}
var lastAutosaveAt = 0;
var autosavePending = false;
async function autosaveSession({ force = false } = {}) {
  if (!session.cacheKey) return;
  const now = Date.now();
  if (!shouldAutosave({
    now,
    lastAt: lastAutosaveAt,
    lineCount: session.lines.length,
    active: session.active,
    force,
    intervalMs: AUTOSAVE_INTERVAL_MS
  })) {
    autosavePending = true;
    return;
  }
  lastAutosaveAt = now;
  autosavePending = false;
  await saveHistory({
    id: session.cacheKey,
    ts: session.startedAt,
    mode: "realtime",
    title: session.tabTitle,
    url: session.tabUrl,
    srcLang: session.config?.srcLang,
    tgtLang: session.config?.tgtLang,
    lines: session.lines
  });
}
async function saveHistory(entry) {
  const { history = [] } = await chrome.storage.local.get("history");
  const list = migrateSessions(history);
  const next = normalizeSession(entry);
  const idx = list.findIndex((h) => h.id === next.id);
  if (idx >= 0) list[idx] = { ...list[idx], ...next, ts: next.ts || list[idx].ts };
  else list.unshift(next);
  await chrome.storage.local.set({ history: migrateSessions(list) });
  toPanel("history-updated", {});
}
async function migrateHistoryIfNeeded() {
  const { history } = await chrome.storage.local.get("history");
  if (!needsMigration(history)) return;
  await chrome.storage.local.set({ history: migrateSessions(history) });
  toPanel("history-updated", {});
}
async function updateSessionConfig(patch) {
  if (!session.active) return;
  session.config = { ...session.config, ...patch };
  toOffscreen("update-config", { config: session.config });
  toContent("config", { config: session.config, cacheCues: session.lines });
}
function publicState() {
  return {
    active: session.active,
    tabId: session.tabId,
    tabTitle: session.tabTitle,
    config: session.config,
    lineCount: session.lines.length,
    cacheMaxTime: session.cacheMaxTime
  };
}
chrome.runtime.onInstalled.addListener(() => {
  void migrateHistoryIfNeeded();
  chrome.contextMenus.create({
    id: "lts-start",
    title: "Start yraverageSubMin on this page / \u5728\u6B64\u9875\u9762\u542F\u52A8",
    contexts: ["page", "video", "audio", "frame"]
  });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "lts-start" || !tab?.id) return;
  try {
    await startRealtime({ tabId: tab.id });
    toPanel("state", publicState());
  } catch (e) {
    toPanel("error", { message: String(e.message || e) });
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (session.active && tabId === session.tabId) stopSession("tab-closed");
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (session.active && tabId === session.tabId && info.status === "loading" && info.url) {
    stopSession("tab-navigated");
  }
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== "bg") return;
  (async () => {
    switch (msg.type) {
      case "panel-start-realtime":
        try {
          await startRealtime(msg.data);
          sendResponse({ ok: true });
        } catch (e) {
          toPanel("error", { message: String(e.message || e) });
          sendResponse({ ok: false, error: String(e.message || e) });
        }
        break;
      case "panel-stop":
        await stopSession("user");
        sendResponse({ ok: true });
        break;
      case "get-state":
        sendResponse(publicState());
        break;
      case "native-host-action": {
        const action = msg.data?.action || "status";
        if (!nativeHostSupported()) {
          sendResponse({
            ok: false,
            error: "nativeMessaging unavailable",
            host: NATIVE_HOST_NAME || NATIVE_MESSAGING_HOST
          });
          break;
        }
        try {
          const res = await nativeHostAction(action, { timeoutMs: msg.data?.timeoutMs || 45e3 });
          sendResponse({ ok: true, host: NATIVE_HOST_NAME, result: res });
        } catch (e) {
          sendResponse({ ok: false, host: NATIVE_HOST_NAME, error: String(e.message || e) });
        }
        break;
      }
      case "native-host-connection": {
        sendResponse(await nativeHostConnection({ timeoutMs: msg.data?.timeoutMs || 4e3 }));
        break;
      }
      case "native-helper-status": {
        const settings = await getSettings();
        const url = settings.nativeUrl || LOCAL_HELPER_ORIGIN;
        const health = await nativeHealth(url);
        sendResponse({
          ok: !!health?.ok,
          online: !!health?.ok,
          host: NATIVE_MESSAGING_HOST,
          nativeMessaging: nativeHostSupported(),
          health,
          engine_label: health?.engine_label || health?.engine || null,
          url
        });
        break;
      }
      case "update-config":
        await updateSessionConfig(msg.data || {});
        sendResponse({ ok: true });
        break;
      case "delete-history":
        {
          const { history = [] } = await chrome.storage.local.get("history");
          const next = history.filter((h) => h.id !== msg.data?.id);
          await chrome.storage.local.set({ history: next });
          if (msg.data?.cacheKey) {
            const { transcriptCache = {} } = await chrome.storage.local.get("transcriptCache");
            delete transcriptCache[msg.data.cacheKey];
            await chrome.storage.local.set({ transcriptCache });
          }
          toPanel("history-updated", {});
          sendResponse({ ok: true });
        }
        break;
      case "ensure-offscreen":
        await ensureOffscreen();
        sendResponse({ ok: true });
        break;
      case "to-offscreen":
        await ensureOffscreen();
        toOffscreen(msg.data.type, { ...msg.data.data || {}, settings: await getSettings() });
        sendResponse({ ok: true });
        break;
      case "mark-model": {
        const { modelsDownloaded = {} } = await chrome.storage.local.get("modelsDownloaded");
        if (msg.data.deleted) delete modelsDownloaded[msg.data.key];
        else modelsDownloaded[msg.data.key] = { ts: Date.now(), ...msg.data.extra || {} };
        await chrome.storage.local.set({ modelsDownloaded });
        sendResponse({ ok: true });
        break;
      }
      case "video-time":
        if (session.active && sender.tab?.id === session.tabId) {
          session.videoTime = msg.data?.time ?? session.videoTime;
        }
        sendResponse({ ok: true });
        break;
      case "speech-start":
        if (session.active) session.speechStartTime = session.videoTime;
        sendResponse({ ok: true, time: session.videoTime });
        break;
      case "get-video-time":
        sendResponse({ ok: true, time: session.videoTime });
        break;
      case "check-cache-range": {
        const { t0, t1 } = msg.data || {};
        let cached = isRangeCached(session.lines, t0, t1);
        if (cached && session.config?.taskMode === "translate") {
          const covering = session.lines.find((l) => {
            const a = l.t0 ?? 0;
            const b = l.t1 ?? a;
            return a - 0.4 <= t0 && b + 0.4 >= t1;
          });
          if (covering && needsTranslation(covering, session.config.srcLang, session.config.tgtLang)) {
            cached = false;
          }
        }
        sendResponse({ ok: true, cached, cacheMaxTime: session.cacheMaxTime });
        break;
      }
      case "force-translate": {
        if (!session.active) {
          sendResponse({ ok: false, error: "No active session" });
          break;
        }
        if (session.config?.taskMode !== "translate") {
          sendResponse({ ok: false, error: "Switch to + Translate mode in the panel" });
          break;
        }
        const retranslate = msg.data?.retranslate !== false;
        const lines = (msg.data?.lines?.length ? msg.data.lines : retranslate ? mergeLinesByTime(session.lines) : pickUntranslatedLines([session.lines], session.config.srcLang, session.config.tgtLang)).map((l) => ({
          t0: l.t0 ?? 0,
          t1: l.t1 ?? (l.t0 ?? 0) + 2,
          src: sourceText(l),
          rawSrc: sourceText(l),
          rawTgt: translationText(l),
          tgt: translationText(l),
          ...l.dir ? { dir: l.dir } : {}
        })).filter((l) => l.src);
        if (!lines.length) {
          sendResponse({ ok: false, error: "No lines to translate" });
          break;
        }
        await ensureOffscreen();
        toOffscreen("force-translate", {
          lines,
          retranslate,
          config: session.config,
          settings: await getSettings()
        });
        sendResponse({ ok: true, count: lines.length });
        break;
      }
      case "force-translate-done":
        toContent("force-translate-done", msg.data);
        sendResponse({ ok: true });
        break;
      case "perf-sample": {
        const d = msg.data || {};
        toPanel("perf-sample", d);
        void (async () => {
          try {
            const { perfSamples = [] } = await chrome.storage.local.get("perfSamples");
            perfSamples.push(d);
            if (perfSamples.length > 3e3) perfSamples.splice(0, perfSamples.length - 3e3);
            await chrome.storage.local.set({ perfSamples });
          } catch (e) {
            console.warn("perf-sample store", e);
          }
        })();
        break;
      }
      case "subtitle": {
        const d = msg.data;
        const dualLine = session.config?.dualLine ?? false;
        const formatted = applyDualLine({
          source: d.rawSource ?? d.source,
          translation: d.rawTranslation ?? d.translation,
          dualLine,
          taskMode: session.config?.taskMode
        });
        toContent("subtitle", { ...d, ...formatted });
        toPanel("subtitle", { ...d, ...formatted });
        if (d.final && d.t0 != null) {
          const line = {
            t0: d.t0,
            t1: d.t1 ?? d.t0 + 2,
            src: (d.rawSource ?? d.source ?? "").trim(),
            tgt: (d.rawTranslation ?? "").trim(),
            // two-way lines remember which way they went; everything that
            // judges "is this translated?" reads it instead of session.config
            ...d.dir?.src && d.dir?.tgt ? { dir: { src: d.dir.src, tgt: d.dir.tgt } } : {}
          };
          if (!line.src && (d.rawTranslation ?? d.translation ?? "").trim()) {
            line.src = (d.rawTranslation ?? d.translation ?? "").trim();
          }
          session.lines = mergeLine(session.lines, line);
          session.cacheMaxTime = Math.max(session.cacheMaxTime, line.t1);
          void autosaveSession();
          if (session.cacheKey) {
            await appendToTranscriptCache(session.cacheKey, line, {
              url: session.tabUrl,
              title: session.tabTitle,
              srcLang: session.config?.srcLang,
              tgtLang: session.config?.tgtLang,
              taskMode: session.config?.taskMode
            });
          }
          toContent("cache-cue", { cue: line, config: session.config });
        }
        sendResponse({ ok: true });
        break;
      }
      case "pipeline-status":
        session.pipelineState = msg.data?.state || null;
        session.pipelineDevice = msg.data?.device || null;
        toPanel("pipeline-status", msg.data);
        toContent("pipeline-status", msg.data);
        sendResponse({ ok: true });
        break;
      // Content script menanyakan keadaan overlay saat ini — ketika baru
      // disuntikkan, dipulihkan dari bfcache, atau tabnya terlihat lagi —
      // supaya overlay tidak tertinggal kosong atau basi setelah ganti tab.
      // Hanya tab yang sedang disubtitle yang dijawab aktif.
      case "content-sync": {
        const mine = session.active && sender?.tab?.id != null && sender.tab.id === session.tabId;
        sendResponse({
          active: mine,
          config: mine ? session.config : null,
          cacheCues: mine ? session.lines : [],
          cacheMaxTime: mine ? session.cacheMaxTime : 0,
          pipelineState: mine ? session.pipelineState || null : null,
          pipelineDevice: mine ? session.pipelineDevice || null : null
        });
        break;
      }
      case "pipeline-error":
        toPanel("error", msg.data);
        await stopSession("error");
        sendResponse({ ok: true });
        break;
      case "capture-ended":
        await stopSession("capture-ended");
        sendResponse({ ok: true });
        break;
      case "model-progress":
      case "model-done":
      case "model-error":
      case "offline-line":
      case "offline-progress":
      case "offline-done":
      case "offline-error":
        toPanel(msg.type, msg.data);
        sendResponse({ ok: true });
        break;
      case "save-history":
        await saveHistory(msg.data);
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: `unknown message: ${msg.type}` });
    }
  })();
  return true;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.settings || !session.active) return;
  const next = changes.settings.newValue || {};
  const prev = changes.settings.oldValue || {};
  if (next.dualLine !== prev.dualLine) {
    updateSessionConfig({ dualLine: next.dualLine });
  }
  if (next.refineTranslation !== prev.refineTranslation) {
    updateSessionConfig({ refineTranslation: next.refineTranslation });
  }
});
