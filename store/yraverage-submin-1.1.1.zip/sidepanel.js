var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/lib/registry.js
function uniqueLangEntries(entries) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const [code, label2] of entries) {
    if (!code || seen.has(code)) continue;
    seen.add(code);
    out.push([code, label2 || LANG_LABELS[code] || code]);
  }
  return out;
}
function langEntry(code) {
  return [code, LANG_LABELS[code] || code];
}
function pairLabel(key) {
  const [s, t2] = key.split("-");
  return `${LANG_NAMES[s] || s} \u2192 ${LANG_NAMES[t2] || t2}`;
}
function translationPlan(src, tgt, { dualLine = false, refineTranslation = false } = {}) {
  if (!tgt || src === tgt) return { mode: "none" };
  const key = src !== "auto" && src !== "en" ? `${src}-${tgt}` : "";
  const pair = key ? MT_PAIRS[key] || null : null;
  const separateMt = dualLine || refineTranslation;
  if (pair && tgt === "en" && !separateMt) {
    return { mode: "mt", pairKey: key, pair };
  }
  if (tgt === "en" && !separateMt) return { mode: "whisper-direct" };
  if (!pair && src !== "auto" && src !== "en" && tgt !== "en") {
    const leg1 = MT_PAIRS[`${src}-en`];
    const leg2 = MT_PAIRS[`en-${tgt}`];
    if (leg1 && leg2) {
      return {
        mode: "mt",
        pairKey: key,
        pair: null,
        pivot: { leg1, leg2, leg1Key: `${src}-en`, leg2Key: `en-${tgt}` }
      };
    }
  }
  return { mode: "mt", pairKey: key, pair };
}
var ASR_MODELS, DEFAULT_ASR, DEFAULT_NATIVE_URL, LANG_LABELS, SOURCE_LANGS, TARGET_LANGS, MT_PAIRS, LANG_NAMES, UI_LANGS;
var init_registry = __esm({
  "src/lib/registry.js"() {
    ASR_MODELS = {
      "whisper-tiny": {
        id: "onnx-community/whisper-tiny",
        label: "Whisper Tiny",
        sizeWebgpu: "~120 MB",
        sizeWasm: "~45 MB",
        note: "fastest, lowest accuracy"
      },
      "whisper-base": {
        id: "onnx-community/whisper-base",
        label: "Whisper Base",
        sizeWebgpu: "~210 MB",
        sizeWasm: "~80 MB",
        note: "recommended balance"
      },
      "whisper-small": {
        id: "onnx-community/whisper-small",
        label: "Whisper Small",
        sizeWebgpu: "~590 MB",
        sizeWasm: "~250 MB",
        note: "good accuracy, slower on WASM"
      },
      "whisper-large-v3-turbo": {
        id: "onnx-community/whisper-large-v3-turbo",
        label: "Whisper Large v3 Turbo",
        sizeWebgpu: "~565 MB",
        sizeWasm: "\u2014",
        note: "high accuracy \xB7 WebGPU only",
        webgpuOnly: true,
        dtype: { encoder_model: "q4f16", decoder_model_merged: "q4f16" }
      },
      "voxtral-mini": {
        id: "onnx-community/Voxtral-Mini-3B-2507-ONNX",
        label: "Voxtral Mini 3B",
        sizeWebgpu: "~2.7 GB",
        sizeWasm: "\u2014",
        note: "best quality \xB7 WebGPU + \u226516 GB RAM \xB7 slower",
        webgpuOnly: true,
        engine: "voxtral",
        dtype: { embed_tokens: "q4", audio_encoder: "q4f16", decoder_model_merged: "q4f16" }
      }
    };
    DEFAULT_ASR = "whisper-base";
    DEFAULT_NATIVE_URL = "http://127.0.0.1:17865";
    LANG_LABELS = {
      auto: "Auto detect",
      en: "English",
      ja: "Japanese",
      zh: "Chinese",
      ko: "Korean",
      de: "German",
      fr: "French",
      es: "Spanish",
      ru: "Russian",
      it: "Italian",
      pt: "Portuguese",
      nl: "Dutch",
      pl: "Polish",
      tr: "Turkish",
      ar: "Arabic",
      hi: "Hindi",
      th: "Thai",
      vi: "Vietnamese",
      id: "Bahasa Indonesia",
      uk: "Ukrainian"
    };
    SOURCE_LANGS = uniqueLangEntries([
      "auto",
      "en",
      "ja",
      "zh",
      "ko",
      "de",
      "fr",
      "es",
      "ru",
      "it",
      "pt",
      "nl",
      "pl",
      "tr",
      "ar",
      "hi",
      "th",
      "vi",
      "id",
      "uk"
    ].map(langEntry));
    TARGET_LANGS = uniqueLangEntries([
      "en",
      "zh",
      "de",
      "fr",
      "es",
      "ru",
      "it",
      "id",
      "vi",
      "ja",
      "ko"
    ].map(langEntry));
    MT_PAIRS = {
      "ja-en": { id: "Xenova/opus-mt-ja-en", size: "~116 MB" },
      "zh-en": { id: "Xenova/opus-mt-zh-en", size: "~120 MB" },
      "ko-en": { id: "Xenova/opus-mt-ko-en", size: "~115 MB" },
      "de-en": { id: "Xenova/opus-mt-de-en", size: "~115 MB" },
      "fr-en": { id: "Xenova/opus-mt-fr-en", size: "~115 MB" },
      "es-en": { id: "Xenova/opus-mt-es-en", size: "~115 MB" },
      "ru-en": { id: "Xenova/opus-mt-ru-en", size: "~115 MB" },
      "it-en": { id: "Xenova/opus-mt-it-en", size: "~115 MB" },
      "nl-en": { id: "Xenova/opus-mt-nl-en", size: "~115 MB" },
      "pl-en": { id: "Xenova/opus-mt-pl-en", size: "~115 MB" },
      "ar-en": { id: "Xenova/opus-mt-ar-en", size: "~115 MB" },
      "vi-en": { id: "Xenova/opus-mt-vi-en", size: "~115 MB" },
      "id-en": { id: "Xenova/opus-mt-id-en", size: "~115 MB" },
      "uk-en": { id: "Xenova/opus-mt-uk-en", size: "~115 MB" },
      "en-zh": { id: "Xenova/opus-mt-en-zh", size: "~121 MB" },
      "en-de": { id: "Xenova/opus-mt-en-de", size: "~115 MB" },
      "en-fr": { id: "Xenova/opus-mt-en-fr", size: "~115 MB" },
      "en-es": { id: "Xenova/opus-mt-en-es", size: "~115 MB" },
      "en-ru": { id: "Xenova/opus-mt-en-ru", size: "~115 MB" },
      "en-it": { id: "Xenova/opus-mt-en-it", size: "~115 MB" },
      "en-id": { id: "Xenova/opus-mt-en-id", size: "~115 MB" },
      "en-vi": { id: "Xenova/opus-mt-en-vi", size: "~115 MB" }
    };
    LANG_NAMES = { ...LANG_LABELS };
    UI_LANGS = (() => {
      const codes = /* @__PURE__ */ new Set();
      for (const key of Object.keys(MT_PAIRS)) {
        const [src] = key.split("-");
        if (src) codes.add(src);
      }
      const nativeLabels = {
        en: "English",
        zh: "\u4E2D\u6587",
        ja: "\u65E5\u672C\u8A9E",
        ko: "\uD55C\uAD6D\uC5B4",
        de: "Deutsch",
        fr: "Fran\xE7ais",
        es: "Espa\xF1ol",
        ru: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439",
        it: "Italiano",
        nl: "Nederlands",
        pl: "Polski",
        ar: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
        vi: "Ti\u1EBFng Vi\u1EC7t",
        id: "Bahasa Indonesia",
        uk: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430"
      };
      const preferred = ["en", "zh"];
      const rest = [...codes].filter((c) => !preferred.includes(c)).sort();
      return uniqueLangEntries(
        [...preferred.filter((c) => codes.has(c)), ...rest].map((code) => [
          code,
          nativeLabels[code] || LANG_NAMES[code] || code
        ])
      );
    })();
  }
});

// src/lib/native-protocol.js
function classifyNativeHostError(err) {
  const m = String(err?.message ?? err ?? "");
  if (!m) return "error";
  if (/forbidden|not allowed|allowed_origins/i.test(m)) return "forbidden";
  if (/not found|not registered|no such (native )?host|tidak ditemukan/i.test(m)) return "not-installed";
  if (/has exited|failed to start|exited early|terminated/i.test(m)) return "crashed";
  if (/timed out|timeout/i.test(m)) return "timeout";
  if (/not available|unavailable|unsupported/i.test(m)) return "unsupported";
  return "error";
}
function hostInstalledFromState(state2) {
  if (state2 === "connected" || state2 === "crashed" || state2 === "forbidden") return true;
  if (state2 === "not-installed") return false;
  return null;
}
function assertLocalUrl(url) {
  const u = String(url || LOCAL_HELPER_ORIGIN);
  let parsed;
  try {
    parsed = new URL(u);
  } catch {
    throw new Error("URL helper tidak valid");
  }
  const host = parsed.hostname;
  if (host !== "127.0.0.1" && host !== "localhost") {
    throw new Error("Helper hanya boleh alamat lokal (127.0.0.1 / localhost)");
  }
  return u.replace(/\/+$/, "");
}
var LOCAL_HELPER_ORIGIN, NATIVE_HOST_ACTIONS, NATIVE_CONNECTION_STATES;
var init_native_protocol = __esm({
  "src/lib/native-protocol.js"() {
    LOCAL_HELPER_ORIGIN = "http://127.0.0.1:17865";
    NATIVE_HOST_ACTIONS = Object.freeze([
      "ping",
      "start",
      "stop",
      "restart",
      "status",
      "ensure_lab"
    ]);
    NATIVE_CONNECTION_STATES = Object.freeze([
      "connected",
      "unsupported",
      "not-installed",
      "forbidden",
      "crashed",
      "timeout",
      "error"
    ]);
  }
});

// src/lib/native.js
function base(url) {
  return assertLocalUrl(url || DEFAULT_NATIVE_URL);
}
async function nativeHealth(url, timeoutMs = 1500) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/health`, { signal: ctrl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeGetModels(url, timeoutMs = 5e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/models`, { signal: ctrl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeGetUiPrefs(url, timeoutMs = 1500) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/ui-prefs`, { signal: ctrl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeSetUiPrefs(url, patch, timeoutMs = 1500) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/ui-prefs`, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(patch || {}),
      signal: ctrl.signal
    });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeGetNotes(url, timeoutMs = 3e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/notes`, { signal: ctrl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeSaveNote(url, note, timeoutMs = 5e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/notes`, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({ note }),
      signal: ctrl.signal
    });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeDeleteNote(url, id3, timeoutMs = 3e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/notes/${encodeURIComponent(id3)}`, {
      method: "DELETE",
      signal: ctrl.signal
    });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeShutdown(url, timeoutMs = 3e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/shutdown`, { method: "POST", signal: ctrl.signal });
    return r.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeGetDevice(url, timeoutMs = 2e3) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/engine/device`, { signal: ctrl.signal });
    if (r.status === 404) return { supported: false };
    if (!r.ok) throw new Error(`native /engine/device ${r.status}`);
    const j = await r.json();
    return { supported: true, ...j };
  } catch (e) {
    if (e?.name === "AbortError") return { supported: false };
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
async function nativeSetDevice(url, device, timeoutMs = 3e3) {
  if (!HELPER_DEVICE_OPTIONS.includes(device)) throw new Error(`device must be one of ${HELPER_DEVICE_OPTIONS.join(", ")}`);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base(url)}/engine/device`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ device }),
      signal: ctrl.signal
    });
    if (r.status === 404) return { supported: false, device, restart_required: true };
    if (!r.ok) throw new Error(`native /engine/device ${r.status}: ${await r.text()}`);
    return { supported: true, ...await r.json() };
  } finally {
    clearTimeout(timer);
  }
}
var HELPER_DEVICE_OPTIONS;
var init_native = __esm({
  "src/lib/native.js"() {
    init_registry();
    init_native_protocol();
    HELPER_DEVICE_OPTIONS = ["auto", "cpu", "cuda"];
  }
});

// src/lib/notes-schema.js
function normalizeProjectType(v) {
  const t2 = String(v || "").trim().toLowerCase();
  return PROJECT_TYPES.includes(t2) ? t2 : "general";
}
function rnd() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID().slice(0, 8);
  return Math.random().toString(36).slice(2, 10);
}
function toTimecode(sec) {
  const s = Math.max(0, Math.floor(num(sec, 0)));
  const h = String(Math.floor(s / 3600)).padStart(2, "0");
  const m = String(Math.floor(s % 3600 / 60)).padStart(2, "0");
  const r = String(s % 60).padStart(2, "0");
  return `${h}:${m}:${r}`;
}
function normalizeText(value, locale = "en") {
  if (value == null) return {};
  if (typeof value === "string") return value.trim() ? { [locale]: value.trim() } : {};
  const out = {};
  for (const [k, v] of Object.entries(value)) {
    const t2 = str(v).trim();
    if (t2) out[k] = t2;
  }
  return out;
}
function pickText(text, lang, fallbackLocale = "en") {
  if (!text) return "";
  return text[lang] || text[fallbackLocale] || text.en || Object.values(text)[0] || "";
}
function createProvenance(partial) {
  if (!partial) return null;
  const t0 = num(partial.t0, 0);
  return {
    t0,
    t1: num(partial.t1, t0),
    tc: partial.tc ? str(partial.tc) : toTimecode(t0),
    speaker: strOrNull(partial.speaker),
    lang: str(partial.lang || "auto"),
    orig: str(partial.orig),
    tr: str(partial.tr),
    segmentIds: Array.isArray(partial.segmentIds) ? partial.segmentIds.map(String) : [],
    meetingId: strOrNull(partial.meetingId)
  };
}
function createMetric(partial) {
  if (!partial) return null;
  const value = num(partial.value, NaN);
  if (!Number.isFinite(value)) return null;
  const baseline = partial.baseline == null ? null : num(partial.baseline, NaN);
  const hasBaseline = baseline != null && Number.isFinite(baseline);
  return {
    measure: str(partial.measure || "unnamed"),
    value,
    baseline: hasBaseline ? baseline : null,
    variance: partial.variance != null && Number.isFinite(Number(partial.variance)) ? Number(partial.variance) : hasBaseline ? Number((value - baseline).toFixed(6)) : null,
    unit: str(partial.unit || ""),
    asOf: strOrNull(partial.asOf),
    sourceDoc: strOrNull(partial.sourceDoc)
  };
}
function createCorrection(partial) {
  if (!partial || typeof partial !== "object") return null;
  const from = str(partial.from).trim();
  const to = str(partial.to).trim();
  if (!from || !to || from === to) return null;
  return { from, to, origPhrase: strOrNull(partial.origPhrase) };
}
function createMinuteItem(partial = {}, { locale = "en" } = {}) {
  const type = oneOf(partial.type, ITEM_TYPES, "info");
  return {
    ref: str(partial.ref || `TMP-${rnd()}`),
    type,
    topic: str(partial.topic || "general"),
    agenda: strOrNull(partial.agenda),
    text: normalizeText(partial.text, locale),
    owner: strOrNull(partial.owner),
    org: strOrNull(partial.org),
    due: strOrNull(partial.due),
    status: oneOf(partial.status, ITEM_STATUSES, type === "info" ? "closed" : "open"),
    priority: oneOf(partial.priority, ["high", "med", "low"], "med"),
    likelihood: oneOf(partial.likelihood, LIKELIHOODS, "possible"),
    review: oneOf(partial.review, REVIEW_STATES, "ai"),
    confidence: Math.min(1, Math.max(0, num(partial.confidence, 1))),
    src: createProvenance(partial.src),
    metric: type === "metric" ? createMetric(partial.metric) : null,
    correction: createCorrection(partial.correction),
    carriedFrom: strOrNull(partial.carriedFrom),
    openedAt: strOrNull(partial.openedAt),
    links: Array.isArray(partial.links) ? partial.links.map(String) : [],
    history: Array.isArray(partial.history) ? partial.history.map(createRevision) : []
  };
}
function createRevision(partial = {}) {
  return {
    at: str(partial.at || (/* @__PURE__ */ new Date()).toISOString()),
    by: str(partial.by || "local"),
    field: str(partial.field || ""),
    from: partial.from ?? null,
    to: partial.to ?? null
  };
}
function createMeeting(partial = {}) {
  const locale = str(partial.locale || "en");
  const date = str(partial.date || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
  return {
    id: str(partial.id || `MOM-${rnd()}`),
    seriesId: str(partial.seriesId || "default"),
    seq: num(partial.seq, 1),
    projectType: normalizeProjectType(partial.projectType),
    title: str(partial.title || "Untitled meeting").trim(),
    date,
    start: strOrNull(partial.start),
    end: strOrNull(partial.end),
    tz: str(partial.tz || "local"),
    chair: strOrNull(partial.chair),
    attendees: (Array.isArray(partial.attendees) ? partial.attendees : []).map((a) => ({
      name: str(a?.name),
      org: strOrNull(a?.org),
      speakerLabel: strOrNull(a?.speakerLabel)
    })).filter((a) => a.name),
    agenda: (Array.isArray(partial.agenda) ? partial.agenda : []).map((a) => ({
      ref: str(a?.ref),
      title: normalizeText(a?.title, locale),
      covered: !!a?.covered
    })).filter((a) => a.ref),
    topics: partial.topics && typeof partial.topics === "object" ? partial.topics : {},
    summary: normalizeText(partial.summary, locale),
    items: (Array.isArray(partial.items) ? partial.items : []).map(
      (i) => createMinuteItem(i, { locale })
    ),
    engine: partial.engine ? {
      asr: str(partial.engine.asr),
      mt: strOrNull(partial.engine.mt),
      extractor: strOrNull(partial.engine.extractor),
      segments: num(partial.engine.segments, 0),
      durationSec: partial.engine.durationSec == null ? null : num(partial.engine.durationSec, 0)
    } : null,
    generatedAt: str(partial.generatedAt || (/* @__PURE__ */ new Date()).toISOString()),
    issuedAt: strOrNull(partial.issuedAt),
    locale,
    schemaVersion: NOTE_SCHEMA_VERSION
  };
}
function nextRef(meeting, prefix) {
  const p = prefix || `W${String(meeting.seq).padStart(2, "0")}`;
  let max = 0;
  for (const it of meeting.items) {
    const m = /^(.+)-(\d+)$/.exec(it.ref);
    if (m && m[1] === p) max = Math.max(max, Number(m[2]));
  }
  return `${p}-${String(max + 1).padStart(3, "0")}`;
}
function assertMeeting(meeting) {
  if (!meeting || typeof meeting !== "object") throw new Error("meeting harus objek");
  const m = (
    /** @type {Record<string, unknown>} */
    meeting
  );
  if (typeof m.id !== "string" || !m.id) throw new Error("meeting.id wajib string");
  if (typeof m.seriesId !== "string" || !m.seriesId) throw new Error("meeting.seriesId wajib");
  if (!Array.isArray(m.items)) throw new Error("meeting.items wajib array");
  for (const it of m.items) {
    if (!it || typeof it !== "object") throw new Error("item invalid");
    const i = (
      /** @type {Record<string, unknown>} */
      it
    );
    if (typeof i.ref !== "string" || !i.ref) throw new Error("item.ref wajib");
    if (!ITEM_TYPES.includes(
      /** @type {any} */
      i.type
    )) {
      throw new Error(`item.type tidak dikenal: ${String(i.type)}`);
    }
    if (!i.text || typeof i.text !== "object") throw new Error(`item ${i.ref}: text wajib objek`);
  }
  return createMeeting(m);
}
function wrapMeetingStore(meetings) {
  return {
    schemaVersion: NOTE_SCHEMA_VERSION,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    meetings: meetings.map((m) => assertMeeting(m))
  };
}
function meetingStats(meeting, today2 = /* @__PURE__ */ new Date()) {
  const items = meeting.items || [];
  const actions = items.filter((i) => i.type === "action");
  const isOpen = (i) => i.status !== "closed";
  const daysTo = (iso) => iso ? Math.round((/* @__PURE__ */ new Date(`${iso}T00:00:00Z`) - startOfDayUTC(today2)) / 864e5) : null;
  const overdue = items.filter((i) => isOpen(i) && i.due && daysTo(i.due) < 0);
  const covered = (meeting.agenda || []).filter((a) => a.covered).length;
  const agendaTotal = (meeting.agenda || []).length;
  const progress = items.find(
    (i) => i.type === "metric" && i.metric && i.metric.measure === "cumulative_progress"
  );
  return {
    total: items.length,
    actionsOpen: actions.filter(isOpen).length,
    actionsTotal: actions.length,
    overdue: overdue.length,
    decisions: items.filter((i) => i.type === "decision").length,
    questionsOpen: items.filter((i) => i.type === "question" && isOpen(i)).length,
    unreviewed: items.filter((i) => i.review === "ai").length,
    lowConfidence: items.filter((i) => i.confidence < LOW_CONFIDENCE).length,
    carried: items.filter((i) => i.carriedFrom).length,
    agendaCovered: covered,
    agendaTotal,
    agendaPct: agendaTotal ? Math.round(covered / agendaTotal * 100) : 0,
    variance: progress?.metric?.variance ?? null,
    varianceUnit: progress?.metric?.unit ?? ""
  };
}
function startOfDayUTC(d) {
  const x = new Date(d);
  return new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), x.getUTCDate()));
}
var NOTE_SCHEMA_VERSION, ITEM_TYPES, PROJECT_TYPES, ITEM_STATUSES, REVIEW_STATES, LIKELIHOODS, TYPE_COLOR, LOW_CONFIDENCE, oneOf, str, strOrNull, num;
var init_notes_schema = __esm({
  "src/lib/notes-schema.js"() {
    NOTE_SCHEMA_VERSION = 2;
    ITEM_TYPES = /** @type {const} */
    [
      "decision",
      "action",
      "question",
      "risk",
      "metric",
      "info"
    ];
    PROJECT_TYPES = /** @type {const} */
    [
      "general",
      "weekly-progress",
      "hse",
      "design-review",
      "client-review",
      "standup",
      "sprint",
      "sales",
      "finance",
      "legal",
      "training",
      "research",
      "healthcare",
      "education"
    ];
    ITEM_STATUSES = /** @type {const} */
    ["open", "progress", "closed", "carried"];
    REVIEW_STATES = /** @type {const} */
    ["ai", "accepted", "edited"];
    LIKELIHOODS = /** @type {const} */
    ["certain", "likely", "possible", "unlikely"];
    TYPE_COLOR = {
      decision: "#7fb3d5",
      action: "#e0b05c",
      question: "#b79ce0",
      risk: "#e06c75",
      metric: "#4fb8c9",
      info: "#9a9a9a"
    };
    LOW_CONFIDENCE = 0.7;
    oneOf = (v, list, fallback) => list.includes(v) ? v : fallback;
    str = (v) => v == null ? "" : String(v);
    strOrNull = (v) => v == null || v === "" ? null : String(v);
    num = (v, d = 0) => Number.isFinite(Number(v)) ? Number(v) : d;
  }
});

// src/lib/notes-migrate.js
function migrateNoteV1(v1) {
  const locale = String(v1?.locale || "id");
  const date = String(v1?.generatedAt || (/* @__PURE__ */ new Date()).toISOString()).slice(0, 10);
  const seq = 1;
  const prefix = "V1";
  const items = [];
  let n = 0;
  const ref = () => `${prefix}-${String(++n).padStart(3, "0")}`;
  if (v1?.summary) {
    items.push(
      createMinuteItem(
        {
          ref: ref(),
          type: "info",
          topic: "summary",
          text: { [locale]: String(v1.summary) },
          status: "closed",
          review: "ai",
          confidence: 0,
          src: NO_SOURCE
        },
        { locale }
      )
    );
  }
  for (const d of Array.isArray(v1?.decisions) ? v1.decisions : []) {
    if (!String(d || "").trim()) continue;
    items.push(
      createMinuteItem(
        {
          ref: ref(),
          type: "decision",
          topic: "general",
          text: { [locale]: String(d) },
          status: "closed",
          review: "ai",
          confidence: 0,
          src: NO_SOURCE
        },
        { locale }
      )
    );
  }
  for (const a of Array.isArray(v1?.actions) ? v1.actions : []) {
    if (!a || !String(a.text || "").trim()) continue;
    items.push(
      createMinuteItem(
        {
          ref: ref(),
          type: "action",
          topic: "general",
          text: { [locale]: String(a.text) },
          owner: a.owner ?? null,
          due: a.due ?? null,
          status: a.status === "done" ? "closed" : "open",
          openedAt: date,
          review: "ai",
          confidence: 0,
          src: NO_SOURCE
        },
        { locale }
      )
    );
  }
  const meeting = createMeeting({
    id: String(v1?.id || `MOM-${date}`),
    seriesId: "imported-v1",
    seq,
    title: String(v1?.title || "Imported meeting"),
    date,
    generatedAt: v1?.generatedAt,
    locale,
    items,
    topics: {
      summary: { en: "Summary", id: "Ringkasan" },
      general: { en: "General", id: "Umum" }
    }
  });
  meeting.legacyPreview = String(v1?.transcriptPreview || "");
  meeting.legacySource = String(v1?.source || "");
  return meeting;
}
function migrateStore(raw) {
  if (!raw || typeof raw !== "object") {
    return { schemaVersion: NOTE_SCHEMA_VERSION, updatedAt: null, meetings: [], migrated: 0 };
  }
  if (Number(raw.schemaVersion) >= NOTE_SCHEMA_VERSION && Array.isArray(raw.meetings)) {
    return {
      schemaVersion: NOTE_SCHEMA_VERSION,
      updatedAt: raw.updatedAt ?? null,
      meetings: raw.meetings,
      migrated: 0
    };
  }
  const legacy = Array.isArray(raw.notes) ? raw.notes : [];
  const meetings = legacy.map((n) => migrateNoteV1(n));
  return {
    schemaVersion: NOTE_SCHEMA_VERSION,
    updatedAt: raw.updatedAt ?? null,
    meetings,
    migrated: meetings.length
  };
}
var NO_SOURCE;
var init_notes_migrate = __esm({
  "src/lib/notes-migrate.js"() {
    init_notes_schema();
    NO_SOURCE = null;
  }
});

// src/lib/notes-store.js
var notes_store_exports = {};
__export(notes_store_exports, {
  __resetForTests: () => __resetForTests,
  backendName: () => backendName,
  deleteMeeting: () => deleteMeeting,
  getMeeting: () => getMeeting,
  listMeetings: () => listMeetings,
  listOpenItems: () => listOpenItems,
  listSeries: () => listSeries,
  saveMeeting: () => saveMeeting,
  searchItems: () => searchItems,
  setBackend: () => setBackend
});
function detectBackend() {
  if (typeof chrome !== "undefined" && chrome?.storage?.local) return chromeBackend;
  if (typeof localStorage !== "undefined") return localBackend;
  return memoryBackend;
}
function setBackend(next) {
  const prev = backend;
  backend = next || detectBackend();
  return prev;
}
function backendName() {
  return backend.name;
}
async function readStore() {
  let raw = await backend.get(KEY);
  let fromLegacy = false;
  if (!raw) {
    const legacy = await backend.get(LEGACY_KEY);
    if (legacy) {
      raw = legacy;
      fromLegacy = true;
    }
  }
  const upgraded = migrateStore(raw);
  if (upgraded.migrated > 0 || fromLegacy) {
    await backend.set(KEY, wrapMeetingStore(upgraded.meetings.map((m) => createMeeting(m))));
  }
  return upgraded;
}
async function writeStore(meetings) {
  const env = wrapMeetingStore(meetings.slice(0, MAX_MEETINGS));
  await backend.set(KEY, env);
  return env;
}
async function listMeetings() {
  const { meetings } = await readStore();
  return meetings.map((m) => createMeeting(m)).sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : b.seq - a.seq);
}
async function getMeeting(id3) {
  const all = await listMeetings();
  return all.find((m) => m.id === id3) || null;
}
async function saveMeeting(partial) {
  const meeting = assertMeeting(createMeeting(partial));
  const prev = await listMeetings();
  const next = [meeting, ...prev.filter((m) => m.id !== meeting.id)];
  await writeStore(next);
  return meeting;
}
async function deleteMeeting(id3) {
  const prev = await listMeetings();
  const next = prev.filter((m) => m.id !== id3);
  await writeStore(next);
  return next.length;
}
async function listSeries(seriesId) {
  const all = await listMeetings();
  return all.filter((m) => m.seriesId === seriesId).sort((a, b) => a.seq - b.seq);
}
async function listOpenItems(seriesId) {
  const meetings = await listSeries(seriesId);
  const rows = [];
  for (const meeting of meetings) {
    for (const item of meeting.items) {
      if (item.status === "closed") continue;
      if (item.type === "info" || item.type === "metric") continue;
      rows.push({ item, meeting });
    }
  }
  return rows;
}
async function searchItems(query, { seriesId = null } = {}) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return [];
  const meetings = seriesId ? await listSeries(seriesId) : await listMeetings();
  const hits = [];
  for (const meeting of meetings) {
    for (const item of meeting.items) {
      const hay = [
        item.ref,
        item.owner || "",
        ...Object.values(item.text || {}),
        item.src?.orig || "",
        item.src?.tr || "",
        item.src?.speaker || ""
      ].join(" ").toLowerCase();
      if (hay.includes(q)) hits.push({ item, meeting });
    }
  }
  return hits;
}
async function __resetForTests() {
  memory.clear();
  await backend.set(KEY, null);
}
var KEY, LEGACY_KEY, MAX_MEETINGS, memory, memoryBackend, chromeBackend, localBackend, backend;
var init_notes_store = __esm({
  "src/lib/notes-store.js"() {
    init_notes_schema();
    init_notes_migrate();
    KEY = "minutesRegister";
    LEGACY_KEY = "meetingNotes";
    MAX_MEETINGS = 500;
    memory = /* @__PURE__ */ new Map();
    memoryBackend = {
      name: "memory",
      async get(key) {
        return memory.get(key) ?? null;
      },
      async set(key, value) {
        memory.set(key, value);
      }
    };
    chromeBackend = {
      name: "chrome.storage.local",
      async get(key) {
        const out = await chrome.storage.local.get(key);
        return out?.[key] ?? null;
      },
      async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
      }
    };
    localBackend = {
      name: "localStorage",
      async get(key) {
        try {
          const raw = localStorage.getItem(key);
          return raw ? JSON.parse(raw) : null;
        } catch {
          return null;
        }
      },
      async set(key, value) {
        try {
          localStorage.setItem(key, JSON.stringify(value));
        } catch {
          memory.set(key, value);
        }
      }
    };
    backend = detectBackend();
  }
});

// src/lib/notes-generate.js
var notes_generate_exports = {};
__export(notes_generate_exports, {
  generateNotesFromTranscript: () => generateNotesFromTranscript
});
function guessOwner(text, speaker) {
  const m = /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:will|to|akan|please)\b/.exec(text);
  const cand = m && m[1];
  if (cand && !NOT_A_NAME.has(cand.split(/\s+/)[0])) return cand;
  return speaker || null;
}
function classify(text) {
  if (PLEASANTRY_RE.test(text) || CHECKIN_RE.test(text)) return null;
  if (DECISION_RE.test(text)) return "decision";
  if (ACTION_RE.test(text)) return "action";
  if (RISK_RE.test(text)) return "risk";
  if (QUESTION_RE.test(text) && text.length >= MIN_QUESTION_CHARS) return "question";
  return null;
}
function generateNotesFromTranscript(lines, meta = {}) {
  const locale = meta.locale || "en";
  const rows = (Array.isArray(lines) ? lines : []).map((l) => ({
    text: String(l?.text ?? l?.tgt ?? l?.src ?? "").trim(),
    speaker: l?.speaker ? String(l.speaker) : null,
    t0: Number(l?.t0) || 0,
    t1: Number(l?.t1 ?? l?.t0) || 0
  })).filter((r) => r.text);
  const items = [];
  let n = 0;
  for (const r of rows) {
    const type = classify(r.text);
    if (!type || r.text.length < 12) continue;
    n += 1;
    items.push(
      createMinuteItem(
        {
          ref: `AI-${String(n).padStart(3, "0")}`,
          type,
          text: r.text,
          owner: type === "action" ? guessOwner(r.text, r.speaker) : null,
          // Heuristik lokal tidak pernah seyakin manusia; tandai agar ditelaah.
          review: "ai",
          confidence: 0.6,
          src: { t0: r.t0, t1: r.t1, speaker: r.speaker, orig: r.text, lang: locale }
        },
        { locale }
      )
    );
  }
  const speakers = [...new Set(rows.map((r) => r.speaker).filter(Boolean))];
  const summary = rows.length ? `${rows.length} segmen transkrip dari ${speakers.length || 1} pembicara; ${items.length} butir terdeteksi otomatis.` : "Transkrip kosong \u2014 tidak ada yang bisa diringkas.";
  return createMeeting({
    title: meta.title || "Untitled meeting",
    date: meta.date,
    seriesId: meta.seriesId,
    projectType: meta.projectType,
    locale,
    attendees: speakers.map((name) => ({ name, speakerLabel: name })),
    summary,
    items,
    engine: {
      asr: meta.source || "pasted-transcript",
      extractor: "heuristic-v2",
      segments: rows.length,
      durationSec: rows.length ? rows[rows.length - 1].t1 || rows[rows.length - 1].t0 : 0
    }
  });
}
var DECISION_RE, ACTION_RE, RISK_RE, QUESTION_RE, PLEASANTRY_RE, CHECKIN_RE, MIN_QUESTION_CHARS, NOT_A_NAME;
var init_notes_generate = __esm({
  "src/lib/notes-generate.js"() {
    init_notes_schema();
    DECISION_RE = /\b(?:keputusan|diputuskan|kita putuskan|we (?:decided|agreed)|it was agreed|decision|agreed to|sepakat)\b/i;
    ACTION_RE = new RegExp(
      [
        "\\baction item\\b",
        "\\btindak lanjut\\b",
        "\\bfollow up\\b",
        "\\bto be (?:established|reviewed|inspected|completed|submitted|removed|secured|checked)\\b",
        "\\bto (?:review|check|carry out|inspect|prepare|submit|update|ensure|establish|remove|secure|add)\\b",
        "\\bwill (?:send|share|prepare|check|update|review|submit|provide)\\b",
        "\\bplease \\w+",
        "\\b(?:shall|must|need to|required to)\\b",
        "\\bakan (?:mengirim|menyiapkan|mengecek|memperbarui|meninjau)\\b",
        "\\b(?:harus|mohon|segera)\\b",
        "\\brecommendation\\b"
      ].join("|"),
      "i"
    );
    RISK_RE = /\b(?:risk|risiko|issue|kendala|delay|terlambat|blocker|incident|insiden|concern)\b/i;
    QUESTION_RE = /\?\s*$/;
    PLEASANTRY_RE = /^(?:hi\b|hello\b|good (?:morning|afternoon|evening)|thank you|thanks|bye|okay[.! ]*$|ok[.! ]*$|yeah|selamat (?:pagi|siang|sore)|terima kasih)/i;
    CHECKIN_RE = /\b(?:can you hear me|are you there|is it clear|do you hear me|sound ok|bisa dengar)\b/i;
    MIN_QUESTION_CHARS = 40;
    NOT_A_NAME = /* @__PURE__ */ new Set([
      "So",
      "Then",
      "And",
      "But",
      "We",
      "You",
      "They",
      "It",
      "This",
      "That",
      "Please",
      "Now",
      "Okay",
      "Ok",
      "After",
      "Before",
      "Also",
      "However",
      "Jadi",
      "Lalu",
      "Kemudian",
      "Mohon",
      "Kami",
      "Kita",
      "Saya",
      "Anda"
    ]);
  }
});

// src/lib/teams-transcript.js
var teams_transcript_exports = {};
__export(teams_transcript_exports, {
  looksLikeTeamsTranscript: () => looksLikeTeamsTranscript,
  parseTeamsTranscript: () => parseTeamsTranscript
});
function isNoise(line) {
  return NOISE.some((re) => re.test(line));
}
function parseHeader(line) {
  if (!/\d+\s+(minutes?|seconds?)\s*$/i.test(line)) return null;
  const m = HEADER.exec(line);
  if (!m) return null;
  const speaker = (m[1] || "").trim().replace(/[,\s]+$/, "");
  if (!speaker || BARE_TIME.test(speaker) || AVATAR.test(speaker)) return null;
  const mins = Number(m[2] || 0);
  const secs = Number(m[3] || 0);
  if (!m[2] && !m[3]) return null;
  return { speaker, t0: mins * 60 + secs };
}
function parseTeamsTranscript(raw) {
  const rows = String(raw ?? "").split(/\r?\n/).map((l) => l.trim());
  const known = /* @__PURE__ */ new Set();
  for (const row of rows) {
    const h = parseHeader(row);
    if (h) known.add(h.speaker);
  }
  const lines = [];
  let current = null;
  const flush = () => {
    if (current && current.text.trim()) {
      lines.push({ speaker: current.speaker, t0: current.t0, text: current.text.trim() });
    }
    current = null;
  };
  for (const row of rows) {
    if (!row || isNoise(row) || BARE_TIME.test(row) || AVATAR.test(row)) continue;
    const head = parseHeader(row);
    if (head) {
      flush();
      current = { ...head, text: "" };
      continue;
    }
    if (known.has(row)) continue;
    if (!current) continue;
    current.text += (current.text ? " " : "") + row;
  }
  flush();
  const speakers = [...new Set(lines.map((l) => l.speaker))];
  const durationSec = lines.length ? lines[lines.length - 1].t0 : 0;
  return { lines, speakers, durationSec };
}
function looksLikeTeamsTranscript(raw) {
  const s = String(raw ?? "");
  if (!s.trim()) return false;
  if (/\bstarted transcription\b/i.test(s)) return true;
  const heads = s.split(/\r?\n/).filter((l) => parseHeader(l.trim()));
  return heads.length >= 2;
}
var NOISE, BARE_TIME, AVATAR, HEADER;
var init_teams_transcript = __esm({
  "src/lib/teams-transcript.js"() {
    NOISE = [
      /^transcript\b/i,
      /^search$/i,
      /^ai-generated content may be incorrect$/i,
      /\bstarted transcription$/i,
      /\bstopped transcription$/i,
      /^use arrow keys/i
    ];
    BARE_TIME = /^(?:\d+\s+minutes?\s*(?:\d+\s+seconds?)?)?\s*\d{1,2}:\d{2}$/i;
    AVATAR = /^[A-Z]{1,3}$/;
    HEADER = /^(.+?)\s+(?:(\d+)\s+minutes?)?(?:\s*(\d+)\s+seconds?)?$/i;
  }
});

// src/lib/notes-sync.js
var notes_sync_exports = {};
__export(notes_sync_exports, {
  deleteSharedNote: () => deleteSharedNote,
  docToSummary: () => docToSummary,
  meetingToDoc: () => meetingToDoc,
  pullSharedNotes: () => pullSharedNotes,
  pushMeetingToHelper: () => pushMeetingToHelper
});
function textOf(t2, lang = "en") {
  if (!t2) return "";
  if (typeof t2 === "string") return t2;
  return t2[lang] || t2.en || Object.values(t2)[0] || "";
}
function meetingToDoc(meeting, lang = meeting?.locale || "en") {
  const items = meeting?.items || [];
  return {
    id: meeting.id,
    title: meeting.title || "Notulen sesi",
    date: meeting.date || "",
    source: "extension",
    status: meeting.issuedAt ? "issued" : "ready",
    summary: textOf(meeting.summary, lang),
    decisions: items.filter((i) => i.type === "decision").map((i) => textOf(i.text, lang)).filter(Boolean),
    actions: items.filter((i) => i.type === "action").map((i, n) => ({
      id: i.ref || `act-${n + 1}`,
      text: textOf(i.text, lang),
      owner: i.owner || null,
      due: i.due || null,
      status: i.status === "closed" ? "closed" : "open"
    })).filter((a) => a.text),
    transcriptPreview: ""
  };
}
function docToSummary(doc, lang = "en") {
  return {
    id: doc?.id || "",
    title: doc?.title || "Notulen sesi",
    date: doc?.date || "",
    source: doc?.source || "helper",
    summary: typeof doc?.summary === "string" ? doc.summary : textOf(doc?.summary, lang),
    decisions: Array.isArray(doc?.decisions) ? doc.decisions.length : 0,
    actions: Array.isArray(doc?.actions) ? doc.actions.length : 0
  };
}
async function pushMeetingToHelper(url, meeting, lang) {
  if (!meeting) return null;
  const res = await nativeSaveNote(url, meetingToDoc(meeting, lang));
  return res?.note || null;
}
async function pullSharedNotes(url, lang = "en") {
  const res = await nativeGetNotes(url);
  const notes = res?.notes;
  if (!Array.isArray(notes)) return [];
  return notes.map((n) => docToSummary(n, lang));
}
async function deleteSharedNote(url, id3) {
  const res = await nativeDeleteNote(url, id3);
  return !!res?.ok;
}
var init_notes_sync = __esm({
  "src/lib/notes-sync.js"() {
    init_native();
    init_notes_schema();
  }
});

// src/lib/notes-export.js
var notes_export_exports = {};
__export(notes_export_exports, {
  serializeMeetingCsv: () => serializeMeetingCsv,
  serializeMeetingMarkdown: () => serializeMeetingMarkdown,
  serializeMeetingTxt: () => serializeMeetingTxt
});
function label(T, key, fallback) {
  if (!T) return fallback;
  const v = T(key);
  return v === key ? fallback : v;
}
function serializeMeetingMarkdown(meeting, lang = meeting.locale || "en", T = null) {
  const stats = meetingStats(meeting);
  const lines = [
    `# ${meeting.title}`,
    "",
    `_${meeting.id}_ \xB7 ${meeting.date}${meeting.start ? ` \xB7 ${meeting.start}${meeting.end ? `\u2013${meeting.end}` : ""}${meeting.tz ? ` ${meeting.tz}` : ""}` : ""}${meeting.chair ? ` \xB7 ${label(T, "chair", "Chair")}: ${meeting.chair}` : ""}${meeting.projectType && meeting.projectType !== "general" ? ` \xB7 ${label(T, "projectType", "Type")}: ${label(T, ptKey2(meeting.projectType), meeting.projectType)}` : ""}`,
    meeting.issuedAt ? `_${label(T, "issued", "Issued")}: ${meeting.issuedAt}_` : "_Draft \u2014 not yet issued_",
    "",
    `${stats.total} items \xB7 ${stats.actionsOpen}/${stats.actionsTotal} actions open \xB7 ${stats.decisions} decisions \xB7 ${stats.questionsOpen} open questions \xB7 agenda ${stats.agendaPct}% covered`,
    ""
  ];
  if (meeting.agenda?.length) {
    lines.push(`## Agenda`, "");
    for (const a of meeting.agenda) {
      lines.push(`- [${a.covered ? "x" : " "}] ${a.ref} \u2014 ${pickText(a.title, lang)}`);
    }
    lines.push("");
  }
  for (const [type, key, fallback] of DOC_SECTIONS) {
    const rows = meeting.items.filter((i) => i.type === type);
    if (!rows.length) continue;
    lines.push(`## ${label(T, key, fallback)}`, "");
    for (const it of rows) {
      const meta = [];
      if (it.owner) meta.push(it.owner);
      if (it.due) meta.push(`due ${it.due}`);
      if (it.status && it.status !== "open") meta.push(it.status);
      if (it.type === "metric" && it.metric) {
        meta.push(`${it.metric.value}${it.metric.unit}${it.metric.baseline != null ? ` (baseline ${it.metric.baseline}${it.metric.unit})` : ""}`);
      }
      const suffix = meta.length ? ` \u2014 ${meta.join(" \xB7 ")}` : "";
      const flag = it.review === "ai" ? " \u2021" : "";
      lines.push(`- **${it.ref}** ${pickText(it.text, lang)}${suffix}${flag}`);
    }
    lines.push("");
  }
  const unreviewed = meeting.items.filter((i) => i.review === "ai");
  lines.push(
    "---",
    unreviewed.length ? `\u2021 ${unreviewed.length} item(s) still AI-drafted, not yet reviewed by a human.` : "Every item has been reviewed by a human.",
    `Drafted on-device${meeting.engine ? ` \u2014 ${meeting.engine.asr}` : ""}. Nothing left this machine.`,
    ""
  );
  return lines.join("\n");
}
function serializeMeetingTxt(meeting, lang = meeting.locale || "en") {
  const stats = meetingStats(meeting);
  const lines = [
    meeting.title,
    `${meeting.id} \xB7 ${meeting.date}`,
    ...meeting.projectType && meeting.projectType !== "general" ? [`Type: ${meeting.projectType}`] : [],
    meeting.issuedAt ? `Issued: ${meeting.issuedAt}` : "Draft \u2014 not yet issued",
    "",
    `${stats.total} items \xB7 ${stats.actionsOpen}/${stats.actionsTotal} actions open \xB7 ${stats.decisions} decisions`,
    ""
  ];
  const summary = meeting.summary?.[lang] || meeting.summary?.en || Object.values(meeting.summary || {})[0] || "";
  if (summary) lines.push("Summary", summary, "");
  for (const [type, title] of [["decision", "Decisions"], ["action", "Action items"]]) {
    const rows = meeting.items.filter((i) => i.type === type);
    if (!rows.length) continue;
    lines.push(title);
    for (const it of rows) {
      const meta = [];
      if (it.owner) meta.push(it.owner);
      if (it.due) meta.push(`due ${it.due}`);
      if (it.status && it.status !== "open") meta.push(it.status);
      lines.push(`- [${it.ref}] ${pickText(it.text, lang)}${meta.length ? ` \u2014 ${meta.join(" \xB7 ")}` : ""}`);
    }
    lines.push("");
  }
  lines.push("Drafted on-device. Nothing left this machine.", "");
  return lines.join("\n");
}
function serializeMeetingCsv(meeting, lang = meeting.locale || "en") {
  const cols = ["ref", "type", "topic", "text", "owner", "due", "status", "review", "confidence"];
  const esc4 = (v) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows = meeting.items.map((it) => [
    it.ref,
    it.type,
    it.topic,
    pickText(it.text, lang),
    it.owner || "",
    it.due || "",
    it.status,
    it.review,
    it.confidence
  ]);
  return [cols.join(","), ...rows.map((r) => r.map(esc4).join(","))].join("\n");
}
var DOC_SECTIONS, ptKey2;
var init_notes_export = __esm({
  "src/lib/notes-export.js"() {
    init_notes_schema();
    DOC_SECTIONS = [
      ["decision", "docDecisions", "Decisions"],
      ["action", "docActions", "Action register"],
      ["question", "docQuestions", "Open questions"],
      ["risk", "docRisks", "Risks"],
      ["metric", "docMetrics", "Progress"],
      ["info", "docNotes", "Discussion notes"]
    ];
    ptKey2 = (t2) => `pt_${String(t2 || "").replace(/-/g, "_")}`;
  }
});

// src/sidepanel.js
init_registry();
init_native();

// src/lib/native-host.js
init_native_protocol();
var NATIVE_HOST_NAME = "com.localtranssub.helper";
async function nativeHostConnection({ timeoutMs = 4e3 } = {}) {
  const base2 = { host: NATIVE_HOST_NAME, info: null, helperPortOpen: null, error: null };
  if (!nativeHostSupported()) {
    return { ...base2, state: "unsupported", connected: false, hostInstalled: null };
  }
  try {
    const res = await nativeHostAction("ping", { timeoutMs });
    const stale = res?.ok === false && /unknown action/i.test(String(res?.error || ""));
    return {
      ...base2,
      state: "connected",
      connected: true,
      hostInstalled: true,
      info: res?.host || null,
      helperPortOpen: typeof res?.helper_port_open === "boolean" ? res.helper_port_open : null,
      error: stale ? "host lama: aksi ping belum didukung" : null
    };
  } catch (e) {
    const state2 = classifyNativeHostError(e);
    return { ...base2, state: state2, connected: false, hostInstalled: hostInstalledFromState(state2), error: String(e?.message || e) };
  }
}
function nativeHostSupported() {
  return typeof chrome?.runtime?.connectNative === "function";
}
function nativeHostAction(action, { timeoutMs = 45e3 } = {}) {
  return new Promise((resolve, reject) => {
    if (!nativeHostSupported()) {
      reject(new Error("Native messaging is not available in this browser"));
      return;
    }
    let settled = false;
    const finish = (fn, val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(val);
    };
    let port;
    try {
      port = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    } catch (e) {
      reject(e);
      return;
    }
    const timer = setTimeout(() => {
      try {
        port.disconnect();
      } catch {
      }
      finish(reject, new Error("Native host timed out"));
    }, timeoutMs);
    port.onMessage.addListener((msg) => {
      try {
        port.disconnect();
      } catch {
      }
      finish(resolve, msg);
    });
    port.onDisconnect.addListener(() => {
      if (settled) return;
      const err = chrome.runtime.lastError?.message;
      finish(reject, new Error(err || "Native host disconnected"));
    });
    port.postMessage({ action });
  });
}

// src/sidepanel.js
init_native_protocol();

// src/lib/transcript-cache.js
var SUBTITLE_MAX_CHARS = 84;
var SUBTITLE_LINE_CHARS = 42;
function splitSubtitleCues(lines, { maxChars = SUBTITLE_MAX_CHARS } = {}) {
  const out = [];
  for (const l of lines || []) {
    const t0 = Number(l.t0 ?? (l.t ?? 0) / 1e3) || 0;
    let t1 = Number(l.t1 ?? t0 + 3);
    if (!(t1 > t0)) t1 = t0 + 3;
    const src = (l.src || l.source || "").trim();
    const tgt = (l.tgt || l.translation || "").trim();
    const primary = tgt || src;
    if (!primary) continue;
    const chunks = chunkWords(primary, maxChars);
    const srcChunks = src && tgt && src !== tgt ? alignChunks(src, chunks.length) : null;
    const weights = chunks.map((c) => Math.max(1, c.replace(/\n/g, "").length));
    const totalW = weights.reduce((a, b) => a + b, 0);
    const dur = t1 - t0;
    let acc = 0;
    for (let i = 0; i < chunks.length; i++) {
      const start = t0 + dur * (acc / totalW);
      acc += weights[i];
      const end = i === chunks.length - 1 ? t1 : t0 + dur * (acc / totalW);
      const cueTgt = tgt ? chunks[i] : "";
      const cueSrc = srcChunks ? srcChunks[i] : tgt ? "" : chunks[i];
      out.push({
        t0: round3(start),
        t1: round3(Math.max(end, start + 0.05)),
        src: cueSrc || (tgt ? "" : chunks[i]),
        tgt: cueTgt || (!tgt ? chunks[i] : "")
      });
    }
  }
  return out;
}
function chunkWords(text, maxChars) {
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length) return [text];
  const chunks = [];
  let cur = "";
  for (const w of words) {
    const next = cur ? `${cur} ${w}` : w;
    if (next.length > maxChars && cur) {
      chunks.push(wrapCueLines(cur));
      cur = w.length > maxChars ? w.slice(0, maxChars) : w;
    } else {
      cur = next;
    }
  }
  if (cur) chunks.push(wrapCueLines(cur));
  return chunks;
}
function wrapCueLines(text) {
  if (text.length <= SUBTITLE_LINE_CHARS) return text;
  const words = text.split(/\s+/);
  let line1 = "";
  let i = 0;
  for (; i < words.length; i++) {
    const next = line1 ? `${line1} ${words[i]}` : words[i];
    if (next.length > SUBTITLE_LINE_CHARS && line1) break;
    line1 = next;
  }
  const line2 = words.slice(i).join(" ");
  return line2 ? `${line1}
${line2}` : line1;
}
function alignChunks(text, n) {
  const words = text.split(/\s+/).filter(Boolean);
  if (n <= 1) return [wrapCueLines(text)];
  if (!words.length) return Array(n).fill("");
  const chunks = [];
  const per = words.length / n;
  for (let i = 0; i < n; i++) {
    const a = Math.round(i * per);
    const b = Math.round((i + 1) * per);
    const part = words.slice(a, Math.max(b, a + (i === n - 1 ? 0 : 1))).join(" ");
    chunks.push(wrapCueLines(part || (i === n - 1 ? words.slice(a).join(" ") : "")));
  }
  if (chunks.length === n) {
    const used = chunks.join(" ").split(/\s+/).filter(Boolean).length;
    if (used < words.length) {
      chunks[n - 1] = wrapCueLines(words.slice(Math.round((n - 1) * per)).join(" "));
    }
  }
  return chunks;
}
function round3(n) {
  return Math.round(n * 1e3) / 1e3;
}
function normalizeCues(cues) {
  const out = (cues || []).map((c) => {
    const t0raw = Number(c.t0);
    const t0 = Number.isFinite(t0raw) ? Math.max(0, t0raw) : 0;
    const t1raw = Number(c.t1);
    const t1 = Number.isFinite(t1raw) && t1raw > t0 ? t1raw : t0 + 3;
    return { ...c, t0, t1 };
  });
  return out.map((c, i) => [c, i]).sort((a, b) => a[0].t0 - b[0].t0 || a[1] - b[1]).map(([c]) => c);
}
function cueBody(l) {
  const src = (l.src || l.source || "").trim();
  const tgt = (l.tgt || l.translation || "").trim();
  if (src && tgt && src !== tgt) return `${src}
${tgt}`;
  return tgt || src;
}
function formatSrt(lines, { url, title } = {}) {
  const cues = [];
  if (url || title) {
    const meta = [`yraverageSubMin`, title && `Title: ${title}`, url && `Source: ${url}`].filter(Boolean).join("\n");
    cues.push({ t0: 0, t1: 1e-3, src: "", tgt: meta, _meta: true });
  }
  for (const l of normalizeCues(splitSubtitleCues(lines || []))) {
    cues.push(l);
  }
  return cues.map((l, i) => {
    const t0 = l.t0 ?? 0;
    const t1 = l.t1 ?? t0 + 3;
    const text = l._meta ? l.tgt : cueBody(l);
    return `${i + 1}
${fmtSrt(t0)} --> ${fmtSrt(t1)}
${text}
`;
  }).join("\n");
}
function formatVtt(lines, { url, title } = {}) {
  const hdr = ["WEBVTT"];
  if (url) hdr.push(`NOTE Source: ${url}`);
  if (title) hdr.push(`NOTE Title: ${title}`);
  hdr.push("", "");
  const body = normalizeCues(splitSubtitleCues(lines || [])).map((l) => `${fmtVtt(l.t0)} --> ${fmtVtt(l.t1)}
${cueBody(l)}
`).join("\n");
  return hdr.join("\n") + body;
}
function formatTxt(lines, { url, title } = {}) {
  const hdr = [];
  if (title) hdr.push(`Title: ${title}`);
  if (url) hdr.push(`Source: ${url}`);
  if (hdr.length) hdr.push("", "---", "");
  const body = (lines || []).map((l) => {
    const t0 = l.t0 ?? (l.t ?? 0) / 1e3;
    const ts2 = fmtVtt(t0);
    const src = l.src || l.source || "";
    const tgt = l.tgt || l.translation || "";
    if (src && tgt) return `[${ts2}]
${src}
${tgt}`;
    return `[${ts2}] ${tgt || src}`;
  }).join("\n\n");
  return hdr.join("\n") + body;
}
function safeMs(sec) {
  const n = Number(sec);
  return Number.isFinite(n) ? Math.max(0, Math.round(n * 1e3)) : 0;
}
function fmtSrt(sec) {
  const ms = safeMs(sec);
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  const f = String(ms % 1e3).padStart(3, "0");
  return `${h}:${m}:${s},${f}`;
}
function fmtVtt(sec) {
  const ms = safeMs(sec);
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  const f = String(ms % 1e3).padStart(3, "0");
  return `${h}:${m}:${s}.${f}`;
}

// src/lib/session-search.js
function norm(s) {
  return String(s ?? "").toLocaleLowerCase().replace(/\s+/g, " ").trim();
}
function parseQuery(query) {
  const out = [];
  const re = /"([^"]+)"|(\S+)/g;
  let m;
  while ((m = re.exec(String(query ?? ""))) !== null) {
    const term = norm(m[1] ?? m[2]);
    if (term) out.push(term);
  }
  return out;
}
function haystack(session) {
  const lines = Array.isArray(session?.lines) ? session.lines : [];
  const body = lines.map((l) => `${l.src ?? l.source ?? ""} ${l.tgt ?? l.translation ?? ""}`).join(" ");
  return norm(`${session?.title ?? ""} ${session?.url ?? ""} ${body}`);
}
function matchingLines(session, query, limit = 3) {
  const terms = parseQuery(query);
  if (!terms.length) return [];
  const lines = Array.isArray(session?.lines) ? session.lines : [];
  const hits = [];
  for (const l of lines) {
    const text = norm(`${l.src ?? l.source ?? ""} ${l.tgt ?? l.translation ?? ""}`);
    if (terms.every((t2) => text.includes(t2))) hits.push(l);
    if (hits.length >= limit) break;
  }
  return hits;
}
function searchSessions(sessions, query) {
  const terms = parseQuery(query);
  const list = Array.isArray(sessions) ? sessions : [];
  if (!terms.length) return list;
  return list.filter((s) => {
    const hay = haystack(s);
    return terms.every((t2) => hay.includes(t2));
  });
}

// src/lib/export-formats.js
function ts(sec) {
  const ms = Math.max(0, Math.round(Number(sec) * 1e3) || 0);
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  return `${h}:${m}:${s}.${String(ms % 1e3).padStart(3, "0")}`;
}
function normLines(lines) {
  return (Array.isArray(lines) ? lines : []).map((l) => {
    const t0 = Number(l?.t0 ?? (l?.t ?? 0) / 1e3) || 0;
    const t1raw = l?.t1 != null ? Number(l.t1) : t0 + 3;
    return {
      t0,
      t1: t1raw > 1e3 ? t1raw / 1e3 : t1raw,
      // entri lama menyimpan ms
      src: String(l?.src ?? l?.source ?? ""),
      tgt: String(l?.tgt ?? l?.translation ?? "")
    };
  });
}
function formatMarkdown(lines, { title, url, dualLine = false } = {}) {
  const out = [`# ${title || "Transcript"}`, ""];
  if (url) out.push(`Source: <${url}>`, "");
  for (const l of normLines(lines)) {
    const primary = l.tgt || l.src;
    if (!primary) continue;
    out.push(`**${ts(l.t0)}** \u2014 ${primary}`);
    if (dualLine && l.src && l.tgt && l.src !== l.tgt) out.push(`> ${l.src}`);
    out.push("");
  }
  return out.join("\n");
}
function cell(v) {
  const s = String(v ?? "");
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function formatCsv(lines, { title, url } = {}) {
  const rows = [["start", "end", "duration", "source", "translation"].join(",")];
  for (const l of normLines(lines)) {
    rows.push([
      cell(ts(l.t0)),
      cell(ts(l.t1)),
      cell((l.t1 - l.t0).toFixed(2)),
      cell(l.src),
      cell(l.tgt)
    ].join(","));
  }
  return rows.join("\n");
}
function formatJson(lines, { title, url, srcLang, tgtLang } = {}) {
  return JSON.stringify(
    {
      kind: "yraverage-transcript",
      version: 1,
      title: title || "",
      url: url || "",
      srcLang: srcLang || "",
      tgtLang: tgtLang || "",
      lines: normLines(lines)
    },
    null,
    2
  );
}

// src/lib/export.js
var dirHandle = null;
async function loadExportDir() {
  try {
    const db = await openDb();
    const tx = db.transaction("handles", "readonly");
    const req = tx.objectStore("handles").get("exportDir");
    const handle = await reqToPromise(req);
    if (handle && await verifyPermission(handle)) {
      dirHandle = handle;
      return handle.name;
    }
  } catch {
  }
  return null;
}
async function pickExportDir() {
  if (!window.showDirectoryPicker) {
    throw new Error("Folder picker not supported in this browser");
  }
  dirHandle = await window.showDirectoryPicker({ mode: "readwrite" });
  await verifyPermission(dirHandle, true);
  const db = await openDb();
  const tx = db.transaction("handles", "readwrite");
  tx.objectStore("handles").put(dirHandle, "exportDir");
  return dirHandle.name;
}
async function clearExportDir() {
  dirHandle = null;
  try {
    const db = await openDb();
    const tx = db.transaction("handles", "readwrite");
    tx.objectStore("handles").delete("exportDir");
  } catch {
  }
}
async function saveExportFile(filename, content) {
  if (dirHandle) {
    const fh = await dirHandle.getFileHandle(filename, { create: true });
    const w = await fh.createWritable();
    await w.write(content);
    await w.close();
    return { saved: true, path: `${dirHandle.name}/${filename}` };
  }
  const url = URL.createObjectURL(new Blob([content], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5e3);
  return { saved: false, path: filename };
}
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("local-transsub", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("handles");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function reqToPromise(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function verifyPermission(handle, write = false) {
  const opts = { mode: write ? "readwrite" : "read" };
  if (await handle.queryPermission(opts) === "granted") return true;
  if (write) return await handle.requestPermission(opts) === "granted";
  return false;
}
function exportDirLabel() {
  return dirHandle?.name || null;
}

// src/lib/helper-status.js
function detectOs() {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent || "" : "";
  if (/Mac OS X|Macintosh/i.test(ua)) return "macos";
  if (/Windows/i.test(ua)) return "windows";
  if (/Linux/i.test(ua)) return "linux";
  return "unknown";
}
var OS_GUIDES = {
  macos: {
    label: "macOS",
    engine: "mlx-whisper (Apple Silicon) / faster-whisper",
    steps: [
      "Jalankan ./scripts/ensure-native.sh atau native/run.sh",
      "Pastikan Native Messaging Host com.localtranssub.helper terpasang",
      "Side Panel \u2192 Settings \u2192 Engine \u2192 Native helper"
    ]
  },
  windows: {
    label: "Windows",
    engine: "faster-whisper (CPU/CUDA)",
    steps: [
      "Install Python 3 + jalankan native\\run.sh (Git Bash) atau native\\run.bat bila ada",
      "Daftarkan Native Messaging Host untuk Chrome (manifest di native/)",
      "Buka http://127.0.0.1:17865/health \u2014 harus {ok:true}",
      "Di ekstensi pilih Engine \u2192 Native helper"
    ]
  },
  linux: {
    label: "Linux",
    engine: "faster-whisper (CPU/CUDA)",
    steps: [
      "python3 -m venv di native/ lalu ./native/run.sh",
      "Pasang host Native Messaging (JSON di ~/.config/google-chrome/NativeMessagingHosts/)",
      "Verifikasi curl -sf http://127.0.0.1:17865/health",
      "Side Panel \u2192 Native helper"
    ]
  },
  unknown: {
    label: "OS ini",
    engine: "faster-whisper atau mlx-whisper",
    steps: [
      "Ikuti README Native Helper",
      "Pastikan port 17865 menjawab /health"
    ]
  }
};
function exportBasename(title, kind) {
  const safe = String(title || "subtitles").replace(/[^\w\s.-]+/g, "_").replace(/\s+/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "").slice(0, 60) || "subtitles";
  const ext = kind === "vtt" ? "vtt" : kind === "txt" ? "txt" : "srt";
  return `${safe}.${ext}`;
}
var STUB_LARGE_FILE = {
  name: "conference-long.wav",
  sizeBytes: 2.4 * 1024 * 1024 * 1024,
  progress: 0.42,
  cancellable: true,
  status: "running",
  // idle | running | cancelling | cancelled | done | error
  stage: "transcribe",
  // upload | queued | transcribe | translate | finalize | …
  elapsedS: 154
};
function formatBytes(n) {
  if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(1)} GiB`;
  if (n >= 1024 ** 2) return `${(n / 1024 ** 2).toFixed(1)} MiB`;
  return `${Math.round(n / 1024)} KiB`;
}

// src/lib/export-options.js
var EXPORT_FORMATS = (
  /** @type {const} */
  [
    { kind: "srt", label: "SRT", mime: "application/x-subrip", desc: { en: "SubRip \u2014 every player, Premiere, YouTube", id: "SubRip \u2014 semua pemutar, Premiere, YouTube" } },
    { kind: "vtt", label: "VTT", mime: "text/vtt", desc: { en: "WebVTT \u2014 browsers, <track>, Teams/Zoom upload", id: "WebVTT \u2014 browser, <track>, unggah Teams/Zoom" } },
    { kind: "txt", label: "TXT", mime: "text/plain", desc: { en: "Plain transcript with timestamps \u2014 notes, search", id: "Transkrip polos bertanda waktu \u2014 catatan, pencarian" } },
    { kind: "md", label: "MD", mime: "text/markdown", desc: { en: "Markdown transcript \u2014 docs, minutes, sharing", id: "Transkrip Markdown \u2014 dokumen, notulen, dibagikan" } },
    { kind: "csv", label: "CSV", mime: "text/csv", desc: { en: "Spreadsheet rows with durations \u2014 analysis", id: "Baris spreadsheet dengan durasi \u2014 analisis" } },
    { kind: "json", label: "JSON", mime: "application/json", desc: { en: "Lossless data \u2014 re-import, tooling", id: "Data lossless \u2014 impor ulang, alat lain" } }
  ]
);
var EXPORT_KINDS = EXPORT_FORMATS.map((f) => f.kind);
function defaultExportOptions(os) {
  const win = os === "windows";
  return { crlf: win, bom: win, langSuffix: true };
}
function normalizeExportOptions(saved, os) {
  const d = defaultExportOptions(os);
  const o = saved && typeof saved === "object" ? saved : {};
  return {
    crlf: typeof o.crlf === "boolean" ? o.crlf : d.crlf,
    bom: typeof o.bom === "boolean" ? o.bom : d.bom,
    langSuffix: typeof o.langSuffix === "boolean" ? o.langSuffix : d.langSuffix
  };
}
var BOM = "\uFEFF";
function applyExportOptions(text, { crlf = false, bom = false } = {}) {
  let out = String(text ?? "");
  if (out.startsWith(BOM)) out = out.slice(1);
  out = out.replace(/\r\n/g, "\n");
  if (crlf) out = out.replace(/\n/g, "\r\n");
  if (bom) out = BOM + out;
  return out;
}
function exportFilename(title, kind, { srcLang, tgtLang, langSuffix = true } = {}) {
  const k = EXPORT_KINDS.includes(kind) ? kind : "srt";
  const base2 = exportBasename(String(title || "subtitles").replace(/\.[a-z0-9]{1,5}$/i, ""), k).replace(/\.(srt|vtt|txt)$/i, "");
  let suffix = "";
  if (langSuffix && srcLang) {
    suffix = tgtLang && tgtLang !== srcLang ? `.${srcLang}-${tgtLang}` : `.${srcLang}`;
    suffix = suffix.replace(/[^a-z0-9.\-]/gi, "");
  }
  return `${base2}${suffix}.${k}`;
}
function exportMime(kind) {
  return EXPORT_FORMATS.find((f) => f.kind === kind)?.mime || "text/plain";
}
function describeExportOptions(o) {
  const parts = [o.crlf ? "CRLF" : "LF"];
  if (o.bom) parts.push("BOM");
  return parts.join(" \xB7 ");
}

// src/lib/offline-io.js
var OFFLINE_INPUT_NAME = "offline-input";
var CHUNK_BYTES = 8 * 1024 * 1024;
var BROWSER_MAX_BYTES = 1536 * 1024 * 1024;
function needsNativeFilePath(size) {
  return size >= BROWSER_MAX_BYTES;
}
async function opfsRoot() {
  return navigator.storage.getDirectory();
}
async function stageFileToOpfs(file, onProgress) {
  const root = await opfsRoot();
  const fh = await root.getFileHandle(OFFLINE_INPUT_NAME, { create: true });
  const w = await fh.createWritable({ keepExistingData: false });
  try {
    const reader = file.stream().getReader();
    let loaded = 0;
    const total = file.size;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      await w.write(value);
      loaded += value.byteLength;
      onProgress?.(loaded, total);
    }
  } finally {
    await w.close();
  }
}

// src/lib/notes-i18n.js
var en = {
  /* chrome */
  minutes: "Minutes",
  register: "Minutes register",
  openRegister: "Open minutes register",
  registerHint: "The register opens in a full tab \u2014 a table does not belong in a 400px rail.",
  onDevice: "On-device",
  export: "Export",
  issue: "Issue MoM",
  issued: "Issued",
  startNext: "Start next meeting",
  newMeeting: "New meeting",
  newMeetingPlaceholder: "Meeting or project name",
  create: "Create",
  cancelNewMeeting: "Cancel",
  newMeetingNeedsTitle: "Give the meeting a name first.",
  exportStanding: "Export standing register",
  /* project types */
  projectType: "Project type",
  projectTypeHint: "Pick before you record \u2014 the register groups and filters by it.",
  pt_general: "General",
  pt_weekly_progress: "Weekly progress",
  pt_hse: "HSE / safety",
  pt_design_review: "Design review",
  pt_client_review: "Client review",
  pt_standup: "Stand-up",
  pt_sprint: "Sprint planning / retro",
  pt_sales: "Sales pipeline",
  pt_finance: "Finance / budget",
  pt_legal: "Legal / contract",
  pt_training: "Training",
  pt_research: "Research",
  pt_healthcare: "Healthcare",
  pt_education: "Education / class",
  allTypes: "All types",
  draftFromSession: (n) => `Draft built from the recording \u2014 ${n} items detected, review them`,
  /* meeting facts */
  date: "Date",
  time: "Time",
  chair: "Chair",
  present: "Present",
  mom: "MoM",
  series: "Series",
  nth: (n) => `meeting ${n}`,
  cadence: "Cadence",
  span: "Span",
  meetings: "Meetings",
  next: "Next",
  preparedBy: "Prepared by",
  distribution: "Distribution",
  /* provenance band */
  draftedOnDevice: "Drafted on this Mac",
  pipeline: (asr, seg, items) => `${asr} \u2192 ${seg} segments \u2192 ${items} register items`,
  needReview: "need review",
  lowConfFlag: "low-confidence flag",
  nothingLeft: "No audio, transcript or text left this device.",
  noSource: "No source \u2014 imported from v1",
  /* views */
  vRegister: "Register",
  vTopic: "By topic",
  vDoc: "Minutes",
  vCarry: "Carry-forward",
  vSeries: "Series",
  /* columns */
  cRef: "Ref",
  cType: "Type",
  cTopic: "Topic",
  cItem: "Item",
  cOwner: "Owner",
  cDue: "Due",
  cStatus: "Status",
  cSource: "Source",
  cAge: "Age",
  cRaised: "Raised",
  /* types */
  decision: "Decision",
  action: "Action",
  question: "Open question",
  risk: "Risk",
  metric: "Metric",
  info: "Note",
  /* statuses */
  open: "Open",
  progress: "In progress",
  closed: "Closed",
  carried: "Carried",
  /* review states */
  ai: "AI draft",
  accepted: "Accepted",
  edited: "Edited",
  /* stats */
  sItems: "Register items",
  sActions: "Actions open",
  sOverdue: "Overdue",
  sDecisions: "Decisions",
  sQuestions: "Open questions",
  sUnreviewed: "Unreviewed",
  sCoverage: "Agenda covered",
  sVariance: "Progress vs baseline",
  sMeanAge: "Mean age, open",
  sOldest: "Oldest open item",
  /* fields / drawer */
  dText: "Item text",
  dOwner: "Owner",
  dDue: "Due date",
  dStatus: "Status",
  dTopic: "Topic",
  dAgenda: "Agenda ref",
  dProvenance: "Where this came from",
  dLinked: "Linked in this register",
  dHistory: "History",
  asSpoken: "As spoken",
  machineTranslation: "Machine translation",
  citedSpan: "cited span",
  lowConfWords: "low-confidence words",
  /* actions */
  accept: "Accept",
  saveEdit: "Save edit",
  discard: "Discard",
  playFrom: "Play from here",
  addItem: "Add item",
  carryIn: "Carry in",
  close: "Close",
  applyCorrection: "Apply correction",
  keepAsHeard: "Keep as heard",
  addToGlossary: "Add to glossary",
  /* toolbar */
  search: "Search items, owners, quotes\u2026",
  mine: "Mine",
  dual: "Dual text",
  groupBy: "Group",
  groupNone: "none",
  needsReviewOnly: "Needs review only",
  showing: (n, total) => `Showing ${n} of ${total}`,
  /* low confidence banner */
  asrUnsure: (pct) => `Speech recognition was unsure here \u2014 ${pct}%`,
  extractorWrote: "The extractor wrote",
  audioSays: "The audio says",
  /* carry-forward */
  carryIntro: "Open items inherited from the previous meeting. Anything still open is re-numbered into this register and keeps its original age.",
  openFor: "open for",
  days: "d",
  today: "today",
  overdue: "overdue",
  dueIn: "in",
  noOwner: "Unassigned",
  noDue: "No date",
  noneYet: "Nothing here yet",
  raisedAgain: "Raised again this week",
  consecutive: (n) => `open question in ${n} consecutive meetings`,
  /* doc view */
  docSummary: "Summary",
  docDecisions: "Decisions",
  docActions: "Action register",
  docQuestions: "Open questions",
  docRisks: "Risks",
  docMetrics: "Progress",
  docNotes: "Discussion notes",
  /* messages */
  msgAccepted: "Item accepted \u2014 locked into the MoM",
  msgCarried: "Carried into this register",
  msgIssued: "MoM issued",
  msgBlocked: (n) => `${n} items still need review \u2014 issue anyway?`,
  msgIssuedFrozen: "This MoM is issued and read-only. Create an amendment to correct it.",
  msgMigrated: (n) => `${n} meeting(s) upgraded from the old notes format`,
  msgItemAdded: "Item added to the register",
  msgAmended: (id3) => `Amendment created \u2014 ${id3}`,
  msgSeeking: "Seeking transcript to",
  msgEmpty: "No items match the current filters.",
  msgNoMeeting: "No meeting selected.",
  /* app bar / header (design canvas: Main artboard) */
  presentN: (n) => `${n}`,
  seriesNth: (n) => `meeting ${n}`,
  lowAsr: "Low ASR confidence",
  aiDraftPct: (pct) => `AI draft \xB7 ${pct}%`,
  reported: "reported",
  ahead: "ahead",
  behind: "behind",
  vsBaseline: "baseline",
  /* footer */
  kbdMove: "move",
  kbdAccept: "accept",
  kbdOwner: "owner",
  kbdDate: "date",
  kbdSearch: "search",
  kbdClose: "close",
  lastSaved: (t2, backend2) => `Last saved ${t2} \xB7 ${backend2}`,
  notSavedYet: (backend2) => `Not saved yet \xB7 ${backend2}`,
  /* drawer (Provenance artboard) */
  agendaRef: (a) => `agenda ${a}`,
  translationHint: (other) => `${other} text is kept separately \u2014 switch language to edit it`,
  dPriority: "Priority",
  prHigh: "High",
  prMed: "Medium",
  prLow: "Low",
  dSevLik: "Severity \xD7 likelihood",
  lkCertain: "Certain",
  lkLikely: "Likely",
  lkPossible: "Possible",
  lkUnlikely: "Unlikely",
  segRange: (a, b) => a === b ? `seg ${a}` : `seg ${a}\u2013${b}`,
  asr: "ASR",
  correctionApplied: "Correction applied \u2014 item marked as edited",
  keptAsHeard: "Kept as heard \u2014 item accepted",
  glossaryAdded: (t2) => `\u201C${t2}\u201D added to the local glossary`,
  extractedBy: (by) => `created by ${by}`,
  flaggedLow: (pct) => `flagged low confidence \xB7 ${pct}% < 70%`,
  /* metric detail (Progress artboard) */
  mActual: "Actual",
  mBaseline: "Baseline",
  mVariance: "Variance",
  mAhead: "ahead of baseline",
  mBehind: "behind baseline",
  mOnBaseline: "on baseline",
  mChart: "Cumulative progress against baseline",
  mChartNote: "Only figures stated in this series are plotted \u2014 nothing is interpolated",
  mWhereFrom: "Where the figure came from",
  mAheadNotSafe: "Ahead, but not safe",
  mAheadNotSafeBody: (n) => `${n} open risk item(s) share this agenda line \u2014 read them together.`,
  mSingle: "One data point so far \u2014 the curve starts next meeting",
  mTypedNote: "Three numbers were extracted from one sentence and typed as a measure, not prose \u2014 so next week's figure lands on the same axis instead of in a new paragraph.",
  /* series (Series artboard) */
  seriesLabel: "Meeting series",
  standingRegister: "Standing action register",
  openAcross: (n, m) => `${n} open across ${m} meeting(s)`,
  sortedByAge: "Sorted by age \u2014 the number that goes on the progress report",
  flowTitle: "Items opened and closed, per meeting",
  flowNote: (up, total, net) => `Opened outpaced closed in ${up} of ${total} meeting(s) \u2014 net ${net >= 0 ? "+" : ""}${net} over the series.`,
  opened: "Opened",
  byParty: "Open items by party",
  showAll: "Show all",
  showLess: "Show less",
  moreOpen: (n) => `+ ${n} more open item(s)`,
  raisedAgainBody: (text, n) => `\u201C${text}\u201D has been open in ${n} consecutive meetings without an owner. Assign it or close it.`,
  raisedAgainOwned: (text, n, owner) => `\u201C${text}\u201D has been carried through ${n} consecutive meetings (owner: ${owner}). Close it or re-plan it.`,
  raisedAgainNone: "Nothing has been carried more than once \u2014 the register is clean.",
  startW: (n) => `Start W${n}`,
  nOpen: (n) => `${n} open`,
  cadenceWeekly: "Weekly",
  cadenceBiweekly: "Every two weeks",
  cadenceDays: (d) => `Every ${d} days`,
  cadenceNA: "\u2014",
  consecutivePill: (n) => `raised in ${n} consecutive meetings`,
  /* issued document (MoM artboard) */
  momTitle: "MINUTES OF MEETING",
  rev: "Rev",
  draftWatermark: "DRAFT \u2014 not yet issued",
  docMeeting: "Meeting",
  docProject: "Project",
  docNo: (n) => `no. ${n}`,
  docAccountable: "Accountable",
  docReferredTo: "Referred to",
  docBy: "By",
  docAction: "Action",
  docQuestion: "Question",
  docRisk: "Risk",
  docDecision: "Decision",
  docCarriedFrom: (id3, d) => `Carried from ${id3}, open ${d} days.`,
  docFootAi: (n) => `${n} item(s) marked \u2021 were drafted by on-device speech recognition and accepted without amendment by the minute-taker.`,
  docFootAllReviewed: "Every item was reviewed by a human before issue.",
  docFootCorrected: (ref, from, to, tc) => `${ref} was corrected against the recording before issue: \u201C${from}\u201D \u2192 \u201C${to}\u201D, verified at ${tc}.`,
  docFootEngine: (asr, seg) => `Transcribed and drafted on the minute-taker's own machine \u2014 ${asr}, ${seg} segments. No audio, transcript or minute text was sent to any external service.`,
  docFootTrace: "Every entry above is traceable to a timestamped segment of the recording kept on this device.",
  minutedBy: "Minuted by",
  docSevLik: "Sev \xD7 Lik",
  docRaisedRepeatedly: (n) => `Raised in ${n} consecutive meetings; no owner assigned.`,
  docRaisedRepeatedlyOwned: (n) => `Raised in ${n} consecutive meetings.`,
  saveSummary: "Save summary",
  msgSummarySaved: "Summary saved \u2014 this is what \xA71 says from now on",
  summaryPlaceholder: "Write the summary in your own words \u2014 what opened the meeting, what it turned on, what it closed with.",
  summaryGenerated: "Until you write one, the document uses the figures below.",
  printPdf: "Print / PDF",
  /* side panel (SidePanel artboard) */
  capturedSoFar: "Captured so far",
  latest: "Latest",
  secSummary: "Summary",
  secDecisions: "Decisions",
  secActions: "Action items",
  autoSummary: "Generate auto summary",
  draftCancel: "Discard draft",
  saveShort: "Save",
  ownerLabel: "Owner",
  panelHint: "The register opens in a full tab \u2014 a table does not belong in a 400px rail.",
  recording: "Recording",
  idle: "Idle",
  endAndDraft: "End & draft",
  flagMoment: "Flag this moment",
  flagNeedsRecording: "Start a capture task first \u2014 a flag is a timecode, and there is no clock yet.",
  flagRefusedIssued: "This MoM is issued \u2014 flags go to an amendment or the next meeting",
  flaggedAt: (tc) => `Flagged at ${tc} \u2014 review this moment`,
  untitledMeeting: "Untitled meeting",
  /* lapisan dock / workspace (dipulihkan dari build) */
  navigator: "Navigator",
  navViews: "Views",
  navTypes: "Item type",
  navFilters: "Filters",
  navPresets: "Layout presets",
  panel_left: "Navigator",
  panel_right: "Item detail",
  panel_bottom: "Where this came from",
  srcPanel: "Where this came from",
  srcHidden: "Sources hidden",
  srcShow: "Show where items came from",
  srcCount: (n, total) => `${n} of ${total} items have a source`,
  noSourcesYet: "No item in this meeting points back to a transcript segment yet.",
  floatPanel: "Float this panel",
  dockPanel: "Dock back",
  collapsePanel: "Collapse to rail",
  expandPanel: "Expand",
  hidePanel: "Hide",
  collapseHeader: "Collapse meeting header",
  expandHeader: "Expand meeting header",
  panelDocked: (name) => `${name} docked`,
  preset_review: "Review",
  preset_review_sub: "Wide detail, sources below",
  preset_reading: "Reading",
  preset_reading_sub: "Header open, no side panels",
  preset_compact: "Compact",
  preset_compact_sub: "Rails only, dense rows",
  resetLayout: "Reset layout to default",
  resetLayoutShort: "Reset layout",
  layoutReset: "Layout reset to default",
  layoutLine: (name, mem) => `Layout: ${name} \xB7 ${mem}`,
  layoutDefault: "default",
  layoutCustom: "custom",
  layoutRemembered: "remembered on this Mac",
  layoutNotRemembered: "not remembered",
  settingsTitle: "Layout & appearance",
  theme: "Theme",
  themeDark: "Local \xB7 dark",
  themeDarkSub: "Charcoal, emerald accent",
  themeCoretax: "Coretax \xB7 paper",
  themeCoretaxSub: "Navy, gold, glass bars",
  uiLanguage: "Interface language",
  uiLanguageNote: "Labels and menus only. Item text follows the language pair in the view dock.",
  density: "Density",
  densityComfortable: "Comfortable",
  densityCompact: "Compact",
  rememberLayout: "Remember panel sizes on this Mac",
  reduceMotion: "Reduce motion",
  kbdSearchTitle: "Search (/)",
  expandDock: "Expand view dock",
  backToApp: "Back to the main page",
  dockAutoOpen: "Hover to open the dock",
  dockAutoOff: "Off",
  dockAutoNote: "Point at the minimized dock this long and it opens by itself.",
  dockAnimStyle: "Open & close animation",
  dockAnimWipe: "Wipe",
  dockAnimSlide: "Slide",
  dockAnimFade: "Fade",
  dockAnimScale: "Scale",
  dockAnimNote: "Closing sweeps right to left toward the icon; opening comes back left to right.",
  dockAnimSpeed: "Animation speed",
  speedSlow: "Slow",
  speedNormal: "Normal",
  speedFast: "Fast",
  shrinkDock: "Shrink dock to an icon",
  dockGrip: "Drag to move \xB7 drop near the top or bottom edge to snap",
  translateTitle: "Translation",
  registerLanguage: "Register language",
  translateInto: "Translate into",
  onDeviceMt: "on-device MT",
  translateFoot: "Source is detected per item. Missing models are fetched once by the native helper.",
  translateN: (n) => `Translate ${n} item${n === 1 ? "" : "s"}`,
  translated: "Translated",
  translating: (p) => `Translating ${p}%`,
  translateDone: (n, lang) => `${n} item${n === 1 ? "" : "s"} translated into ${lang} on this Mac`,
  translateOffline: "Native helper is not running \u2014 start it from the side panel to translate on this Mac.",
  langDone: "translated",
  langPartial: (n, t2) => `${n}/${t2}`,
  langReady: "ready",
  groupNone: "none",
  needsReviewOnly: "Needs review only",
  days: "d",
  today: "today",
  overdue: "overdue",
  dueIn: "in",
  noDue: "No date",
  noneYet: "Nothing here yet",
  docDecisions: "Decisions",
  docActions: "Action register",
  docRisks: "Risks",
  docMetrics: "Progress",
  behind: "behind",
  kbdAccept: "accept",
  kbdOwner: "owner",
  kbdDate: "date",
  kbdClose: "close",
  prHigh: "High",
  prMed: "Medium",
  prLow: "Low",
  lkLikely: "Likely",
  lkPossible: "Possible",
  lkUnlikely: "Unlikely",
  mBaseline: "Baseline",
  mVariance: "Variance",
  mBehind: "behind baseline",
  mOnBaseline: "on baseline",
  showLess: "Show less",
  cadenceBiweekly: "Every two weeks",
  cadenceNA: "\u2014",
  docProject: "Project",
  docNo: (n) => `no. ${n}`,
  docReferredTo: "Referred to",
  docBy: "By",
  docQuestion: "Question",
  docRisk: "Risk",
  docDecision: "Decision"
};
var id = {
  /* project types */
  projectType: "Tipe proyek",
  projectTypeHint: "Pilih sebelum merekam \u2014 register mengelompokkan dan memfilter berdasarkan ini.",
  pt_general: "Umum",
  pt_weekly_progress: "Progres mingguan",
  pt_hse: "K3 / keselamatan",
  pt_design_review: "Tinjauan desain",
  pt_client_review: "Tinjauan klien",
  pt_standup: "Stand-up",
  pt_sprint: "Perencanaan / retro sprint",
  pt_sales: "Pipeline penjualan",
  pt_finance: "Keuangan / anggaran",
  pt_legal: "Hukum / kontrak",
  pt_training: "Pelatihan",
  pt_research: "Riset",
  pt_healthcare: "Kesehatan",
  pt_education: "Pendidikan / kelas",
  allTypes: "Semua tipe",
  draftFromSession: (n) => `Draf dibuat dari rekaman \u2014 ${n} butir terdeteksi, mohon ditelaah`,
  minutes: "Notulen",
  register: "Register notulen",
  openRegister: "Buka register notulen",
  registerHint: "Register terbuka di tab penuh \u2014 tabel tidak muat di rel 400px.",
  onDevice: "Di perangkat",
  export: "Ekspor",
  issue: "Terbitkan Notulen",
  issued: "Terbit",
  startNext: "Mulai rapat berikutnya",
  newMeeting: "Rapat baru",
  newMeetingPlaceholder: "Nama rapat atau proyek",
  create: "Buat",
  cancelNewMeeting: "Batal",
  newMeetingNeedsTitle: "Beri nama rapatnya dulu.",
  exportStanding: "Ekspor register berjalan",
  date: "Tanggal",
  time: "Waktu",
  chair: "Pimpinan",
  present: "Hadir",
  mom: "Notulen",
  series: "Seri",
  nth: (n) => `rapat ke-${n}`,
  cadence: "Irama",
  span: "Rentang",
  meetings: "Rapat",
  next: "Berikutnya",
  preparedBy: "Disusun oleh",
  distribution: "Distribusi",
  draftedOnDevice: "Disusun di perangkat ini",
  pipeline: (asr, seg, items) => `${asr} \u2192 ${seg} segmen \u2192 ${items} butir register`,
  needReview: "perlu ditinjau",
  lowConfFlag: "tanda keyakinan rendah",
  nothingLeft: "Tidak ada audio, transkrip, atau teks yang keluar dari perangkat ini.",
  noSource: "Tanpa sumber \u2014 impor dari v1",
  vRegister: "Register",
  vTopic: "Per topik",
  vDoc: "Notulen",
  vCarry: "Bawaan",
  vSeries: "Seri",
  cRef: "Ref",
  cType: "Jenis",
  cTopic: "Topik",
  cItem: "Butir",
  cOwner: "Penanggung jawab",
  cDue: "Tenggat",
  cStatus: "Status",
  cSource: "Sumber",
  cAge: "Umur",
  cRaised: "Diangkat",
  decision: "Keputusan",
  action: "Tindak lanjut",
  question: "Pertanyaan terbuka",
  risk: "Risiko",
  metric: "Metrik",
  info: "Catatan",
  open: "Terbuka",
  progress: "Berjalan",
  closed: "Selesai",
  carried: "Dibawa",
  ai: "Draf AI",
  accepted: "Disetujui",
  edited: "Disunting",
  sItems: "Butir register",
  sActions: "Tindak lanjut terbuka",
  sOverdue: "Lewat tenggat",
  sDecisions: "Keputusan",
  sQuestions: "Pertanyaan terbuka",
  sUnreviewed: "Belum ditinjau",
  sCoverage: "Agenda terbahas",
  sVariance: "Progres vs baseline",
  sMeanAge: "Umur rata-rata",
  sOldest: "Butir tertua",
  dText: "Teks butir",
  dOwner: "Penanggung jawab",
  dDue: "Tenggat",
  dStatus: "Status",
  dTopic: "Topik",
  dAgenda: "Ref agenda",
  dProvenance: "Asal butir ini",
  dLinked: "Terkait di register ini",
  dHistory: "Riwayat",
  asSpoken: "Sesuai ucapan",
  machineTranslation: "Terjemahan mesin",
  citedSpan: "rentang dikutip",
  lowConfWords: "kata keyakinan rendah",
  accept: "Setujui",
  saveEdit: "Simpan suntingan",
  discard: "Buang",
  playFrom: "Putar dari sini",
  addItem: "Tambah butir",
  carryIn: "Bawa masuk",
  close: "Tutup",
  applyCorrection: "Terapkan koreksi",
  keepAsHeard: "Biarkan sesuai terdengar",
  addToGlossary: "Tambah ke glosarium",
  search: "Cari butir, penanggung jawab, kutipan\u2026",
  mine: "Milik saya",
  dual: "Dua bahasa",
  groupBy: "Kelompok",
  groupNone: "tidak",
  needsReviewOnly: "Hanya yang perlu ditinjau",
  showing: (n, total) => `Menampilkan ${n} dari ${total}`,
  asrUnsure: (pct) => `Pengenalan suara ragu di sini \u2014 ${pct}%`,
  extractorWrote: "Ekstraktor menulis",
  audioSays: "Audionya berbunyi",
  carryIntro: "Butir terbuka warisan rapat sebelumnya. Yang masih terbuka dinomori ulang ke register ini dan mempertahankan umurnya.",
  openFor: "terbuka",
  days: "h",
  today: "hari ini",
  overdue: "lewat",
  dueIn: "dalam",
  noOwner: "Belum ditugaskan",
  noDue: "Tanpa tenggat",
  noneYet: "Belum ada apa-apa",
  raisedAgain: "Diangkat lagi minggu ini",
  consecutive: (n) => `pertanyaan terbuka di ${n} rapat berturut-turut`,
  docSummary: "Ringkasan",
  docDecisions: "Poin keputusan",
  docActions: "Register tindak lanjut",
  docQuestions: "Pertanyaan terbuka",
  docRisks: "Risiko",
  docMetrics: "Progres",
  docNotes: "Catatan pembahasan",
  msgAccepted: "Butir disetujui \u2014 terkunci di notulen",
  msgCarried: "Dibawa ke register ini",
  msgIssued: "Notulen diterbitkan",
  msgBlocked: (n) => `${n} butir belum ditinjau \u2014 tetap terbitkan?`,
  msgIssuedFrozen: "Notulen ini sudah terbit dan hanya-baca. Buat amandemen untuk mengoreksi.",
  msgMigrated: (n) => `${n} rapat dinaikkan dari format notulen lama`,
  msgItemAdded: "Butir ditambahkan ke register",
  msgAmended: (id3) => `Amandemen dibuat \u2014 ${id3}`,
  msgSeeking: "Menggeser transkrip ke",
  msgEmpty: "Tidak ada butir yang cocok dengan filter.",
  msgNoMeeting: "Belum ada rapat yang dipilih.",
  presentN: (n) => `${n}`,
  seriesNth: (n) => `rapat ke-${n}`,
  lowAsr: "Keyakinan ASR rendah",
  aiDraftPct: (pct) => `Draf AI \xB7 ${pct}%`,
  reported: "dilaporkan",
  ahead: "di depan",
  behind: "di belakang",
  vsBaseline: "baseline",
  kbdMove: "pindah",
  kbdAccept: "setujui",
  kbdOwner: "penanggung jawab",
  kbdDate: "tenggat",
  kbdSearch: "cari",
  kbdClose: "tutup",
  lastSaved: (t2, backend2) => `Tersimpan ${t2} \xB7 ${backend2}`,
  notSavedYet: (backend2) => `Belum tersimpan \xB7 ${backend2}`,
  agendaRef: (a) => `agenda ${a}`,
  translationHint: (other) => `Teks ${other} disimpan terpisah \u2014 ganti bahasa untuk menyuntingnya`,
  dPriority: "Prioritas",
  prHigh: "Tinggi",
  prMed: "Sedang",
  prLow: "Rendah",
  dSevLik: "Keparahan \xD7 kemungkinan",
  lkCertain: "Pasti",
  lkLikely: "Besar",
  lkPossible: "Mungkin",
  lkUnlikely: "Kecil",
  segRange: (a, b) => a === b ? `seg ${a}` : `seg ${a}\u2013${b}`,
  asr: "ASR",
  correctionApplied: "Koreksi diterapkan \u2014 butir ditandai disunting",
  keptAsHeard: "Dibiarkan sesuai terdengar \u2014 butir disetujui",
  glossaryAdded: (t2) => `\u201C${t2}\u201D ditambahkan ke glosarium lokal`,
  extractedBy: (by) => `dibuat oleh ${by}`,
  flaggedLow: (pct) => `ditandai keyakinan rendah \xB7 ${pct}% < 70%`,
  mActual: "Aktual",
  mBaseline: "Baseline",
  mVariance: "Selisih",
  mAhead: "di depan baseline",
  mBehind: "di belakang baseline",
  mOnBaseline: "sesuai baseline",
  mChart: "Progres kumulatif terhadap baseline",
  mChartNote: "Hanya angka yang disebut dalam seri ini yang digambar \u2014 tidak ada interpolasi",
  mWhereFrom: "Asal angka ini",
  mAheadNotSafe: "Di depan, tapi belum aman",
  mAheadNotSafeBody: (n) => `${n} risiko terbuka ada di baris agenda yang sama \u2014 baca bersama.`,
  mSingle: "Baru satu titik data \u2014 kurvanya mulai di rapat berikutnya",
  mTypedNote: "Tiga angka diambil dari satu kalimat dan dijadikan tipe ukuran, bukan prosa \u2014 sehingga angka minggu depan jatuh di sumbu yang sama, bukan di paragraf baru.",
  seriesLabel: "Seri rapat",
  standingRegister: "Register tindak lanjut berjalan",
  openAcross: (n, m) => `${n} terbuka dari ${m} rapat`,
  sortedByAge: "Diurutkan berdasarkan umur \u2014 angka yang masuk laporan progres",
  flowTitle: "Butir dibuka dan ditutup, per rapat",
  flowNote: (up, total, net) => `Yang dibuka melebihi yang ditutup di ${up} dari ${total} rapat \u2014 bersih ${net >= 0 ? "+" : ""}${net} sepanjang seri.`,
  opened: "Dibuka",
  byParty: "Butir terbuka per pihak",
  showAll: "Tampilkan semua",
  showLess: "Tampilkan lebih sedikit",
  moreOpen: (n) => `+ ${n} butir terbuka lainnya`,
  raisedAgainBody: (text, n) => `\u201C${text}\u201D sudah terbuka di ${n} rapat berturut-turut tanpa penanggung jawab. Tugaskan atau tutup.`,
  raisedAgainOwned: (text, n, owner) => `\u201C${text}\u201D sudah dibawa melewati ${n} rapat berturut-turut (penanggung jawab: ${owner}). Tutup atau rencanakan ulang.`,
  raisedAgainNone: "Belum ada yang dibawa lebih dari sekali \u2014 register bersih.",
  startW: (n) => `Mulai W${n}`,
  nOpen: (n) => `${n} terbuka`,
  cadenceWeekly: "Mingguan",
  cadenceBiweekly: "Dua mingguan",
  cadenceDays: (d) => `Setiap ${d} hari`,
  cadenceNA: "\u2014",
  consecutivePill: (n) => `diangkat di ${n} rapat berturut-turut`,
  momTitle: "NOTULEN RAPAT",
  rev: "Rev",
  draftWatermark: "DRAF \u2014 belum diterbitkan",
  docMeeting: "Rapat",
  docProject: "Proyek",
  docNo: (n) => `ke-${n}`,
  docAccountable: "Bertanggung jawab",
  docReferredTo: "Dirujuk ke",
  docBy: "Batas",
  docAction: "Tindak lanjut",
  docQuestion: "Pertanyaan",
  docRisk: "Risiko",
  docDecision: "Keputusan",
  docCarriedFrom: (id3, d) => `Dibawa dari ${id3}, terbuka ${d} hari.`,
  docFootAi: (n) => `${n} butir bertanda \u2021 disusun oleh pengenalan suara di perangkat dan disetujui tanpa perubahan oleh notulis.`,
  docFootAllReviewed: "Setiap butir ditinjau manusia sebelum diterbitkan.",
  docFootCorrected: (ref, from, to, tc) => `${ref} dikoreksi terhadap rekaman sebelum terbit: \u201C${from}\u201D \u2192 \u201C${to}\u201D, diverifikasi pada ${tc}.`,
  docFootEngine: (asr, seg) => `Ditranskripsi dan disusun di mesin notulis sendiri \u2014 ${asr}, ${seg} segmen. Tidak ada audio, transkrip, atau teks notulen yang dikirim ke layanan eksternal.`,
  docFootTrace: "Setiap entri di atas dapat ditelusuri ke segmen rekaman bercap waktu yang tersimpan di perangkat ini.",
  minutedBy: "Dicatat oleh",
  docSevLik: "Parah \xD7 Kemungkinan",
  docRaisedRepeatedly: (n) => `Diangkat di ${n} rapat berturut-turut; belum ada penanggung jawab.`,
  docRaisedRepeatedlyOwned: (n) => `Diangkat di ${n} rapat berturut-turut.`,
  saveSummary: "Simpan ringkasan",
  msgSummarySaved: "Ringkasan tersimpan \u2014 inilah isi \xA71 mulai sekarang",
  summaryPlaceholder: "Tulis ringkasan dengan kata-kata Anda sendiri \u2014 apa yang membuka rapat, apa yang menjadi pokoknya, dan apa penutupnya.",
  summaryGenerated: "Selama belum ditulis, dokumen memakai angka-angka di bawah ini.",
  printPdf: "Cetak / PDF",
  capturedSoFar: "Tertangkap sejauh ini",
  latest: "Terbaru",
  secSummary: "Ringkasan",
  secDecisions: "Keputusan",
  secActions: "Tindak lanjut",
  autoSummary: "Buat ringkasan otomatis",
  draftCancel: "Buang draf",
  saveShort: "Simpan",
  ownerLabel: "Pemilik",
  panelHint: "Register terbuka di tab penuh \u2014 tabel tidak muat di rel 400px.",
  recording: "Merekam",
  idle: "Siaga",
  endAndDraft: "Akhiri & buat draf",
  flagMoment: "Tandai momen ini",
  flagNeedsRecording: "Mulai tugas perekaman dulu \u2014 tanda itu sebuah timecode, dan jamnya belum berjalan.",
  flagRefusedIssued: "Notulen ini sudah terbit \u2014 tanda masuk lewat amandemen atau rapat berikutnya",
  flaggedAt: (tc) => `Ditandai pada ${tc} \u2014 tinjau momen ini`,
  untitledMeeting: "Rapat tanpa judul",
  /* lapisan dock / workspace (dipulihkan dari build) */
  navigator: "Navigator",
  navViews: "Tampilan",
  navTypes: "Jenis butir",
  navFilters: "Filter",
  navPresets: "Preset tata letak",
  panel_left: "Navigator",
  panel_right: "Detail butir",
  panel_bottom: "Asal butir ini",
  srcPanel: "Asal butir ini",
  srcHidden: "Sumber disembunyikan",
  srcShow: "Tampilkan asal butir",
  srcCount: (n, total) => `${n} dari ${total} butir punya sumber`,
  noSourcesYet: "Belum ada butir di rapat ini yang menunjuk ke segmen transkrip.",
  floatPanel: "Lepaskan panel ini",
  dockPanel: "Tambatkan kembali",
  collapsePanel: "Lipat ke rel",
  expandPanel: "Buka",
  hidePanel: "Sembunyikan",
  collapseHeader: "Lipat kepala rapat",
  expandHeader: "Buka kepala rapat",
  panelDocked: (name) => `${name} ditambatkan`,
  preset_review: "Tinjau",
  preset_review_sub: "Detail lebar, sumber di bawah",
  preset_reading: "Baca",
  preset_reading_sub: "Kepala terbuka, tanpa panel samping",
  preset_compact: "Ringkas",
  preset_compact_sub: "Hanya rel, baris rapat",
  resetLayout: "Kembalikan tata letak bawaan",
  resetLayoutShort: "Reset tata letak",
  layoutReset: "Tata letak kembali ke bawaan",
  layoutLine: (name, mem) => `Tata letak: ${name} \xB7 ${mem}`,
  layoutDefault: "bawaan",
  layoutCustom: "kustom",
  layoutRemembered: "diingat di Mac ini",
  layoutNotRemembered: "tidak diingat",
  settingsTitle: "Tata letak & tampilan",
  theme: "Tema",
  themeDark: "Lokal \xB7 gelap",
  themeDarkSub: "Arang, aksen zamrud",
  themeCoretax: "Coretax \xB7 kertas",
  themeCoretaxSub: "Navy, emas, bilah kaca",
  uiLanguage: "Bahasa antarmuka",
  uiLanguageNote: "Hanya label dan menu. Teks butir mengikuti pasangan bahasa di dok tampilan.",
  density: "Kepadatan",
  densityComfortable: "Nyaman",
  densityCompact: "Ringkas",
  rememberLayout: "Ingat ukuran panel di Mac ini",
  reduceMotion: "Kurangi gerakan",
  kbdSearchTitle: "Cari (/)",
  expandDock: "Buka dok tampilan",
  backToApp: "Kembali ke halaman utama",
  dockAutoOpen: "Buka dok dengan hover",
  dockAutoOff: "Mati",
  dockAutoNote: "Arahkan kursor ke dok yang mengecil selama ini, lalu ia membuka sendiri.",
  dockAnimStyle: "Animasi buka & tutup",
  dockAnimWipe: "Sapu",
  dockAnimSlide: "Geser",
  dockAnimFade: "Pudar",
  dockAnimScale: "Skala",
  dockAnimNote: "Menutup menyapu kanan ke kiri menuju ikon; membuka kembali dari kiri ke kanan.",
  dockAnimSpeed: "Kecepatan animasi",
  speedSlow: "Pelan",
  speedNormal: "Normal",
  speedFast: "Cepat",
  shrinkDock: "Kecilkan dok jadi ikon",
  dockGrip: "Seret untuk memindah \xB7 lepas dekat tepi atas/bawah untuk menempel",
  translateTitle: "Terjemahan",
  registerLanguage: "Bahasa register",
  translateInto: "Terjemahkan ke",
  onDeviceMt: "MT di perangkat",
  translateFoot: "Bahasa sumber dideteksi per butir. Model yang belum ada diunduh sekali oleh helper native.",
  translateN: (n) => `Terjemahkan ${n} butir`,
  translated: "Sudah diterjemahkan",
  translating: (p) => `Menerjemahkan ${p}%`,
  translateDone: (n, lang) => `${n} butir diterjemahkan ke ${lang} di Mac ini`,
  translateOffline: "Helper native tidak berjalan \u2014 nyalakan dari side panel untuk menerjemahkan di Mac ini.",
  langDone: "sudah",
  langPartial: (n, t2) => `${n}/${t2}`,
  langReady: "siap",
  groupNone: "tidak",
  needsReviewOnly: "Hanya yang perlu ditinjau",
  days: "h",
  today: "hari ini",
  overdue: "lewat",
  dueIn: "dalam",
  noDue: "Tanpa tenggat",
  noneYet: "Belum ada apa-apa",
  docDecisions: "Poin keputusan",
  docActions: "Register tindak lanjut",
  docRisks: "Risiko",
  docMetrics: "Progres",
  behind: "di belakang",
  kbdAccept: "setujui",
  kbdOwner: "penanggung jawab",
  kbdDate: "tenggat",
  kbdClose: "tutup",
  prHigh: "Tinggi",
  prMed: "Sedang",
  prLow: "Rendah",
  lkLikely: "Besar",
  lkPossible: "Mungkin",
  lkUnlikely: "Kecil",
  mBaseline: "Baseline",
  mVariance: "Selisih",
  mBehind: "di belakang baseline",
  mOnBaseline: "sesuai baseline",
  showLess: "Tampilkan lebih sedikit",
  cadenceBiweekly: "Dua mingguan",
  cadenceNA: "\u2014",
  docProject: "Proyek",
  docNo: (n) => `ke-${n}`,
  docReferredTo: "Dirujuk ke",
  docBy: "Batas",
  docQuestion: "Pertanyaan",
  docRisk: "Risiko",
  docDecision: "Keputusan"
};
var NOTES_I18N = { en, id: { ...en, ...id } };
function notesStrings(lang) {
  return NOTES_I18N[lang] || NOTES_I18N.en;
}
function makeT(lang) {
  const dict = notesStrings(lang);
  return function T(key, ...args) {
    const v = dict[key] ?? NOTES_I18N.en[key] ?? key;
    return typeof v === "function" ? v(...args) : v;
  };
}

// src/lib/i18n.js
var en2 = {
  settingsSearch: "Search settings\u2026 (e.g. font, model, folder)",
  settingsNoMatch: (q) => `No setting matches \u201C${q}\u201D.`,
  notesResize: "Drag to resize the notes panel",
  liveThisTab: "\u{1F534} Live",
  liveOtherTab: "\u{1F534} Live on another tab",
  gotoSessionTab: "Go to tab",
  sessionKeepsRunning: "Captions keep running on the tab above while you work elsewhere.",
  fmtSrtHint: "SRT \u2014 timed subtitles for VLC, YouTube, video editors",
  fmtVttHint: "VTT \u2014 WebVTT for web players and HTML5 video",
  fmtTxtHint: "TXT \u2014 plain text without timestamps, easy to copy",
  exportDestDownloads: "Saves to your Downloads folder (Chrome default)",
  exportDestFolder: (name) => `Saves to folder \u201C${name}\u201D`,
  exportDestChange: "Change\u2026",
  exportFolderHint: "By default Chrome saves each export to Downloads and shows its download bar. Pick a folder to write files straight there instead; Chrome asks for permission once.",
  requestingCapture: "Requesting tab audio from Chrome\u2026",
  loadingAsr: "Loading speech model\u2026",
  loadingTranslator: "Loading translation model\u2026",
  warmingUp: "Warming up the engine \u2014 first subtitle in a few seconds",
  stepCapture: "Capture",
  stepModels: "Models",
  stepWarmup: "Warm-up",
  stepListening: "Listening",
  errShowDetail: "Technical detail",
  errActionPick: "Pick tab manually",
  errActionSettings: "Open Settings",
  errActionRetry: "Try again",
  errDismiss: "Dismiss",
  err_cancelled_title: "Cancelled",
  err_cancelled_hint: "Nothing was saved. Press Start whenever you are ready.",
  err_captureBlocked_title: "Chrome blocked automatic capture",
  err_captureBlocked_hint: "Use the manual picker and choose the tab that is playing, or right-click the page and start yraverageSubMin there.",
  err_pageNotCapturable_title: "This page cannot be captioned",
  err_pageNotCapturable_hint: "Chrome pages, the Web Store and extension pages block audio capture. Open a normal website tab.",
  err_noAudioShared_title: "No audio was shared",
  err_noAudioShared_hint: "Re-open the picker and tick \u201CAlso share tab audio\u201D before confirming.",
  err_captureFailed_title: "Tab audio stopped",
  err_captureFailed_hint: "The tab was closed, muted or navigated away. Go back to it and press Start again.",
  err_fileTooLarge_title: "File too large for the browser",
  err_fileTooLarge_hint: "Files over 1.5 GB need the Native Helper with ffmpeg. Settings \u2192 Engine \u2192 Native, then install ffmpeg.",
  err_fileRead_title: "Could not read the file",
  err_fileRead_hint: "Choose the file again. On macOS, give Chrome Full Disk Access if it lives in Downloads or Desktop.",
  err_webgpu_title: "WebGPU is not available",
  err_webgpu_hint: "Switch Device to WASM in Settings, or pick a smaller model. Everything still runs on this machine.",
  err_nativeOffline_title: "Native Helper is not responding",
  err_nativeOffline_hint: "Start it from Settings \u2192 Native Helper, or switch Engine to Browser to keep going without it.",
  err_outOfMemory_title: "Ran out of memory",
  err_outOfMemory_hint: "Close other tabs or choose a smaller model in Settings. For long files, use the Native Helper.",
  err_vad_title: "Speech detector failed to start",
  err_vad_hint: "Press Start again. If it keeps failing, reload the extension from chrome://extensions.",
  err_modelLoad_title: "Model could not be loaded",
  err_modelLoad_hint: "Check the download in Settings \u2192 Models and try again. First-time downloads need an internet connection.",
  err_generic_title: "Something went wrong",
  err_generic_hint: "Press Try again. If it repeats, open Settings \u2192 Native Helper \u2192 Refresh, or reload the extension.",
  densityGroup: "Panel density",
  densitySimple: "Simple",
  densityDetail: "Detail",
  densitySimpleHint: "Simple \u2014 everyday controls only",
  densityDetailHint: "Detail \u2014 engine, models and Performance",
  genTitle: "\u{1F4AC} Subtitle Generation",
  offline: "Offline",
  realtime: "Realtime",
  currentPage: "Current page",
  dropHint: "Click or drag audio/video files here",
  dropFormats: "Supports mp3, wav, m4a, mp4, webm, ogg",
  taskMode: "Task Mode",
  transcribe: "Transcribe",
  plusTranslate: "+ Translate",
  sourceLang: "From (speech)",
  targetLang: "To (translation)",
  sourceLangGroup: "Speech language",
  targetLangGroup: "Translate into",
  tabCaptions: "Captions",
  tabNotes: "Notes",
  startTask: "Start Task",
  endTask: "End Task",
  cancelTask: "Cancel Task",
  history: "\u{1F558} History",
  clear: "\u{1F5D1} Clear",
  noHistory: "No history yet",
  settings: "Settings",
  uiLang: "UI language",
  dlSource: "Download source",
  device: "Inference device",
  dualLine: "Show original + translation (dual line)",
  dualShort: "Dual line",
  refineLine: "Live refine translation (draft while speaking, correct at end)",
  refineShort: "Refine",
  refineNote: "Refine shows draft subtitles while you speak and corrects the final translation when the sentence ends (like smart-glasses live captioning).",
  liveOriginal: "Original",
  liveTranslation: "Translation",
  fontSize: "Subtitle font size",
  modelFiles: "Model Files",
  manageModels: "Manage models",
  asrPreset: "Speed vs accuracy",
  presetFast: "Fast",
  presetBalanced: "Balanced",
  presetAccurate: "Accurate",
  presetHint: (label2, size, note) => `${label2} \xB7 ${size} \u2014 ${note}. Larger models need the download once, then run fully offline.`,
  presetCustom: "Custom model selected below \u2014 presets cover Tiny / Base / Small.",
  mtModels: "Translation models (per language pair)",
  modelHint: "Models download once and are cached locally \u2014 everything runs offline afterwards. If downloads stall, switch the download source and retry.",
  download: "Download",
  delete: "Delete",
  downloaded: "Downloaded",
  notDownloaded: "Not downloaded",
  needAsrModel: (name) => `Speech recognition needs the ${name} model \u2014 download it below or it will download automatically on start.`,
  needMtModel: (name) => `Translating ${name} needs its translation model.`,
  directNote: "Translating to English uses the speech model directly \u2014 no extra download needed.",
  needInvoke: 'Chrome blocked automatic tab capture \u2014 opening the manual picker. Or right-click the page \u2192 "Start yraverageSubMin on this page".',
  downloading: "Downloading",
  lines: "lines",
  historyOpen: "Open",
  historySearch: "Search transcripts\u2026",
  pasteTitle: "\u{1F4CB} Paste a Teams transcript \u2192 minutes",
  pasteHelp: "Open the Teams meeting transcript, select all, copy, and paste it here. Everything is parsed on this device.",
  pastePlaceholder: "Paste the transcript here\u2026",
  pasteMeetingTitle: "Meeting title (optional)",
  pasteGenerate: "Make minutes",
  pasteNotTeams: "That does not look like a Teams transcript \u2014 paste the panel contents, including the speaker names and timestamps.",
  pasteDone: (seg, people, items) => `${seg} segments \xB7 ${people} speakers \xB7 ${items} items detected`,
  historyNoMatch: (q) => `No session matches \u201C${q}\u201D`,
  historyMatchCount: (n, total) => `${n} of ${total} sessions`,
  historyLoaded: (n, at) => `Loaded ${n} lines \u2014 last position ${at}`,
  historyResume: (url) => `Start a session on ${url} to continue from there.`,
  cacheResume: (time, n) => `Resuming from ${time} \u2014 ${n} cached lines (no re-translation)`,
  exportFolder: "Save exports to folder",
  exportFolderNone: "Downloads (default)",
  exportFolderSet: "Folder",
  exportFolderPick: "Choose\u2026",
  exportFolderClear: "Clear",
  savedTo: (p) => `Saved to ${p}`,
  downloadedTo: (p) => `Downloaded ${p} \u2014 check your Downloads folder`,
  exportFailed: (m) => `Export failed: ${m}`,
  flagSaved: (tc) => `Moment flagged at ${tc} \u2014 saved to meeting notes`,
  engine: "Engine",
  engineBrowser: "Browser (in-extension)",
  engineNative: "Native helper (fastest \xB7 most accurate)",
  nativeUrl: "Helper address",
  nativeOnline: (m) => `\u25CF Native helper online \u2014 ${m}`,
  nativeOffline: "\u25CB Native helper not running",
  nativeStale: "Helper running \u2014 click Restart to load latest features",
  nativeChecking: "Checking native helper\u2026",
  nativeStarting: "Starting native helper\u2026",
  nativeStopping: "Stopping native helper\u2026",
  nativeRestarting: "Restarting native helper\u2026",
  nativeStart: "Start",
  nativeStop: "Stop",
  nativeRestart: "Restart",
  nativeHostHint: "Helper offline. Click Start (needs launcher \u2014 run once: ./scripts/ensure-native.sh) or run: ./scripts/start-native.sh",
  nativeHostMissing: "Native launcher not installed. Run: ./scripts/ensure-native.sh  \u2014 or manually: cd native && ./run.sh",
  nativeNote: "Native engine: Whisper Large v3 Turbo on the Apple Silicon GPU (MLX). The helper downloads its own models on first run (~1.6 GB). Use Start/Stop above once the launcher is installed.",
  check: "Refresh",
  theme: "Theme",
  themeAuto: "Auto",
  themeLight: "Light",
  themeDark: "Dark",
  reskin: "Reskin pattern",
  reskinYraverage: "Yraverage Klasik",
  reskinCoretax: "Coretax",
  reskinModern: "Yraverage Modern",
  reskinReset: "Reset to default",
  srcGroup: "\u{1F399} Source",
  taskGroup: "\u2699 Task & Languages",
  actionGroup: "\u25B6 Actions & Preview",
  pickManually: "\u{1F5A5} Pick tab / window manually",
  pickHint: "In the picker choose the Chrome Tab playing the video and tick \u201CAlso share tab audio\u201D. (Window/screen with system audio isn't supported on macOS \u2014 pick a tab instead.)",
  pickHintLab: "Share a Chrome Tab (or window) and enable audio. On macOS, pick a tab \u2014 window/screen system audio is often unavailable.",
  noAudioShared: "No audio was shared. Re-open the picker and tick \u201CAlso share tab audio\u201D / \u201CShare system audio\u201D.",
  loadingModels: "Loading local AI models\u2026",
  listening: "Listening \u2014 subtitles appear on the video page",
  processing: "Processing\u2026",
  done: "Done",
  cancelled: "Cancelled",
  noTab: "Open a normal website tab to caption it.",
  pickFile: "Choose a file first.",
  stagingFile: "Copying file\u2026",
  fileReadError: "Could not read the file \u2014 try choosing it again. On macOS, grant Chrome Full Disk Access if the file is in Downloads.",
  fileTooLarge: "Files over 1.5 GB cannot be decoded in the browser \u2014 they are streamed to the native helper as a job (progress + Cancel in the Native Helper card). Start the helper (Settings \u2192 Engine \u2192 Native helper) and make sure ffmpeg is installed.",
  /* large-file helper job stages (Native Helper card + status line) */
  lfStage_upload: "Uploading to helper",
  lfStage_queued: "Queued on helper",
  lfStage_transcribe: "Transcribing on helper",
  lfStage_translate: "Translating",
  lfStage_finalize: "Finalizing",
  lfStage_cancelling: "Cancelling\u2026",
  lfStage_cancelled: "Cancelled",
  lfStage_done: "Done",
  lfStage_error: "Failed",
  lfTitle: "Large file (>1.5 GB) via helper",
  lfIdle: "No large-file job. Files over 1.5 GB run on the helper with live progress here.",
  lfElapsed: (s) => `${Math.floor(s / 60)}m ${s % 60}s elapsed`,
  lfCancel: "Cancel",
  /* cross-OS export options (Native Helper card) */
  exportTitle: "Export subtitles",
  exportSource: (n) => `${n} lines ready`,
  exportNoSource: "Nothing to export yet \u2014 run an Offline file or a live session first.",
  exportCrlf: "Windows line endings (CRLF)",
  exportBom: "UTF-8 BOM (Notepad / older players)",
  exportLangSuffix: "Language suffix in file name",
  exportPreview: "File name",
  exportTarget: (folder) => folder ? `Saves to folder: ${folder}` : "Saves to Downloads \u2014 choose a folder in Settings",
  exportOsDefault: (os) => `Defaults for ${os}`,
  exportReset: "OS defaults",
  /* helper compute device (Windows/Linux CPU vs CUDA; macOS Apple Silicon) */
  helperDevice: "Helper compute",
  helperDeviceAuto: "Auto",
  helperDeviceGpu: "GPU (CUDA)",
  helperDeviceActive: (d, c) => `Active: ${d}${c ? ` \xB7 ${c}` : ""}`,
  helperDeviceOffline: "Helper offline \u2014 the choice applies when it starts.",
  helperDeviceAuto_hint: "Auto picks CUDA when an NVIDIA GPU + CUDA runtime is found, otherwise CPU (int8).",
  helperDeviceCpu_hint: "CPU only (int8). Works everywhere; large models are slow \u2014 prefer Whisper small/base here.",
  helperDeviceCuda_hint: "NVIDIA GPU via CUDA 12 (float16). Needs the driver + cuBLAS/cuDNN; falls back to CPU if unavailable.",
  helperDeviceApple: "Apple Silicon runs on the GPU/Neural Engine through MLX \u2014 no CPU/GPU switch needed.",
  helperDeviceRestart: "Saved \u2014 Restart the helper to apply.",
  helperDeviceManual: (d) => `This helper build has no device setting yet \u2014 restart it with DEVICE=${d} (e.g. DEVICE=${d} ./run.sh).`,
  helperDeviceNoCuda: "No CUDA device detected on the helper \u2014 CUDA will fall back to CPU.",
  helperDeviceMismatch: (want, got) => `Requested ${want}, helper is running on ${got} \u2014 Restart to apply.`,
  stagingFilePct: (pct) => `Copying file\u2026 ${pct}%`,
  qaSamples: "CC0 test samples",
  qaSamplesHint: "Pick a language-pair sample (10\u201330s, CC0/Public Domain) and run Offline.",
  qaTest: "Test",
  qaRunSample: "Run sample",
  qaNoSample: "No CC0 sample for this pair (open lab at :8799).",
  qaLoadingSample: "Loading CC0 sample\u2026",
  notesTitle: "\u{1F4DD} Meeting notes",
  interpreterMode: "Interpreter mode",
  interpreterChange: "Change",
  interpreterChoose: "Choose an Interpreter mode",
  interpConsecutive: "Consecutive interpretation",
  interpConsecutiveDesc: "Interpreter translates after each speaker. Good for interactive discussions in two languages.",
  interpSimultaneous: "Simultaneous interpretation",
  interpSimultaneousDesc: "Real-time translation into your chosen language. Good for one-way communication like town halls.",
  interpTwoWay: "Two-way",
  interpOneWay: "One-way",
  interpPreview: "Preview",
  interpYourLang: "Your interpretation language",
  interpTurnOn: "Turn on",
  interpCancel: "Cancel",
  interpNeedsBoth: "Two-way mode needs both translation directions:",
  interpCannotApply: "Pick two different languages for two-way interpreting.",
  interpAppliesNextTask: "Changes apply to the next task",
  interpSummaryOneWay: (a, b) => `One-way \xB7 ${a} \u2192 ${b}`,
  interpSummaryTwoWay: (a, b) => `Two-way \xB7 ${a} \u21C4 ${b}`
};
var zh = {
  settingsSearch: "\u641C\u7D22\u8BBE\u7F6E\u2026\uFF08\u5982\uFF1A\u5B57\u53F7\u3001\u6A21\u578B\u3001\u6587\u4EF6\u5939\uFF09",
  settingsNoMatch: (q) => `\u6CA1\u6709\u4E0E\u201C${q}\u201D\u5339\u914D\u7684\u8BBE\u7F6E\u3002`,
  notesResize: "\u62D6\u52A8\u4EE5\u8C03\u6574\u7EAA\u8981\u9762\u677F\u9AD8\u5EA6",
  liveThisTab: "\u{1F534} \u8FDB\u884C\u4E2D",
  liveOtherTab: "\u{1F534} \u5728\u53E6\u4E00\u4E2A\u6807\u7B7E\u9875\u8FDB\u884C\u4E2D",
  gotoSessionTab: "\u524D\u5F80\u8BE5\u6807\u7B7E\u9875",
  sessionKeepsRunning: "\u60A8\u5728\u5176\u4ED6\u6807\u7B7E\u9875\u5DE5\u4F5C\u65F6\uFF0C\u4E0A\u65B9\u6807\u7B7E\u9875\u7684\u5B57\u5E55\u4ECD\u4F1A\u7EE7\u7EED\u3002",
  fmtSrtHint: "SRT \u2014 \u5E26\u65F6\u95F4\u8F74\u5B57\u5E55\uFF0C\u9002\u7528\u4E8E VLC\u3001YouTube\u3001\u526A\u8F91\u8F6F\u4EF6",
  fmtVttHint: "VTT \u2014 WebVTT\uFF0C\u9002\u7528\u4E8E\u7F51\u9875\u64AD\u653E\u5668\u4E0E HTML5 \u89C6\u9891",
  fmtTxtHint: "TXT \u2014 \u65E0\u65F6\u95F4\u8F74\u7EAF\u6587\u672C\uFF0C\u4FBF\u4E8E\u590D\u5236",
  exportDestDownloads: "\u4FDD\u5B58\u5230\u201C\u4E0B\u8F7D\u201D\u6587\u4EF6\u5939\uFF08Chrome \u9ED8\u8BA4\uFF09",
  exportDestFolder: (name) => `\u4FDD\u5B58\u5230\u6587\u4EF6\u5939\u201C${name}\u201D`,
  exportDestChange: "\u66F4\u6539\u2026",
  exportFolderHint: "\u9ED8\u8BA4\u60C5\u51B5\u4E0B Chrome \u4F1A\u628A\u6BCF\u6B21\u5BFC\u51FA\u4FDD\u5B58\u5230\u201C\u4E0B\u8F7D\u201D\u5E76\u663E\u793A\u4E0B\u8F7D\u680F\u3002\u9009\u62E9\u6587\u4EF6\u5939\u540E\u5C06\u76F4\u63A5\u5199\u5165\u8BE5\u5904\uFF1BChrome \u53EA\u8BE2\u95EE\u4E00\u6B21\u6743\u9650\u3002",
  requestingCapture: "\u6B63\u5728\u5411 Chrome \u8BF7\u6C42\u6807\u7B7E\u9875\u97F3\u9891\u2026",
  loadingAsr: "\u6B63\u5728\u52A0\u8F7D\u8BED\u97F3\u6A21\u578B\u2026",
  loadingTranslator: "\u6B63\u5728\u52A0\u8F7D\u7FFB\u8BD1\u6A21\u578B\u2026",
  warmingUp: "\u5F15\u64CE\u9884\u70ED\u4E2D \u2014 \u51E0\u79D2\u540E\u51FA\u73B0\u7B2C\u4E00\u6761\u5B57\u5E55",
  stepCapture: "\u6355\u83B7",
  stepModels: "\u6A21\u578B",
  stepWarmup: "\u9884\u70ED",
  stepListening: "\u76D1\u542C",
  errShowDetail: "\u6280\u672F\u8BE6\u60C5",
  errActionPick: "\u624B\u52A8\u9009\u62E9\u6807\u7B7E\u9875",
  errActionSettings: "\u6253\u5F00\u8BBE\u7F6E",
  errActionRetry: "\u91CD\u8BD5",
  errDismiss: "\u5173\u95ED",
  err_cancelled_title: "\u5DF2\u53D6\u6D88",
  err_cancelled_hint: "\u672A\u4FDD\u5B58\u4EFB\u4F55\u5185\u5BB9\u3002\u51C6\u5907\u597D\u540E\u518D\u6309\u5F00\u59CB\u5373\u53EF\u3002",
  err_captureBlocked_title: "Chrome \u963B\u6B62\u4E86\u81EA\u52A8\u6355\u83B7",
  err_captureBlocked_hint: "\u8BF7\u7528\u624B\u52A8\u9009\u62E9\u5668\u9009\u62E9\u6B63\u5728\u64AD\u653E\u7684\u6807\u7B7E\u9875\uFF0C\u6216\u5728\u9875\u9762\u4E0A\u53F3\u952E\u542F\u52A8 yraverageSubMin\u3002",
  err_pageNotCapturable_title: "\u6B64\u9875\u9762\u65E0\u6CD5\u751F\u6210\u5B57\u5E55",
  err_pageNotCapturable_hint: "Chrome \u5185\u90E8\u9875\u9762\u3001\u5E94\u7528\u5546\u5E97\u548C\u6269\u5C55\u9875\u9762\u7981\u6B62\u97F3\u9891\u6355\u83B7\u3002\u8BF7\u6253\u5F00\u666E\u901A\u7F51\u9875\u6807\u7B7E\u9875\u3002",
  err_noAudioShared_title: "\u672A\u5171\u4EAB\u97F3\u9891",
  err_noAudioShared_hint: "\u8BF7\u91CD\u65B0\u6253\u5F00\u9009\u62E9\u5668\uFF0C\u5E76\u5728\u786E\u8BA4\u524D\u52FE\u9009\u201C\u540C\u65F6\u5171\u4EAB\u6807\u7B7E\u9875\u97F3\u9891\u201D\u3002",
  err_captureFailed_title: "\u6807\u7B7E\u9875\u97F3\u9891\u5DF2\u4E2D\u65AD",
  err_captureFailed_hint: "\u6807\u7B7E\u9875\u88AB\u5173\u95ED\u3001\u9759\u97F3\u6216\u5DF2\u8DF3\u8F6C\u3002\u8BF7\u56DE\u5230\u8BE5\u6807\u7B7E\u9875\u5E76\u518D\u6B21\u6309\u5F00\u59CB\u3002",
  err_fileTooLarge_title: "\u6587\u4EF6\u8FC7\u5927\uFF0C\u6D4F\u89C8\u5668\u65E0\u6CD5\u5904\u7406",
  err_fileTooLarge_hint: "\u8D85\u8FC7 1.5 GB \u7684\u6587\u4EF6\u9700\u8981\u5E26 ffmpeg \u7684\u672C\u5730\u52A9\u624B\u3002\u8BBE\u7F6E \u2192 \u5F15\u64CE \u2192 \u672C\u5730\uFF0C\u7136\u540E\u5B89\u88C5 ffmpeg\u3002",
  err_fileRead_title: "\u65E0\u6CD5\u8BFB\u53D6\u6587\u4EF6",
  err_fileRead_hint: "\u8BF7\u91CD\u65B0\u9009\u62E9\u6587\u4EF6\u3002macOS \u4E0A\u82E5\u6587\u4EF6\u4F4D\u4E8E\u201C\u4E0B\u8F7D\u201D\u6216\u201C\u684C\u9762\u201D\uFF0C\u8BF7\u6388\u4E88 Chrome \u5B8C\u5168\u78C1\u76D8\u8BBF\u95EE\u6743\u9650\u3002",
  err_webgpu_title: "WebGPU \u4E0D\u53EF\u7528",
  err_webgpu_hint: "\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u5C06\u8BBE\u5907\u5207\u6362\u4E3A WASM\uFF0C\u6216\u9009\u62E9\u66F4\u5C0F\u7684\u6A21\u578B\u3002\u8FD0\u7B97\u59CB\u7EC8\u5728\u672C\u673A\u8FDB\u884C\u3002",
  err_nativeOffline_title: "\u672C\u5730\u52A9\u624B\u65E0\u54CD\u5E94",
  err_nativeOffline_hint: "\u8BF7\u5728\u8BBE\u7F6E \u2192 \u672C\u5730\u52A9\u624B\u4E2D\u542F\u52A8\u5B83\uFF0C\u6216\u5C06\u5F15\u64CE\u5207\u6362\u4E3A\u6D4F\u89C8\u5668\u4EE5\u7EE7\u7EED\u3002",
  err_outOfMemory_title: "\u5185\u5B58\u4E0D\u8DB3",
  err_outOfMemory_hint: "\u8BF7\u5173\u95ED\u5176\u4ED6\u6807\u7B7E\u9875\u6216\u5728\u8BBE\u7F6E\u4E2D\u9009\u62E9\u66F4\u5C0F\u7684\u6A21\u578B\u3002\u957F\u6587\u4EF6\u8BF7\u4F7F\u7528\u672C\u5730\u52A9\u624B\u3002",
  err_vad_title: "\u8BED\u97F3\u68C0\u6D4B\u5668\u542F\u52A8\u5931\u8D25",
  err_vad_hint: "\u8BF7\u518D\u6B21\u6309\u5F00\u59CB\u3002\u82E5\u6301\u7EED\u5931\u8D25\uFF0C\u8BF7\u5728 chrome://extensions \u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u3002",
  err_modelLoad_title: "\u6A21\u578B\u65E0\u6CD5\u52A0\u8F7D",
  err_modelLoad_hint: "\u8BF7\u5728\u8BBE\u7F6E \u2192 \u6A21\u578B\u4E2D\u68C0\u67E5\u4E0B\u8F7D\u5E76\u91CD\u8BD5\u3002\u9996\u6B21\u4E0B\u8F7D\u9700\u8981\u8054\u7F51\u3002",
  err_generic_title: "\u51FA\u4E86\u70B9\u95EE\u9898",
  err_generic_hint: "\u8BF7\u6309\u91CD\u8BD5\u3002\u82E5\u53CD\u590D\u51FA\u73B0\uFF0C\u8BF7\u6253\u5F00\u8BBE\u7F6E \u2192 \u672C\u5730\u52A9\u624B \u2192 \u5237\u65B0\uFF0C\u6216\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u3002",
  densityGroup: "\u9762\u677F\u5BC6\u5EA6",
  densitySimple: "\u7B80\u6D01",
  densityDetail: "\u8BE6\u7EC6",
  densitySimpleHint: "\u7B80\u6D01 \u2014 \u4EC5\u663E\u793A\u65E5\u5E38\u63A7\u4EF6",
  densityDetailHint: "\u8BE6\u7EC6 \u2014 \u5F15\u64CE\u3001\u6A21\u578B\u4E0E\u6027\u80FD",
  ...en2,
  genTitle: "\u{1F4AC} \u5B57\u5E55\u751F\u6210",
  offline: "\u79BB\u7EBF",
  realtime: "\u5B9E\u65F6",
  currentPage: "\u5F53\u524D\u9875\u9762",
  dropHint: "\u70B9\u51FB\u6216\u62D6\u62FD\u97F3\u89C6\u9891\u6587\u4EF6\u5230\u8FD9\u91CC",
  dropFormats: "\u652F\u6301 mp3\u3001wav\u3001m4a\u3001mp4\u3001webm\u3001ogg",
  taskMode: "\u4EFB\u52A1\u6A21\u5F0F",
  transcribe: "\u8F6C\u5F55",
  plusTranslate: "+ \u7FFB\u8BD1",
  sourceLang: "\u6E90\u8BED\u8A00\uFF08\u8BED\u97F3\uFF09",
  targetLang: "\u76EE\u6807\u8BED\u8A00\uFF08\u7FFB\u8BD1\uFF09",
  sourceLangGroup: "\u8BED\u97F3\u8BED\u8A00",
  targetLangGroup: "\u7FFB\u8BD1\u4E3A",
  tabCaptions: "\u5B57\u5E55",
  tabNotes: "\u7B14\u8BB0",
  startTask: "\u5F00\u59CB\u4EFB\u52A1",
  endTask: "\u7ED3\u675F\u4EFB\u52A1",
  cancelTask: "\u53D6\u6D88\u4EFB\u52A1",
  history: "\u{1F558} \u5386\u53F2\u8BB0\u5F55",
  historyOpen: "\u6253\u5F00",
  historySearch: "\u641C\u7D22\u8F6C\u5F55\u5185\u5BB9\u2026",
  pasteTitle: "\u{1F4CB} \u7C98\u8D34 Teams \u8F6C\u5F55 \u2192 \u4F1A\u8BAE\u7EAA\u8981",
  pasteHelp: "\u6253\u5F00 Teams \u4F1A\u8BAE\u8F6C\u5F55\uFF0C\u5168\u9009\u590D\u5236\u5E76\u7C98\u8D34\u5230\u6B64\u5904\u3002\u5168\u90E8\u5728\u672C\u673A\u89E3\u6790\u3002",
  pastePlaceholder: "\u5728\u6B64\u7C98\u8D34\u8F6C\u5F55\u5185\u5BB9\u2026",
  pasteMeetingTitle: "\u4F1A\u8BAE\u6807\u9898\uFF08\u53EF\u9009\uFF09",
  pasteGenerate: "\u751F\u6210\u7EAA\u8981",
  pasteNotTeams: "\u8FD9\u770B\u8D77\u6765\u4E0D\u662F Teams \u8F6C\u5F55 \u2014 \u8BF7\u7C98\u8D34\u5305\u542B\u53D1\u8A00\u4EBA\u548C\u65F6\u95F4\u6233\u7684\u9762\u677F\u5185\u5BB9\u3002",
  pasteDone: (seg, people, items) => `${seg} \u6BB5 \xB7 ${people} \u4F4D\u53D1\u8A00\u4EBA \xB7 \u68C0\u6D4B\u5230 ${items} \u6761`,
  historyNoMatch: (q) => `\u6CA1\u6709\u4F1A\u8BDD\u5339\u914D\u201C${q}\u201D`,
  historyMatchCount: (n, total) => `${total} \u4E2A\u4F1A\u8BDD\u4E2D\u7684 ${n} \u4E2A`,
  historyLoaded: (n, at) => `\u5DF2\u8F7D\u5165 ${n} \u884C \u2014 \u6700\u540E\u4F4D\u7F6E ${at}`,
  historyResume: (url) => `\u5728 ${url} \u5F00\u59CB\u4F1A\u8BDD\u5373\u53EF\u4ECE\u8BE5\u5904\u7EE7\u7EED\u3002`,
  clear: "\u{1F5D1} \u6E05\u7A7A",
  noHistory: "\u6682\u65E0\u5386\u53F2\u8BB0\u5F55",
  settings: "\u8BBE\u7F6E",
  uiLang: "\u754C\u9762\u8BED\u8A00",
  dlSource: "\u4E0B\u8F7D\u6E90",
  device: "\u63A8\u7406\u8BBE\u5907",
  dualLine: "\u663E\u793A\u539F\u6587 + \u8BD1\u6587\uFF08\u53CC\u884C\uFF09",
  dualShort: "\u53CC\u884C",
  refineLine: "\u5B9E\u65F6\u6DA6\u8272\u7FFB\u8BD1\uFF08\u8BF4\u8BDD\u65F6\u663E\u793A\u8349\u7A3F\uFF0C\u53E5\u672B\u8BED\u4E49\u6821\u6B63\uFF09",
  refineShort: "\u6DA6\u8272",
  refineNote: "\u6DA6\u8272\u6A21\u5F0F\u5728\u8BF4\u8BDD\u8FC7\u7A0B\u4E2D\u663E\u793A\u8349\u7A3F\u5B57\u5E55\uFF0C\u53E5\u5B50\u7ED3\u675F\u540E\u6839\u636E\u5B8C\u6574\u8BED\u4E49\u6821\u6B63\u6700\u7EC8\u8BD1\u6587\uFF08\u7C7B\u4F3C\u667A\u80FD\u773C\u955C\u5B9E\u65F6\u5B57\u5E55\uFF09\u3002",
  liveOriginal: "\u539F\u6587",
  liveTranslation: "\u8BD1\u6587",
  fontSize: "\u5B57\u5E55\u5B57\u53F7",
  modelFiles: "\u6A21\u578B\u6587\u4EF6",
  mtModels: "\u7FFB\u8BD1\u6A21\u578B\uFF08\u6309\u8BED\u8A00\u5BF9\uFF09",
  modelHint: "\u6A21\u578B\u53EA\u9700\u4E0B\u8F7D\u4E00\u6B21\u5E76\u7F13\u5B58\u5728\u672C\u5730\uFF0C\u6B64\u540E\u5B8C\u5168\u79BB\u7EBF\u8FD0\u884C\u3002\u5982\u4E0B\u8F7D\u7F13\u6162\u8BF7\u5207\u6362\u4E0B\u8F7D\u6E90\u540E\u91CD\u8BD5\u3002",
  download: "\u4E0B\u8F7D",
  delete: "\u5220\u9664",
  downloaded: "\u5DF2\u4E0B\u8F7D",
  notDownloaded: "\u672A\u4E0B\u8F7D",
  needAsrModel: (name) => `\u8BED\u97F3\u8BC6\u522B\u9700\u8981 ${name} \u6A21\u578B \u2014 \u53EF\u5728\u4E0B\u65B9\u4E0B\u8F7D\uFF0C\u6216\u5F00\u59CB\u4EFB\u52A1\u65F6\u81EA\u52A8\u4E0B\u8F7D\u3002`,
  needMtModel: (name) => `\u7FFB\u8BD1 ${name} \u9700\u8981\u5148\u4E0B\u8F7D\u5BF9\u5E94\u7684\u7FFB\u8BD1\u6A21\u578B\u3002`,
  directNote: "\u7FFB\u8BD1\u4E3A\u82F1\u8BED\u65F6\u76F4\u63A5\u4F7F\u7528\u8BED\u97F3\u6A21\u578B\uFF0C\u65E0\u9700\u989D\u5916\u4E0B\u8F7D\u3002",
  check: "\u5237\u65B0",
  lines: "\u884C",
  cacheResume: (time, n) => `\u4ECE ${time} \u7EE7\u7EED \u2014 \u5DF2\u6709 ${n} \u884C\u7F13\u5B58\uFF08\u4E0D\u91CD\u590D\u7FFB\u8BD1\uFF09`,
  exportFolder: "\u5BFC\u51FA\u4FDD\u5B58\u6587\u4EF6\u5939",
  exportFolderNone: "\u9ED8\u8BA4\u4E0B\u8F7D\u4F4D\u7F6E",
  exportFolderSet: "\u6587\u4EF6\u5939",
  exportFolderPick: "\u9009\u62E9\u2026",
  exportFolderClear: "\u6E05\u9664",
  savedTo: (p) => `\u5DF2\u4FDD\u5B58\u5230 ${p}`,
  needInvoke: "Chrome \u963B\u6B62\u4E86\u81EA\u52A8\u6355\u83B7 \u2014 \u6B63\u5728\u6253\u5F00\u624B\u52A8\u9009\u62E9\u5668\u3002\u6216\u5728\u9875\u9762\u53F3\u952E \u2192 \u201C\u5728\u6B64\u9875\u9762\u542F\u52A8 yraverageSubMin\u201D\u3002",
  downloading: "\u4E0B\u8F7D\u4E2D",
  engine: "\u5F15\u64CE",
  engineBrowser: "\u6D4F\u89C8\u5668\uFF08\u6269\u5C55\u5185\u7F6E\uFF09",
  engineNative: "\u672C\u5730\u539F\u751F\u52A9\u624B\uFF08\u6700\u5FEB \xB7 \u6700\u51C6\u786E\uFF09",
  nativeUrl: "\u52A9\u624B\u5730\u5740",
  nativeOnline: (m) => `\u25CF \u539F\u751F\u52A9\u624B\u5728\u7EBF \u2014 ${m}`,
  nativeOffline: "\u25CB \u539F\u751F\u52A9\u624B\u672A\u8FD0\u884C",
  nativeStale: "\u52A9\u624B\u5728\u8FD0\u884C \u2014 \u8BF7\u70B9\u51FB Restart \u52A0\u8F7D\u6700\u65B0\u529F\u80FD",
  nativeChecking: "\u6B63\u5728\u68C0\u6D4B\u539F\u751F\u52A9\u624B\u2026",
  nativeStarting: "\u6B63\u5728\u542F\u52A8\u539F\u751F\u52A9\u624B\u2026",
  nativeStopping: "\u6B63\u5728\u505C\u6B62\u539F\u751F\u52A9\u624B\u2026",
  nativeRestarting: "\u6B63\u5728\u91CD\u542F\u539F\u751F\u52A9\u624B\u2026",
  nativeStart: "\u542F\u52A8",
  nativeStop: "\u505C\u6B62",
  nativeRestart: "\u91CD\u542F",
  nativeHostHint: "\u52A9\u624B\u672A\u8FD0\u884C\u3002\u70B9\u51FB Start\uFF08\u9700\u5148\u8FD0\u884C\u4E00\u6B21 ./scripts/ensure-native.sh\uFF09\u6216\u8FD0\u884C\uFF1A./scripts/start-native.sh",
  nativeHostMissing: "\u672A\u5B89\u88C5\u539F\u751F\u542F\u52A8\u5668\u3002\u8BF7\u8FD0\u884C\uFF1A./scripts/ensure-native.sh  \u2014 \u6216\u624B\u52A8\uFF1Acd native && ./run.sh",
  nativeNote: "\u539F\u751F\u5F15\u64CE\uFF1A\u5728 Apple Silicon GPU\uFF08MLX\uFF09\u4E0A\u8FD0\u884C Whisper Large v3 Turbo\u3002\u52A9\u624B\u9996\u6B21\u8FD0\u884C\u65F6\u81EA\u884C\u4E0B\u8F7D\u6A21\u578B\uFF08\u7EA6 1.6 GB\uFF09\u3002\u5B89\u88C5\u542F\u52A8\u5668\u540E\u53EF\u4F7F\u7528\u4E0A\u65B9\u542F\u52A8/\u505C\u6B62\u6309\u94AE\u3002",
  pickManually: "\u{1F5A5} \u624B\u52A8\u9009\u62E9\u6807\u7B7E\u9875 / \u7A97\u53E3",
  pickHint: "\u5728\u9009\u62E9\u5668\u4E2D\u9009\u62E9\u6B63\u5728\u64AD\u653E\u89C6\u9891\u7684 Chrome \u6807\u7B7E\u9875\uFF0C\u5E76\u52FE\u9009\u201C\u540C\u65F6\u5171\u4EAB\u6807\u7B7E\u9875\u97F3\u9891\u201D\u3002\uFF08macOS \u4E0D\u652F\u6301\u7A97\u53E3/\u5C4F\u5E55\u7684\u7CFB\u7EDF\u97F3\u9891\uFF0C\u8BF7\u9009\u62E9\u6807\u7B7E\u9875\u3002\uFF09",
  noAudioShared: "\u672A\u5171\u4EAB\u97F3\u9891\u3002\u8BF7\u91CD\u65B0\u6253\u5F00\u9009\u62E9\u5668\u5E76\u52FE\u9009\u201C\u540C\u65F6\u5171\u4EAB\u6807\u7B7E\u9875\u97F3\u9891\u201D\u3002",
  loadingModels: "\u6B63\u5728\u52A0\u8F7D\u672C\u5730 AI \u6A21\u578B\u2026",
  listening: "\u76D1\u542C\u4E2D \u2014 \u5B57\u5E55\u5C06\u663E\u793A\u5728\u89C6\u9891\u9875\u9762\u4E0A",
  processing: "\u5904\u7406\u4E2D\u2026",
  done: "\u5B8C\u6210",
  cancelled: "\u5DF2\u53D6\u6D88",
  noTab: "\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u666E\u901A\u7F51\u9875\u6807\u7B7E\u9875\u3002",
  pickFile: "\u8BF7\u5148\u9009\u62E9\u6587\u4EF6\u3002",
  stagingFile: "\u6B63\u5728\u590D\u5236\u6587\u4EF6\u2026",
  fileReadError: "\u65E0\u6CD5\u8BFB\u53D6\u6587\u4EF6 \u2014 \u8BF7\u91CD\u65B0\u9009\u62E9\u3002\u82E5\u5728 macOS \u7684\u201C\u4E0B\u8F7D\u201D\u6587\u4EF6\u5939\u4E2D\uFF0C\u8BF7\u4E3A Chrome \u6388\u4E88\u201C\u5B8C\u5168\u78C1\u76D8\u8BBF\u95EE\u6743\u9650\u201D\u3002",
  fileTooLarge: "\u8D85\u8FC7 1.5 GB \u7684\u6587\u4EF6\u65E0\u6CD5\u5728\u6D4F\u89C8\u5668\u5185\u89E3\u7801\u2014\u2014\u5B83\u4EEC\u4F1A\u4EE5\u4EFB\u52A1\u5F62\u5F0F\u6D41\u5F0F\u53D1\u9001\u7ED9\u539F\u751F\u52A9\u624B\uFF08\u8FDB\u5EA6\u548C\u53D6\u6D88\u5728\u201C\u539F\u751F\u52A9\u624B\u201D\u5361\u7247\uFF09\u3002\u8BF7\u542F\u52A8\u52A9\u624B\uFF08\u8BBE\u7F6E \u2192 \u5F15\u64CE \u2192 \u539F\u751F\u52A9\u624B\uFF09\u5E76\u786E\u8BA4\u5DF2\u5B89\u88C5 ffmpeg\u3002",
  lfStage_upload: "\u6B63\u5728\u4E0A\u4F20\u5230\u52A9\u624B",
  lfStage_queued: "\u52A9\u624B\u6392\u961F\u4E2D",
  lfStage_transcribe: "\u52A9\u624B\u8F6C\u5199\u4E2D",
  lfStage_translate: "\u7FFB\u8BD1\u4E2D",
  lfStage_finalize: "\u6536\u5C3E\u4E2D",
  lfStage_cancelling: "\u6B63\u5728\u53D6\u6D88\u2026",
  lfStage_cancelled: "\u5DF2\u53D6\u6D88",
  lfStage_done: "\u5B8C\u6210",
  lfStage_error: "\u5931\u8D25",
  lfTitle: "\u5927\u6587\u4EF6\uFF08>1.5 GB\uFF09\u7ECF\u52A9\u624B\u5904\u7406",
  lfIdle: "\u6CA1\u6709\u5927\u6587\u4EF6\u4EFB\u52A1\u3002\u8D85\u8FC7 1.5 GB \u7684\u6587\u4EF6\u5728\u52A9\u624B\u4E0A\u8FD0\u884C\uFF0C\u8FDB\u5EA6\u663E\u793A\u5728\u6B64\u5904\u3002",
  lfElapsed: (s) => `\u5DF2\u7528 ${Math.floor(s / 60)} \u5206 ${s % 60} \u79D2`,
  lfCancel: "\u53D6\u6D88",
  exportTitle: "\u5BFC\u51FA\u5B57\u5E55",
  exportSource: (n) => `${n} \u884C\u53EF\u5BFC\u51FA`,
  exportNoSource: "\u6682\u65E0\u53EF\u5BFC\u51FA\u5185\u5BB9\u2014\u2014\u5148\u8FD0\u884C\u79BB\u7EBF\u6587\u4EF6\u6216\u5B9E\u65F6\u4F1A\u8BDD\u3002",
  exportCrlf: "Windows \u6362\u884C\uFF08CRLF\uFF09",
  exportBom: "UTF-8 BOM\uFF08\u8BB0\u4E8B\u672C / \u65E7\u64AD\u653E\u5668\uFF09",
  exportLangSuffix: "\u6587\u4EF6\u540D\u5E26\u8BED\u8A00\u540E\u7F00",
  exportPreview: "\u6587\u4EF6\u540D",
  exportTarget: (folder) => folder ? `\u4FDD\u5B58\u5230\u6587\u4EF6\u5939\uFF1A${folder}` : "\u4FDD\u5B58\u5230\u4E0B\u8F7D\u2014\u2014\u53EF\u5728\u8BBE\u7F6E\u4E2D\u9009\u62E9\u6587\u4EF6\u5939",
  exportOsDefault: (os) => `${os} \u9ED8\u8BA4`,
  exportReset: "\u6062\u590D\u7CFB\u7EDF\u9ED8\u8BA4",
  helperDevice: "\u52A9\u624B\u8BA1\u7B97\u8BBE\u5907",
  helperDeviceAuto: "\u81EA\u52A8",
  helperDeviceGpu: "GPU\uFF08CUDA\uFF09",
  helperDeviceActive: (d, c) => `\u5F53\u524D\uFF1A${d}${c ? ` \xB7 ${c}` : ""}`,
  helperDeviceOffline: "\u52A9\u624B\u672A\u8FD0\u884C\u2014\u2014\u542F\u52A8\u65F6\u751F\u6548\u3002",
  helperDeviceAuto_hint: "\u81EA\u52A8\uFF1A\u68C0\u6D4B\u5230 NVIDIA GPU + CUDA \u65F6\u7528 CUDA\uFF0C\u5426\u5219\u7528 CPU\uFF08int8\uFF09\u3002",
  helperDeviceCpu_hint: "\u4EC5 CPU\uFF08int8\uFF09\u3002\u968F\u5904\u53EF\u7528\uFF0C\u4F46\u5927\u6A21\u578B\u8F83\u6162\u2014\u2014\u5EFA\u8BAE Whisper small/base\u3002",
  helperDeviceCuda_hint: "NVIDIA GPU\uFF0CCUDA 12\uFF08float16\uFF09\u3002\u9700\u8981\u9A71\u52A8 + cuBLAS/cuDNN\uFF1B\u4E0D\u53EF\u7528\u65F6\u56DE\u9000\u5230 CPU\u3002",
  helperDeviceApple: "Apple Silicon \u901A\u8FC7 MLX \u4F7F\u7528 GPU/\u795E\u7ECF\u5F15\u64CE\u2014\u2014\u65E0\u9700\u5207\u6362 CPU/GPU\u3002",
  helperDeviceRestart: "\u5DF2\u4FDD\u5B58\u2014\u2014\u91CD\u542F\u52A9\u624B\u540E\u751F\u6548\u3002",
  helperDeviceManual: (d) => `\u6B64\u52A9\u624B\u7248\u672C\u5C1A\u65E0\u8BBE\u5907\u8BBE\u7F6E\u2014\u2014\u8BF7\u7528 DEVICE=${d} \u91CD\u542F\uFF08\u5982 DEVICE=${d} ./run.sh\uFF09\u3002`,
  helperDeviceNoCuda: "\u52A9\u624B\u4E0A\u672A\u68C0\u6D4B\u5230 CUDA \u8BBE\u5907\u2014\u2014CUDA \u5C06\u56DE\u9000\u5230 CPU\u3002",
  helperDeviceMismatch: (want, got) => `\u5DF2\u8BF7\u6C42 ${want}\uFF0C\u52A9\u624B\u5F53\u524D\u8FD0\u884C\u5728 ${got}\u2014\u2014\u91CD\u542F\u4EE5\u751F\u6548\u3002`,
  stagingFilePct: (pct) => `\u6B63\u5728\u590D\u5236\u6587\u4EF6\u2026 ${pct}%`,
  qaSamples: "CC0 \u6D4B\u8BD5\u6837\u4F8B",
  qaSamplesHint: "\u9009\u62E9\u8BED\u8A00\u5BF9\u6837\u4F8B\uFF0810\u201330 \u79D2\uFF0CCC0/\u516C\u6709\u9886\u57DF\uFF09\u5E76\u5728\u79BB\u7EBF\u6A21\u5F0F\u8FD0\u884C\u3002",
  qaTest: "\u6D4B\u8BD5",
  qaRunSample: "\u8FD0\u884C\u6837\u4F8B",
  qaNoSample: "\u6B64\u8BED\u8A00\u5BF9\u6682\u65E0 CC0 \u6837\u4F8B\uFF08\u8BF7\u6253\u5F00 :8799 \u5B9E\u9A8C\u5BA4\uFF09\u3002",
  qaLoadingSample: "\u6B63\u5728\u52A0\u8F7D CC0 \u6837\u4F8B\u2026",
  notesTitle: "\u{1F4DD} \u4F1A\u8BAE\u7B14\u8BB0",
  interpreterMode: "\u53E3\u8BD1\u6A21\u5F0F",
  interpreterChange: "\u66F4\u6539",
  interpreterChoose: "\u9009\u62E9\u53E3\u8BD1\u6A21\u5F0F",
  interpConsecutive: "\u4EA4\u66FF\u4F20\u8BD1",
  interpConsecutiveDesc: "\u6BCF\u4F4D\u8BB2\u8BDD\u4EBA\u8BF4\u5B8C\u540E\u518D\u7FFB\u8BD1\u3002\u9002\u5408\u4E24\u79CD\u8BED\u8A00\u7684\u4E92\u52A8\u8BA8\u8BBA\u3002",
  interpSimultaneous: "\u540C\u58F0\u4F20\u8BD1",
  interpSimultaneousDesc: "\u5B9E\u65F6\u7FFB\u8BD1\u4E3A\u4F60\u9009\u5B9A\u7684\u8BED\u8A00\u3002\u9002\u5408\u5355\u5411\u8BB2\u8FF0\uFF0C\u5982\u5168\u5458\u5927\u4F1A\u3002",
  interpTwoWay: "\u53CC\u5411",
  interpOneWay: "\u5355\u5411",
  interpPreview: "\u9884\u89C8",
  interpYourLang: "\u4F60\u7684\u53E3\u8BD1\u8BED\u8A00",
  interpTurnOn: "\u5F00\u542F",
  interpCancel: "\u53D6\u6D88",
  interpNeedsBoth: "\u53CC\u5411\u6A21\u5F0F\u9700\u8981\u4E24\u4E2A\u7FFB\u8BD1\u65B9\u5411\uFF1A",
  interpCannotApply: "\u53CC\u5411\u53E3\u8BD1\u9700\u8981\u9009\u62E9\u4E24\u79CD\u4E0D\u540C\u7684\u8BED\u8A00\u3002",
  interpAppliesNextTask: "\u66F4\u6539\u5C06\u5728\u4E0B\u4E00\u4E2A\u4EFB\u52A1\u751F\u6548",
  interpSummaryOneWay: (a, b) => `\u5355\u5411 \xB7 ${a} \u2192 ${b}`,
  interpSummaryTwoWay: (a, b) => `\u53CC\u5411 \xB7 ${a} \u21C4 ${b}`
};
var I18N = {
  en: en2,
  zh,
  ja: { ...en2, uiLang: "UI\u8A00\u8A9E", offline: "\u30AA\u30D5\u30E9\u30A4\u30F3", realtime: "\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0", startTask: "\u958B\u59CB", endTask: "\u7D42\u4E86", settings: "\u8A2D\u5B9A", qaTest: "\u30C6\u30B9\u30C8", qaRunSample: "\u30B5\u30F3\u30D7\u30EB\u5B9F\u884C", qaSamples: "CC0\u30C6\u30B9\u30C8\u97F3\u58F0", theme: "\u30C6\u30FC\u30DE", themeAuto: "\u81EA\u52D5", themeLight: "\u30E9\u30A4\u30C8", themeDark: "\u30C0\u30FC\u30AF" },
  ko: { ...en2, uiLang: "UI \uC5B8\uC5B4", offline: "\uC624\uD504\uB77C\uC778", realtime: "\uC2E4\uC2DC\uAC04", startTask: "\uC2DC\uC791", endTask: "\uC885\uB8CC", settings: "\uC124\uC815", qaTest: "\uD14C\uC2A4\uD2B8", qaRunSample: "\uC0D8\uD50C \uC2E4\uD589", qaSamples: "CC0 \uD14C\uC2A4\uD2B8 \uC0D8\uD50C", theme: "\uD14C\uB9C8", themeAuto: "\uC790\uB3D9", themeLight: "\uB77C\uC774\uD2B8", themeDark: "\uB2E4\uD06C" },
  de: { ...en2, uiLang: "UI-Sprache", offline: "Offline", realtime: "Echtzeit", startTask: "Starten", endTask: "Beenden", settings: "Einstellungen", qaTest: "Test", qaRunSample: "Sample starten", qaSamples: "CC0-Testsamples", theme: "Thema", themeAuto: "Automatisch", themeLight: "Hell", themeDark: "Dunkel" },
  fr: { ...en2, uiLang: "Langue UI", offline: "Hors ligne", realtime: "Temps r\xE9el", startTask: "D\xE9marrer", endTask: "Arr\xEAter", settings: "Param\xE8tres", qaTest: "Tester", qaRunSample: "Lancer l\u2019\xE9chantillon", qaSamples: "\xC9chantillons CC0", theme: "Th\xE8me", themeAuto: "Automatique", themeLight: "Clair", themeDark: "Sombre" },
  es: { ...en2, uiLang: "Idioma UI", offline: "Sin conexi\xF3n", realtime: "Tiempo real", startTask: "Iniciar", endTask: "Finalizar", settings: "Ajustes", qaTest: "Probar", qaRunSample: "Ejecutar muestra", qaSamples: "Muestras CC0", theme: "Tema", themeAuto: "Autom\xE1tico", themeLight: "Claro", themeDark: "Oscuro" },
  ru: { ...en2, uiLang: "\u042F\u0437\u044B\u043A UI", offline: "\u041E\u0444\u043B\u0430\u0439\u043D", realtime: "\u041E\u043D\u043B\u0430\u0439\u043D", startTask: "\u0421\u0442\u0430\u0440\u0442", endTask: "\u0421\u0442\u043E\u043F", settings: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438", qaTest: "\u0422\u0435\u0441\u0442", qaRunSample: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043E\u0431\u0440\u0430\u0437\u0435\u0446", qaSamples: "CC0 \u043E\u0431\u0440\u0430\u0437\u0446\u044B", theme: "\u0422\u0435\u043C\u0430", themeAuto: "\u0410\u0432\u0442\u043E", themeLight: "\u0421\u0432\u0435\u0442\u043B\u0430\u044F", themeDark: "\u0422\u0451\u043C\u043D\u0430\u044F" },
  it: { ...en2, uiLang: "Lingua UI", offline: "Offline", realtime: "Tempo reale", startTask: "Avvia", endTask: "Termina", settings: "Impostazioni", qaTest: "Test", qaRunSample: "Esegui campione", qaSamples: "Campioni CC0", theme: "Tema", themeAuto: "Auto", themeLight: "Chiaro", themeDark: "Scuro" },
  nl: { ...en2, uiLang: "UI-taal", offline: "Offline", realtime: "Realtime", startTask: "Start", endTask: "Stop", settings: "Instellingen", qaTest: "Test", qaRunSample: "Sample starten", qaSamples: "CC0-testsamples", theme: "Thema", themeAuto: "Automatisch", themeLight: "Licht", themeDark: "Donker" },
  pl: { ...en2, uiLang: "J\u0119zyk UI", offline: "Offline", realtime: "Na \u017Cywo", startTask: "Start", endTask: "Koniec", settings: "Ustawienia", qaTest: "Test", qaRunSample: "Uruchom pr\xF3bk\u0119", qaSamples: "Pr\xF3bki CC0", theme: "Motyw", themeAuto: "Automatyczny", themeLight: "Jasny", themeDark: "Ciemny" },
  ar: { ...en2, uiLang: "\u0644\u063A\u0629 \u0627\u0644\u0648\u0627\u062C\u0647\u0629", offline: "\u062F\u0648\u0646 \u0627\u062A\u0635\u0627\u0644", realtime: "\u0645\u0628\u0627\u0634\u0631", startTask: "\u0628\u062F\u0621", endTask: "\u0625\u0646\u0647\u0627\u0621", settings: "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A", qaTest: "\u0627\u062E\u062A\u0628\u0627\u0631", qaRunSample: "\u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0639\u064A\u0646\u0629", qaSamples: "\u0639\u064A\u0646\u0627\u062A CC0", theme: "\u0627\u0644\u0645\u0638\u0647\u0631", themeAuto: "\u062A\u0644\u0642\u0627\u0626\u064A", themeLight: "\u0641\u0627\u062A\u062D", themeDark: "\u062F\u0627\u0643\u0646" },
  vi: { ...en2, uiLang: "Ng\xF4n ng\u1EEF UI", offline: "Ngo\u1EA1i tuy\u1EBFn", realtime: "Th\u1EDDi gian th\u1EF1c", startTask: "B\u1EAFt \u0111\u1EA7u", endTask: "K\u1EBFt th\xFAc", settings: "C\xE0i \u0111\u1EB7t", qaTest: "Th\u1EED", qaRunSample: "Ch\u1EA1y m\u1EABu", qaSamples: "M\u1EABu CC0", theme: "Ch\u1EE7 \u0111\u1EC1", themeAuto: "T\u1EF1 \u0111\u1ED9ng", themeLight: "S\xE1ng", themeDark: "T\u1ED1i" },
  id: {
    ...en2,
    settingsSearch: "Cari pengaturan\u2026 (mis. font, model, folder)",
    settingsNoMatch: (q) => `Tidak ada pengaturan yang cocok dengan \u201C${q}\u201D.`,
    notesResize: "Seret untuk mengubah tinggi panel notulen",
    liveThisTab: "\u{1F534} Berjalan",
    liveOtherTab: "\u{1F534} Berjalan di tab lain",
    gotoSessionTab: "Ke tab itu",
    sessionKeepsRunning: "Subtitel tetap berjalan di tab di atas selagi Anda bekerja di tab lain.",
    fmtSrtHint: "SRT \u2014 subtitel berstempel waktu untuk VLC, YouTube, penyunting video",
    fmtVttHint: "VTT \u2014 WebVTT untuk pemutar web dan video HTML5",
    fmtTxtHint: "TXT \u2014 teks polos tanpa stempel waktu, mudah disalin",
    exportDestDownloads: "Disimpan ke folder Downloads (bawaan Chrome)",
    exportDestFolder: (name) => `Disimpan ke folder \u201C${name}\u201D`,
    exportDestChange: "Ganti\u2026",
    exportFolderHint: "Secara bawaan Chrome menyimpan tiap ekspor ke Downloads dan menampilkan bilah unduhannya. Pilih folder agar berkas langsung ditulis ke sana; Chrome hanya meminta izin sekali.",
    requestingCapture: "Meminta audio tab dari Chrome\u2026",
    loadingAsr: "Memuat model suara\u2026",
    loadingTranslator: "Memuat model terjemahan\u2026",
    warmingUp: "Memanaskan mesin \u2014 subtitel pertama beberapa detik lagi",
    stepCapture: "Tangkap",
    stepModels: "Model",
    stepWarmup: "Pemanasan",
    stepListening: "Mendengarkan",
    errShowDetail: "Detail teknis",
    errActionPick: "Pilih tab manual",
    errActionSettings: "Buka Pengaturan",
    errActionRetry: "Coba lagi",
    errDismiss: "Tutup",
    err_cancelled_title: "Dibatalkan",
    err_cancelled_hint: "Tidak ada yang tersimpan. Tekan Mulai kapan saja Anda siap.",
    err_captureBlocked_title: "Chrome memblokir penangkapan otomatis",
    err_captureBlocked_hint: "Pakai pemilih manual dan pilih tab yang sedang memutar, atau klik kanan halamannya lalu mulai yraverageSubMin di sana.",
    err_pageNotCapturable_title: "Halaman ini tidak bisa disubtitle",
    err_pageNotCapturable_hint: "Halaman internal Chrome, Web Store, dan halaman ekstensi memblokir penangkapan audio. Buka tab situs biasa.",
    err_noAudioShared_title: "Audio tidak ikut dibagikan",
    err_noAudioShared_hint: "Buka lagi pemilihnya dan centang \u201CAlso share tab audio\u201D sebelum menekan konfirmasi.",
    err_captureFailed_title: "Audio tab terputus",
    err_captureFailed_hint: "Tab ditutup, dibisukan, atau berpindah halaman. Kembali ke tab itu lalu tekan Mulai lagi.",
    err_fileTooLarge_title: "Berkas terlalu besar untuk peramban",
    err_fileTooLarge_hint: "Berkas di atas 1,5 GB butuh Native Helper beserta ffmpeg. Pengaturan \u2192 Mesin \u2192 Native, lalu pasang ffmpeg.",
    err_fileRead_title: "Berkas tidak terbaca",
    err_fileRead_hint: "Pilih ulang berkasnya. Di macOS, beri Chrome Full Disk Access bila berkas ada di Downloads atau Desktop.",
    err_webgpu_title: "WebGPU tidak tersedia",
    err_webgpu_hint: "Ganti Perangkat ke WASM di Pengaturan, atau pilih model yang lebih kecil. Semuanya tetap berjalan di perangkat ini.",
    err_nativeOffline_title: "Native Helper tidak merespons",
    err_nativeOffline_hint: "Nyalakan dari Pengaturan \u2192 Native Helper, atau ganti Mesin ke Browser agar tetap bisa jalan.",
    err_outOfMemory_title: "Kehabisan memori",
    err_outOfMemory_hint: "Tutup tab lain atau pilih model yang lebih kecil di Pengaturan. Untuk berkas panjang, pakai Native Helper.",
    err_vad_title: "Pendeteksi suara gagal mulai",
    err_vad_hint: "Tekan Mulai lagi. Kalau terus gagal, muat ulang ekstensi dari chrome://extensions.",
    err_modelLoad_title: "Model gagal dimuat",
    err_modelLoad_hint: "Periksa unduhannya di Pengaturan \u2192 Model lalu coba lagi. Unduhan pertama butuh koneksi internet.",
    err_generic_title: "Ada yang tidak beres",
    err_generic_hint: "Tekan Coba lagi. Kalau berulang, buka Pengaturan \u2192 Native Helper \u2192 Refresh, atau muat ulang ekstensi.",
    densityGroup: "Kepadatan panel",
    densitySimple: "Ringkas",
    densityDetail: "Rinci",
    densitySimpleHint: "Ringkas \u2014 hanya kendali sehari-hari",
    densityDetailHint: "Rinci \u2014 mesin, model, dan Performance",
    uiLang: "Bahasa UI",
    interpreterMode: "Mode juru bahasa",
    interpreterChange: "Ubah",
    interpreterChoose: "Pilih mode juru bahasa",
    interpConsecutive: "Penerjemahan konsekutif",
    interpConsecutiveDesc: "Juru bahasa menerjemahkan setelah setiap penutur. Cocok untuk diskusi dua arah dalam dua bahasa.",
    interpSimultaneous: "Penerjemahan simultan",
    interpSimultaneousDesc: "Terjemahan waktu nyata ke bahasa pilihan Anda. Cocok untuk komunikasi satu arah seperti town hall.",
    interpTwoWay: "Dua arah",
    interpOneWay: "Satu arah",
    interpPreview: "Pratinjau",
    interpYourLang: "Bahasa terjemahan Anda",
    interpTurnOn: "Aktifkan",
    interpCancel: "Batal",
    interpNeedsBoth: "Mode dua arah membutuhkan kedua arah terjemahan:",
    interpCannotApply: "Pilih dua bahasa yang berbeda untuk mode dua arah.",
    interpAppliesNextTask: "Perubahan berlaku pada tugas berikutnya",
    interpSummaryOneWay: (a, b) => `Satu arah \xB7 ${a} \u2192 ${b}`,
    interpSummaryTwoWay: (a, b) => `Dua arah \xB7 ${a} \u21C4 ${b}`,
    offline: "Luring",
    realtime: "Waktu nyata",
    startTask: "Mulai",
    endTask: "Selesai",
    settings: "Pengaturan",
    qaTest: "Uji",
    qaRunSample: "Jalankan sampel",
    qaSamples: "Sampel CC0",
    theme: "Tema",
    themeAuto: "Otomatis",
    themeLight: "Terang",
    themeDark: "Gelap",
    reskin: "Pola reskin",
    reskinYraverage: "Yraverage Klasik",
    reskinCoretax: "Coretax",
    reskinModern: "Yraverage Modern",
    reskinReset: "Kembali ke bawaan",
    manageModels: "Kelola model",
    asrPreset: "Kecepatan vs akurasi",
    presetFast: "Cepat",
    presetBalanced: "Seimbang",
    presetAccurate: "Akurat",
    presetHint: (label2, size, note) => `${label2} \xB7 ${size} \u2014 ${note}. Model besar cukup diunduh sekali, lalu jalan luring penuh.`,
    presetCustom: "Model kustom dipilih di bawah \u2014 preset mencakup Tiny / Base / Small.",
    srcGroup: "\u{1F399} Sumber",
    taskGroup: "\u2699 Tugas & Bahasa",
    actionGroup: "\u25B6 Aksi & Pratinjau",
    downloadedTo: (p) => `Mengunduh ${p} \u2014 periksa folder Unduhan`,
    exportFailed: (m) => `Ekspor gagal: ${m}`,
    flagSaved: (tc) => `Momen ditandai pada ${tc} \u2014 tersimpan di notulen`,
    fileTooLarge: "Berkas di atas 1,5 GB tidak bisa didekode di browser \u2014 dialirkan ke Native Helper sebagai job (progres + Batalkan di kartu Native Helper). Jalankan helper (Pengaturan \u2192 Mesin \u2192 Native helper) dan pastikan ffmpeg terpasang.",
    lfStage_upload: "Mengunggah ke helper",
    lfStage_queued: "Antre di helper",
    lfStage_transcribe: "Transkripsi di helper",
    lfStage_translate: "Menerjemahkan",
    lfStage_finalize: "Menyelesaikan",
    lfStage_cancelling: "Membatalkan\u2026",
    lfStage_cancelled: "Dibatalkan",
    lfStage_done: "Selesai",
    lfStage_error: "Gagal",
    lfTitle: "Berkas besar (>1,5 GB) lewat helper",
    lfIdle: "Tidak ada job berkas besar. Berkas di atas 1,5 GB diproses di helper dengan progres langsung di sini.",
    lfElapsed: (s) => `${Math.floor(s / 60)}m ${s % 60}d berjalan`,
    lfCancel: "Batalkan",
    exportTitle: "Ekspor subtitel",
    exportSource: (n) => `${n} baris siap`,
    exportNoSource: "Belum ada yang bisa diekspor \u2014 jalankan berkas Luring atau sesi langsung dulu.",
    exportCrlf: "Akhir baris Windows (CRLF)",
    exportBom: "BOM UTF-8 (Notepad / pemutar lama)",
    exportLangSuffix: "Akhiran bahasa di nama berkas",
    exportPreview: "Nama berkas",
    exportTarget: (folder) => folder ? `Simpan ke folder: ${folder}` : "Simpan ke Unduhan \u2014 pilih folder di Pengaturan",
    exportOsDefault: (os) => `Bawaan ${os}`,
    exportReset: "Bawaan OS",
    helperDevice: "Komputasi helper",
    helperDeviceAuto: "Otomatis",
    helperDeviceGpu: "GPU (CUDA)",
    helperDeviceActive: (d, c) => `Aktif: ${d}${c ? ` \xB7 ${c}` : ""}`,
    helperDeviceOffline: "Helper mati \u2014 pilihan berlaku saat helper dijalankan.",
    helperDeviceAuto_hint: "Otomatis memakai CUDA bila ada GPU NVIDIA + runtime CUDA, selain itu CPU (int8).",
    helperDeviceCpu_hint: "Hanya CPU (int8). Jalan di mana saja; model besar lambat \u2014 pakai Whisper small/base.",
    helperDeviceCuda_hint: "GPU NVIDIA lewat CUDA 12 (float16). Butuh driver + cuBLAS/cuDNN; mundur ke CPU bila tak tersedia.",
    helperDeviceApple: "Apple Silicon memakai GPU/Neural Engine lewat MLX \u2014 tidak perlu saklar CPU/GPU.",
    helperDeviceRestart: "Tersimpan \u2014 Restart helper untuk menerapkan.",
    helperDeviceManual: (d) => `Build helper ini belum punya pengaturan device \u2014 jalankan ulang dengan DEVICE=${d} (mis. DEVICE=${d} ./run.sh).`,
    helperDeviceNoCuda: "CUDA tidak terdeteksi di helper \u2014 CUDA akan mundur ke CPU.",
    helperDeviceMismatch: (want, got) => `Diminta ${want}, helper berjalan di ${got} \u2014 Restart untuk menerapkan.`
  },
  uk: { ...en2, uiLang: "\u041C\u043E\u0432\u0430 UI", offline: "\u041E\u0444\u043B\u0430\u0439\u043D", realtime: "\u041E\u043D\u043B\u0430\u0439\u043D", startTask: "\u0421\u0442\u0430\u0440\u0442", endTask: "\u0421\u0442\u043E\u043F", settings: "\u041D\u0430\u043B\u0430\u0448\u0442\u0443\u0432\u0430\u043D\u043D\u044F", qaTest: "\u0422\u0435\u0441\u0442", qaRunSample: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u0438 \u0437\u0440\u0430\u0437\u043E\u043A", qaSamples: "CC0 \u0437\u0440\u0430\u0437\u043A\u0438", theme: "\u0422\u0435\u043C\u0430", themeAuto: "\u0410\u0432\u0442\u043E", themeLight: "\u0421\u0432\u0456\u0442\u043B\u0430", themeDark: "\u0422\u0435\u043C\u043D\u0430" }
};

// src/lib/interpreter.js
function usable(code) {
  return typeof code === "string" && code !== "" && code !== "auto";
}
function normalizeInterpreter(settings, srcLang = "zh", tgtLang = "en") {
  const raw = settings && typeof settings === "object" ? settings.interpreter : null;
  const mode = raw && raw.mode === "consecutive" ? "consecutive" : "simultaneous";
  const a = usable(raw?.a) ? raw.a : usable(srcLang) ? srcLang : "";
  const b = usable(raw?.b) ? raw.b : usable(tgtLang) ? tgtLang : "";
  if (mode === "consecutive" && (!usable(a) || !usable(b) || a === b)) {
    return { mode: "simultaneous", a, b };
  }
  return { mode, a, b };
}

// src/notes-panel.js
init_notes_schema();
init_notes_store();

// src/lib/notes-actions.js
init_notes_schema();
init_notes_store();
var clone = (m) => JSON.parse(JSON.stringify(m));
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var RegisterError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "RegisterError";
  }
};
function assertEditable(meeting) {
  if (meeting.issuedAt) {
    throw new RegisterError(
      "issued",
      `${meeting.id} sudah diterbitkan ${meeting.issuedAt}. Buat amandemen, jangan ubah catatannya.`
    );
  }
}
function findIndex(meeting, ref) {
  const i = meeting.items.findIndex((x) => x.ref === ref);
  if (i < 0) throw new RegisterError("not_found", `item ${ref} tidak ada di ${meeting.id}`);
  return i;
}
function withHistory(item, changes, by = "local") {
  const at = (/* @__PURE__ */ new Date()).toISOString();
  const history = [...item.history || []];
  for (const [field, [from, to]] of Object.entries(changes)) {
    history.push(createRevision({ at, by, field, from, to }));
  }
  return history;
}
function acceptItem(meeting, ref, { by = "local" } = {}) {
  assertEditable(meeting);
  const next = clone(meeting);
  const i = findIndex(next, ref);
  const item = next.items[i];
  if (item.review === "accepted" && !item.correction) return next;
  const changes = {};
  if (item.review !== "accepted") changes.review = [item.review, "accepted"];
  if (item.correction) changes.correction = [item.correction, null];
  next.items[i] = {
    ...item,
    review: "accepted",
    correction: null,
    history: withHistory(item, changes, by)
  };
  return next;
}
function applyCorrection(meeting, ref, { by = "local" } = {}) {
  const item = meeting.items[findIndex(meeting, ref)];
  if (!item.correction) throw new RegisterError("no_correction", `${ref} tidak punya saran koreksi`);
  const { from, to } = item.correction;
  const text = {};
  const pattern = new RegExp(from.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  for (const [lang, t2] of Object.entries(item.text || {})) {
    text[lang] = t2.replace(pattern, (hit) => hit[0] === hit[0].toUpperCase() && hit.slice(1) === hit.slice(1).toLowerCase() ? to[0].toUpperCase() + to.slice(1) : to);
  }
  return editItem(meeting, ref, { text, correction: null }, { by });
}
function editItem(meeting, ref, patch = {}, { by = "local" } = {}) {
  assertEditable(meeting);
  const next = clone(meeting);
  const i = findIndex(next, ref);
  const item = next.items[i];
  const changes = {};
  const merged = { ...item };
  for (const [k, v] of Object.entries(patch)) {
    if (k === "ref" || k === "history" || k === "src") continue;
    if (k === "text") {
      const before = { ...item.text || {} };
      const after = { ...before, ...v || {} };
      for (const lang of Object.keys(after)) {
        if (before[lang] !== after[lang]) changes[`text.${lang}`] = [before[lang] ?? null, after[lang]];
      }
      merged.text = after;
      continue;
    }
    if (JSON.stringify(item[k]) !== JSON.stringify(v)) {
      changes[k] = [item[k], v];
      merged[k] = v;
    }
  }
  if (!Object.keys(changes).length) return next;
  merged.review = "edited";
  if (item.review !== "edited") changes.review = [item.review, "edited"];
  merged.history = withHistory(item, changes, by);
  next.items[i] = createMinuteItem(merged, { locale: next.locale });
  return next;
}
function addItem(meeting, partial = {}, { by = "local" } = {}) {
  assertEditable(meeting);
  const next = clone(meeting);
  const item = createMinuteItem(
    {
      openedAt: partial.status && partial.status !== "closed" ? today() : null,
      ...partial,
      ref: partial.ref || nextRef(next),
      review: partial.review || "edited",
      // ditulis manusia
      confidence: partial.confidence ?? 1
    },
    { locale: next.locale }
  );
  item.history = [createRevision({ by, field: "created", to: item.ref })];
  next.items.push(item);
  return next;
}
function flagMoment(meeting, { tc, t0 = 0, text, by = "local" } = {}) {
  assertEditable(meeting);
  if (!text) {
    throw new RegisterError("no_text", 'flagMoment butuh teks jadi dari pemanggil: T("flaggedAt", tc)');
  }
  const stamp = tc || toTimecode(t0);
  return addItem(
    meeting,
    {
      type: "info",
      topic: "flag",
      text: { [meeting.locale || "en"]: String(text) },
      review: "edited",
      src: { t0, t1: t0, tc: stamp, lang: "auto", orig: "", tr: "" }
    },
    { by }
  );
}
function setSummary(meeting, lang, text) {
  assertEditable(meeting);
  const next = clone(meeting);
  const key = String(lang || next.locale || "en");
  const value = String(text ?? "").trim();
  next.summary = { ...next.summary || {} };
  if (value) next.summary[key] = value;
  else delete next.summary[key];
  return next;
}
function setStatus(meeting, ref, status, opts = {}) {
  return editItem(meeting, ref, { status }, opts);
}
function removeItem(meeting, ref) {
  assertEditable(meeting);
  const next = clone(meeting);
  findIndex(next, ref);
  next.items = next.items.filter((x) => x.ref !== ref);
  return next;
}
function carryCandidates(source) {
  return (source.items || []).filter(
    (i) => i.status !== "closed" && i.type !== "info" && i.type !== "metric"
  );
}
function carryForward(target, source, { refs = null, by = "local" } = {}) {
  assertEditable(target);
  const next = clone(target);
  const wanted = carryCandidates(source).filter((i) => !refs || refs.includes(i.ref));
  const already = new Set(next.items.map((i) => i.carriedFrom && i.links[0]).filter(Boolean));
  for (const item of wanted) {
    if (already.has(item.ref)) continue;
    const carried = createMinuteItem(
      {
        ...item,
        ref: nextRef(next),
        status: item.status === "carried" ? "open" : item.status,
        carriedFrom: source.id,
        openedAt: item.openedAt || source.date,
        links: [item.ref, ...item.links || []],
        src: item.src ? { ...item.src, meetingId: item.src.meetingId || source.id } : null
      },
      { locale: next.locale }
    );
    carried.history = [
      ...item.history || [],
      createRevision({ by, field: "carriedFrom", from: item.ref, to: carried.ref })
    ];
    next.items.push(carried);
  }
  return next;
}
function startNextMeeting(source, partial = {}) {
  const seq = Number(source.seq || 0) + 1;
  const blank = createMeeting({
    seriesId: source.seriesId,
    seq,
    title: source.title,
    tz: source.tz,
    // A standing series keeps its slot, so the START time carries over unless
    // the caller says otherwise. The END time does NOT: when the next meeting
    // finishes is a measurement nobody has made yet.
    start: source.start,
    chair: source.chair,
    attendees: source.attendees,
    topics: source.topics,
    locale: source.locale,
    projectType: source.projectType,
    date: partial.date || today(),
    id: partial.id || `${source.seriesId}-W${String(seq).padStart(2, "0")}`,
    ...partial
  });
  return carryForward(blank, source);
}
function blockingItems(meeting) {
  return (meeting.items || []).filter(
    (i) => i.review === "ai" || i.confidence < LOW_CONFIDENCE
  );
}
function issueMeeting(meeting, { force = false, by = "local" } = {}) {
  if (meeting.issuedAt) throw new RegisterError("issued", `${meeting.id} sudah diterbitkan.`);
  const blocking = blockingItems(meeting);
  if (blocking.length && !force) {
    throw new RegisterError(
      "unreviewed",
      `${blocking.length} butir belum ditelaah: ${blocking.map((i) => i.ref).join(", ")}`
    );
  }
  const next = clone(meeting);
  next.issuedAt = (/* @__PURE__ */ new Date()).toISOString();
  next.issuedBy = by;
  next.issuedWithUnreviewed = blocking.map((i) => i.ref);
  return next;
}
var persist = (fn) => async (meeting, ...args) => saveMeeting(fn(meeting, ...args));
var acceptItemAndSave = persist(acceptItem);
var applyCorrectionAndSave = persist(applyCorrection);
var editItemAndSave = persist(editItem);
var addItemAndSave = persist(addItem);
var flagMomentAndSave = persist(flagMoment);
var setStatusAndSave = persist(setStatus);
var setSummaryAndSave = persist(setSummary);
var removeItemAndSave = persist(removeItem);
var carryForwardAndSave = persist(carryForward);
var issueMeetingAndSave = persist(issueMeeting);

// src/lib/notes-fixture.js
init_notes_schema();
var SAMPLE_SERIES_ID = "CPOC7-WEEKLY";
var ATTENDEES = [
  { name: "Nasmee Samang", org: "GZS" },
  { name: "Lai Kong Teng", org: "COMPANY" },
  { name: "Riza", org: "GZS" },
  { name: "Jagdeep", org: "MWS" },
  { name: "Huimin", org: "GZS" },
  { name: "QA/QC", org: "GZS" },
  { name: "CVL", org: "SUBCON" }
];
function buildW35() {
  let m = createMeeting({
    id: "MOM-CPOC7-W35",
    seriesId: SAMPLE_SERIES_ID,
    seq: 35,
    projectType: "weekly-progress",
    title: "CPOC Phase 7 \u2014 GZS Weekly Progress Meeting",
    date: "2026-08-19",
    start: "10:00",
    end: "12:00",
    tz: "GMT+8",
    chair: "Nasmee Samang",
    attendees: ATTENDEES,
    locale: "en",
    agenda: [
      { ref: "A2", title: { en: "Dropped-object controls", id: "Kendali dropped object" }, covered: true },
      { ref: "A3", title: { en: "Document review status (MDR/GMDR)", id: "Status tinjauan dokumen (MDR/GMDR)" }, covered: true },
      { ref: "A5", title: { en: "HSE performance & yard audits", id: "Kinerja K3 & audit yard" }, covered: true },
      { ref: "A6", title: { en: "Vessel selection (C900)", id: "Pemilihan kapal (C900)" }, covered: false }
    ],
    engine: { asr: "Whisper large-v3-turbo (MLX)", mt: "local NMT", extractor: "heuristic v1", segments: 196, durationSec: 6900 }
  });
  const items = [
    {
      type: "decision",
      topic: "controls",
      agenda: "A2",
      owner: "Lai Kong Teng",
      org: "COMPANY",
      text: {
        en: "Cranes are to be inspected and secured before operation and before transport \u2014 not operation alone.",
        id: "Crane wajib diperiksa dan diamankan sebelum operasi dan sebelum transportasi \u2014 bukan hanya saat operasi."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.91,
      src: {
        t0: 698,
        speaker: "Lai Kong Teng",
        lang: "zh",
        orig: "\u8D77\u91CD\u673A\u7684\u62A4\u680F\u548C\u6F5C\u5728\u5760\u7269\u4E0D\u4EC5\u8981\u5728\u4F5C\u4E1A\u65F6\u68C0\u67E5\uFF0C\u6E2F\u53E3\u52A8\u5458\u548C\u8FD0\u8F93\u5230\u73B0\u573A\u65F6\u4E5F\u8981\u68C0\u67E5\u3002",
        tr: "Crane handrails and potential dropped objects need inspection not only during operation but also during port-side mobilisation and transport to field."
      }
    },
    {
      type: "decision",
      topic: "perf",
      agenda: "A5",
      owner: "QA/QC",
      org: "GZS",
      text: {
        en: "CUL onshore fabrication yard prefabrication audits confirmed for 21\u201322 September, run jointly with QA/QC.",
        id: "Audit prefabrikasi di yard fabrikasi onshore CUL dikonfirmasi 21\u201322 September, dijalankan bersama QA/QC."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.92,
      src: {
        t0: 2332,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "CUL \u9646\u4E0A\u9884\u5236\u573A\u7684\u9884\u5236\u5BA1\u6838\u5B89\u6392\u5728 9 \u6708 21 \u5230 22 \u65E5\uFF0C\u4E0E QAQC \u4E00\u8D77\u8FDB\u884C\u3002",
        tr: "Prefabrication audits at the CUL onshore fabrication yard were planned for September 21\u201322 in conjunction with QAQC."
      }
    },
    {
      type: "info",
      topic: "perf",
      agenda: "A5",
      text: {
        en: "35,000+ accumulated man-hours; lagging KPI indicators positive; zero HSE incidents recorded this period.",
        id: "Lebih dari 35.000 jam kerja terakumulasi; indikator KPI lagging positif; nol insiden K3 pada periode ini."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.95
    },
    {
      type: "metric",
      topic: "progress",
      agenda: "A5",
      text: { en: "Cumulative actual progress, week 35" },
      status: "closed",
      review: "accepted",
      confidence: 0.93,
      metric: { measure: "cumulative_progress", value: 9.78, baseline: 9, unit: "%", asOf: "2026-08-21" }
    },
    {
      type: "action",
      topic: "marine",
      agenda: "A6",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-08-29",
      text: {
        en: "Obtain written C900 availability window from the vessel owner.",
        id: "Peroleh jendela ketersediaan C900 tertulis dari pemilik kapal."
      },
      status: "open",
      review: "accepted",
      confidence: 0.9,
      openedAt: "2026-08-19",
      src: {
        t0: 2642,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u9700\u8981\u8239\u4E1C\u4E66\u9762\u786E\u8BA4 C900 \u7684\u53EF\u7528\u7A97\u53E3\u3002",
        tr: "Written confirmation of the C900 availability window is needed from the vessel owner."
      }
    },
    {
      type: "action",
      topic: "docs",
      agenda: "A3",
      owner: "Riza",
      org: "GZS",
      due: "2026-08-26",
      text: {
        en: "Issue GMDR rev.3 to COMPANY with the revised submission priority list.",
        id: "Terbitkan GMDR rev.3 ke COMPANY dengan daftar prioritas penyerahan yang direvisi."
      },
      status: "open",
      review: "accepted",
      confidence: 0.88,
      openedAt: "2026-08-12",
      src: {
        t0: 1795,
        speaker: "Riza",
        lang: "zh",
        orig: "GMDR \u7B2C\u4E09\u7248\u8981\u8FDE\u540C\u4FEE\u8BA2\u540E\u7684\u63D0\u4EA4\u4F18\u5148\u7EA7\u6E05\u5355\u4E00\u8D77\u53D1\u7ED9\u516C\u53F8\u3002",
        tr: "GMDR rev.3 to be issued to COMPANY together with the revised submission priority list."
      }
    },
    {
      type: "risk",
      topic: "mob",
      agenda: "A6",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-09-15",
      text: {
        en: "OSP approval slipping into the mobilisation window would delay sail-away; no float remains on the marine spread.",
        id: "Persetujuan OSP yang bergeser ke jendela mobilisasi akan menunda sail-away; tidak ada float tersisa pada marine spread."
      },
      status: "open",
      review: "edited",
      confidence: 0.84,
      openedAt: "2026-08-19",
      priority: "high",
      likelihood: "possible",
      src: {
        t0: 2020,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u5982\u679C OSP \u6279\u51C6\u62D6\u5230\u52A8\u5458\u7A97\u53E3\uFF0C\u8D77\u822A\u4F1A\u88AB\u63A8\u8FDF\u3002",
        tr: "If OSP approval slips into the mobilisation window, sail-away will be delayed."
      }
    }
  ];
  for (const it of items) m = addItem(m, it, { by: "seed" });
  return m;
}
function buildW36(w35) {
  let m = startNextMeeting(w35, {
    id: "MOM-CPOC7-W36",
    date: "2026-09-02",
    end: "12:00",
    summary: {
      en: "The meeting opened on the dropped-object incident during conductor installation and closed on yard-audit readiness. Crane inspection and securement were agreed as standing requirements covering transport as well as operation. Document review is progressing under MDR/GMDR priority with no issues flagged; one MWS signature remains outstanding. Cumulative actual progress reached 10.89%, 1.11% ahead of baseline, offset by a delay risk on bending and coating for the DNS shipment. Seven items remain open, two of them carried from week 35, and the prefab audit checklist is now the standing template \u2014 the series is audit-ready.",
      id: "Rapat dibuka dengan insiden dropped object saat pemasangan conductor dan ditutup dengan kesiapan audit yard. Inspeksi dan pengamanan crane disepakati sebagai syarat tetap yang mencakup transportasi, bukan hanya operasi. Tinjauan dokumen berjalan sesuai prioritas MDR/GMDR tanpa temuan; satu tanda tangan MWS masih tertunda. Progres aktual kumulatif mencapai 10,89%, 1,11% di depan baseline, tetapi diimbangi risiko keterlambatan bending dan coating untuk pengiriman DNS. Tujuh butir masih terbuka, dua di antaranya bawaan dari minggu 35, dan checklist audit prefab kini menjadi templat tetap \u2014 seri ini siap diaudit."
    },
    agenda: [
      { ref: "A1", title: { en: "Safety moment & incident review", id: "Momen keselamatan & tinjauan insiden" }, covered: true },
      { ref: "A2", title: { en: "Dropped-object controls", id: "Kendali dropped object" }, covered: true },
      { ref: "A3", title: { en: "Document review status (MDR/GMDR)", id: "Status tinjauan dokumen (MDR/GMDR)" }, covered: true },
      { ref: "A5", title: { en: "HSE performance & yard audits", id: "Kinerja K3 & audit yard" }, covered: true },
      { ref: "A6", title: { en: "Vessel selection (C900)", id: "Pemilihan kapal (C900)" }, covered: true },
      { ref: "A7", title: { en: "Marine budget & pipeline cargo", id: "Anggaran marine & kargo pipa" }, covered: false },
      { ref: "A8", title: { en: "Look-ahead: 3-week plan", id: "Look-ahead: rencana 3 minggu" }, covered: false }
    ],
    engine: { asr: "Whisper large-v3-turbo (MLX)", mt: "local NMT", extractor: "heuristic v1", segments: 214, durationSec: 7320 }
  });
  const items = [
    {
      type: "info",
      topic: "hse",
      agenda: "A1",
      text: {
        en: "Grating fell from the HLV main-boom walkway onto the jacket sea deck and struck a portable fire extinguisher; a second object later fell from the main crane into the sea. Personnel on the sea deck were evacuated to the barge \u2014 no injuries.",
        id: "Grating jatuh dari walkway main-boom HLV ke sea deck jacket dan menghantam APAR portabel; benda kedua kemudian jatuh dari main crane ke laut. Personel di sea deck dievakuasi ke barge \u2014 tidak ada cedera."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.94,
      src: {
        t0: 252,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u540A\u81C2\u8D70\u9053\u4E0A\u7684\u683C\u6805\u6389\u843D\u5230\u5BFC\u7BA1\u67B6\u7532\u677F\u4E0A\uFF0C\u7838\u5230\u4E00\u4E2A\u624B\u63D0\u706D\u706B\u5668\u3002\u4EBA\u5458\u5DF2\u64A4\u5230\u9A73\u8239\uFF0C\u4E4B\u540E\u53C8\u6709\u7269\u4EF6\u6389\u5165\u6D77\u4E2D\uFF0C\u65E0\u4EBA\u53D7\u4F24\u3002",
        tr: "A grating from the boom walkway fell onto the jacket deck and hit a portable extinguisher. Personnel were moved to the barge; another object then fell into the sea. No injuries."
      }
    },
    {
      type: "action",
      topic: "controls",
      agenda: "A2",
      owner: "Lai Kong Teng",
      org: "COMPANY",
      due: "2026-09-08",
      text: {
        en: "Issue a crane inspection checklist covering greasing, fast-line block inspection and a boom-walkway sweep for loose items.",
        id: "Terbitkan checklist inspeksi crane mencakup greasing, inspeksi fast-line block, dan penyisiran walkway boom untuk barang lepas."
      },
      status: "open",
      review: "ai",
      confidence: 0.88,
      openedAt: "2026-09-02",
      src: {
        t0: 545,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u4E8B\u6545\u590D\u76D8\u5EFA\u8BAE\u5EFA\u7ACB\u8D77\u91CD\u673A\u68C0\u67E5\u6E05\u5355\uFF0C\u5305\u62EC\u6DA6\u6ED1\u3001\u5FEB\u7EF3\u6ED1\u8F66\u68C0\u67E5\uFF0C\u4EE5\u53CA\u68C0\u67E5\u540A\u81C2\u8D70\u9053\u6709\u65E0\u677E\u6563\u7269\u4EF6\u3002",
        tr: "The incident review recommended establishing a crane inspection checklist, including greasing, fast-line block inspection, and checking the crane-boom walkway for loose items."
      }
    },
    {
      type: "action",
      topic: "docs",
      agenda: "A3",
      owner: "Riza",
      org: "GZS",
      due: "2026-09-05",
      text: {
        en: "Obtain Mr. Huimin's signature on the SCI MWS draft before submission to COMPANY.",
        id: "Peroleh tanda tangan Bapak Huimin pada draf SCI MWS sebelum penyerahan ke COMPANY."
      },
      status: "progress",
      review: "ai",
      confidence: 0.85,
      openedAt: "2026-09-02",
      src: {
        t0: 1541,
        speaker: "Riza",
        lang: "zh",
        orig: "SCI \u7684 MWS \u8349\u7A3F\u5DF2\u7ECF\u53D1\u7ED9\u516C\u53F8\uFF0C\u6B63\u5728\u7B49\u60E0\u6C11\u5148\u751F\u7B7E\u5B57\u540E\u518D\u6B63\u5F0F\u63D0\u4EA4\u3002",
        tr: "The SCI MWS draft had been shared with the company and was awaiting Mr. Huimin\u2019s signature before submission."
      }
    },
    {
      type: "question",
      topic: "marine",
      agenda: "A6",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-09-09",
      text: {
        en: "Which vessel is selected? Pending evaluation of C900 capability and availability window.",
        id: "Kapal mana yang dipilih? Menunggu evaluasi kapabilitas dan jendela ketersediaan C900."
      },
      status: "open",
      review: "ai",
      confidence: 0.81,
      openedAt: "2026-09-02",
      src: {
        t0: 2842,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u8239\u7684\u9009\u62E9\u8981\u7B49\u8BC4\u4F30\u5B8C C900 \u7684\u80FD\u529B\u548C\u53EF\u7528\u6027\u518D\u5B9A\u3002",
        tr: "Vessel selection to be resolved after evaluating C900 capability and availability."
      }
    },
    {
      type: "decision",
      topic: "perf",
      agenda: "A5",
      owner: "QA/QC",
      org: "GZS",
      text: {
        en: "Adopt the prefab audit checklist as the standing template for future GZS yard audits.",
        id: "Jadikan checklist audit prefab sebagai templat tetap untuk audit yard GZS berikutnya."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.9,
      src: {
        t0: 2410,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u68C0\u67E5\u6E05\u5355\u5DF2\u7ECF\u53D1\u7ED9 CVL\uFF0C\u6548\u679C\u4E0D\u9519\uFF0C\u4EE5\u540E\u5C31\u7528\u8FD9\u4EFD\u6A21\u677F\u3002",
        tr: "The checklist had already been shared with CVL and worked well \u2014 use this template going forward."
      }
    },
    // W36-009 — the figure below cites this line, so it has to exist as its own
    // register item rather than living inside the metric's sentence.
    {
      type: "info",
      topic: "progress",
      agenda: "A8",
      text: {
        en: "Land-pack manufacturing complete for all batches, ready for shipment.",
        id: "Manufaktur land-pack selesai untuk semua batch, siap dikirim."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.93,
      src: {
        t0: 3372,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u9646\u4E0A\u7BA1\u6BB5\u7684\u5236\u9020\u5DF2\u7ECF\u5168\u90E8\u5B8C\u6210\uFF0C\u5404\u6279\u6B21\u90FD\u53EF\u4EE5\u53D1\u8FD0\u4E86\u3002",
        tr: "Land-pack manufacturing is complete for all batches and ready for shipment."
      }
    },
    // W36-010 — links back to the metric (W36-011): being ahead of baseline does
    // not absorb this risk, and the drawer says so.
    {
      type: "risk",
      topic: "schedule",
      agenda: "A8",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-09-09",
      text: {
        en: "Delay risk on Ben and Coding activities for DNS shipment.",
        id: "Risiko keterlambatan pada aktivitas Ben and Coding untuk pengiriman DNS."
      },
      status: "open",
      review: "ai",
      confidence: 0.61,
      openedAt: "2026-09-02",
      priority: "high",
      likelihood: "possible",
      links: ["W36-011"],
      correction: { from: "Ben and Coding", to: "bending and coating", origPhrase: "\u5F2F\u7BA1\u548C\u6D82\u6577" },
      src: {
        t0: 3738,
        t1: 3761,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u672C\u5468\u867D\u7136\u8FDB\u5EA6\u9886\u5148\uFF0C\u4F46\u5F2F\u7BA1\u548C\u6D82\u6577\u7684\u6D3B\u52A8\u6709\u660E\u663E\u7684\u5EF6\u8BEF\u98CE\u9669\uFF0C\u7279\u522B\u662F\u8981\u53D1\u5F80 DNS \u7684\u90E8\u5206\u3002",
        tr: "Although progress is ahead this week, there is a significant delay risk on the bending and coating activities, particularly the part to be shipped to DNS.",
        segmentIds: ["s1284", "s1287"]
      }
    },
    // W36-011 — cites the land-pack note (W36-009) and the delay risk (W36-010).
    {
      type: "metric",
      topic: "progress",
      agenda: "A8",
      text: { en: "Cumulative actual progress, week 36", id: "Progres aktual kumulatif, minggu 36" },
      status: "closed",
      review: "accepted",
      confidence: 0.94,
      links: ["W36-009", "W36-010"],
      metric: { measure: "cumulative_progress", value: 10.89, baseline: 9.78, unit: "%", asOf: "2026-08-28" },
      src: {
        t0: 3390,
        t1: 3421,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "8 \u6708 28 \u65E5\u7684\u8FDB\u5EA6\u62A5\u544A\u4F5C\u4E3A WPR \u7684\u9884\u57FA\u51C6\u7248\u672C\u53D1\u5E03\uFF0C\u6743\u91CD\u6309\u6700\u65B0\u4FE1\u606F\u66F4\u65B0\u3002\u9646\u4E0A\u7BA1\u6BB5\u5404\u6279\u6B21\u5236\u9020\u5B8C\u6210\u3001\u53EF\u4EE5\u53D1\u8FD0\uFF0C\u6240\u4EE5\u7D2F\u8BA1\u5B9E\u9645\u8FDB\u5EA6\u662F 10.89%\uFF0C\u6BD4\u57FA\u51C6\u8D85\u524D 1.11%\u3002",
        tr: "The 28 August progress report was issued as the pre-baseline version for the WPR, with weightage updated according to the latest information. Land-pack manufacturing is complete for all batches and ready for shipment, so cumulative actual progress is 10.89% \u2014 1.11% ahead of baseline.",
        segmentIds: ["s1198", "s1204"]
      }
    },
    {
      type: "metric",
      topic: "perf",
      agenda: "A5",
      text: { en: "Accumulated man-hours", id: "Jam kerja terakumulasi" },
      status: "closed",
      review: "accepted",
      confidence: 0.95,
      metric: { measure: "man_hours", value: 35e3, unit: "", asOf: "2026-09-02" }
    },
    {
      type: "metric",
      topic: "perf",
      agenda: "A5",
      text: { en: "HSE incidents this period", id: "Insiden K3 pada periode ini" },
      status: "closed",
      review: "accepted",
      confidence: 0.95,
      metric: { measure: "hse_incidents", value: 0, unit: "" }
    }
  ];
  for (const it of items) m = addItem(m, it, { by: "seed" });
  return m;
}
function buildSampleSeries() {
  const w35 = buildW35();
  const w36 = buildW36(w35);
  return [w35, w36];
}
async function seedSampleData() {
  const { saveMeeting: saveMeeting2 } = await Promise.resolve().then(() => (init_notes_store(), notes_store_exports));
  const [w35, w36] = buildSampleSeries();
  await saveMeeting2(w35);
  await saveMeeting2(w36);
  return [w35, w36];
}

// src/notes-panel.js
init_notes_schema();
var PT_PREF_KEY = "notesProjectType";
var UI_COLLAPSE_KEY = "uiCollapsed";
var MEETINGS_VISIBLE = 5;
function readCollapseMap() {
  try {
    return JSON.parse(localStorage.getItem(UI_COLLAPSE_KEY) || "{}");
  } catch {
    return {};
  }
}
function isCollapsed(key, openByDefault = true) {
  const map = readCollapseMap();
  return map[key] === void 0 ? !openByDefault : map[key] !== true;
}
function setCollapsed(key, collapsed) {
  const map = readCollapseMap();
  map[key] = !collapsed;
  try {
    localStorage.setItem(UI_COLLAPSE_KEY, JSON.stringify(map));
  } catch {
  }
}
var ptKey = (t2) => `pt_${String(t2 || "general").replace(/-/g, "_")}`;
async function loadProjectTypePref() {
  try {
    if (globalThis.chrome?.storage?.local) {
      const o = await chrome.storage.local.get(PT_PREF_KEY);
      return normalizeProjectType(o?.[PT_PREF_KEY]);
    }
  } catch {
  }
  try {
    return normalizeProjectType(localStorage.getItem(PT_PREF_KEY));
  } catch {
    return "general";
  }
}
async function saveProjectTypePref(t2) {
  const v = normalizeProjectType(t2);
  try {
    if (globalThis.chrome?.storage?.local) await chrome.storage.local.set({ [PT_PREF_KEY]: v });
  } catch {
  }
  try {
    localStorage.setItem(PT_PREF_KEY, v);
  } catch {
  }
  return v;
}
function projectTypeSelectHtml(T, current) {
  return `<label class="notes-pt" for="notes-project-type" title="${escapeHtml(T("projectTypeHint"))}">
        <span>${escapeHtml(T("projectType"))}</span>
        <select id="notes-project-type" data-tour="notes-project-type">
          ${PROJECT_TYPES.map((t2) => `<option value="${t2}"${t2 === current ? " selected" : ""}>${escapeHtml(T(ptKey(t2)))}</option>`).join("")}
        </select>
      </label>`;
}
function escapeHtml(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function registerUrl() {
  const lang = (document.documentElement.lang || "en").startsWith("id") ? "id" : "en";
  const base2 = typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL("minutes.html") : "minutes.html";
  return `${base2}?lang=${lang}`;
}
function openRegister() {
  const url = registerUrl();
  if (typeof chrome !== "undefined" && chrome.tabs?.create) chrome.tabs.create({ url });
  else window.open(url, "_blank");
}
function byRecency(a, b) {
  return (b.i.src?.t0 ?? Infinity) - (a.i.src?.t0 ?? Infinity) || b.idx - a.idx;
}
function latestItems(meeting, lang, n = 3) {
  if (!meeting) return [];
  return meeting.items.map((i, idx) => ({ i, idx })).sort(byRecency).slice(0, n).map(({ i }) => rowItem(i, lang));
}
function rowItem(i, lang) {
  return {
    ref: i.ref,
    type: i.type,
    text: pickText(i.text, lang),
    tc: i.src?.tc || null,
    speaker: i.src?.speaker ? i.src.speaker.split(/\s+/)[0] : null,
    conf: i.src ? Math.round(i.confidence * 100) : null,
    low: i.confidence < LOW_CONFIDENCE,
    owner: i.owner || null,
    status: i.status || null
  };
}
function latestByType(meeting, lang, type, n = 3) {
  if (!meeting) return [];
  return meeting.items.map((i, idx) => ({ i, idx })).filter(({ i }) => i.type === type).sort(byRecency).slice(0, n).map(({ i }) => rowItem(i, lang));
}
function elapsedSeconds(capture, now = Date.now()) {
  if (!capture?.running || !capture.startedAt) return 0;
  return Math.max(0, Math.floor((now - capture.startedAt) / 1e3));
}
var macLike = () => /^Mac/i.test(globalThis.navigator?.platform || "");
function flagShortcutHint() {
  return macLike() ? "\u2318\u21E7F" : "Ctrl+Shift+F";
}
var NOTICE_MS = 6e3;
var WAVE_BARS = [22, 38, 55, 31, 64, 44, 73, 36, 58, 81, 47, 29, 66, 52, 88, 61, 94, 70, 45, 78];
function waveHtml(running) {
  const live = WAVE_BARS.length - 5;
  return `<div class="notes-wave" aria-hidden="true">${WAVE_BARS.map((h, i) => `<span class="${running && i >= live ? "on" : ""}" style="height:${h}%"></span>`).join("")}</div>`;
}
function captureRailHtml(capture, T, { issued = false, projectType = "general" } = {}) {
  const running = !!capture.running;
  const blocked = !running || issued;
  const why = issued ? T("flagRefusedIssued") : T("flagNeedsRecording");
  return `
      <div class="notes-rec" id="notes-recording-card">
        <div class="notes-rec-head">
          <span class="notes-rec-dot${running ? " live" : ""}" aria-hidden="true"></span>
          <span class="notes-rec-label">${escapeHtml(T(running ? "recording" : "idle"))}</span>
          <span class="notes-rec-clock mono" id="notes-elapsed">${toTimecode(elapsedSeconds(capture))}</span>
          <span class="notes-rec-spacer"></span>
          <span class="notes-engine mono" data-density="detail">${escapeHtml(capture.engine || "")}</span>
        </div>
        ${waveHtml(running)}
        ${projectTypeSelectHtml(T, projectType)}
        <div class="notes-rec-actions">
          <button type="button" class="btn primary notes-end-btn" id="btn-end-draft" data-tour="notes-end-draft"${running ? "" : " disabled"}>
            ${escapeHtml(T("endAndDraft"))}
          </button>
        </div>
      </div>

      <button type="button" class="notes-flag" id="btn-flag-moment" data-density="detail" data-tour="notes-flag"${blocked ? ` disabled title="${escapeHtml(why)}"` : ""}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#e0b05c" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 21V4"/><path d="M5 5h12l-2.2 3.6L17 12H5"/></svg>
        ${escapeHtml(T("flagMoment"))}
        <span class="notes-flag-key mono">${escapeHtml(flagShortcutHint())}</span>
      </button>`;
}
function meetingBarHtml({ meetings, active, T, creating }) {
  if (creating) {
    return `<input type="text" class="notes-mnew-input" id="notes-new-title"
        placeholder="${escapeHtml(T("newMeetingPlaceholder"))}" aria-label="${escapeHtml(T("newMeeting"))}" />
      <button type="button" class="mini-btn notes-mnew" id="btn-notes-new-save">${escapeHtml(T("create"))}</button>
      <button type="button" class="mini-btn notes-mnew" id="btn-notes-new-cancel" aria-label="${escapeHtml(T("cancelNewMeeting"))}">\u2715</button>`;
  }
  const newBtn = `<button type="button" class="mini-btn notes-mnew" id="btn-notes-new" title="${escapeHtml(T("newMeeting"))}">\uFF0B</button>`;
  if (!meetings.length) {
    return `<button type="button" class="mini-btn notes-mnew" id="btn-notes-new">\uFF0B ${escapeHtml(T("newMeeting"))}</button>`;
  }
  return `<select class="notes-mswitch" id="notes-meeting-switch" aria-label="${escapeHtml(T("meetings"))}">
      ${meetings.map(
    (m) => `<option value="${escapeHtml(m.id)}"${m.id === active?.id ? " selected" : ""}>${escapeHtml(`${m.date} \u2014 ${m.title}`)}</option>`
  ).join("")}
    </select>${newBtn}`;
}
function renderNotesPanel(root, state2, handlers = {}) {
  const { meetings, active, lang, T, capture, notice, summaryDraft, addingDecision, addingAction, projectType = "general" } = state2;
  const stats = active ? meetingStats(active) : null;
  const latest = latestItems(active, lang);
  const decisions = latestByType(active, lang, "decision");
  const actions = latestByType(active, lang, "action");
  const summary = active ? pickText(active.summary, lang) : "";
  const meetingsCollapsed = isCollapsed("notesMeetings", true);
  const counts = active ? ITEM_TYPES.map((t2) => [t2, active.items.filter((i) => i.type === t2).length]).filter(([, n]) => n > 0) : [];
  root.innerHTML = `
    <div class="notes-panel" data-notes-root>
      ${capture ? captureRailHtml(capture, T, { issued: !!active?.issuedAt, projectType }) : ""}

      <div class="notes-status-row">
        <span class="notes-pill ${notice ? "error" : active ? "ready" : "idle"}" id="notes-status-pill">
          <span aria-hidden="true">\u25CF</span>
          ${notice ? escapeHtml(notice) : active ? escapeHtml(T("onDevice")) : escapeHtml(T("msgNoMeeting"))}
        </span>
        <span class="notes-meta" data-density="detail">${escapeHtml(backendName())}</span>
      </div>

      <div class="notes-block" id="notes-active-block">
        <div class="notes-block-head">
          <h3>${active ? escapeHtml(T("capturedSoFar")) : escapeHtml(T("minutes"))}</h3>
          ${active ? `<span class="notes-count">${stats.total}</span>` : ""}
        </div>
        ${active ? `<p class="notes-meta notes-title-line">${escapeHtml(active.title)} \xB7 ${escapeHtml(active.date)}${active.projectType && active.projectType !== "general" ? ` \xB7 <span class="notes-pt-badge">${escapeHtml(T(ptKey(active.projectType)))}</span>` : ""}${stats.unreviewed ? ` \xB7 <span class="warn">${stats.unreviewed} ${escapeHtml(T("needReview"))}</span>` : ""}</p>
             ${counts.length ? `<div class="notes-chips" data-density="detail">${counts.map(([t2, n]) => `<span class="notes-chip"><i style="background:${TYPE_COLOR[t2]}"></i>${escapeHtml(T(t2))}<b>${n}</b></span>`).join("")}</div>` : ""}
              <div class="notes-sec">
                <div class="notes-sec-head"><h4>${escapeHtml(T("secSummary"))}</h4></div>
                ${summaryDraft ? `<p class="notes-summary notes-draft">${escapeHtml(summaryDraft)}</p>
                     <div class="notes-draft-actions">
                       <button type="button" class="mini-btn" id="btn-save-summary">${escapeHtml(T("saveSummary"))}</button>
                       <button type="button" class="mini-btn" id="btn-cancel-summary">${escapeHtml(T("draftCancel"))}</button>
                     </div>` : summary ? `<p class="notes-summary">${escapeHtml(summary)}</p>` : `<p class="notes-empty">${escapeHtml(T("noneYet"))}</p>`}
                ${!summaryDraft && active.items.length ? `<div class="notes-draft-actions"><button type="button" class="mini-btn" id="btn-auto-summary">${escapeHtml(T("autoSummary"))}</button></div>` : ""}
              </div>
              <div class="notes-sec">
                <div class="notes-sec-head"><h4>${escapeHtml(T("secDecisions"))}</h4>${stats.decisions ? `<span class="notes-count">${stats.decisions}</span>` : ""}</div>
                ${decisions.length ? `<div class="notes-latest">${decisions.map((i) => `
                <div class="notes-latest-row" data-ref="${escapeHtml(i.ref)}">
                  <span class="rail" style="background:${TYPE_COLOR[i.type]}"></span>
                  <span class="body">
                    <span class="txt">${escapeHtml(i.text)}</span>
                    <span class="meta">${i.tc ? `${escapeHtml(i.tc)} \xB7 ` : ""}${escapeHtml(i.ref)}</span>
                  </span>
                  <button type="button" class="mini-btn row-del" data-del="${escapeHtml(i.ref)}" title="\u2715">\u2715</button>
                </div>`).join("")}</div>` : `<p class="notes-empty">${escapeHtml(T("noneYet"))}</p>`}
                ${addingDecision ? `<div class="notes-add-row">
                       <input type="text" id="decision-input" class="notes-input" placeholder="${escapeHtml(T("decision"))}\u2026" />
                       <button type="button" class="mini-btn" id="btn-save-decision">${escapeHtml(T("saveShort"))}</button>
                       <button type="button" class="mini-btn" id="btn-cancel-decision">${escapeHtml(T("draftCancel"))}</button>
                     </div>` : `<div class="notes-draft-actions"><button type="button" class="mini-btn" id="btn-add-decision">+ ${escapeHtml(T("secDecisions"))}</button></div>`}
              </div>
              <div class="notes-sec">
                <div class="notes-sec-head"><h4>${escapeHtml(T("secActions"))}</h4>${stats.actionsTotal ? `<span class="notes-count">${stats.actionsOpen}/${stats.actionsTotal}</span>` : ""}</div>
                ${actions.length ? `<div class="notes-latest">${actions.map((i) => `
                <div class="notes-latest-row" data-ref="${escapeHtml(i.ref)}">
                  <span class="rail" style="background:${TYPE_COLOR[i.type]}"></span>
                  <span class="body">
                    <span class="txt">${escapeHtml(i.text)}</span>
                    <span class="meta">${i.owner ? `${escapeHtml(i.owner)} \xB7 ` : `${escapeHtml(T("noOwner"))} \xB7 `}${i.tc ? `${escapeHtml(i.tc)}` : escapeHtml(i.ref)}</span>
                  </span>
                  <button type="button" class="mini-btn row-del" data-del="${escapeHtml(i.ref)}" title="\u2715">\u2715</button>
                </div>`).join("")}</div>` : `<p class="notes-empty">${escapeHtml(T("noneYet"))}</p>`}
                ${addingAction ? `<div class="notes-add-row">
                       <input type="text" id="action-input" class="notes-input" placeholder="${escapeHtml(T("secActions"))}\u2026" />
                       <input type="text" id="action-owner-input" class="notes-input notes-owner-input" placeholder="${escapeHtml(T("ownerLabel"))}" />
                       <button type="button" class="mini-btn" id="btn-save-action">${escapeHtml(T("saveShort"))}</button>
                       <button type="button" class="mini-btn" id="btn-cancel-action">${escapeHtml(T("draftCancel"))}</button>
                     </div>` : `<div class="notes-draft-actions"><button type="button" class="mini-btn" id="btn-add-action">+ ${escapeHtml(T("secActions"))}</button></div>`}
              </div>
              ${latest.length ? `<div class="notes-latest-label">${escapeHtml(T("latest"))}</div>
              <div class="notes-latest" id="notes-open-list">${latest.map((i, idx) => `
                <div class="notes-latest-row${idx === latest.length - 1 && latest.length > 2 ? " dim" : ""}" data-ref="${escapeHtml(i.ref)}">
                  <span class="rail" style="background:${TYPE_COLOR[i.type]}"></span>
                  <span class="body">
                    <span class="txt">${escapeHtml(i.text)}</span>
                    <span class="meta">${i.tc ? `${escapeHtml(i.tc)} \xB7 ` : ""}${i.speaker ? `${escapeHtml(i.speaker)} \xB7 ` : ""}${i.conf != null ? `<span class="${i.low ? "low" : ""}">${i.conf}%</span>` : escapeHtml(i.ref)}</span>
                  </span>
                </div>`).join("")}</div>` : ""}` : `<p class="notes-empty">${escapeHtml(T("nothingLeft"))}</p>`}
      </div>

      <div class="notes-toolbar">
        <button type="button" class="btn primary notes-open-btn" id="btn-open-register" data-tour="notes-open-register">
          ${escapeHtml(T("openRegister"))}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 16 16 8"/><path d="M9.5 8H16v6.5"/></svg>
        </button>
        ${active ? `<div class="notes-export-row">
          <button type="button" class="mini-btn" id="btn-notes-txt">TXT</button>
          <button type="button" class="mini-btn" id="btn-notes-md">Markdown</button>
          <button type="button" class="mini-btn" id="btn-notes-sync" title="Dorong ke penyimpanan bersama Native Helper">Sync</button>
        </div>` : ""}
        ${!meetings.length ? `<button type="button" class="btn ghost" id="btn-notes-sample">${escapeHtml(T("startNext"))} (${escapeHtml(T("minutes"))} demo)</button>` : ""}
      </div>
      <p class="notes-meta notes-hint">${escapeHtml(T("panelHint"))}</p>

      ${meetings.length ? `<div class="notes-block notes-collapsible${meetingsCollapsed ? " collapsed" : ""}" id="notes-recent-block">
            <div class="notes-block-head">
              <button type="button" class="notes-block-toggle" id="btn-toggle-meetings"
                      aria-expanded="${meetingsCollapsed ? "false" : "true"}" aria-controls="notes-saved-list">
                <span class="notes-chevron" aria-hidden="true">\u203A</span>
                <h3>${escapeHtml(T("meetings"))}</h3>
              </button>
              <span class="notes-count">${meetings.length}</span>
            </div>
            <div class="notes-saved-list" id="notes-saved-list">
              ${meetings.slice(0, MEETINGS_VISIBLE).map(
    (m) => `
                <div class="notes-saved-row">
                  <button type="button" class="notes-saved-item${m.id === active?.id ? " active" : ""}" data-meeting-id="${escapeHtml(m.id)}">
                    <div>
                      <div class="ns-title">${escapeHtml(m.title)}</div>
                      <div class="ns-meta">${escapeHtml(m.date)}${m.issuedAt ? ` \xB7 ${escapeHtml(T("issued"))}` : ""}</div>
                    </div>
                  </button>
                  <button type="button" class="mini-btn row-del" data-meeting-del="${escapeHtml(m.id)}" title="\u2715">\u2715</button>
                </div>`
  ).join("")}
            </div>
          </div>` : ""}
    </div>
  `;
  root.querySelector("#btn-toggle-meetings")?.addEventListener("click", () => {
    const block = root.querySelector("#notes-recent-block");
    const nowCollapsed = !block.classList.contains("collapsed");
    block.classList.toggle("collapsed", nowCollapsed);
    root.querySelector("#btn-toggle-meetings").setAttribute("aria-expanded", String(!nowCollapsed));
    setCollapsed("notesMeetings", nowCollapsed);
  });
  const bar = state2.headMount;
  if (bar) {
    bar.innerHTML = meetingBarHtml({ meetings, active, T, creating: !!state2.creatingMeeting });
    bar.querySelector("#notes-meeting-switch")?.addEventListener(
      "change",
      (e) => handlers.onSelectMeeting?.(e.target.value)
    );
    bar.querySelector("#btn-notes-new")?.addEventListener("click", () => handlers.onNewMeetingStart?.());
    bar.querySelector("#btn-notes-new-cancel")?.addEventListener("click", () => handlers.onNewMeetingCancel?.());
    const input = bar.querySelector("#notes-new-title");
    const commit = () => handlers.onNewMeetingSave?.(input?.value || "");
    bar.querySelector("#btn-notes-new-save")?.addEventListener("click", commit);
    input?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        commit();
      } else if (e.key === "Escape") {
        e.preventDefault();
        handlers.onNewMeetingCancel?.();
      }
    });
    if (input && document.activeElement !== input) input.focus();
  }
  root.querySelector("#btn-open-register")?.addEventListener("click", () => handlers.onOpenRegister?.());
  root.querySelector("#btn-end-draft")?.addEventListener("click", () => handlers.onEndAndDraft?.());
  root.querySelector("#btn-flag-moment")?.addEventListener("click", () => handlers.onFlagMoment?.());
  root.querySelector("#btn-notes-sample")?.addEventListener("click", () => handlers.onLoadSample?.());
  root.querySelector("#notes-project-type")?.addEventListener("change", (e) => handlers.onProjectType?.(e.target.value));
  root.querySelector("#btn-notes-txt")?.addEventListener("click", () => handlers.onExportNotes?.("txt"));
  root.querySelector("#btn-notes-md")?.addEventListener("click", () => handlers.onExportNotes?.("md"));
  root.querySelector("#btn-notes-sync")?.addEventListener("click", (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    Promise.resolve(handlers.onPushShared?.()).finally(() => {
      btn.disabled = false;
    });
  });
  root.querySelector("#btn-auto-summary")?.addEventListener("click", () => handlers.onGenerateSummary?.());
  root.querySelector("#btn-save-summary")?.addEventListener("click", () => handlers.onSaveSummary?.());
  root.querySelector("#btn-cancel-summary")?.addEventListener("click", () => handlers.onCancelSummary?.());
  root.querySelector("#btn-add-decision")?.addEventListener("click", () => handlers.onAddDecision?.());
  root.querySelector("#btn-save-decision")?.addEventListener("click", () => handlers.onSaveDecision?.());
  root.querySelector("#btn-cancel-decision")?.addEventListener("click", () => handlers.onCancelDecision?.());
  root.querySelector("#btn-add-action")?.addEventListener("click", () => handlers.onAddAction?.());
  root.querySelector("#btn-save-action")?.addEventListener("click", () => handlers.onSaveAction?.());
  root.querySelector("#btn-cancel-action")?.addEventListener("click", () => handlers.onCancelAction?.());
  root.querySelectorAll("[data-del]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      handlers.onDeleteDecision?.(btn.getAttribute("data-del"));
    });
  });
  root.querySelectorAll(".notes-latest-row[data-ref]").forEach((row) => {
    row.addEventListener("click", () => handlers.onOpenRegister?.());
  });
  root.querySelectorAll("[data-meeting-id]").forEach((btn) => {
    btn.addEventListener("click", () => handlers.onSelectMeeting?.(btn.getAttribute("data-meeting-id")));
  });
  root.querySelectorAll("[data-meeting-del]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      handlers.onDeleteMeeting?.(btn.getAttribute("data-meeting-del"));
    });
  });
}
async function mountNotesPanel(root, { getCapture: getCapture2, getSessionLines, onEndCapture, onExportNotes, onPushShared } = {}) {
  const lang = (document.documentElement.lang || "en").startsWith("id") ? "id" : "en";
  const T = makeT(lang);
  let meetings = await listMeetings();
  let activeId = meetings[0]?.id || null;
  let projectType = await loadProjectTypePref();
  if (root.__notesTick) {
    clearInterval(root.__notesTick);
    root.__notesTick = null;
  }
  if (root.__notesNoticeTimer) {
    clearTimeout(root.__notesNoticeTimer);
    root.__notesNoticeTimer = null;
  }
  let addingDecision = false;
  let addingAction = false;
  let creatingMeeting = false;
  const guardEditable = (meeting) => {
    if (!meeting) {
      say(T("msgNoMeeting"));
      return false;
    }
    if (meeting.issuedAt) {
      say(T("flagRefusedIssued"));
      return false;
    }
    return true;
  };
  const persistMeeting = async (meeting) => {
    await saveMeeting(meeting);
    meetings = await listMeetings();
    redraw();
  };
  let summaryDraft = null;
  const draftSummary = (meeting) => {
    const texts = (meeting?.items || []).map((i) => pickText(i.text, lang).trim()).filter(Boolean);
    if (!texts.length) return null;
    if (texts.length === 1) return texts[0];
    return `${texts[0]} \u2026 ${texts[texts.length - 1]} (${texts.length} butir).`;
  };
  let notice = null;
  const say = (msg) => {
    notice = msg;
    try {
      window.__ltsToast?.(msg, "error");
    } catch {
    }
    redraw();
    clearTimeout(root.__notesNoticeTimer);
    root.__notesNoticeTimer = setTimeout(() => {
      notice = null;
      root.__notesNoticeTimer = null;
      redraw();
    }, NOTICE_MS);
  };
  const readCapture = () => {
    if (!getCapture2) return null;
    const c = getCapture2() || {};
    return { running: !!c.running, startedAt: c.startedAt ?? null, engine: c.engine || "" };
  };
  const draftFromSession = async (lines, cap) => {
    if (!lines.length) return;
    const active = meetings.find((m) => m.id === activeId) || null;
    if (active?.issuedAt) return;
    const { generateNotesFromTranscript: generateNotesFromTranscript2 } = await Promise.resolve().then(() => (init_notes_generate(), notes_generate_exports));
    const gen = generateNotesFromTranscript2(lines, {
      title: active?.title || T("untitledMeeting"),
      locale: lang,
      source: cap?.engine || "realtime",
      projectType,
      seriesId: active?.seriesId,
      date: active?.date
    });
    const merged = active ? {
      ...gen,
      id: active.id,
      seq: active.seq,
      seriesId: active.seriesId,
      title: active.title,
      agenda: active.agenda,
      attendees: active.attendees.length ? active.attendees : gen.attendees,
      summary: Object.keys(active.summary || {}).length ? active.summary : gen.summary,
      items: [...active.items, ...gen.items]
    } : gen;
    const saved = await saveMeeting(merged);
    meetings = await listMeetings();
    activeId = saved?.id || merged.id;
    say(T("draftFromSession", gen.items.length));
  };
  const flagNow = async () => {
    const cap = readCapture();
    if (!cap?.running) return;
    const t0 = elapsedSeconds(cap);
    const tc = toTimecode(t0);
    let meeting = meetings.find((m) => m.id === activeId) || null;
    if (meeting?.issuedAt) {
      say(T("flagRefusedIssued"));
      return;
    }
    if (!meeting) {
      meeting = await saveMeeting(
        createMeeting({
          title: T("untitledMeeting"),
          date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
          locale: lang,
          projectType
        })
      );
    }
    try {
      await flagMomentAndSave(meeting, { tc, t0, text: T("flaggedAt", tc) });
    } catch (e) {
      console.warn("[notes] flagMoment:", e?.message || e);
      say(e?.code === "issued" ? T("flagRefusedIssued") : String(e?.message || e));
      return;
    }
    meetings = await listMeetings();
    activeId = meeting.id;
    try {
      window.__ltsToast?.(T("flaggedAt", tc), "ok");
    } catch {
    }
    redraw();
  };
  const redraw = () => {
    renderNotesPanel(
      root,
      {
        meetings,
        active: meetings.find((m) => m.id === activeId) || null,
        lang,
        T,
        capture: readCapture(),
        notice,
        summaryDraft,
        addingDecision,
        addingAction,
        projectType,
        creatingMeeting,
        headMount: document.getElementById("notes-meeting-bar")
      },
      {
        onOpenRegister: openRegister,
        onFlagMoment: flagNow,
        onExportNotes: (kind) => onExportNotes?.(kind),
        onPushShared: async () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (!meeting) {
            say(T("msgNoMeeting"));
            return;
          }
          try {
            const note = await onPushShared?.(meeting, lang);
            if (note) {
              try {
                window.__ltsToast?.(note.title || "Synced", "ok");
              } catch {
              }
            } else {
              say(lang === "id" ? "Helper native luring" : "Native helper offline");
            }
          } catch (e) {
            say(String(e?.message || e));
          }
        },
        onGenerateSummary: () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (meeting?.issuedAt) {
            say(T("flagRefusedIssued"));
            return;
          }
          summaryDraft = draftSummary(meeting);
          if (!summaryDraft) {
            say(T("noneYet"));
            return;
          }
          redraw();
        },
        onSaveSummary: async () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (!meeting || !summaryDraft) return;
          if (meeting.issuedAt) {
            say(T("flagRefusedIssued"));
            return;
          }
          try {
            meeting.summary = { ...meeting.summary || {}, [lang]: summaryDraft };
            await saveMeeting(meeting);
          } catch (e) {
            say(String(e?.message || e));
            return;
          }
          summaryDraft = null;
          meetings = await listMeetings();
          try {
            window.__ltsToast?.(T("msgSummarySaved"), "ok");
          } catch {
          }
          redraw();
        },
        onCancelSummary: () => {
          summaryDraft = null;
          redraw();
        },
        onAddDecision: () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (!meeting) {
            say(T("msgNoMeeting"));
            return;
          }
          if (meeting.issuedAt) {
            say(T("flagRefusedIssued"));
            return;
          }
          addingDecision = true;
          redraw();
          root.querySelector("#decision-input")?.focus();
        },
        onSaveDecision: async () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          const text = root.querySelector("#decision-input")?.value.trim() || "";
          if (!meeting || !text) {
            addingDecision = false;
            redraw();
            return;
          }
          addingDecision = false;
          try {
            await persistMeeting(addItem(meeting, { type: "decision", text: { [lang]: text } }));
          } catch (e) {
            say(e?.code === "issued" ? T("flagRefusedIssued") : String(e?.message || e));
            return;
          }
          try {
            window.__ltsToast?.(T("secDecisions"), "ok");
          } catch {
          }
        },
        onCancelDecision: () => {
          addingDecision = false;
          redraw();
        },
        onDeleteDecision: async (ref) => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (!meeting || !ref) return;
          try {
            await persistMeeting(removeItem(meeting, ref));
          } catch (e) {
            say(e?.code === "issued" ? T("flagRefusedIssued") : String(e?.message || e));
          }
        },
        onAddAction: () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (!guardEditable(meeting)) return;
          addingAction = true;
          redraw();
          root.querySelector("#action-input")?.focus();
        },
        onSaveAction: async () => {
          const meeting = meetings.find((m) => m.id === activeId) || null;
          const text = root.querySelector("#action-input")?.value.trim() || "";
          const owner = root.querySelector("#action-owner-input")?.value.trim() || null;
          addingAction = false;
          if (!meeting || !text) {
            redraw();
            return;
          }
          try {
            await persistMeeting(
              addItem(meeting, { type: "action", text: { [lang]: text }, ...owner ? { owner } : {} })
            );
          } catch (e) {
            say(e?.code === "issued" ? T("flagRefusedIssued") : String(e?.message || e));
          }
        },
        onCancelAction: () => {
          addingAction = false;
          redraw();
        },
        onEndAndDraft: async () => {
          const cap = readCapture();
          const lines = (getSessionLines?.() || []).slice();
          await onEndCapture?.();
          try {
            await draftFromSession(lines, cap);
          } catch (e) {
            console.warn("[notes] draftFromSession:", e?.message || e);
          }
          openRegister();
        },
        onProjectType: async (v) => {
          projectType = await saveProjectTypePref(v);
          const meeting = meetings.find((m) => m.id === activeId) || null;
          if (meeting && !meeting.issuedAt && meeting.projectType !== projectType) {
            await saveMeeting({ ...meeting, projectType });
            meetings = await listMeetings();
          }
          redraw();
        },
        onSelectMeeting: (id3) => {
          activeId = id3;
          summaryDraft = null;
          addingDecision = false;
          addingAction = false;
          creatingMeeting = false;
          redraw();
        },
        onNewMeetingStart: () => {
          creatingMeeting = true;
          redraw();
        },
        onNewMeetingCancel: () => {
          creatingMeeting = false;
          redraw();
        },
        // Rapat baru = seri baru (proyek baru), bukan lanjutan seri yang aktif.
        // Zona waktu dan pemimpin rapat ikut dari rapat aktif kalau ada, sisanya kosong.
        onNewMeetingSave: async (rawTitle) => {
          const title = String(rawTitle || "").trim();
          if (!title) {
            say(T("newMeetingNeedsTitle"));
            return;
          }
          const base2 = meetings.find((m) => m.id === activeId) || null;
          const meeting = createMeeting({
            title,
            projectType,
            locale: lang,
            seriesId: `S-${Date.now().toString(36)}`,
            tz: base2?.tz,
            chair: base2?.chair
          });
          try {
            await saveMeeting(meeting);
          } catch (e) {
            say(String(e?.message || e));
            return;
          }
          meetings = await listMeetings();
          activeId = meeting.id;
          creatingMeeting = false;
          summaryDraft = null;
          addingDecision = false;
          addingAction = false;
          redraw();
        },
        onDeleteMeeting: async (id3) => {
          if (!id3) return;
          try {
            await deleteMeeting(id3);
          } catch (e) {
            say(String(e?.message || e));
            return;
          }
          meetings = await listMeetings();
          if (activeId === id3) {
            activeId = meetings[0]?.id || null;
            summaryDraft = null;
            addingDecision = false;
            addingAction = false;
          }
          redraw();
        },
        onLoadSample: async () => {
          await seedSampleData();
          meetings = await listMeetings();
          activeId = meetings[0]?.id || null;
          redraw();
          openRegister();
        }
      }
    );
  };
  redraw();
  if (getCapture2) {
    let wasRunning = readCapture().running;
    root.__notesTick = setInterval(() => {
      const cap = readCapture();
      if (cap.running !== wasRunning) {
        wasRunning = cap.running;
        redraw();
        return;
      }
      if (!cap.running) return;
      const clock = root.querySelector("#notes-elapsed");
      if (clock) clock.textContent = toTimecode(elapsedSeconds(cap));
    }, 1e3);
  }
  return () => ({ meetings, activeId });
}

// src/lib/friendly-error.js
var RULES = [
  { key: "cancelled", test: /^cancelled$|cancelled/i, action: null },
  { key: "captureBlocked", test: /invoked|activeTab|not been invoked/i, action: "pick" },
  { key: "pageNotCapturable", test: /cannot be captured|normal website tab|chrome:\/\/|chrome-extension:/i, action: null },
  { key: "noAudioShared", test: /no audio was shared|canRequestAudioTrack|no audio track/i, action: "pick" },
  { key: "captureFailed", test: /audio capture failed|getMediaStreamId|tabCapture|capture-ended|track ended/i, action: "retry" },
  { key: "fileTooLarge", test: /1\.5 ?GB|need ffmpeg|ffmpeg/i, action: "settings" },
  { key: "fileRead", test: /could not be read|NotReadableError|permission denied reading/i, action: null },
  { key: "webgpu", test: /WebGPU/i, action: "settings" },
  { key: "nativeOffline", test: /native \/\w+ \d+|Failed to fetch|ECONNREFUSED|NetworkError|Load failed|helper (is )?(offline|not running|unavailable)|nativeMessaging unavailable/i, action: "settings" },
  { key: "outOfMemory", test: /out of memory|OOM|RangeError|allocation failed|memory/i, action: "settings" },
  { key: "vad", test: /VAD init failed/i, action: "retry" },
  { key: "modelLoad", test: /model|download|onnx|404|Failed to load|not loaded|checkpoint|HTTP error/i, action: "settings" }
];
function classifyError(raw) {
  const detail = String(raw?.message ?? raw ?? "").trim();
  for (const r of RULES) {
    if (r.test.test(detail)) return { key: r.key, action: r.action, detail };
  }
  return { key: "generic", action: "retry", detail };
}
var errTitleKey = (key) => `err_${key}_title`;
var errHintKey = (key) => `err_${key}_hint`;

// src/lib/resizable.js
function clampSize(value, min, max) {
  if (value == null || value === "") return null;
  const v = Number(value);
  if (!Number.isFinite(v)) return null;
  return Math.min(max, Math.max(min, Math.round(v)));
}
async function readSaved(key) {
  try {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return null;
    const { [key]: v } = await chrome.storage.local.get(key);
    return v ?? null;
  } catch {
    return null;
  }
}
async function writeSaved(key, value) {
  try {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return;
    if (value == null) await chrome.storage.local.remove(key);
    else await chrome.storage.local.set({ [key]: value });
  } catch {
  }
}
async function makeResizable(target, opts) {
  const { storageKey, min = 160, max = 1200, axis = "height", label: label2 = "Resize panel" } = opts;
  const prop = axis === "width" ? "width" : "height";
  const handle = document.createElement("div");
  handle.className = `resize-handle resize-${axis}`;
  handle.setAttribute("role", "separator");
  handle.setAttribute("aria-orientation", axis === "width" ? "vertical" : "horizontal");
  handle.setAttribute("aria-label", label2);
  handle.title = `${label2} \u2014 double-click to reset`;
  handle.tabIndex = 0;
  target.insertAdjacentElement("afterend", handle);
  target.classList.add("resizable-target");
  let current = null;
  const apply = (px) => {
    current = px == null ? null : clampSize(px, min, max);
    target.style[prop] = current == null ? "" : `${current}px`;
    target.classList.toggle("resized", current != null);
    handle.setAttribute("aria-valuenow", current == null ? "" : String(current));
  };
  apply(clampSize(await readSaved(storageKey), min, max));
  let startPos = 0;
  let startSize = 0;
  handle.addEventListener("pointerdown", (ev) => {
    if (ev.button !== 0) return;
    ev.preventDefault();
    handle.setPointerCapture(ev.pointerId);
    startPos = axis === "width" ? ev.clientX : ev.clientY;
    startSize = target.getBoundingClientRect()[prop];
    handle.classList.add("dragging");
    document.body.classList.add("is-resizing");
  });
  handle.addEventListener("pointermove", (ev) => {
    if (!handle.classList.contains("dragging")) return;
    const pos = axis === "width" ? ev.clientX : ev.clientY;
    apply(startSize + (pos - startPos));
  });
  const end = (ev) => {
    if (!handle.classList.contains("dragging")) return;
    handle.classList.remove("dragging");
    document.body.classList.remove("is-resizing");
    try {
      handle.releasePointerCapture(ev.pointerId);
    } catch {
    }
    writeSaved(storageKey, current);
  };
  handle.addEventListener("pointerup", end);
  handle.addEventListener("pointercancel", end);
  handle.addEventListener("dblclick", () => {
    apply(null);
    writeSaved(storageKey, null);
  });
  handle.addEventListener("keydown", (ev) => {
    const step = ev.shiftKey ? 40 : 10;
    const grow = axis === "width" ? "ArrowRight" : "ArrowDown";
    const shrink = axis === "width" ? "ArrowLeft" : "ArrowUp";
    if (ev.key !== grow && ev.key !== shrink && ev.key !== "Home") return;
    ev.preventDefault();
    if (ev.key === "Home") apply(null);
    else apply((current ?? target.getBoundingClientRect()[prop]) + (ev.key === grow ? step : -step));
    writeSaved(storageKey, current);
  });
  return {
    handle,
    set: (px) => {
      apply(px);
      writeSaved(storageKey, current);
    },
    reset: () => {
      apply(null);
      writeSaved(storageKey, null);
    },
    get: () => current
  };
}

// src/lib/perf-log.js
var PERF_KEY = "perfSamples";
var STAGES = (
  /** @type {const} */
  ["asr", "asr-partial", "mt", "mt-partial", "draft", "refine"]
);
var SERIES = (
  /** @type {const} */
  [
    { id: "native", label: { en: "Native helper", id: "Helper native" }, cssVar: "--viz-1" },
    { id: "browser-webgpu", label: { en: "Browser \xB7 WebGPU", id: "Browser \xB7 WebGPU" }, cssVar: "--viz-2" },
    { id: "browser-wasm", label: { en: "Browser \xB7 WASM", id: "Browser \xB7 WASM" }, cssVar: "--viz-3" }
  ]
);
var num2 = (v, d = null) => Number.isFinite(Number(v)) ? Number(v) : d;
var str2 = (v) => v == null ? null : String(v);
function seriesOf(s) {
  if (s.engine === "native") return "native";
  return String(s.device || "").toLowerCase() === "webgpu" ? "browser-webgpu" : "browser-wasm";
}
function normalizeSample(raw) {
  if (!raw || typeof raw !== "object") return null;
  const ms = num2(raw.ms);
  const stage = STAGES.includes(raw.stage) ? raw.stage : null;
  if (ms == null || ms < 0 || !stage) return null;
  const out = {
    at: str2(raw.at) || (/* @__PURE__ */ new Date(0)).toISOString(),
    stage,
    ms: Math.round(ms),
    engine: raw.engine === "native" ? "native" : "browser",
    device: str2(raw.device) || "wasm",
    platform: ["macos", "windows", "linux"].includes(raw.platform) ? raw.platform : "unknown",
    src: str2(raw.src),
    tgt: str2(raw.tgt),
    audioSec: num2(raw.audioSec),
    chars: num2(raw.chars),
    mode: raw.mode === "offline" || raw.mode === "bench" ? raw.mode : "realtime",
    source: raw.source === "bench" || raw.source === "import" ? raw.source : "session"
  };
  out.series = seriesOf(out);
  return out;
}
function normalizeAll(list) {
  return (Array.isArray(list) ? list : []).map(normalizeSample).filter(Boolean);
}
function pairLabel2(s) {
  if (!s.src) return "\u2014";
  return s.tgt && s.tgt !== s.src ? `${s.src}\u2192${s.tgt}` : s.src;
}
function quantile(values, q) {
  const v = values.filter((n) => Number.isFinite(n)).sort((a, b) => a - b);
  if (!v.length) return null;
  const pos = (v.length - 1) * q;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  return lo === hi ? v[lo] : v[lo] + (v[hi] - v[lo]) * (pos - lo);
}
function summarize(samples) {
  const ms = samples.map((s) => s.ms);
  const withAudio = samples.filter((s) => s.audioSec > 0 && (s.stage.startsWith("asr") || s.stage === "draft"));
  const rtf = withAudio.length ? quantile(withAudio.map((s) => s.ms / (s.audioSec * 1e3)), 0.5) : null;
  return {
    n: samples.length,
    p50: quantile(ms, 0.5),
    p95: quantile(ms, 0.95),
    mean: ms.length ? Math.round(ms.reduce((a, b) => a + b, 0) / ms.length) : null,
    min: ms.length ? Math.min(...ms) : null,
    max: ms.length ? Math.max(...ms) : null,
    rtf: rtf == null ? null : Math.round(rtf * 1e3) / 1e3
  };
}
function groupBy(samples, keyFn) {
  const m = /* @__PURE__ */ new Map();
  for (const s of samples) {
    const k = keyFn(s);
    if (!m.has(k)) m.set(k, []);
    m.get(k).push(s);
  }
  return m;
}
function filterSamples(samples, f = {}) {
  return samples.filter((s) => {
    if (f.stage && f.stage !== "all" && s.stage !== f.stage) return false;
    if (f.series && f.series.size && !f.series.has(s.series)) return false;
    if (f.pair && f.pair !== "all" && pairLabel2(s) !== f.pair) return false;
    if (f.source && f.source !== "all" && s.source !== f.source) return false;
    if (f.platform && f.platform !== "all" && s.platform !== f.platform) return false;
    return true;
  });
}
function p50ByPair(samples, { limit = 12 } = {}) {
  const rows = [...groupBy(samples, pairLabel2).entries()].map(([label2, list]) => ({
    label: label2,
    value: summarize(list).p50,
    n: list.length
  }));
  rows.sort((a, b) => (b.value ?? 0) - (a.value ?? 0));
  if (rows.length <= limit) return rows;
  const head = rows.slice(0, limit - 1);
  const rest = rows.slice(limit - 1);
  const all = samples.filter((s) => rest.some((r) => r.label === pairLabel2(s)));
  head.push({ label: "Other", value: summarize(all).p50, n: all.length, other: true });
  return head;
}
function scatterPoints(samples) {
  return samples.filter((s) => s.audioSec > 0).map((s) => ({ x: s.audioSec, y: s.ms, series: s.series, label: `${pairLabel2(s)} \xB7 ${s.stage}` }));
}
function lineSeries(samples) {
  const sorted = [...samples].sort((a, b) => a.at.localeCompare(b.at));
  return SERIES.map((ser) => ({
    id: ser.id,
    label: ser.label,
    points: sorted.filter((s) => s.series === ser.id).map((s, i) => ({ x: i + 1, y: s.ms, at: s.at }))
  })).filter((s) => s.points.length);
}
function fromBenchJson(json, { platform } = {}) {
  const rows = Array.isArray(json?.rows) ? json.rows : [];
  const engine = json?.health?.engine ? "native" : "native";
  const dev = String(json?.health?.device || json?.health?.platform || "").toLowerCase();
  const plat = platform || (dev.includes("apple") || dev.includes("mlx") || dev.includes("darwin") ? "macos" : dev.includes("cuda") || dev.includes("cpu") ? "unknown" : "unknown");
  const out = [];
  for (const r of rows) {
    const st = String(r.stage || "");
    const stage = st.startsWith("draft") ? "draft" : st === "final ASR" ? "asr" : st === "fast MT" ? "mt" : st === "refine" ? "refine" : null;
    if (!stage) continue;
    const [src, tgt] = String(r.pair || "").split("\u2192");
    const win = /draft[@ ]([\d.]+)s/.exec(st);
    out.push(normalizeSample({
      at: json?.at || (/* @__PURE__ */ new Date(0)).toISOString(),
      stage,
      ms: r.ms,
      engine,
      device: engine === "native" ? "native" : "wasm",
      platform: plat,
      src: src?.trim() || null,
      tgt: tgt?.trim() || null,
      audioSec: win ? Number(win[1]) : null,
      chars: (r.source || r.translation || "").length || null,
      mode: "bench",
      source: "bench"
    }));
  }
  return out.filter(Boolean);
}
function toReport(samples, meta = {}) {
  const bySeries = {};
  for (const [k, list] of groupBy(samples, (s) => s.series)) bySeries[k] = summarize(list);
  const byStage = {};
  for (const [k, list] of groupBy(samples, (s) => s.stage)) byStage[k] = summarize(list);
  const byPair = {};
  for (const [k, list] of groupBy(samples, pairLabel2)) byPair[k] = summarize(list);
  return {
    version: 1,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    platform: meta.platform || samples[0]?.platform || "unknown",
    app: meta.app || "yraverageSubMin",
    counts: { total: samples.length },
    summary: { bySeries, byStage, byPair },
    samples
  };
}
function fromReport(json) {
  if (!json || json.version !== 1 || !Array.isArray(json.samples)) return [];
  return normalizeAll(json.samples).map((s) => ({ ...s, source: "import" }));
}
var fmt = (v) => v == null ? "\u2014" : String(Math.round(v));
function toMarkdown(report) {
  const L = [];
  L.push(`# Performance report \u2014 ${report.app} (${report.platform})`, "", `Generated ${report.generatedAt} \xB7 ${report.counts.total} samples`, "");
  const table = (title, obj) => {
    L.push(`## ${title}`, "", "| Key | n | p50 ms | p95 ms | mean | RTF |", "| --- | ---: | ---: | ---: | ---: | ---: |");
    for (const [k, s] of Object.entries(obj)) L.push(`| ${k} | ${s.n} | ${fmt(s.p50)} | ${fmt(s.p95)} | ${fmt(s.mean)} | ${s.rtf ?? "\u2014"} |`);
    L.push("");
  };
  table("By engine", report.summary.bySeries);
  table("By stage", report.summary.byStage);
  table("By language pair", report.summary.byPair);
  return L.join("\n");
}

// src/lib/perf-charts.js
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var fmtMs = (v) => v == null ? "\u2014" : `${Math.round(v)} ms`;
function niceMax(v) {
  if (!(v > 0)) return 1;
  const p = 10 ** Math.floor(Math.log10(v));
  const n = v / p;
  const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return step * p;
}
function ticks(max, count = 4) {
  const out = [];
  for (let i = 0; i <= count; i++) out.push(max * i / count);
  return out;
}
function barChart({ rows, width = 560, unit = "ms", target = null, lang = "en" }) {
  const rowH = 30, barH = 18, padL = 84, padR = 64, padT = 8, padB = 26;
  const data = rows.filter((r) => r.value != null);
  const height = padT + padB + Math.max(1, data.length) * rowH;
  const max = niceMax(Math.max(...data.map((r) => r.value), target || 0));
  const plotW = width - padL - padR;
  const x = (v) => padL + v / max * plotW;
  let g = "";
  for (const t2 of ticks(max)) {
    g += `<line x1="${x(t2)}" y1="${padT}" x2="${x(t2)}" y2="${height - padB}" class="viz-grid"/>`;
    g += `<text x="${x(t2)}" y="${height - 8}" class="viz-tick" text-anchor="middle">${Math.round(t2)}</text>`;
  }
  let bars = "";
  data.forEach((r, i) => {
    const y = padT + i * rowH + (rowH - barH) / 2;
    const w = Math.max(2, x(r.value) - padL);
    const rr = Math.min(4, w / 2);
    const path = `M${padL},${y} h${w - rr} a${rr},${rr} 0 0 1 ${rr},${rr} v${barH - 2 * rr} a${rr},${rr} 0 0 1 -${rr},${rr} h-${w - rr} z`;
    bars += `<g class="viz-hit" data-tip="${esc(r.label)}: ${fmtMs(r.value)} (n=${r.n ?? "?"})">
      <rect x="${padL}" y="${padT + i * rowH}" width="${plotW}" height="${rowH}" fill="transparent"/>
      <path d="${path}" class="viz-bar${r.other ? " viz-bar-other" : ""}"/>
      <text x="${padL - 8}" y="${y + barH / 2 + 4}" class="viz-label" text-anchor="end">${esc(r.label)}</text>
      <text x="${x(r.value) + 6}" y="${y + barH / 2 + 4}" class="viz-value">${Math.round(r.value)}</text>
    </g>`;
  });
  const tgt = target ? `<line x1="${x(target)}" y1="${padT}" x2="${x(target)}" y2="${height - padB}" class="viz-target"/><text x="${x(target) + 4}" y="${padT + 10}" class="viz-tick">${lang === "id" ? "target" : "target"} ${target}</text>` : "";
  return `<svg viewBox="0 0 ${width} ${height}" width="100%" role="img" class="viz" aria-label="p50 ${unit} per language pair">
    <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${height - padB}" class="viz-axis"/>${g}${tgt}${bars}
    ${data.length ? "" : `<text x="${width / 2}" y="${height / 2}" class="viz-empty" text-anchor="middle">\u2014</text>`}
  </svg>`;
}
function scatterChart({ points, series, width = 560, height = 260, lang = "en" }) {
  const padL = 52, padR = 16, padT = 12, padB = 34;
  const maxX = niceMax(Math.max(...points.map((p) => p.x), 1));
  const maxY = niceMax(Math.max(...points.map((p) => p.y), 1));
  const x = (v) => padL + v / maxX * (width - padL - padR);
  const y = (v) => height - padB - v / maxY * (height - padT - padB);
  let g = "";
  for (const t2 of ticks(maxY)) g += `<line x1="${padL}" y1="${y(t2)}" x2="${width - padR}" y2="${y(t2)}" class="viz-grid"/><text x="${padL - 6}" y="${y(t2) + 4}" class="viz-tick" text-anchor="end">${Math.round(t2)}</text>`;
  for (const t2 of ticks(maxX)) g += `<text x="${x(t2)}" y="${height - 12}" class="viz-tick" text-anchor="middle">${+t2.toFixed(1)}</text>`;
  const idx = new Map(series.map((s, i) => [s.id, i + 1]));
  let dots = "";
  for (const p of points) {
    const k = idx.get(p.series) || 1;
    dots += `<g class="viz-hit" data-tip="${esc(p.label || p.series)}: ${fmtMs(p.y)} \xB7 ${+p.x.toFixed(2)} s">
      <circle cx="${x(p.x)}" cy="${y(p.y)}" r="12" fill="transparent"/>
      <circle cx="${x(p.x)}" cy="${y(p.y)}" r="4" class="viz-dot viz-s${k}"/>
    </g>`;
  }
  return `<svg viewBox="0 0 ${width} ${height}" width="100%" role="img" class="viz" aria-label="latency vs audio length">
    <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${height - padB}" class="viz-axis"/>
    <line x1="${padL}" y1="${height - padB}" x2="${width - padR}" y2="${height - padB}" class="viz-axis"/>
    ${g}${dots}
    <text x="${width - padR}" y="${height - 12}" class="viz-tick" text-anchor="end">${lang === "id" ? "audio (dtk)" : "audio (s)"}</text>
    <text x="${padL}" y="${padT}" class="viz-tick">ms</text>
  </svg>`;
}
function lineChart({ series, order, width = 560, height = 220 }) {
  const padL = 52, padR = 16, padT = 12, padB = 26;
  const all = series.flatMap((s) => s.points);
  const maxX = Math.max(...all.map((p) => p.x), 1);
  const maxY = niceMax(Math.max(...all.map((p) => p.y), 1));
  const x = (v) => padL + (v - 1) / Math.max(1, maxX - 1) * (width - padL - padR);
  const y = (v) => height - padB - v / maxY * (height - padT - padB);
  const idx = new Map(order.map((s, i) => [s.id, i + 1]));
  let g = "";
  for (const t2 of ticks(maxY)) g += `<line x1="${padL}" y1="${y(t2)}" x2="${width - padR}" y2="${y(t2)}" class="viz-grid"/><text x="${padL - 6}" y="${y(t2) + 4}" class="viz-tick" text-anchor="end">${Math.round(t2)}</text>`;
  let lines = "";
  for (const s of series) {
    if (!s.points.length) continue;
    const k = idx.get(s.id) || 1;
    const d = s.points.map((p, i) => `${i ? "L" : "M"}${x(p.x)},${y(p.y)}`).join(" ");
    const last = s.points[s.points.length - 1];
    lines += `<path d="${d}" class="viz-line viz-s${k}"/>
      <g class="viz-hit" data-tip="${esc(typeof s.label === "object" ? s.label.en : s.label)}: ${fmtMs(last.y)} (#${last.x})"><circle cx="${x(last.x)}" cy="${y(last.y)}" r="12" fill="transparent"/><circle cx="${x(last.x)}" cy="${y(last.y)}" r="4" class="viz-dot viz-s${k}"/></g>`;
  }
  return `<svg viewBox="0 0 ${width} ${height}" width="100%" role="img" class="viz" aria-label="latency over samples">
    <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${height - padB}" class="viz-axis"/>
    <line x1="${padL}" y1="${height - padB}" x2="${width - padR}" y2="${height - padB}" class="viz-axis"/>
    ${g}${lines}<text x="${padL}" y="${padT}" class="viz-tick">ms</text>
  </svg>`;
}
function legend(series, order, lang = "en") {
  const idx = new Map(order.map((s, i) => [s.id, i + 1]));
  return `<div class="viz-legend">${series.map((s) => `<span class="viz-key"><i class="viz-s${idx.get(s.id) || 1}"></i>${esc(typeof s.label === "object" ? s.label[lang] || s.label.en : s.label)}</span>`).join("")}</div>`;
}

// src/perf-panel.js
var STR = {
  title: { en: "Performance", id: "Kinerja" },
  sub: { en: "How fast recognition and translation run on this machine, per language and per engine. Export a report to compare platforms.", id: "Seberapa cepat pengenalan dan terjemahan berjalan di mesin ini, per bahasa dan per mesin. Ekspor laporan untuk membandingkan platform." },
  stage: { en: "Stage", id: "Tahap" },
  all: { en: "All", id: "Semua" },
  pair: { en: "Language pair", id: "Pasangan bahasa" },
  source: { en: "Source", id: "Sumber" },
  session: { en: "This device", id: "Perangkat ini" },
  bench: { en: "Lab bench", id: "Bench lab" },
  import: { en: "Imported", id: "Impor" },
  kpiAsr: { en: "ASR p50", id: "ASR p50" },
  kpiMt: { en: "MT p50", id: "MT p50" },
  kpiRtf: { en: "RTF (p50)", id: "RTF (p50)" },
  kpiN: { en: "Samples", id: "Sampel" },
  rtfHint: { en: "processing time \xF7 audio time; < 1 is faster than realtime", id: "waktu proses \xF7 durasi audio; < 1 lebih cepat dari realtime" },
  chartPair: { en: "p50 latency per language pair", id: "Latensi p50 per pasangan bahasa" },
  chartScatter: { en: "Latency vs audio length", id: "Latensi vs durasi audio" },
  chartLine: { en: "Latency over samples", id: "Latensi sepanjang sampel" },
  table: { en: "Table", id: "Tabel" },
  charts: { en: "Charts", id: "Grafik" },
  float: { en: "Float", id: "Apungkan" },
  dock: { en: "Dock", id: "Tambatkan" },
  exportJson: { en: "Export report (JSON)", id: "Ekspor laporan (JSON)" },
  exportMd: { en: "Export (Markdown)", id: "Ekspor (Markdown)" },
  importJson: { en: "Import report / bench JSON", id: "Impor laporan / bench JSON" },
  loadBench: { en: "Load lab bench", id: "Muat bench lab" },
  clear: { en: "Clear device samples", id: "Hapus sampel perangkat" },
  empty: { en: "No samples yet. Run a live session or an offline file \u2014 every recognition and translation step is timed automatically.", id: "Belum ada sampel. Jalankan sesi langsung atau berkas offline \u2014 tiap langkah pengenalan dan terjemahan diukur otomatis." },
  imported: { en: (n) => `${n} samples imported`, id: (n) => `${n} sampel diimpor` },
  cleared: { en: "Device samples cleared", id: "Sampel perangkat dihapus" },
  hEngine: { en: "Engine", id: "Mesin" },
  hStage: { en: "Stage", id: "Tahap" },
  hPair: { en: "Pair", id: "Pasangan" },
  hN: "n",
  hP50: "p50",
  hP95: "p95",
  hRtf: "RTF",
  hPlatform: { en: "Platform", id: "Platform" }
};
var pick = (v, lang) => v && typeof v === "object" ? v[lang] ?? v.en : v;
var esc2 = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var fmtMs2 = (v) => v == null ? "\u2014" : `${Math.round(v)} ms`;
function storage() {
  if (globalThis.chrome?.storage?.local) {
    return {
      async get() {
        const o = await chrome.storage.local.get(PERF_KEY);
        return o?.[PERF_KEY] || [];
      },
      async set(v) {
        await chrome.storage.local.set({ [PERF_KEY]: v });
      }
    };
  }
  return {
    async get() {
      try {
        return JSON.parse(localStorage.getItem(PERF_KEY) || "[]");
      } catch {
        return [];
      }
    },
    async set(v) {
      try {
        localStorage.setItem(PERF_KEY, JSON.stringify(v));
      } catch {
      }
    }
  };
}
function mountPerfPanel(root, ctx) {
  const tx = (k, ...a) => {
    const v = pick(STR[k], ctx.lang());
    return typeof v === "function" ? v(...a) : v;
  };
  const store = storage();
  const ui = { samples: [], extra: [], filter: { stage: "all", series: /* @__PURE__ */ new Set(), pair: "all", source: "all" }, view: "charts", floating: false, pos: null };
  let win = null;
  let tip = null;
  const all = () => normalizeAll([...ui.samples, ...ui.extra]);
  const shown = () => filterSamples(all(), ui.filter);
  async function load() {
    ui.samples = await store.get();
    try {
      ui.pos = JSON.parse(localStorage.getItem("perfFloatPos") || "null");
    } catch {
      ui.pos = null;
    }
  }
  function download(name, text, mime) {
    if (ctx.download) return ctx.download(name, text, mime);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: mime }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 3e3);
  }
  function kpi(label2, value, hint = "") {
    return `<div class="perf-kpi" title="${esc2(hint)}"><span class="perf-kpi-v">${esc2(value)}</span><span class="perf-kpi-l">${esc2(label2)}</span></div>`;
  }
  function render() {
    const lang = ctx.lang();
    const host = ui.floating && win ? win.querySelector(".perf-win-body") : root;
    if (!host) return;
    const data = shown();
    const asr = summarize(data.filter((s) => s.stage === "asr"));
    const mt = summarize(data.filter((s) => s.stage === "mt" || s.stage === "refine"));
    const rtf = summarize(data.filter((s) => s.stage === "asr" || s.stage === "draft")).rtf;
    const pairs = [...new Set(all().map(pairLabel2))].sort();
    const seriesPresent = SERIES.filter((s) => data.some((x) => x.series === s.id));
    host.innerHTML = `
      <div class="perf-head">
        <div><h2 class="perf-title">\u{1F4C8} ${esc2(tx("title"))}</h2><p class="perf-sub">${esc2(tx("sub"))}</p></div>
        <div class="perf-actions">
          <button type="button" class="mini-btn" data-act="view">${esc2(ui.view === "charts" ? tx("table") : tx("charts"))}</button>
          <button type="button" class="mini-btn" data-act="float">${esc2(ui.floating ? tx("dock") : tx("float"))}</button>
        </div>
      </div>
      <div class="perf-filters" role="group">
        <label>${esc2(tx("stage"))}<select data-f="stage">${["all", ...STAGES].map((s) => `<option value="${s}"${ui.filter.stage === s ? " selected" : ""}>${s === "all" ? esc2(tx("all")) : s}</option>`).join("")}</select></label>
        <label>${esc2(tx("pair"))}<select data-f="pair"><option value="all"${ui.filter.pair === "all" ? " selected" : ""}>${esc2(tx("all"))}</option>${pairs.map((p) => `<option value="${esc2(p)}"${ui.filter.pair === p ? " selected" : ""}>${esc2(p)}</option>`).join("")}</select></label>
        <label>${esc2(tx("source"))}<select data-f="source">${["all", "session", "bench", "import"].map((s) => `<option value="${s}"${ui.filter.source === s ? " selected" : ""}>${esc2(s === "all" ? tx("all") : tx(s))}</option>`).join("")}</select></label>
        <div class="perf-series">${SERIES.map((s, i) => `<button type="button" class="perf-chip${ui.filter.series.size && !ui.filter.series.has(s.id) ? " off" : ""}" data-series="${s.id}" aria-pressed="${!ui.filter.series.size || ui.filter.series.has(s.id)}"><i class="viz-s${i + 1}"></i>${esc2(pick(s.label, lang))}</button>`).join("")}</div>
      </div>
      ${data.length ? `
      <div class="perf-kpis">${kpi(tx("kpiAsr"), fmtMs2(asr.p50))}${kpi(tx("kpiMt"), fmtMs2(mt.p50))}${kpi(tx("kpiRtf"), rtf == null ? "\u2014" : rtf.toFixed(2), tx("rtfHint"))}${kpi(tx("kpiN"), String(data.length))}</div>
      ${ui.view === "charts" ? `
        <section class="perf-chart"><h3>${esc2(tx("chartPair"))}</h3>${barChart({ rows: p50ByPair(data), target: 500, lang })}</section>
        <section class="perf-chart"><h3>${esc2(tx("chartScatter"))}</h3>${seriesPresent.length > 1 ? legend(seriesPresent, SERIES, lang) : ""}${scatterChart({ points: scatterPoints(data), series: SERIES, lang })}</section>
        <section class="perf-chart"><h3>${esc2(tx("chartLine"))}</h3>${seriesPresent.length > 1 ? legend(seriesPresent, SERIES, lang) : ""}${lineChart({ series: lineSeries(data), order: SERIES })}</section>` : `<div class="perf-table-wrap"><table class="perf-table"><thead><tr><th>${esc2(tx("hEngine"))}</th><th>${esc2(tx("hPlatform"))}</th><th>${esc2(tx("hStage"))}</th><th>${esc2(tx("hPair"))}</th><th>n</th><th>p50</th><th>p95</th><th>RTF</th></tr></thead><tbody>${[...groupBy(data, (s) => [s.series, s.platform, s.stage, pairLabel2(s)].join("|")).entries()].map(([k, list]) => {
      const [ser, plat, st, pr] = k.split("|");
      const sm = summarize(list);
      return `<tr><td>${esc2(pick(SERIES.find((x) => x.id === ser)?.label, lang) || ser)}</td><td>${esc2(plat)}</td><td>${esc2(st)}</td><td>${esc2(pr)}</td><td>${sm.n}</td><td>${Math.round(sm.p50)}</td><td>${Math.round(sm.p95)}</td><td>${sm.rtf ?? "\u2014"}</td></tr>`;
    }).join("")}</tbody></table></div>`}` : `<p class="perf-empty">${esc2(tx("empty"))}</p>`}
      <div class="perf-foot">
        <button type="button" class="mini-btn" data-act="export-json"${data.length ? "" : " disabled"}>${esc2(tx("exportJson"))}</button>
        <button type="button" class="mini-btn" data-act="export-md"${data.length ? "" : " disabled"}>${esc2(tx("exportMd"))}</button>
        <label class="mini-btn perf-import">${esc2(tx("importJson"))}<input type="file" accept="application/json,.json" hidden data-act="import"></label>
        <button type="button" class="mini-btn" data-act="load-bench">${esc2(tx("loadBench"))}</button>
        <button type="button" class="mini-btn" data-act="clear"${ui.samples.length ? "" : " disabled"}>${esc2(tx("clear"))}</button>
      </div>
      <div class="perf-tip" hidden></div>`;
    wire2(host);
  }
  function wire2(host) {
    host.querySelectorAll("select[data-f]").forEach((sel) => sel.addEventListener("change", () => {
      ui.filter[sel.dataset.f] = sel.value;
      render();
    }));
    host.querySelectorAll("[data-series]").forEach((b) => b.addEventListener("click", () => {
      const id3 = b.dataset.series;
      if (ui.filter.series.has(id3)) ui.filter.series.delete(id3);
      else ui.filter.series.add(id3);
      if (ui.filter.series.size === SERIES.length) ui.filter.series.clear();
      render();
    }));
    host.querySelector('[data-act="view"]')?.addEventListener("click", () => {
      ui.view = ui.view === "charts" ? "table" : "charts";
      render();
    });
    host.querySelector('[data-act="float"]')?.addEventListener("click", () => ui.floating ? dock() : float());
    host.querySelector('[data-act="export-json"]')?.addEventListener("click", () => {
      const rep = toReport(shown(), { platform: shown()[0]?.platform });
      download(`yraveragesub-performance-${rep.generatedAt.slice(0, 10)}.json`, JSON.stringify(rep, null, 2), "application/json");
    });
    host.querySelector('[data-act="export-md"]')?.addEventListener("click", () => {
      const rep = toReport(shown(), { platform: shown()[0]?.platform });
      download(`yraveragesub-performance-${rep.generatedAt.slice(0, 10)}.md`, toMarkdown(rep), "text/markdown");
    });
    host.querySelector('[data-act="import"]')?.addEventListener("change", async (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      try {
        const json = JSON.parse(await f.text());
        const added = json.version === 1 ? fromReport(json) : fromBenchJson(json);
        ui.extra.push(...added);
        ctx.toast?.(tx("imported", added.length));
      } catch (err) {
        ctx.toast?.(String(err?.message || err));
      }
      render();
    });
    host.querySelector('[data-act="load-bench"]')?.addEventListener("click", async () => {
      try {
        const r = await fetch("/last-bench.json", { cache: "no-store" });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const added = fromBenchJson(await r.json(), { platform: "macos" });
        ui.extra = ui.extra.filter((s) => s.source !== "bench").concat(added);
        ctx.toast?.(tx("imported", added.length));
      } catch (err) {
        ctx.toast?.(`bench: ${err?.message || err}`);
      }
      render();
    });
    host.querySelector('[data-act="clear"]')?.addEventListener("click", async () => {
      ui.samples = [];
      await store.set([]);
      ctx.toast?.(tx("cleared"));
      render();
    });
    tip = host.querySelector(".perf-tip");
    host.querySelectorAll(".viz-hit").forEach((h) => {
      h.addEventListener("pointerenter", (e) => {
        tip.textContent = h.dataset.tip;
        tip.hidden = false;
        place(e);
      });
      h.addEventListener("pointermove", place);
      h.addEventListener("pointerleave", () => {
        tip.hidden = true;
      });
    });
  }
  function place(e) {
    if (!tip) return;
    const r = tip.parentElement.getBoundingClientRect();
    tip.style.left = `${Math.min(e.clientX - r.left + 12, r.width - 200)}px`;
    tip.style.top = `${e.clientY - r.top + 12}px`;
  }
  function float() {
    if (win) return;
    win = document.createElement("div");
    win.className = "perf-win";
    win.innerHTML = `<div class="perf-win-head"><span>\u{1F4C8} ${esc2(tx("title"))}</span><span class="spacer"></span><button type="button" class="mini-btn" data-act="dock">${esc2(tx("dock"))}</button></div><div class="perf-win-body"></div>`;
    document.body.appendChild(win);
    const p = ui.pos || { x: Math.max(8, window.innerWidth - 640), y: 60 };
    win.style.left = `${p.x}px`;
    win.style.top = `${p.y}px`;
    win.querySelector('[data-act="dock"]').addEventListener("click", dock);
    const head = win.querySelector(".perf-win-head");
    let drag = null;
    head.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      drag = { dx: e.clientX - win.offsetLeft, dy: e.clientY - win.offsetTop };
      head.setPointerCapture(e.pointerId);
    });
    head.addEventListener("pointermove", (e) => {
      if (!drag) return;
      win.style.left = `${Math.max(0, e.clientX - drag.dx)}px`;
      win.style.top = `${Math.max(0, e.clientY - drag.dy)}px`;
    });
    head.addEventListener("pointerup", () => {
      if (!drag) return;
      drag = null;
      ui.pos = { x: win.offsetLeft, y: win.offsetTop };
      try {
        localStorage.setItem("perfFloatPos", JSON.stringify(ui.pos));
      } catch {
      }
    });
    ui.floating = true;
    root.innerHTML = `<p class="perf-empty">${esc2(tx("title"))} \u2192 ${esc2(tx("float"))}</p>`;
    render();
  }
  function dock() {
    ui.floating = false;
    win?.remove();
    win = null;
    render();
  }
  function push(sample) {
    ui.samples.push(sample);
    if (ui.samples.length > 3e3) ui.samples.splice(0, ui.samples.length - 3e3);
    if (!root.classList.contains("hidden") || ui.floating) render();
  }
  load().then(render);
  return { render, push, float, dock, reload: () => load().then(render) };
}

// src/lib/notes-stub.js
var STUB_TRANSCRIPT = [
  {
    t0: 0,
    t1: 12,
    speaker: "Alya",
    text: "Mari kita mulai. Agenda hari ini: status rilis yraverageSubMin dan pembagian tindak lanjut."
  },
  {
    t0: 12,
    t1: 28,
    speaker: "Bima",
    text: "Smoke 26 sub-fitur sudah hijau. Yang masih menahan gerbang: E2E --pick, --native, dan berkas offline."
  },
  {
    t0: 28,
    t1: 45,
    speaker: "Citra",
    text: "Saya usul kita anggap draft native 500 ms sebagai target yang harus digeser ke Fase 2.1 jika belum tercapai minggu ini."
  },
  {
    t0: 45,
    t1: 62,
    speaker: "Alya",
    text: "Keputusan: rilis internal boleh jalan setelah E2E pick dan file lulus; draft latency tetap dilacak tapi tidak memblokir soft-launch."
  },
  {
    t0: 62,
    t1: 80,
    speaker: "Bima",
    text: "Action: Citra kerjakan e2e --pick besok; Bima siapkan --native; Alya update catatan rilis Jumat."
  }
];
var STUB_NOTE = {
  id: "note-demo-001",
  title: "Standup rilis Fase 1 \u2014 contoh",
  source: "transkrip contoh (lokal)",
  status: "ready",
  generatedAt: "2026-09-03T04:00:00Z",
  summary: "Tim meninjau gerbang rilis Fase 1. Smoke katalog 26 sub-fitur sudah lulus; fokus sisa adalah E2E pemilih tab, helper native, dan berkas offline. Soft-launch internal boleh setelah dua E2E itu hijau; target draft 500 ms dilacak terpisah.",
  decisions: [
    "Soft-launch internal setelah E2E --pick dan e2e-file --browser lulus.",
    "Target draft native \u2264500 ms tidak memblokir soft-launch; masuk backlog Fase 2.1."
  ],
  actions: [
    {
      id: "act-1",
      text: "Jalankan dan arsipkan hasil e2e.mjs --pick",
      owner: "Citra",
      due: "2026-09-04",
      status: "open"
    },
    {
      id: "act-2",
      text: "Verifikasi e2e.mjs --native dengan helper hidup",
      owner: "Bima",
      due: "2026-09-04",
      status: "open"
    },
    {
      id: "act-3",
      text: "Perbarui catatan rilis + gerbang mustFix",
      owner: "Alya",
      due: "2026-09-05",
      status: "open"
    }
  ],
  transcriptPreview: STUB_TRANSCRIPT.map((l) => `${l.speaker}: ${l.text}`).join("\n"),
  savedLocally: true
};
var STUB_SAVED_NOTES = [
  STUB_NOTE,
  {
    id: "note-demo-000",
    title: "Retro lab benchmark",
    source: "riwayat sesi \xB7 2026-08-22",
    status: "saved",
    generatedAt: "2026-08-22T22:10:00Z",
    summary: "Bottleneck utama di jalur fast MT; draft ASR relatif cepat di MLX.",
    decisions: ["Pertahankan mlx-whisper Large v3 Turbo sebagai default native."],
    actions: [
      {
        id: "act-r1",
        text: "Profilkan translate_refine vs fast MT",
        owner: "Bima",
        due: null,
        status: "done"
      }
    ],
    transcriptPreview: "(arsip singkat)",
    savedLocally: true
  }
];
var STUB_NOTES_STATE = {
  source: "stub",
  localStatus: (
    /** @type {NotesLocalStatus} */
    "ready"
  ),
  activeNoteId: STUB_NOTE.id,
  note: STUB_NOTE,
  saved: STUB_SAVED_NOTES,
  emptyDecisionsMessage: "Belum ada poin keputusan pada notulen ini.",
  emptyActionsMessage: "Belum ada tindak lanjut. Tambahkan setelah notulen dibuat."
};

// src/helper-status.js
function escapeHtml2(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function renderHelperStatusCard(root, opts) {
  const os = opts.os || detectOs();
  const guide = OS_GUIDES[os] || OS_GUIDES.unknown;
  const online = !!opts.online;
  const health = opts.health || null;
  const engine = opts.engine || "browser";
  const task = opts.task || "transcribe";
  const mode = opts.mode || "realtime";
  const dict = I18N[opts.lang] || I18N.en;
  const tt = (k, ...a) => {
    const v = dict[k] ?? I18N.en[k] ?? k;
    return typeof v === "function" ? v(...a) : v;
  };
  const lf = opts.largeFile === void 0 ? STUB_LARGE_FILE : opts.largeFile;
  const pct = lf ? Math.round((lf.progress || 0) * 100) : 0;
  const lfStage = lf ? tt(`lfStage_${lf.stage || lf.status}`, lf.stage || lf.status) : "";
  const lfDetail = lf ? [
    lf.stage === "upload" && lf.total ? `${formatBytes(lf.loaded || 0)} / ${formatBytes(lf.total)}` : "",
    lf.idx != null && lf.total && lf.stage !== "upload" ? `${lf.idx} / ${lf.total}` : "",
    lf.elapsedS ? tt("lfElapsed", lf.elapsedS) : "",
    lf.status === "error" && lf.error ? lf.error : ""
  ].filter(Boolean).join(" \xB7 ") : "";
  const lfState = lf ? lf.status : "idle";
  const lang = opts.lang || "en";
  const xo = normalizeExportOptions(opts.exportOptions, os);
  const src = opts.exportSource || null;
  const hasSource = !!(src && src.count > 0);
  const exportTitle = src && src.title || (typeof opts.onExport === "function" ? "subtitles" : "meeting_notes_demo");
  root.innerHTML = `
    <div class="helper-status" data-os="${escapeHtml2(os)}">
      <div class="notes-status-row">
        <span class="notes-pill ${online ? "ready" : "error"}" id="helper-conn-pill">
          ${online ? "Helper terhubung" : "Helper terputus"}
        </span>
        <span class="notes-meta">${escapeHtml2(guide.label)} \xB7 ${escapeHtml2(guide.engine)}</span>
      </div>

      <div class="helper-indicators" id="helper-mode-indicators">
        <span class="notes-pill idle">Mode: <strong>${escapeHtml2(mode)}</strong></span>
        <span class="notes-pill idle">Tugas: <strong>${escapeHtml2(task)}</strong></span>
        <span class="notes-pill idle">Mesin: <strong>${escapeHtml2(engine)}</strong></span>
        ${health ? `<span class="notes-pill ready">${escapeHtml2(health.engine || "asr")} \xB7 ${escapeHtml2((health.model || "").split("/").pop() || "")}</span>` : ""}
        ${health && health.device ? `<span class="notes-pill ${String(health.device).toLowerCase() === "cpu" ? "idle" : "ready"}" id="helper-device-pill" title="${escapeHtml2(health.compute || "")}">${String(health.device).toLowerCase() === "apple-silicon" ? "Apple Silicon \xB7 MLX" : String(health.device).toLowerCase() === "cuda" ? "GPU \xB7 CUDA" : "CPU"}${health.compute && String(health.device).toLowerCase() !== "apple-silicon" ? ` \xB7 ${escapeHtml2(health.compute)}` : ""}</span>` : ""}
      </div>

      <div id="helper-disconnect-banner" class="helper-banner ${online || engine !== "native" ? "hidden" : ""}">
        <strong>Helper terputus</strong> \u2014 subtitel tab lewat mesin native tidak bisa berjalan.
        Beralih ke Browser di Settings, atau ikuti panduan ${escapeHtml2(guide.label)} di bawah.
      </div>

      <div class="notes-block">
        <h3>Panduan ${escapeHtml2(guide.label)}</h3>
        <ol class="helper-steps">
          ${guide.steps.map((s) => `<li>${escapeHtml2(s)}</li>`).join("")}
        </ol>
      </div>

      <div class="notes-block helper-lf ${escapeHtml2(lfState)}" id="helper-large-file" data-state="${escapeHtml2(lfState)}">
        <div class="notes-block-head">
          <h3>${escapeHtml2(tt("lfTitle"))}</h3>
          ${lf ? `<span class="notes-pill ${lfState === "running" ? "generating" : lfState === "done" ? "ready" : lfState === "error" ? "error" : "idle"}" id="helper-lf-state">${escapeHtml2(lfStage)}</span>` : ""}
        </div>
        ${lf ? `
        <p class="notes-meta helper-lf-name" title="${escapeHtml2(lf.name)}">${escapeHtml2(lf.name)} \xB7 ${formatBytes(lf.sizeBytes || 0)}</p>
        <div class="helper-progress-track" role="progressbar" aria-label="${escapeHtml2(lfStage)}" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100">
          <div class="helper-progress-bar ${lfState === "running" && lf.stage !== "upload" ? "indeterminate" : ""}" style="width:${pct}%"></div>
        </div>
        <div class="notes-status-row" style="margin-top:8px">
          <span class="notes-meta" id="helper-lf-pct">${pct}%${lfDetail ? ` \xB7 ${escapeHtml2(lfDetail)}` : ""}</span>
          <button type="button" class="mini-btn" id="btn-helper-lf-cancel" ${lf.cancellable && lfState === "running" ? "" : "disabled"}>
            ${escapeHtml2(tt("lfCancel"))}
          </button>
        </div>` : `<p class="notes-meta">${escapeHtml2(tt("lfIdle"))}</p>`}
      </div>

      <div class="notes-block helper-export" id="helper-export">
        <div class="notes-block-head">
          <h3>${escapeHtml2(tt("exportTitle"))}</h3>
          <span class="notes-pill ${hasSource ? "ready" : "idle"}" id="helper-export-source">${hasSource ? escapeHtml2(tt("exportSource", src.count)) : escapeHtml2(guide.label)}</span>
        </div>
        ${hasSource ? "" : `<p class="notes-meta">${escapeHtml2(tt("exportNoSource"))}</p>`}
        <div class="helper-export-formats" role="group" aria-label="${escapeHtml2(tt("exportTitle"))}">
          ${EXPORT_FORMATS.map(
    (f) => `
          <button type="button" class="helper-export-btn" data-export-kind="${f.kind}" ${hasSource || !opts.onExport ? "" : "disabled"}>
            <span class="helper-export-kind">${f.label}</span>
            <span class="helper-export-desc">${escapeHtml2(f.desc[lang] || f.desc.en)}</span>
          </button>`
  ).join("")}
        </div>
        <div class="helper-export-opts">
          <label class="dual-inline"><span>${escapeHtml2(tt("exportCrlf"))}</span><input type="checkbox" class="switch" data-export-opt="crlf" ${xo.crlf ? "checked" : ""} /></label>
          <label class="dual-inline"><span>${escapeHtml2(tt("exportBom"))}</span><input type="checkbox" class="switch" data-export-opt="bom" ${xo.bom ? "checked" : ""} /></label>
          <label class="dual-inline"><span>${escapeHtml2(tt("exportLangSuffix"))}</span><input type="checkbox" class="switch" data-export-opt="langSuffix" ${xo.langSuffix ? "checked" : ""} /></label>
        </div>
        <div class="notes-status-row helper-export-foot">
          <span class="notes-meta" id="helper-export-name-hint"></span>
          <button type="button" class="mini-btn" id="btn-export-os-default" title="${escapeHtml2(tt("exportOsDefault", guide.label))}">${escapeHtml2(tt("exportReset"))}</button>
        </div>
        <p class="notes-meta helper-export-target">${escapeHtml2(tt("exportTarget", opts.exportFolder || ""))} \xB7 ${escapeHtml2(describeExportOptions(xo))}</p>
      </div>
    </div>
  `;
  const cues = STUB_TRANSCRIPT.map((l, i) => ({
    t0: l.t0,
    t1: l.t1,
    src: `${l.speaker}: ${l.text}`,
    tgt: `${l.speaker}: ${l.text}`
  }));
  const hint = root.querySelector("#helper-export-name-hint");
  const title = exportTitle;
  const nameFor = (kind) => exportFilename(title, kind, { srcLang: src?.srcLang, tgtLang: src?.tgtLang, langSuffix: xo.langSuffix });
  if (hint) {
    hint.textContent = `${tt("exportPreview")}: ${nameFor("srt")}`;
  }
  root.querySelectorAll("[data-export-kind]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const kind = btn.getAttribute("data-export-kind");
      if (typeof opts.onExport === "function") {
        opts.onExport(kind);
        if (hint) hint.textContent = `${tt("exportPreview")}: ${nameFor(kind)}`;
        return;
      }
      let body = "";
      if (kind === "srt") body = formatSrt(cues, { dualLine: false, title });
      else if (kind === "vtt") body = formatVtt(cues, { dualLine: false, title });
      else body = formatTxt(cues, { title });
      body = applyExportOptions(body, xo);
      const name = nameFor(kind);
      const url = URL.createObjectURL(new Blob([body], { type: `${exportMime(kind)};charset=utf-8` }));
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.click();
      URL.revokeObjectURL(url);
      if (hint) hint.textContent = `${tt("exportPreview")}: ${name}`;
    });
  });
  root.querySelectorAll("[data-export-opt]").forEach((cb) => {
    cb.addEventListener("change", () => {
      const patch = { [cb.getAttribute("data-export-opt")]: cb.checked };
      if (typeof opts.onExportOptionChange === "function") opts.onExportOptionChange(patch);
      else renderHelperStatusCard(root, { ...opts, exportOptions: { ...xo, ...patch } });
    });
  });
  root.querySelector("#btn-export-os-default")?.addEventListener("click", () => {
    const d = normalizeExportOptions(null, os);
    if (typeof opts.onExportOptionChange === "function") opts.onExportOptionChange(d);
    else renderHelperStatusCard(root, { ...opts, exportOptions: d });
  });
  root.querySelector("#btn-helper-lf-cancel")?.addEventListener("click", () => {
    btnDisabled(root.querySelector("#btn-helper-lf-cancel"));
    if (typeof opts.onCancelLargeFile === "function") {
      opts.onCancelLargeFile();
      return;
    }
    const pctEl = root.querySelector("#helper-lf-pct");
    if (pctEl) pctEl.textContent = `${pct}% \xB7 ${tt("lfStage_cancelled")}`;
    const stateEl = root.querySelector("#helper-lf-state");
    if (stateEl) stateEl.textContent = tt("lfStage_cancelled");
    const bar = root.querySelector(".helper-progress-bar");
    if (bar) bar.style.opacity = "0.4";
  });
}
function btnDisabled(el) {
  if (el) el.disabled = true;
}
function mountHelperStatusCard(root, getOpts) {
  const draw = () => {
    renderHelperStatusCard(root, getOpts());
    const exp = root.querySelector("#helper-export");
    const mount = document.getElementById("export-mount");
    if (exp && mount) {
      mount.replaceChildren(exp);
    }
  };
  draw();
  return draw;
}

// src/lib/helper-guide.js
var HELPER_PORT = 17865;
var HELPER_URL = `http://127.0.0.1:${HELPER_PORT}`;
var HOST_NAME = "com.localtranssub.helper";
var GUIDE_OS_ORDER = (
  /** @type {GuideOS[]} */
  ["windows", "linux", "macos"]
);
function guideOsFor(os) {
  return GUIDE_OS_ORDER.includes(os) ? os : "linux";
}
var en3 = {
  title: "Install guide & troubleshooting",
  subtitle: "Get the Native Helper running on this machine \u2014 everything stays on 127.0.0.1.",
  tabs: "Operating system",
  prereqs: "Before you start",
  steps: "Install steps",
  copy: "Copy",
  copied: "Copied",
  hostManifest: "Native Messaging manifest",
  diagnostics: "Diagnostics",
  rerun: "Re-check",
  openDocs: "Full guide (native/SETUP.md)",
  troubleshooting: "Troubleshooting",
  cause: "Why",
  fix: "Fix",
  relatedFail: "Flagged by diagnostics",
  extIdHint: "Replace <EXT_ID> with the extension ID shown on chrome://extensions (Developer mode).",
  stateOk: "OK",
  stateWarn: "Check",
  stateFail: "Problem",
  stateUnknown: "Unknown",
  allGood: "Everything looks good \u2014 the helper is reachable and ready.",
  offlineIntro: "The helper is not reachable. Work through the install steps, then Re-check.",
  browserEngineNote: "Engine is set to Browser \u2014 the helper is optional. Switch to Native helper in Settings to use it.",
  os: { windows: "Windows", linux: "Linux", macos: "macOS" },
  osEngine: {
    windows: "faster-whisper \xB7 CPU or CUDA",
    linux: "faster-whisper \xB7 CPU or CUDA",
    macos: "mlx-whisper (Apple Silicon) \xB7 faster-whisper fallback"
  },
  checks: {
    reachable: "Helper reachable on 127.0.0.1:17865",
    platform: "Helper OS matches this browser",
    engineSel: "Extension engine set to Native helper",
    host: "Native Messaging host (Start/Stop from the panel)",
    ffmpeg: "ffmpeg available to the helper",
    gpu: "Hardware acceleration",
    translate: "On-device translation LLM",
    bigFile: "Large-file jobs (>2 GiB) supported"
  },
  detail: {
    reachableOk: (m) => `${m}`,
    reachableFail: "GET /health did not answer \u2014 the helper process is not running or the port is blocked.",
    platformOk: (p) => `helper reports ${p}`,
    platformWarn: (p, o) => `helper reports ${p} but this browser is on ${o} \u2014 remote helper?`,
    engineSelOk: "native",
    engineSelWarn: "browser \u2014 the helper is not used for captions until you switch.",
    hostOk: "connected \u2014 Start / Stop / Restart work from Settings.",
    hostForbidden: "installed but this extension ID is not in the host manifest allowed_origins.",
    hostCrashed: "manifest found but the host process failed to start \u2014 check the Python path inside it.",
    hostTimeout: "no reply from the host \u2014 it may be hung; restart Chrome and re-check.",
    hostWarn: "not registered \u2014 Start/Stop need the host manifest; you can still run ./run.sh manually.",
    hostUnknown: "native messaging is not available in this browser.",
    ffmpegOk: "found",
    ffmpegFail: "missing \u2014 media files (mp4, mkv, m4a\u2026) cannot be decoded.",
    gpuOk: (d) => `${d}`,
    gpuWarn: "cpu \u2014 transcription works but is slower; CUDA needs an NVIDIA GPU + CUDA runtime.",
    translateOk: (m) => `${m}`,
    translateWarn: "off \u2014 translation falls back to the in-browser Opus-MT models (fine on Windows/Linux).",
    bigFileOk: "transcribe_file jobs with progress/cancel",
    bigFileWarn: "helper is too old \u2014 Restart it to load the job endpoints.",
    unknown: "run the checks with the helper online."
  }
};
var id2 = {
  title: "Panduan pemasangan & pemecahan masalah",
  subtitle: "Jalankan Native Helper di mesin ini \u2014 semuanya tetap di 127.0.0.1.",
  tabs: "Sistem operasi",
  prereqs: "Sebelum mulai",
  steps: "Langkah pemasangan",
  copy: "Salin",
  copied: "Tersalin",
  hostManifest: "Manifest Native Messaging",
  diagnostics: "Diagnostik",
  rerun: "Periksa ulang",
  openDocs: "Panduan lengkap (native/SETUP.md)",
  troubleshooting: "Pemecahan masalah",
  cause: "Penyebab",
  fix: "Perbaikan",
  relatedFail: "Ditandai diagnostik",
  extIdHint: "Ganti <EXT_ID> dengan ID ekstensi di chrome://extensions (Developer mode).",
  stateOk: "OK",
  stateWarn: "Periksa",
  stateFail: "Masalah",
  stateUnknown: "Belum diketahui",
  allGood: "Semua baik \u2014 helper terjangkau dan siap dipakai.",
  offlineIntro: "Helper tidak terjangkau. Ikuti langkah pemasangan, lalu Periksa ulang.",
  browserEngineNote: "Mesin masih Browser \u2014 helper opsional. Pilih Native helper di Pengaturan untuk memakainya.",
  os: { windows: "Windows", linux: "Linux", macos: "macOS" },
  osEngine: {
    windows: "faster-whisper \xB7 CPU atau CUDA",
    linux: "faster-whisper \xB7 CPU atau CUDA",
    macos: "mlx-whisper (Apple Silicon) \xB7 cadangan faster-whisper"
  },
  checks: {
    reachable: "Helper terjangkau di 127.0.0.1:17865",
    platform: "OS helper cocok dengan browser ini",
    engineSel: "Mesin ekstensi diset ke Native helper",
    host: "Host Native Messaging (Start/Stop dari panel)",
    ffmpeg: "ffmpeg tersedia untuk helper",
    gpu: "Akselerasi perangkat keras",
    translate: "LLM terjemahan on-device",
    bigFile: "Job berkas besar (>2 GiB) didukung"
  },
  detail: {
    reachableOk: (m) => `${m}`,
    reachableFail: "GET /health tidak menjawab \u2014 proses helper tidak jalan atau port terblokir.",
    platformOk: (p) => `helper melapor ${p}`,
    platformWarn: (p, o) => `helper melapor ${p} tapi browser ini di ${o} \u2014 helper remote?`,
    engineSelOk: "native",
    engineSelWarn: "browser \u2014 helper tidak dipakai untuk subtitel sampai Anda beralih.",
    hostOk: "terhubung \u2014 Start / Stop / Restart bisa dari Pengaturan.",
    hostForbidden: "terpasang, tapi ID ekstensi ini belum ada di allowed_origins manifest host.",
    hostCrashed: "manifest ketemu tapi proses host gagal dijalankan \u2014 periksa path Python di dalamnya.",
    hostTimeout: "host tidak menjawab \u2014 mungkin menggantung; mulai ulang Chrome lalu periksa lagi.",
    hostWarn: "belum terdaftar \u2014 Start/Stop butuh manifest host; ./run.sh manual tetap bisa.",
    hostUnknown: "native messaging tidak tersedia di browser ini.",
    ffmpegOk: "ditemukan",
    ffmpegFail: "tidak ada \u2014 berkas media (mp4, mkv, m4a\u2026) tidak bisa didekode.",
    gpuOk: (d) => `${d}`,
    gpuWarn: "cpu \u2014 transkripsi jalan tapi lebih lambat; CUDA butuh GPU NVIDIA + runtime CUDA.",
    translateOk: (m) => `${m}`,
    translateWarn: "mati \u2014 terjemahan memakai model Opus-MT di browser (wajar di Windows/Linux).",
    bigFileOk: "job transcribe_file dengan progres/batal",
    bigFileWarn: "helper terlalu lama \u2014 Restart agar endpoint job termuat.",
    unknown: "jalankan pemeriksaan saat helper hidup."
  }
};
var HELPER_GUIDE_I18N = { en: en3, id: id2 };
function guideStrings(lang) {
  return HELPER_GUIDE_I18N[lang] || HELPER_GUIDE_I18N.en;
}
function makeGuideT(lang) {
  const dict = guideStrings(lang);
  return function G(path, ...args) {
    const pick2 = (d) => path.split(".").reduce((o, k) => o == null ? void 0 : o[k], d);
    const v = pick2(dict) ?? pick2(HELPER_GUIDE_I18N.en) ?? path;
    return typeof v === "function" ? v(...args) : v;
  };
}
var INSTALL_GUIDES = {
  windows: {
    prereqs: {
      en: ['Python 3.10+ (python.org \u2014 tick "Add to PATH")', "Git Bash or WSL to run run.sh", "ffmpeg on PATH (winget install Gyan.FFmpeg)", "Optional: NVIDIA GPU + CUDA 12 runtime for faster-whisper"],
      id: ['Python 3.10+ (python.org \u2014 centang "Add to PATH")', "Git Bash atau WSL untuk menjalankan run.sh", "ffmpeg di PATH (winget install Gyan.FFmpeg)", "Opsional: GPU NVIDIA + runtime CUDA 12 untuk faster-whisper"]
    },
    steps: [
      { text: { en: "Open Git Bash in the repo and start the helper (creates .venv, installs faster-whisper, serves :17865)", id: "Buka Git Bash di repo dan jalankan helper (membuat .venv, memasang faster-whisper, melayani :17865)" }, cmd: "cd native && ./run.sh" },
      { text: { en: "No Git Bash? Plain PowerShell works too", id: "Tanpa Git Bash? PowerShell biasa juga bisa" }, cmd: "cd native; python -m venv .venv; .venv\\Scripts\\pip install faster-whisper numpy; .venv\\Scripts\\python server.py" },
      { text: { en: "Register the Native Messaging host so Start/Stop work from this panel (Command Prompt)", id: "Daftarkan host Native Messaging agar Start/Stop bisa dari panel ini (Command Prompt)" }, cmd: "cd native && install-host.bat <EXT_ID>" },
      { text: { en: "Verify the helper answers", id: "Pastikan helper menjawab" }, cmd: `curl.exe -sf ${HELPER_URL}/health` },
      { text: { en: "Reload the extension, then Settings \u2192 Engine \u2192 Native helper \u2192 Refresh", id: "Muat ulang ekstensi, lalu Pengaturan \u2192 Mesin \u2192 Native helper \u2192 Refresh" } }
    ],
    hostManifest: "%LOCALAPPDATA%\\Google\\Chrome\\User Data\\NativeMessagingHosts\\com.localtranssub.helper.json",
    hostRegistry: "HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\com.localtranssub.helper"
  },
  linux: {
    prereqs: {
      en: ["Python 3.10+ with venv (apt install python3-venv)", "ffmpeg (apt install ffmpeg / dnf install ffmpeg)", "Google Chrome or Chromium", "Optional: NVIDIA driver + CUDA 12 runtime"],
      id: ["Python 3.10+ dengan venv (apt install python3-venv)", "ffmpeg (apt install ffmpeg / dnf install ffmpeg)", "Google Chrome atau Chromium", "Opsional: driver NVIDIA + runtime CUDA 12"]
    },
    steps: [
      { text: { en: "Start the helper (creates .venv, installs faster-whisper, serves :17865)", id: "Jalankan helper (membuat .venv, memasang faster-whisper, melayani :17865)" }, cmd: "cd native && ./run.sh" },
      { text: { en: "Register the Native Messaging host for Chrome/Chromium", id: "Daftarkan host Native Messaging untuk Chrome/Chromium" }, cmd: "cd native && ./install-host-linux.sh <EXT_ID>" },
      { text: { en: "Verify the helper answers", id: "Pastikan helper menjawab" }, cmd: `curl -sf ${HELPER_URL}/health` },
      { text: { en: "Reload the extension, then Settings \u2192 Engine \u2192 Native helper \u2192 Refresh", id: "Muat ulang ekstensi, lalu Pengaturan \u2192 Mesin \u2192 Native helper \u2192 Refresh" } }
    ],
    hostManifest: "~/.config/google-chrome/NativeMessagingHosts/com.localtranssub.helper.json",
    hostManifestChromium: "~/.config/chromium/NativeMessagingHosts/com.localtranssub.helper.json"
  },
  macos: {
    prereqs: {
      en: ["Python 3.10+ (brew install python)", "ffmpeg (brew install ffmpeg)", "Apple Silicon for mlx-whisper; Intel Macs fall back to faster-whisper"],
      id: ["Python 3.10+ (brew install python)", "ffmpeg (brew install ffmpeg)", "Apple Silicon untuk mlx-whisper; Mac Intel memakai faster-whisper"]
    },
    steps: [
      { text: { en: "One-shot setup from the repo root (venv, launcher, host)", id: "Pemasangan sekali jalan dari root repo (venv, launcher, host)" }, cmd: "./scripts/ensure-native.sh" },
      { text: { en: "Or start manually (mlx-whisper on Apple Silicon)", id: "Atau jalankan manual (mlx-whisper di Apple Silicon)" }, cmd: "cd native && ./run.sh" },
      { text: { en: "Register the Native Messaging host", id: "Daftarkan host Native Messaging" }, cmd: "cd native && ./install-host.sh <EXT_ID>" },
      { text: { en: "Verify the helper answers", id: "Pastikan helper menjawab" }, cmd: `curl -sf ${HELPER_URL}/health` },
      { text: { en: "Settings \u2192 Engine \u2192 Native helper \u2192 Start / Refresh", id: "Pengaturan \u2192 Mesin \u2192 Native helper \u2192 Start / Refresh" } }
    ],
    hostManifest: "~/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.localtranssub.helper.json"
  }
};
var TROUBLESHOOTING = [
  {
    id: "not-running",
    checks: ["reachable"],
    symptom: { en: 'Helper disconnected / "Native helper not running"', id: 'Helper terputus / "Native helper not running"' },
    cause: { en: "server.py is not running, crashed on start, or is bound to another port.", id: "server.py tidak jalan, gagal saat start, atau terikat ke port lain." },
    fix: { en: "Start it from a terminal and watch the first lines of output for errors, then press Re-check.", id: "Jalankan dari terminal dan perhatikan baris awal keluaran untuk galat, lalu tekan Periksa ulang." },
    cmd: { windows: "cd native && ./run.sh", linux: "cd native && ./run.sh", macos: "./scripts/start-native.sh" }
  },
  {
    id: "port-busy",
    checks: ["reachable"],
    symptom: { en: "Port 17865 already in use (EADDRINUSE / OSError 98 / 10048)", id: "Port 17865 sudah dipakai (EADDRINUSE / OSError 98 / 10048)" },
    cause: { en: "A previous helper is still alive, or another program took the port.", id: "Helper lama masih hidup, atau program lain memakai port itu." },
    fix: { en: "Stop the old process, then start again.", id: "Hentikan proses lama, lalu jalankan lagi." },
    cmd: {
      windows: "netstat -ano | findstr :17865   (then)   taskkill /PID <pid> /F",
      linux: "fuser -k 17865/tcp   # or: lsof -i :17865",
      macos: "./scripts/stop-native.sh   # or: lsof -i :17865"
    }
  },
  {
    id: "host-missing",
    checks: ["host"],
    symptom: { en: 'Start / Stop buttons do nothing \u2014 "Native launcher not installed"', id: 'Tombol Start / Stop tidak berfungsi \u2014 "Native launcher not installed"' },
    cause: { en: `Chrome cannot find the ${HOST_NAME} manifest, or its allowed_origins has the wrong extension ID.`, id: `Chrome tidak menemukan manifest ${HOST_NAME}, atau allowed_origins berisi ID ekstensi yang salah.` },
    fix: { en: "Re-run the host installer with the current extension ID from chrome://extensions, then reload the extension. On Windows the installer also writes the HKCU registry key.", id: "Jalankan ulang installer host dengan ID ekstensi terkini dari chrome://extensions, lalu muat ulang ekstensi. Di Windows installer juga menulis kunci registry HKCU." },
    cmd: { windows: "cd native && install-host.bat <EXT_ID>", linux: "cd native && ./install-host-linux.sh <EXT_ID>", macos: "cd native && ./install-host.sh <EXT_ID>" }
  },
  {
    id: "ffmpeg",
    checks: ["ffmpeg"],
    symptom: { en: 'Media files fail: "ffmpeg not installed"', id: 'Berkas media gagal: "ffmpeg not installed"' },
    cause: { en: "The helper decodes mp4/mkv/m4a with ffmpeg; it is not on PATH for the helper process.", id: "Helper mendekode mp4/mkv/m4a dengan ffmpeg; ffmpeg tidak ada di PATH proses helper." },
    fix: { en: "Install ffmpeg, then Restart the helper so it picks up the new PATH.", id: "Pasang ffmpeg, lalu Restart helper agar PATH baru terbaca." },
    cmd: { windows: "winget install Gyan.FFmpeg", linux: "sudo apt install ffmpeg", macos: "brew install ffmpeg" }
  },
  {
    id: "cpu-slow",
    checks: ["gpu"],
    os: ["windows", "linux"],
    symptom: { en: "Transcription is slow / helper reports device=cpu", id: "Transkripsi lambat / helper melapor device=cpu" },
    cause: { en: "faster-whisper found no CUDA device (no NVIDIA GPU, missing driver, or CTranslate2 built without CUDA).", id: "faster-whisper tidak menemukan CUDA (tanpa GPU NVIDIA, driver hilang, atau CTranslate2 tanpa CUDA)." },
    fix: { en: "Install the NVIDIA driver + CUDA 12 runtime (cuBLAS, cuDNN) and restart; or use a smaller model to stay on CPU.", id: "Pasang driver NVIDIA + runtime CUDA 12 (cuBLAS, cuDNN) lalu restart; atau pakai model kecil agar nyaman di CPU." },
    cmd: { windows: "set WHISPER_MODEL=small && ./run.sh", linux: "WHISPER_MODEL=small ./run.sh   # or DEVICE=cuda ./run.sh", macos: "" }
  },
  {
    id: "engine-browser",
    checks: ["engineSel"],
    symptom: { en: "Helper is online but captions still use the browser engine", id: "Helper hidup tapi subtitel masih memakai mesin browser" },
    cause: { en: "The extension engine is still set to Browser.", id: "Mesin ekstensi masih diset ke Browser." },
    fix: { en: "Settings \u2192 Engine \u2192 Native helper. The next task uses the helper.", id: "Pengaturan \u2192 Mesin \u2192 Native helper. Tugas berikutnya memakai helper." }
  },
  {
    id: "big-file",
    checks: ["bigFile"],
    symptom: { en: "Files over 2 GiB fail or freeze the side panel", id: "Berkas di atas 2 GiB gagal atau membekukan side panel" },
    cause: { en: "In-browser decoding cannot hold a >2 GiB file; it must be streamed to the helper as a job.", id: "Dekode di browser tidak sanggup menampung berkas >2 GiB; harus dialirkan ke helper sebagai job." },
    fix: { en: "Use Offline mode with Engine = Native helper; progress and Cancel appear in the Native Helper card. Restart an old helper if the job endpoints are missing.", id: "Pakai mode Luring dengan Mesin = Native helper; progres dan Batalkan tampil di kartu Native Helper. Restart helper lama bila endpoint job tidak ada." }
  },
  {
    id: "firewall",
    checks: ["reachable"],
    os: ["windows"],
    symptom: { en: "Windows Firewall / antivirus prompt when the helper starts", id: "Prompt Windows Firewall / antivirus saat helper mulai" },
    cause: { en: "Python opens a listening socket. It is loopback-only (127.0.0.1) and never reachable from the network.", id: "Python membuka soket pendengar. Hanya loopback (127.0.0.1) dan tidak pernah terjangkau dari jaringan." },
    fix: { en: "Allow it for private networks (or dismiss \u2014 loopback works regardless). Do not expose the port.", id: "Izinkan untuk jaringan privat (atau tutup saja \u2014 loopback tetap jalan). Jangan buka port ke luar." }
  },
  {
    id: "python-missing",
    checks: ["reachable"],
    symptom: { en: '"python3: command not found" / "No module named venv"', id: '"python3: command not found" / "No module named venv"' },
    cause: { en: "Python is not installed, not on PATH, or the venv module is packaged separately (Debian/Ubuntu).", id: "Python belum terpasang, tidak di PATH, atau modul venv dipaket terpisah (Debian/Ubuntu)." },
    fix: { en: "Install Python 3.10+ and re-run run.sh. You can point run.sh at a specific interpreter with PYTHON=.", id: "Pasang Python 3.10+ dan jalankan ulang run.sh. Interpreter tertentu bisa dipilih lewat PYTHON=." },
    cmd: { windows: "winget install Python.Python.3.12", linux: "sudo apt install python3 python3-venv", macos: "brew install python" }
  },
  {
    id: "model-download",
    checks: [],
    symptom: { en: 'First start hangs on "Downloading model\u2026"', id: 'Start pertama tertahan di "Downloading model\u2026"' },
    cause: { en: "Whisper weights (~1.6 GB for large-v3-turbo) download once from Hugging Face; slow or blocked networks stall.", id: "Bobot Whisper (~1,6 GB untuk large-v3-turbo) diunduh sekali dari Hugging Face; jaringan lambat/terblokir membuatnya tertahan." },
    fix: { en: "Wait for the first download, or start with a smaller model. After that everything runs offline.", id: "Tunggu unduhan pertama, atau mulai dengan model kecil. Setelahnya semua jalan luring." },
    cmd: { windows: "set WHISPER_MODEL=base && ./run.sh", linux: "WHISPER_MODEL=base ./run.sh", macos: "WHISPER_MODEL=mlx-community/whisper-small-mlx ./run.sh" }
  }
];
function troubleshootingFor(os) {
  const g = guideOsFor(os);
  return TROUBLESHOOTING.filter((e) => !e.os || e.os.includes(g));
}
function runDiagnostics(ctx) {
  const G = makeGuideT(ctx.lang);
  const os = guideOsFor(ctx.os);
  const h = ctx.health || null;
  const online = !!h;
  const out = [];
  const push = (id3, state2, detail) => out.push({ id: id3, state: state2, label: G(`checks.${id3}`), detail });
  push(
    "reachable",
    online ? "ok" : "fail",
    online ? G("detail.reachableOk", `${h.engine || "asr"} \xB7 ${(h.model || "").split("/").pop() || h.model || ""}`) : G("detail.reachableFail")
  );
  const engine = ctx.engine || "browser";
  push("engineSel", engine === "native" ? "ok" : "warn", engine === "native" ? G("detail.engineSelOk") : G("detail.engineSelWarn"));
  const conn = ctx.hostConnection?.state || null;
  if (ctx.nativeHostSupported === false || conn === "unsupported") push("host", "unknown", G("detail.hostUnknown"));
  else if (conn === "connected") push("host", "ok", G("detail.hostOk"));
  else if (conn === "forbidden") push("host", "fail", G("detail.hostForbidden"));
  else if (conn === "crashed") push("host", "fail", G("detail.hostCrashed"));
  else if (conn === "timeout") push("host", "warn", G("detail.hostTimeout"));
  else if (conn === "not-installed") push("host", "warn", G("detail.hostWarn"));
  else if (ctx.hostInstalled === true) push("host", "ok", G("detail.hostOk"));
  else if (ctx.hostInstalled === false) push("host", "warn", G("detail.hostWarn"));
  else push("host", "unknown", G("detail.unknown"));
  if (!online) {
    push("platform", "unknown", G("detail.unknown"));
    push("ffmpeg", "unknown", G("detail.unknown"));
    push("gpu", "unknown", G("detail.unknown"));
    push("translate", "unknown", G("detail.unknown"));
    push("bigFile", "unknown", G("detail.unknown"));
    return out;
  }
  const plat = String(h.platform || "").toLowerCase();
  const platOs = plat === "darwin" ? "macos" : plat === "windows" ? "windows" : plat === "linux" ? "linux" : "";
  if (!platOs) push("platform", "unknown", G("detail.unknown"));
  else if (platOs === os) push("platform", "ok", G("detail.platformOk", G(`os.${platOs}`)));
  else push("platform", "warn", G("detail.platformWarn", G(`os.${platOs}`), G(`os.${os}`)));
  push("ffmpeg", h.ffmpeg ? "ok" : "fail", h.ffmpeg ? G("detail.ffmpegOk") : G("detail.ffmpegFail"));
  const device = String(h.device || "").toLowerCase();
  const accel = device && device !== "cpu";
  push("gpu", accel ? "ok" : "warn", accel ? G("detail.gpuOk", device) : G("detail.gpuWarn"));
  push(
    "translate",
    h.translate ? "ok" : "warn",
    h.translate ? G("detail.translateOk", (h.translate_model || "llm").split("/").pop()) : G("detail.translateWarn")
  );
  const jobs = !!(h.features && h.features.transcribe_file_jobs);
  push("bigFile", jobs ? "ok" : "warn", jobs ? G("detail.bigFileOk") : G("detail.bigFileWarn"));
  return out;
}
function summarizeDiagnostics(checks) {
  const fail = checks.filter((c) => c.state === "fail").length;
  const warn = checks.filter((c) => c.state === "warn").length;
  const ok = checks.filter((c) => c.state === "ok").length;
  return { fail, warn, ok, healthy: fail === 0 };
}
function relevantTroubleshooting(os, checks) {
  const state2 = new Map((checks || []).map((c) => [c.id, c.state]));
  const rank = (e) => {
    const states = (e.checks || []).map((id3) => state2.get(id3));
    if (states.includes("fail")) return 0;
    if (states.includes("warn")) return 1;
    return 2;
  };
  return troubleshootingFor(os).map((e, i) => ({ ...e, _i: i, _r: rank(e) })).sort((a, b) => a._r - b._r || a._i - b._i).map(({ _i, _r, ...e }) => ({ ...e, flagged: _r === 0 ? "fail" : _r === 1 ? "warn" : null }));
}
function pickLang(obj, lang) {
  if (!obj || typeof obj !== "object") return obj ?? "";
  return obj[lang] ?? obj.en ?? "";
}
function cmdFor(entry, os) {
  const c = entry?.cmd;
  if (!c) return "";
  if (typeof c === "string") return c;
  return c[guideOsFor(os)] || "";
}

// src/helper-guide.js
function esc3(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
async function copyText(text) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}
var STATE_ICON = { ok: "\u25CF", warn: "\u25CF", fail: "\u25CF", unknown: "\u25CB" };
function renderHelperGuide(root, opts = {}, ui = {}) {
  const lang = opts.lang && opts.lang in { en: 1, id: 1 } ? opts.lang : "en";
  const G = makeGuideT(lang);
  const detected = guideOsFor(opts.os || detectOs());
  const os = ui.os || detected;
  const open = ui.open || /* @__PURE__ */ new Set();
  const guide = INSTALL_GUIDES[os];
  const checks = runDiagnostics({ ...opts, os: detected, lang });
  const sum = summarizeDiagnostics(checks);
  const tips = relevantTroubleshooting(os, checks);
  const online = !!opts.health;
  const engine = opts.engine || "browser";
  const intro = online ? sum.healthy ? `<div class="hg-banner ok">${esc3(G("allGood"))}</div>` : "" : engine === "native" ? `<div class="hg-banner fail">${esc3(G("offlineIntro"))}</div>` : `<div class="hg-banner idle">${esc3(G("browserEngineNote"))}</div>`;
  root.innerHTML = `
    <div class="helper-guide" data-os="${esc3(os)}" data-lang="${esc3(lang)}">
      <div class="hg-head">
        <div>
          <h3 class="hg-title">${esc3(G("title"))}</h3>
          <p class="notes-meta">${esc3(G("subtitle"))}</p>
        </div>
        <button type="button" class="mini-btn" id="hg-recheck">${esc3(G("rerun"))}</button>
      </div>

      ${intro}

      <div class="notes-block hg-diag">
        <div class="notes-block-head">
          <h3>${esc3(G("diagnostics"))}</h3>
          <span class="hg-diag-sum">
            <span class="hg-dot ok"></span>${sum.ok}
            <span class="hg-dot warn"></span>${sum.warn}
            <span class="hg-dot fail"></span>${sum.fail}
          </span>
        </div>
        <ul class="hg-checks">
          ${checks.map(
    (c) => `
            <li class="hg-check ${esc3(c.state)}" data-check="${esc3(c.id)}">
              <span class="hg-check-icon" aria-hidden="true">${STATE_ICON[c.state] || "\u25CB"}</span>
              <span class="hg-check-body">
                <span class="hg-check-label">${esc3(c.label)}</span>
                <span class="hg-check-detail">${esc3(c.detail)}</span>
              </span>
              <span class="hg-check-state">${esc3(G(`state${c.state[0].toUpperCase()}${c.state.slice(1)}`))}</span>
            </li>`
  ).join("")}
        </ul>
      </div>

      <div class="notes-block hg-install hg-collapsible${ui.open.has("sec:install") ? "" : " collapsed"}">
        <div class="notes-block-head hg-sec-head" data-sec="install" role="button" tabindex="0" aria-expanded="${ui.open.has("sec:install")}">
          <h3>${esc3(G("steps"))}</h3>
          <div class="seg hg-os-tabs" role="tablist" aria-label="${esc3(G("tabs"))}">
            ${GUIDE_OS_ORDER.map(
    (o) => `<button type="button" role="tab" data-os="${o}" class="${o === os ? "active" : ""}" aria-selected="${o === os}">${esc3(G(`os.${o}`))}${o === detected ? " \xB7" : ""}</button>`
  ).join("")}
          </div>
        </div>
        <p class="notes-meta hg-engine">${esc3(G(`osEngine.${os}`))}</p>

        <details class="hg-details" data-key="prereqs" ${open.has("prereqs") ? "open" : ""}>
          <summary>${esc3(G("prereqs"))}</summary>
          <ul class="hg-prereqs">${(guide.prereqs[lang] || guide.prereqs.en).map((p) => `<li>${esc3(p)}</li>`).join("")}</ul>
        </details>

        <ol class="hg-steps">
          ${guide.steps.map(
    (s, i) => `
            <li class="hg-step">
              <div class="hg-step-text">${esc3(pickLang(s.text, lang))}</div>
              ${s.cmd ? `<div class="hg-cmd"><code>${esc3(s.cmd)}</code><button type="button" class="mini-btn hg-copy" data-copy="${esc3(s.cmd)}" aria-label="${esc3(G("copy"))} ${i + 1}">${esc3(G("copy"))}</button></div>` : ""}
            </li>`
  ).join("")}
        </ol>
        <p class="notes-meta hg-extid">${esc3(G("extIdHint"))}</p>

        <details class="hg-details" data-key="manifest" ${open.has("manifest") ? "open" : ""}>
          <summary>${esc3(G("hostManifest"))}</summary>
          <div class="hg-cmd"><code>${esc3(guide.hostManifest)}</code><button type="button" class="mini-btn hg-copy" data-copy="${esc3(guide.hostManifest)}">${esc3(G("copy"))}</button></div>
          ${guide.hostManifestChromium ? `<div class="hg-cmd"><code>${esc3(guide.hostManifestChromium)}</code><button type="button" class="mini-btn hg-copy" data-copy="${esc3(guide.hostManifestChromium)}">${esc3(G("copy"))}</button></div>` : ""}
          ${guide.hostRegistry ? `<div class="hg-cmd"><code>${esc3(guide.hostRegistry)}</code><button type="button" class="mini-btn hg-copy" data-copy="${esc3(guide.hostRegistry)}">${esc3(G("copy"))}</button></div>` : ""}
        </details>
      </div>

      <div class="notes-block hg-ts hg-collapsible${ui.open.has("sec:ts") ? "" : " collapsed"}">
        <div class="notes-block-head hg-sec-head" data-sec="ts" role="button" tabindex="0" aria-expanded="${ui.open.has("sec:ts")}">
          <h3>${esc3(G("troubleshooting"))}</h3>
          <span class="notes-meta">${tips.length}</span>
        </div>
        <div class="hg-ts-list">
          ${tips.map((e) => {
    const cmd = cmdFor(e, os);
    const key = `ts:${e.id}`;
    return `
            <details class="hg-details hg-ts-item ${e.flagged ? `flagged-${e.flagged}` : ""}" data-key="${esc3(key)}" data-ts="${esc3(e.id)}" ${open.has(key) || e.flagged === "fail" && !ui.touched ? "open" : ""}>
              <summary>
                <span class="hg-ts-symptom">${esc3(pickLang(e.symptom, lang))}</span>
                ${e.flagged ? `<span class="hg-flag ${e.flagged}">${esc3(G("relatedFail"))}</span>` : ""}
              </summary>
              <div class="hg-ts-body">
                <p><strong>${esc3(G("cause"))}:</strong> ${esc3(pickLang(e.cause, lang))}</p>
                <p><strong>${esc3(G("fix"))}:</strong> ${esc3(pickLang(e.fix, lang))}</p>
                ${cmd ? `<div class="hg-cmd"><code>${esc3(cmd)}</code><button type="button" class="mini-btn hg-copy" data-copy="${esc3(cmd)}">${esc3(G("copy"))}</button></div>` : ""}
              </div>
            </details>`;
  }).join("")}
        </div>
      </div>
    </div>
  `;
  root.querySelectorAll(".hg-os-tabs [data-os]").forEach((b) => {
    b.addEventListener("click", () => {
      ui.os = b.getAttribute("data-os");
      ui.touched = true;
      renderHelperGuide(root, opts, ui);
    });
  });
  root.querySelectorAll("details.hg-details").forEach((d) => {
    d.addEventListener("toggle", () => {
      const k = d.getAttribute("data-key");
      if (!k) return;
      ui.touched = true;
      if (d.open) open.add(k);
      else open.delete(k);
      ui.open = open;
    });
  });
  root.querySelectorAll(".hg-copy").forEach((b) => {
    b.addEventListener("click", async () => {
      const ok = await copyText(b.getAttribute("data-copy") || "");
      const orig = b.textContent;
      b.textContent = ok ? G("copied") : "\u2715";
      b.classList.toggle("copied", ok);
      setTimeout(() => {
        b.textContent = orig;
        b.classList.remove("copied");
      }, 1400);
    });
  });
  root.querySelectorAll(".hg-sec-head[data-sec]").forEach((head) => {
    const toggle = (e) => {
      if (e.target.closest('button, a, [role="tab"]')) return;
      const key = `sec:${head.dataset.sec}`;
      if (ui.open.has(key)) ui.open.delete(key);
      else ui.open.add(key);
      renderHelperGuide(root, opts, ui);
    };
    head.addEventListener("click", toggle);
    head.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggle(e);
      }
    });
  });
  root.querySelector("#hg-recheck")?.addEventListener("click", () => {
    if (typeof opts.onRecheck === "function") opts.onRecheck();
    else renderHelperGuide(root, opts, ui);
  });
  return { checks, summary: sum, os, lang };
}
function mountHelperGuide(root, getOpts) {
  const ui = { os: null, open: /* @__PURE__ */ new Set(), touched: false };
  const draw = () => renderHelperGuide(root, getOpts(), ui);
  draw();
  return draw;
}

// src/lib/qa-samples.js
init_registry();
var catalogCache = null;
var catalogTried = false;
function samplesBaseUrl() {
  try {
    const { protocol, hostname, port, pathname } = location;
    if (protocol === "http:" || protocol === "https:") {
      if (port === "8799" || hostname === "127.0.0.1" || hostname === "localhost") {
        return "/samples/";
      }
      if (pathname.includes("/test/") || pathname.endsWith("/app.html")) {
        return "/samples/";
      }
    }
  } catch {
  }
  return null;
}
async function loadSampleCatalog() {
  if (catalogTried) return catalogCache;
  catalogTried = true;
  const base2 = samplesBaseUrl();
  if (!base2) {
    catalogCache = null;
    return null;
  }
  try {
    const r = await fetch(`${base2}manifest.json`, { cache: "no-cache" });
    if (!r.ok) {
      catalogCache = null;
      return null;
    }
    const data = await r.json();
    catalogCache = {
      base: base2,
      samples: Array.isArray(data.samples) ? data.samples : []
    };
    return catalogCache;
  } catch {
    catalogCache = null;
    return null;
  }
}
function samplesForPair(catalog, pairKey) {
  if (!catalog?.samples?.length || !pairKey) return [];
  const [src, tgt] = pairKey.split("-");
  const exact = catalog.samples.filter((s) => s.src === src && s.tgt === tgt);
  if (exact.length) return exact;
  return catalog.samples.filter((s) => s.src === src);
}
function firstSampleForPair(catalog, pairKey) {
  return samplesForPair(catalog, pairKey)[0] || null;
}
async function fetchSampleFile(catalog, sample) {
  if (!catalog || !sample?.file) throw new Error("Sample unavailable");
  const url = `${catalog.base}${sample.file}`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Sample fetch failed (${r.status}): ${sample.file}`);
  const blob = await r.blob();
  const name = sample.file.split("/").pop() || `${sample.id}.mp3`;
  return new File([blob], name, { type: blob.type || "audio/mpeg" });
}

// src/lib/motion.js
var SPRING = {
  number: { stiffness: 200, damping: 20, mass: 0.4 },
  progress: { stiffness: 100, damping: 30, mass: 1 },
  height: { stiffness: 300, damping: 30, mass: 1 },
  highlight: { stiffness: 350, damping: 35, mass: 1 }
};
var STEP = 1 / 240;
var MAX_FRAME = 0.064;
var noop = () => {
};
var raf = typeof requestAnimationFrame === "function" ? requestAnimationFrame : (fn) => setTimeout(() => fn(Date.now()), 16);
var caf = typeof cancelAnimationFrame === "function" ? cancelAnimationFrame : clearTimeout;
var reducedQuery = null;
function prefersReducedMotion() {
  if (typeof matchMedia !== "function") return false;
  if (!reducedQuery) reducedQuery = matchMedia("(prefers-reduced-motion: reduce)");
  return reducedQuery.matches;
}
function integrate(state2, to, cfg, dt) {
  const { stiffness, damping } = cfg;
  const mass = cfg.mass || 1;
  let { x, v } = state2;
  let remaining = Math.min(dt, MAX_FRAME);
  while (remaining > 0) {
    const h = Math.min(STEP, remaining);
    const a = (-stiffness * (x - to) - damping * v) / mass;
    v += a * h;
    x += v * h;
    remaining -= h;
  }
  return { x, v };
}
function spring(from, to, cfg, onUpdate, onDone) {
  if (prefersReducedMotion() || from === to) {
    onUpdate(to);
    if (onDone) onDone();
    return noop;
  }
  const restDelta = cfg.restDelta == null ? 2e-3 : cfg.restDelta;
  const restSpeed = cfg.restSpeed == null ? 0.02 : cfg.restSpeed;
  let state2 = { x: from, v: cfg.velocity || 0 };
  let last = null;
  let id3 = 0;
  let live = true;
  const tick = (now) => {
    if (!live) return;
    const dt = last == null ? STEP : Math.max(0, (now - last) / 1e3);
    last = now;
    state2 = integrate(state2, to, cfg, dt);
    if (Math.abs(to - state2.x) < restDelta && Math.abs(state2.v) < restSpeed) {
      live = false;
      onUpdate(to);
      if (onDone) onDone();
      return;
    }
    onUpdate(state2.x);
    id3 = raf(tick);
  };
  id3 = raf(tick);
  return () => {
    if (!live) return;
    live = false;
    caf(id3);
  };
}
function digitPositions(value, powers, roll = 0.1) {
  const v = Math.max(0, value);
  const least = Math.min(...powers);
  return powers.map((p) => {
    let scaled = v / Math.pow(10, p);
    const nearest = Math.round(scaled);
    if (Math.abs(scaled - nearest) < 1e-9 * Math.max(1, Math.abs(scaled))) {
      scaled = nearest;
    }
    const whole = Math.floor(scaled);
    const frac = scaled - whole;
    const win = roll * Math.pow(10, least - p);
    const carry = frac > 1 - win ? (frac - (1 - win)) / win : 0;
    return whole % 10 + carry;
  });
}
function integerDigits(value) {
  const v = Math.floor(Math.abs(value));
  return v < 1 ? 1 : Math.floor(Math.log10(v)) + 1;
}
function formatNumber(value, opts = {}) {
  const decimals = opts.decimals || 0;
  const groupSep = opts.groupSeparator || "";
  const sep = opts.decimalSeparator || ".";
  const fixed = Math.abs(value).toFixed(decimals);
  const dot = fixed.indexOf(".");
  let int = dot === -1 ? fixed : fixed.slice(0, dot);
  const frac = dot === -1 ? "" : fixed.slice(dot + 1);
  if (groupSep) int = int.replace(/\B(?=(\d{3})+(?!\d))/g, groupSep);
  const sign = value < 0 ? "-" : opts.signed ? "+" : "";
  return sign + int + (frac ? sep + frac : "") + (opts.unit || "");
}
function slidingNumber(el, opts = {}) {
  const decimals = opts.decimals || 0;
  const unit = opts.unit || "";
  const signed = !!opts.signed;
  const pad = !!opts.pad;
  const lineHeight = opts.lineHeight || 1.1;
  const sep = opts.decimalSeparator || ".";
  const groupSep = opts.groupSeparator || "";
  const cfg = opts.cfg || SPRING.number;
  let intDigits = Math.max(1, opts.intDigits || 1);
  let cells = [];
  let groups = [];
  let signEl = null;
  let current = 0;
  let cancel = noop;
  let lastVisible = -1;
  const format = (value) => formatNumber(value, {
    decimals,
    groupSeparator: groupSep,
    decimalSeparator: sep,
    unit,
    signed
  });
  function label2(value) {
    el.setAttribute("role", "img");
    el.setAttribute("aria-label", format(value));
  }
  function build() {
    el.textContent = "";
    cells = [];
    groups = [];
    signEl = null;
    el.style.display = opts.display || "inline-flex";
    el.style.alignItems = "baseline";
    el.style.lineHeight = String(lineHeight);
    signEl = document.createElement("span");
    signEl.className = "mo-sign";
    signEl.textContent = signed ? "+" : "";
    el.appendChild(signEl);
    for (let i = 0; i < intDigits + decimals; i++) {
      const power = intDigits - 1 - i;
      if (power === -1) {
        const dot = document.createElement("span");
        dot.className = "mo-sep";
        dot.textContent = sep;
        el.appendChild(dot);
      }
      const wrap = document.createElement("span");
      wrap.className = "mo-digit";
      wrap.style.cssText = "display:inline-block;overflow:hidden;height:" + lineHeight + "em;";
      const col = document.createElement("span");
      col.className = "mo-col";
      col.style.cssText = "display:flex;flex-direction:column;will-change:transform;";
      for (let d = 0; d <= 10; d++) {
        const cell2 = document.createElement("span");
        cell2.style.cssText = "display:block;height:" + lineHeight + "em;";
        cell2.textContent = String(d % 10);
        col.appendChild(cell2);
      }
      wrap.appendChild(col);
      el.appendChild(wrap);
      cells.push({ wrap, col, power });
      if (groupSep && power > 0 && power % 3 === 0) {
        const g = document.createElement("span");
        g.className = "mo-group";
        g.textContent = groupSep;
        el.appendChild(g);
        groups.push({ el: g, power });
      }
    }
    if (unit) {
      const u = document.createElement("span");
      u.className = "mo-unit";
      u.textContent = unit;
      el.appendChild(u);
    }
    lastVisible = -1;
  }
  function ensureWidth(value) {
    const needed = integerDigits(value);
    if (needed <= intDigits) return;
    intDigits = needed;
    build();
  }
  function render(value) {
    const positions = digitPositions(Math.abs(value), cells.map((c) => c.power));
    for (let i = 0; i < cells.length; i++) {
      cells[i].col.style.transform = "translateY(" + -(positions[i] * lineHeight) + "em)";
    }
    if (signEl) signEl.textContent = value < 0 ? "-" : signed ? "+" : "";
    if (pad) return;
    const visible = integerDigits(value);
    if (visible === lastVisible) return;
    lastVisible = visible;
    for (const c of cells) {
      if (c.power < 0) continue;
      c.wrap.style.display = c.power >= visible ? "none" : "inline-block";
    }
    for (const g of groups) {
      g.el.style.display = g.power >= visible ? "none" : "inline";
    }
  }
  build();
  label2(0);
  render(0);
  return {
    to(value) {
      cancel();
      ensureWidth(value);
      label2(value);
      cancel = spring(
        current,
        value,
        cfg,
        (v) => {
          current = v;
          render(v);
        },
        () => {
          current = value;
          render(value);
        }
      );
    },
    set(value) {
      cancel();
      cancel = noop;
      ensureWidth(value);
      label2(value);
      current = value;
      render(value);
    },
    value: () => current,
    text: format,
    destroy() {
      cancel();
      cancel = noop;
      el.removeAttribute("role");
      el.removeAttribute("aria-label");
      el.textContent = "";
    }
  };
}
function springProgress(fill, opts = {}) {
  const cfg = opts.cfg || SPRING.progress;
  const precision = opts.precision == null ? 2 : opts.precision;
  const onValue = opts.onValue || noop;
  let current = 0;
  let cancel = noop;
  const clamp = (n) => Math.min(100, Math.max(0, n));
  function paint(v) {
    current = v;
    if (fill) fill.style.width = v.toFixed(precision) + "%";
    onValue(v);
  }
  paint(0);
  return {
    to(pct) {
      const target = clamp(pct);
      cancel();
      cancel = spring(current, target, cfg, paint, () => paint(target));
    },
    set(pct) {
      cancel();
      cancel = noop;
      paint(clamp(pct));
    },
    value: () => current,
    destroy() {
      cancel();
      cancel = noop;
    }
  };
}
function autoHeight(panel, opts = {}) {
  const inner = opts.inner || panel.firstElementChild;
  const cfg = opts.cfg || SPRING.height;
  const onChange = opts.onChange || noop;
  const onSettled = opts.onSettled || noop;
  let open = opts.open !== false;
  let measured = 0;
  let cancel = noop;
  let animating = false;
  let observer = null;
  panel.style.overflow = "hidden";
  function measure() {
    if (!inner) return 0;
    let margins = 0;
    if (typeof getComputedStyle === "function") {
      const cs = getComputedStyle(inner);
      const m = parseFloat(cs.marginTop) + parseFloat(cs.marginBottom);
      if (Number.isFinite(m)) margins = m;
    }
    return inner.scrollHeight + margins;
  }
  function apply(h) {
    panel.style.height = h + "px";
  }
  function settle() {
    measured = measure();
    if (open && !animating) apply(measured);
  }
  if (typeof ResizeObserver === "function" && inner) {
    observer = new ResizeObserver(settle);
    observer.observe(inner);
  }
  measured = measure();
  apply(open ? measured : 0);
  function set(next, animated) {
    if (next === open) return;
    open = next;
    onChange(open);
    measured = measure();
    const target = open ? measured : 0;
    cancel();
    if (animated === false) {
      animating = false;
      apply(target);
      onSettled(open);
      return;
    }
    const from = parseFloat(panel.style.height) || 0;
    animating = true;
    cancel = spring(
      from,
      target,
      cfg,
      apply,
      () => {
        animating = false;
        cancel = noop;
        apply(open ? measure() : 0);
        onSettled(open);
      }
    );
  }
  return {
    open: (animated) => set(true, animated),
    close: (animated) => set(false, animated),
    toggle: () => set(!open, true),
    isOpen: () => open,
    remeasure: settle,
    destroy() {
      cancel();
      cancel = noop;
      if (observer) observer.disconnect();
      panel.style.height = "";
      panel.style.overflow = "";
    }
  };
}
function highlight(container, opts = {}) {
  const cfg = opts.cfg || SPRING.highlight;
  const onChange = opts.onChange || noop;
  const selectedAttr = opts.selectedAttr === void 0 ? "aria-selected" : opts.selectedAttr;
  const activeClass = opts.activeClass || "";
  const selector = opts.selector || '[role="tab"], button';
  const pill = opts.pill || container.querySelector(".mo-pill");
  const items = opts.items || Array.from(container.querySelectorAll(selector)).filter((el) => el !== pill);
  let x = 0;
  let w = 0;
  let cancelX = noop;
  let cancelW = noop;
  let active = null;
  function paintX(v) {
    x = v;
    if (pill) pill.style.transform = "translateX(" + v + "px)";
  }
  function paintW(v) {
    w = v;
    if (pill) pill.style.width = v + "px";
  }
  function place(el, animated) {
    if (!el) return;
    const tx = el.offsetLeft;
    const tw = el.offsetWidth;
    cancelX();
    cancelW();
    if (animated === false) {
      cancelX = noop;
      cancelW = noop;
      paintX(tx);
      paintW(tw);
      return;
    }
    cancelX = spring(x, tx, cfg, paintX);
    cancelW = spring(w, tw, cfg, paintW);
  }
  const isSelected = (el) => activeClass ? el.classList.contains(activeClass) : !!selectedAttr && el.getAttribute(selectedAttr) === "true";
  function select(target, animated) {
    const el = typeof target === "number" ? items[target] : target;
    if (!el) return;
    active = el;
    for (const item of items) {
      if (selectedAttr) item.setAttribute(selectedAttr, String(item === el));
      if (activeClass) item.classList.toggle(activeClass, item === el);
    }
    place(el, animated);
    onChange(el, items.indexOf(el));
  }
  const listeners = [];
  if (opts.bind !== false) {
    for (const item of items) {
      const fn = () => select(item, true);
      item.addEventListener("click", fn);
      listeners.push([item, fn]);
    }
  }
  const initial = items.find(isSelected) || items[0];
  if (initial) {
    active = initial;
    place(initial, false);
  }
  function remeasure() {
    place(active, false);
  }
  return {
    select,
    /**
     * Re-read which item the DOM says is selected and move the pill to it.
     * Groups that keep their own selection logic call this instead of `select`,
     * so the attribute or class convention lives in one place. A host that is
     * not laid out yet (a closed modal, a hidden tab panel) measures zero, and
     * is skipped rather than parking the pill at zero width.
     */
    sync(animated = true) {
      const el = items.find(isSelected) || items[0];
      if (!el || !el.offsetWidth) return;
      active = el;
      place(el, animated);
    },
    selected: () => active,
    remeasure,
    destroy() {
      cancelX();
      cancelW();
      cancelX = noop;
      cancelW = noop;
      for (const [el, fn] of listeners) el.removeEventListener("click", fn);
      listeners.length = 0;
    }
  };
}

// src/sidepanel.js
var $ = (id3) => document.getElementById(id3);
var state = {
  sessionTab: null,
  // tab yang sedang disubtitle selagi sesi realtime hidup
  mode: "realtime",
  // 'realtime' | 'offline'
  task: "translate",
  // 'transcribe' | 'translate'
  view: "captions",
  // 'captions' | 'notes'
  srcLang: "zh",
  tgtLang: "en",
  settings: {
    uiLang: "en",
    mirror: "huggingface",
    device: "auto",
    dualLine: false,
    refineTranslation: false,
    overlayFontSize: 24,
    asrModel: DEFAULT_ASR,
    engine: "browser",
    nativeUrl: DEFAULT_NATIVE_URL,
    nativeDevice: "auto",
    // helper compute: 'auto' | 'cpu' | 'cuda' (Win/Linux faster-whisper)
    theme: "auto",
    // 'auto' | 'light' | 'dark'
    reskin: "yraverage",
    // 'yraverage' | 'coretax' | 'modern' — pola interaksi lokal
    // Two-way (consecutive) interpreting is opt-in; 'simultaneous' is the
    // historical one-way srcLang → tgtLang path.
    interpreter: { mode: "simultaneous", a: "ja", b: "en" }
  },
  downloaded: {},
  running: false,
  offlineRunning: false,
  startedAt: null,
  // stempel mulai tugas tangkap — jam rekaman di rel Notulen
  offlineFile: null,
  // { name, size } once staged to OPFS
  offlineStaging: false,
  offlineLines: [],
  realtimeLines: [],
  currentTab: null,
  qaCatalog: null
};
function t(key, ...args) {
  const v = I18N[state.settings.uiLang]?.[key] ?? I18N.en[key] ?? key;
  return typeof v === "function" ? v(...args) : v;
}
function toBG(type, data) {
  return chrome.runtime.sendMessage({ target: "bg", type, data }).catch(() => null);
}
function toOffscreen(type, data) {
  return toBG("to-offscreen", { type, data });
}
function applyI18n() {
  document.documentElement.lang = state.settings.uiLang || "en";
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    el.placeholder = t(el.dataset.i18nPlaceholder);
  });
  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    el.title = t(el.dataset.i18nTitle);
  });
  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    el.setAttribute("aria-label", t(el.dataset.i18nAriaLabel));
  });
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  const notesMount = $("notes-mount");
  if (notesMount && notesMount.dataset.mounted) mountNotesPanel(notesMount, notesMountOptions());
  renderInterpreterUi();
  redrawHelperStatus?.();
}
function optionsHtml(entries) {
  return uniqueLangEntries(entries).map(([c, label2]) => `<option value="${c}">${label2}</option>`).join("");
}
function fillSelects() {
  const srcGroup = t("sourceLangGroup");
  const tgtGroup = t("targetLangGroup");
  $("src-lang").innerHTML = `<optgroup label="${srcGroup}">${optionsHtml(SOURCE_LANGS)}</optgroup>`;
  $("tgt-lang").innerHTML = `<optgroup label="${tgtGroup}">${optionsHtml(TARGET_LANGS)}</optgroup>`;
  $("src-lang").value = state.srcLang;
  $("tgt-lang").value = state.tgtLang;
  $("src-lang").setAttribute("aria-label", t("sourceLang"));
  $("tgt-lang").setAttribute("aria-label", t("targetLang"));
}
function interpreter() {
  return state.settings.interpreter;
}
function twoWay() {
  return interpreter()?.mode === "consecutive";
}
function renderInterpreterUi() {
  const it = interpreter();
  if (!it || !$("interpreter-summary")) return;
  $("interpreter-summary").textContent = it.mode === "consecutive" ? t("interpSummaryTwoWay", it.a.toUpperCase(), it.b.toUpperCase()) : t("interpSummaryOneWay", state.srcLang.toUpperCase(), state.tgtLang.toUpperCase());
  const two = $("interp-badge-consecutive");
  if (two) two.textContent = `${t("interpTwoWay")} \xB7 ${t("interpPreview")}`;
  const one = $("interp-badge-simultaneous");
  if (one) one.textContent = t("interpOneWay");
  syncInterpreterLock();
}
function applyInterpreterUi() {
  const two = twoWay();
  $("lang-row").classList.toggle("hidden", two);
  document.querySelectorAll("#task-toggle button").forEach((b) => {
    b.disabled = two;
  });
  if (two) {
    if (state.task !== "translate") {
      state.taskBeforeTwoWay = state.task;
      setTask("translate");
    }
  } else if (state.taskBeforeTwoWay) {
    const prev = state.taskBeforeTwoWay;
    state.taskBeforeTwoWay = null;
    if (prev !== state.task) setTask(prev);
  }
  renderInterpreterUi();
}
function setSelectValue(el, want) {
  el.value = want || "";
  if (!el.value) el.value = el.options[0]?.value || "";
  return el.value;
}
function showInterpreterError(msg) {
  const el = $("interp-error");
  if (!el) return;
  el.textContent = msg || "";
  el.classList.toggle("hidden", !msg);
}
function openInterpreterModal() {
  const it = interpreter();
  const srcGroup = t("sourceLangGroup");
  const tgtGroup = t("targetLangGroup");
  const twoWaySrc = SOURCE_LANGS.filter(([c]) => c !== "auto");
  $("interp-lang-a").innerHTML = `<optgroup label="${srcGroup}">${optionsHtml(twoWaySrc)}</optgroup>`;
  $("interp-lang-b").innerHTML = `<optgroup label="${tgtGroup}">${optionsHtml(TARGET_LANGS)}</optgroup>`;
  $("interp-lang-one").innerHTML = `<optgroup label="${tgtGroup}">${optionsHtml(TARGET_LANGS)}</optgroup>`;
  setSelectValue($("interp-lang-a"), it.a);
  setSelectValue($("interp-lang-b"), it.b);
  setSelectValue($("interp-lang-one"), state.tgtLang);
  showInterpreterError("");
  selectInterpreterCard(it.mode);
  syncInterpreterLock();
  $("interpreter-modal").classList.remove("hidden");
}
function selectInterpreterCard(mode) {
  document.querySelectorAll(".interp-card").forEach((card) => {
    card.setAttribute("aria-checked", String(card.dataset.mode === mode));
  });
}
function chosenInterpreterMode() {
  const on = document.querySelector('.interp-card[aria-checked="true"]');
  return on?.dataset.mode === "consecutive" ? "consecutive" : "simultaneous";
}
async function applyInterpreterChoice() {
  const mode = chosenInterpreterMode();
  if (mode === "consecutive") {
    const a = $("interp-lang-a").value;
    const b = $("interp-lang-b").value;
    const next = normalizeInterpreter({ interpreter: { mode, a, b } }, a, b);
    if (next.mode !== "consecutive") {
      showInterpreterError(t("interpCannotApply"));
      return;
    }
    state.settings.interpreter = next;
    state.srcLang = next.a;
    state.tgtLang = next.b;
  } else {
    state.tgtLang = $("interp-lang-one").value;
    const prev = interpreter();
    const a = state.srcLang !== "auto" ? state.srcLang : prev?.a !== "auto" ? prev?.a : "";
    state.settings.interpreter = { mode: "simultaneous", b: state.tgtLang, ...a ? { a } : {} };
  }
  showInterpreterError("");
  $("src-lang").value = state.srcLang;
  $("tgt-lang").value = state.tgtLang;
  await saveSettings();
  persistLastConfig();
  applyInterpreterUi();
  updateWarning();
  $("interpreter-modal").classList.add("hidden");
}
function syncCaptureStamp() {
  const on = state.running || state.offlineRunning;
  if (on && !state.startedAt) state.startedAt = Date.now();
  else if (!on) state.startedAt = null;
  syncInterpreterLock();
  syncActiveCapture();
}
function syncActiveCapture() {
  const on = captureRunning();
  document.body.classList.toggle("is-running", on);
  $("topbar-rec")?.classList.toggle("hidden", !on);
}
function captureRunning() {
  return !!(state.running || state.offlineRunning);
}
function syncInterpreterLock() {
  const btn = $("btn-interpreter");
  if (!btn) return;
  const busy = captureRunning();
  btn.disabled = busy;
  btn.title = busy ? t("interpAppliesNextTask") : "";
  const note = $("interp-running-note");
  if (note) note.classList.toggle("hidden", !busy);
}
function captureEngineLabel() {
  if (state.settings.engine === "native" && nativeInfo) {
    const e = String(nativeInfo.engine || "");
    return /mlx/i.test(e) ? "MLX \xB7 GPU" : `${e || "Helper"} \xB7 native`;
  }
  return "Whisper \xB7 browser";
}
function getCapture() {
  return {
    running: state.running || state.offlineRunning,
    startedAt: state.startedAt,
    engine: captureEngineLabel()
  };
}
async function generateMinutesFromPaste() {
  const raw = $("paste-input")?.value || "";
  const out = $("paste-result");
  if (!out) return;
  out.innerHTML = "";
  if (!raw.trim()) return;
  const { parseTeamsTranscript: parseTeamsTranscript2, looksLikeTeamsTranscript: looksLikeTeamsTranscript2 } = await Promise.resolve().then(() => (init_teams_transcript(), teams_transcript_exports));
  if (!looksLikeTeamsTranscript2(raw)) {
    out.innerHTML = `<span class="err">${t("pasteNotTeams")}</span>`;
    return;
  }
  const { lines, speakers } = parseTeamsTranscript2(raw);
  if (!lines.length) {
    out.innerHTML = `<span class="err">${t("pasteNotTeams")}</span>`;
    return;
  }
  const { generateNotesFromTranscript: generateNotesFromTranscript2 } = await Promise.resolve().then(() => (init_notes_generate(), notes_generate_exports));
  const meeting = generateNotesFromTranscript2(lines, {
    title: ($("paste-title")?.value || "").trim() || "Pasted meeting",
    locale: state.settings.uiLang === "id" ? "id" : "en",
    source: "teams-paste",
    projectType: await loadProjectTypePref()
  });
  const { saveMeeting: saveMeeting2 } = await Promise.resolve().then(() => (init_notes_store(), notes_store_exports));
  await saveMeeting2(meeting);
  out.innerHTML = `<span class="ok">${t("pasteDone", lines.length, speakers.length, meeting.items.length)}</span>`;
  showToast(t("pasteDone", lines.length, speakers.length, meeting.items.length), "ok");
  const mount = $("notes-mount");
  if (mount && mount.dataset.mounted) mountNotesPanel(mount, notesMountOptions());
}
function notesMountOptions() {
  return {
    getCapture,
    getSessionLines: () => state.realtimeLines.slice(),
    onEndCapture: () => onStop(),
    onExportNotes: (kind) => exportActiveNotes(kind),
    onPushShared: (meeting, lang) => pushActiveNotes(meeting, lang)
  };
}
async function pushActiveNotes(meeting, lang) {
  if (!nativeInfo) return null;
  const { pushMeetingToHelper: pushMeetingToHelper2 } = await Promise.resolve().then(() => (init_notes_sync(), notes_sync_exports));
  const note = await pushMeetingToHelper2(
    state.settings.nativeUrl || DEFAULT_NATIVE_URL,
    meeting,
    lang
  );
  if (note) setStatus2(t("savedTo", "Native Helper"), "ok");
  return note;
}
async function exportActiveNotes(kind) {
  const mount = $("notes-mount");
  const meetingId = mount?.querySelector(".notes-saved-item.active")?.dataset.meetingId || null;
  const { listMeetings: listMeetings2 } = await Promise.resolve().then(() => (init_notes_store(), notes_store_exports));
  const { serializeMeetingTxt: serializeMeetingTxt2, serializeMeetingMarkdown: serializeMeetingMarkdown2 } = await Promise.resolve().then(() => (init_notes_export(), notes_export_exports));
  const meetings = await listMeetings2();
  const meeting = meetingId && meetings.find((m) => m.id === meetingId) || meetings[0];
  if (!meeting) {
    setStatus2(t("noHistory"), "error");
    return;
  }
  const lang = (document.documentElement.lang || "en").startsWith("id") ? "id" : "en";
  const out = kind === "md" ? serializeMeetingMarkdown2(meeting, lang) : serializeMeetingTxt2(meeting, lang);
  const safe = String(meeting.title || meeting.id || "meeting-notes").replace(/[^\w\s.-]+/g, "_").replace(/\s+/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "").slice(0, 60) || "meeting-notes";
  const name = kind === "md" ? `${safe}.md` : `${safe}.txt`;
  try {
    const res = await saveExportFile(name, out);
    const msg = res.saved ? t("savedTo", res.path) : t("downloadedTo", name);
    setStatus2(msg, "ok");
    showToast(msg, "ok");
  } catch (e) {
    const msg = t("exportFailed", String(e?.message || e));
    setStatus2(msg, "error");
    showToast(msg, "error");
  }
}
var perfPanel = null;
function setSubview(sub) {
  const perf = sub === "perf";
  document.querySelectorAll("#captions-subtabs [data-subview]").forEach((b) => {
    const on = b.dataset.subview === (perf ? "perf" : "live");
    b.classList.toggle("active", on);
    b.setAttribute("aria-selected", String(on));
  });
  syncPill("captions-subtabs");
  document.querySelectorAll("#view-captions > section.card").forEach((sec) => sec.classList.toggle("hidden", perf));
  $("view-perf")?.classList.toggle("hidden", !perf);
  if (perf) perfPanel?.render();
  try {
    localStorage.setItem("captionsSubview", perf ? "perf" : "live");
  } catch {
  }
}
var DENSITY_KEY = "panelDensity";
var density = "simple";
function applyDensity(mode, { persist: persist2 = true } = {}) {
  density = mode === "detail" ? "detail" : "simple";
  document.body.dataset.density = density;
  document.querySelectorAll("#density-toggle [data-density-mode]").forEach((b) => {
    const on = b.dataset.densityMode === density;
    b.classList.toggle("active", on);
    b.setAttribute("aria-pressed", String(on));
  });
  syncPill("density-toggle");
  if (density === "detail") requestAnimationFrame(() => syncPill("captions-subtabs", false));
  if (density === "simple") setSubview("live");
  if (persist2) {
    try {
      chrome.storage.local.set({ [DENSITY_KEY]: density });
    } catch {
    }
  }
}
async function restoreDensity() {
  let saved = null;
  try {
    const got = await chrome.storage.local.get(DENSITY_KEY);
    saved = got?.[DENSITY_KEY] ?? null;
  } catch {
  }
  applyDensity(saved === "detail" ? "detail" : "simple", { persist: false });
}
function initCollapsibles() {
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem("uiCollapsed") || "{}");
  } catch {
    saved = {};
  }
  document.querySelectorAll(".card.collapsible[data-collapse-key]").forEach((card) => {
    const key = card.dataset.collapseKey;
    const openByDefault = card.dataset.collapseDefault === "open";
    const open = saved[key] === void 0 ? openByDefault : saved[key] === true;
    card.classList.toggle("collapsed", !open);
    const btn = card.querySelector(".card-toggle");
    btn?.setAttribute("aria-expanded", String(open));
    btn?.addEventListener("click", () => {
      const nowOpen = card.classList.contains("collapsed");
      card.classList.toggle("collapsed", !nowOpen);
      btn.setAttribute("aria-expanded", String(nowOpen));
      saved[key] = nowOpen;
      try {
        localStorage.setItem("uiCollapsed", JSON.stringify(saved));
      } catch {
      }
    });
  });
}
function filterSettings(query) {
  const q = String(query || "").trim().toLowerCase();
  const modal = $("settings-modal");
  if (!modal) return;
  let visible = 0;
  modal.querySelectorAll(".setting-row, .m-item").forEach((el) => {
    const hit = !q || el.textContent.toLowerCase().includes(q);
    el.classList.toggle("search-hidden", !hit);
    if (hit) visible += 1;
  });
  const nativeBlock = $("native-block");
  if (nativeBlock) {
    const engineRow = $("engine-toggle")?.closest(".setting-row");
    const show = !q || nativeBlock.textContent.toLowerCase().includes(q) || engineRow && !engineRow.classList.contains("search-hidden");
    nativeBlock.classList.toggle("search-hidden", !show);
  }
  modal.querySelectorAll(".models-title").forEach((title) => {
    let el = title.nextElementSibling;
    while (el && !el.classList.contains("model-list")) el = el.nextElementSibling;
    const any = !q || el && [...el.querySelectorAll(".m-item")].some((m) => !m.classList.contains("search-hidden"));
    title.classList.toggle("search-hidden", !any);
  });
  modal.querySelectorAll(".hint").forEach((h) => {
    if (h.id === "settings-no-match") return;
    h.classList.toggle("search-hidden", !!q);
  });
  const none = $("settings-no-match");
  none.classList.toggle("hidden", !q || visible > 0);
  if (q && visible === 0) none.textContent = t("settingsNoMatch", query.trim());
}
async function restoreUiPrefs() {
  try {
    const { lastConfig, panelPrefs } = await chrome.storage.local.get(["lastConfig", "panelPrefs"]);
    if (lastConfig?.srcLang) state.srcLang = lastConfig.srcLang;
    if (lastConfig?.tgtLang) state.tgtLang = lastConfig.tgtLang;
    return {
      task: lastConfig?.taskMode === "transcribe" ? "transcribe" : "translate",
      mode: panelPrefs?.mode === "offline" ? "offline" : "realtime"
    };
  } catch {
    return { task: "translate", mode: "realtime" };
  }
}
function setView(view) {
  state.view = view === "notes" ? "notes" : view === "settings" ? "settings" : "captions";
  document.querySelectorAll("#view-tabs button").forEach((b) => {
    const active = b.dataset.view === state.view;
    b.classList.toggle("active", active);
    if (active) b.setAttribute("aria-current", "page");
    else b.removeAttribute("aria-current");
  });
  $("view-captions")?.classList.toggle("hidden", state.view !== "captions");
  $("view-notes")?.classList.toggle("hidden", state.view !== "notes");
  syncBottomNav();
  const visibleView = state.view === "notes" ? $("view-notes") : $("view-captions");
  if (visibleView) {
    const items = [...visibleView.querySelectorAll(".reveal")];
    for (const el of items) el.classList.remove("reveal");
    void visibleView.offsetWidth;
    requestAnimationFrame(() => {
      items.forEach((el, i) => {
        el.style.animationDelay = `${Math.min(i * 30, 300)}ms`;
        el.classList.add("reveal");
      });
    });
  }
  syncPill("view-tabs");
  syncPill("captions-subtabs");
}
function syncBottomNav() {
  const settingsOpen = !($("settings-modal")?.classList.contains("hidden") ?? true);
  document.querySelectorAll(".bottom-nav-item").forEach((b) => {
    const active = b.dataset.view === "settings" ? settingsOpen : b.dataset.view === state.view && !settingsOpen;
    b.classList.toggle("active", active);
    if (active) b.setAttribute("aria-current", "page");
    else b.removeAttribute("aria-current");
    if (b.dataset.view === "settings") b.setAttribute("aria-pressed", String(settingsOpen));
  });
}
var PILL_GROUPS = [
  "view-tabs",
  "density-toggle",
  "captions-subtabs",
  "mode-toggle",
  "task-toggle",
  "theme-toggle",
  "asr-preset-toggle",
  "mirror-toggle",
  "device-toggle",
  "native-device-toggle"
];
var pills = /* @__PURE__ */ new Map();
function mountPills() {
  for (const id3 of PILL_GROUPS) {
    const host = $(id3);
    if (!host || pills.has(id3)) continue;
    const pill = document.createElement("span");
    pill.className = "mo-pill";
    host.prepend(pill);
    host.classList.add("mo-has-pill");
    pills.set(id3, highlight(host, { pill, bind: false, selectedAttr: null, activeClass: "active" }));
  }
}
function syncPill(id3, animated = true) {
  pills.get(id3)?.sync(animated);
}
function resyncPills(animated = false) {
  for (const id3 of pills.keys()) syncPill(id3, animated);
}
var panels = /* @__PURE__ */ new Map();
var warnPanel = null;
function mountPanel(id3, wrapId, opts = {}) {
  const wrap = $(wrapId);
  const inner = $(id3);
  if (!wrap || !inner || panels.has(id3)) return null;
  const panel = autoHeight(wrap, {
    inner,
    open: false,
    onSettled: (open) => {
      wrap.setAttribute("aria-hidden", String(!open));
      if (!open && opts.clearOnClose) inner.innerHTML = "";
    }
  });
  panels.set(id3, panel);
  return panel;
}
function showPanel(id3, open) {
  const panel = panels.get(id3);
  if (!panel) return;
  if (open) {
    panel.open();
    $(`${id3}-wrap`)?.setAttribute("aria-hidden", "false");
  } else {
    panel.close();
  }
}
function mountPanels() {
  warnPanel = mountPanel("model-warning", "model-warning-wrap", { clearOnClose: true });
  mountPanel("qa-sample-bar", "qa-sample-wrap");
}
function setMode(mode) {
  const modeChanged = state.mode !== mode;
  state.mode = mode;
  if (modeChanged) chrome.storage.local.set({ panelPrefs: { mode } }).catch(() => {
  });
  document.querySelectorAll("#mode-toggle button").forEach((b) => {
    b.classList.toggle("active", b.dataset.mode === mode);
  });
  syncPill("mode-toggle");
  $("rt-target").classList.toggle("hidden", mode !== "realtime");
  $("btn-pick").classList.toggle("hidden", mode !== "realtime");
  $("pick-hint").classList.add("hidden");
  hideError();
  if (!state.running) setStartStep(null);
  $("off-drop").classList.toggle("hidden", mode !== "offline");
  $("off-results").classList.toggle("hidden", mode !== "offline" || state.offlineLines.length === 0);
  showPanel("qa-sample-bar", mode === "offline" && !!state.qaCatalog?.samples?.length);
  $("live-preview").classList.add("hidden");
  updateButtons();
  updateWarning();
  redrawHelperStatus?.();
  redrawHelperGuide?.();
}
function syncDualLineCheckboxes() {
  const on = !!state.settings.dualLine;
  $("dual-line-main").checked = on;
  $("dual-line").checked = on;
  updateLivePreviewLayout();
}
function syncRefineCheckboxes() {
  const on = !!state.settings.refineTranslation;
  $("refine-main").checked = on;
  $("refine").checked = on;
}
async function setRefineTranslation(on) {
  state.settings.refineTranslation = !!on;
  syncRefineCheckboxes();
  await saveSettings();
  persistLastConfig();
  updateWarning();
  await toBG("update-config", { refineTranslation: state.settings.refineTranslation });
}
function updateLivePreviewLayout() {
  const dual = !!state.settings.dualLine;
  $("live-src-box").classList.toggle("hidden", !dual);
  const srcLabel = $("live-src-box").querySelector(".live-box-label");
  const tgtLabel = $("live-tgt-box").querySelector(".live-box-label");
  if (srcLabel) srcLabel.classList.toggle("hidden", !dual);
  if (tgtLabel) tgtLabel.classList.toggle("hidden", !dual);
}
function clearLivePreview() {
  $("live-src-lines").innerHTML = "";
  $("live-tgt-lines").innerHTML = "";
  delete $("live-src-lines").dataset.interim;
  delete $("live-tgt-lines").dataset.interim;
}
async function setDualLine(on) {
  state.settings.dualLine = !!on;
  syncDualLineCheckboxes();
  await saveSettings();
  persistLastConfig();
  updateWarning();
  await toBG("update-config", { dualLine: state.settings.dualLine });
  redrawHelperStatus?.();
}
function setTask(task) {
  state.task = task;
  document.querySelectorAll("#task-toggle button").forEach((b) => {
    b.classList.toggle("active", b.dataset.task === task);
  });
  syncPill("task-toggle");
  $("tgt-col").style.opacity = task === "translate" ? "1" : "0.4";
  $("tgt-lang").disabled = task !== "translate";
  updateWarning();
  redrawHelperStatus?.();
  redrawHelperGuide?.();
}
function mtPairIssues(srcLang, tgtLang, cfg) {
  const issues = [];
  let directNote = "";
  const plan = translationPlan(srcLang, tgtLang, {
    dualLine: cfg.dualLine,
    refineTranslation: cfg.refineTranslation
  });
  if (plan.mode === "whisper-direct") {
    directNote = `<span style="opacity:.85">${t("directNote")}</span>`;
  } else if (cfg.refineTranslation) {
    directNote = `<span style="opacity:.85">${t("refineNote")}</span>`;
  } else if (plan.mode === "mt") {
    const label2 = pairLabel(`${srcLang}-${tgtLang}`);
    if (plan.pivot) {
      if (!state.downloaded[plan.pivot.leg1Key]) {
        issues.push({
          msg: t("needMtModel", `${pairLabel(plan.pivot.leg1Key)} (${plan.pivot.leg1.size})`),
          key: plan.pivot.leg1Key,
          btn: pairLabel(plan.pivot.leg1Key)
        });
      }
      if (!state.downloaded[plan.pivot.leg2Key]) {
        issues.push({
          msg: t("needMtModel", `${pairLabel(plan.pivot.leg2Key)} (${plan.pivot.leg2.size})`),
          key: plan.pivot.leg2Key,
          btn: pairLabel(plan.pivot.leg2Key)
        });
      }
    } else if (!plan.pair) {
      issues.push({
        msg: `No local translation model exists for ${label2}. The browser's built-in translator or native helper LLM will be tried; otherwise pick another pair.`
      });
    } else if (!state.downloaded[plan.pairKey]) {
      issues.push({
        msg: t("needMtModel", `${label2} (${plan.pair.size})`),
        key: plan.pairKey,
        btn: label2
      });
    }
  }
  return { issues, directNote };
}
function updateWarning() {
  const el = $("model-warning");
  const cfg = currentConfig();
  const issues = [];
  const native = state.settings.engine === "native";
  if (native) {
    if (!nativeInfo) issues.push({ msg: t("nativeOffline") });
  } else if (!state.downloaded[state.settings.asrModel]) {
    const m = ASR_MODELS[state.settings.asrModel];
    issues.push({
      msg: t("needAsrModel", `${m.label} (${m.webgpuOnly || state.settings.device !== "wasm" ? m.sizeWebgpu : m.sizeWasm})`),
      key: state.settings.asrModel,
      btn: `${m.label}`
    });
  }
  let directNote = "";
  if (cfg.taskMode === "translate") {
    if (twoWay()) {
      const { a, b } = interpreter();
      const fwd = mtPairIssues(a, b, cfg);
      const rev = mtPairIssues(b, a, cfg);
      const both = [...fwd.issues, ...rev.issues];
      if (both.length) issues.push({ msg: t("interpNeedsBoth") });
      issues.push(...both);
      directNote = fwd.directNote || rev.directNote;
    } else {
      const r = mtPairIssues(cfg.srcLang, cfg.tgtLang, cfg);
      issues.push(...r.issues);
      directNote = r.directNote;
    }
  }
  if (issues.length === 0 && !directNote) {
    warnPanel?.close();
    return;
  }
  const seenKeys = /* @__PURE__ */ new Set();
  const buttons = issues.filter((i) => i.key && !seenKeys.has(i.key) && seenKeys.add(i.key)).map(
    (i) => `<button class="mini-btn dl-now" data-key="${i.key}">\u2B07 ${t("download")} \u2014 ${i.btn}</button>`
  ).join(" ");
  const manage = `<button class="mini-btn manage-models">\u2699 ${t("manageModels")}</button>`;
  el.innerHTML = [issues.map((i) => i.msg).join("<br>"), buttons, manage, directNote].filter(Boolean).join("<br>");
  warnPanel?.open();
  if (warnPanel) $("model-warning-wrap").setAttribute("aria-hidden", "false");
  el.querySelectorAll(".dl-now").forEach((b) => {
    b.addEventListener("click", () => startDownload(b.dataset.key));
  });
  el.querySelector(".manage-models")?.addEventListener("click", () => {
    openSettings();
    requestAnimationFrame(() => {
      document.querySelector("#asr-models")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
}
function openSettings({ about = false } = {}) {
  const search = $("settings-search");
  if (search) {
    search.value = "";
    filterSettings("");
    setTimeout(() => search.focus({ preventScroll: true }), 30);
  }
  $("settings-modal").classList.remove("hidden");
  for (const id3 of ["theme-toggle", "asr-preset-toggle", "mirror-toggle", "device-toggle", "native-device-toggle"]) {
    syncPill(id3, false);
  }
  lastNativeAutoStartMs = 0;
  labEnsureAttempted = false;
  checkNative({ allowAutoStart: true });
  startNativePoll();
  $("about-block").classList.toggle("hidden", !about);
  if (about) $("about-block").scrollIntoView({ behavior: "smooth" });
  renderModelLists();
  syncBottomNav();
}
function persistLastConfig() {
  chrome.storage.local.set({
    lastConfig: {
      srcLang: state.srcLang,
      tgtLang: state.tgtLang,
      taskMode: state.task,
      dualLine: state.settings.dualLine,
      refineTranslation: state.settings.refineTranslation,
      asrModel: state.settings.asrModel
    }
  }).catch(() => {
  });
}
function currentConfig() {
  const it = interpreter();
  const two = it?.mode === "consecutive";
  return {
    tabId: state.currentTab?.id,
    // Two-way: the a → b direction is the nominal pair; offscreen flips it per
    // utterance. Refine (draft-then-correct) has no meaning without a fixed
    // source language, so it is off.
    srcLang: two ? it.a : state.srcLang,
    tgtLang: two ? it.b : state.tgtLang,
    taskMode: two ? "translate" : state.task,
    dualLine: state.settings.dualLine,
    refineTranslation: two ? false : state.settings.refineTranslation,
    asrModel: state.settings.asrModel,
    interpreter: it
  };
}
var dlState = /* @__PURE__ */ new Map();
function labelForKey(key) {
  if (ASR_MODELS[key]) return ASR_MODELS[key].label;
  if (MT_PAIRS[key]) return pairLabel(key);
  return key;
}
function startDownload(key) {
  if (dlState.get(key) && !dlState.get(key).done) return;
  dlState.set(key, { pct: 0, loaded: 0, total: 0 });
  renderDlList();
  renderModelLists();
  toOffscreen("model-download", { key });
}
var dlRows = /* @__PURE__ */ new Map();
var mb = (n) => (n / 1024 / 1024).toFixed(1);
function makeDlRow(key) {
  const row = document.createElement("div");
  row.className = "dl-row";
  row.innerHTML = `
    <div class="dl-label">
      <span class="dl-name"></span>
      <span class="pct"><span class="dl-live"><span class="dl-size"><span class="dl-loaded"></span> / <span class="dl-total"></span> MB \xB7 </span><span class="dl-pct"></span>%</span><span class="dl-tick">\u2713</span></span>
    </div>
    <div class="bar"><div class="fill"></div></div>`;
  const handles = {
    row,
    name: row.querySelector(".dl-name"),
    size: row.querySelector(".dl-size"),
    total: row.querySelector(".dl-total"),
    loaded: slidingNumber(row.querySelector(".dl-loaded"), { decimals: 1 }),
    pct: slidingNumber(row.querySelector(".dl-pct"), { decimals: 0 }),
    bar: springProgress(row.querySelector(".fill"))
  };
  dlRows.set(key, handles);
  return handles;
}
function renderDlList() {
  const host = $("dl-list");
  host.classList.toggle("hidden", dlState.size === 0);
  for (const [key, handles] of dlRows) {
    if (dlState.has(key)) continue;
    handles.loaded.destroy();
    handles.pct.destroy();
    handles.bar.destroy();
    handles.row.remove();
    dlRows.delete(key);
  }
  for (const [key, d] of dlState) {
    const h = dlRows.get(key) || makeDlRow(key);
    if (!h.row.isConnected) host.appendChild(h.row);
    h.name.textContent = `\u2B07 ${t("downloading")}: ${labelForKey(key)}`;
    h.row.classList.toggle("done", !!d.done);
    h.size.hidden = d.done || !d.total;
    if (d.total) h.total.textContent = mb(d.total);
    h.loaded.to(d.done ? (d.total || 0) / 1024 / 1024 : (d.loaded || 0) / 1024 / 1024);
    h.pct.to(d.done ? 100 : Math.round(d.pct || 0));
    h.bar.to(d.done ? 100 : d.pct || 0);
  }
}
function onModelProgress(d) {
  if (!d || !d.key) return;
  const cur = dlState.get(d.key) || {};
  dlState.set(d.key, { ...cur, pct: d.pct ?? cur.pct, loaded: d.loaded ?? cur.loaded, total: d.total ?? cur.total });
  renderDlList();
  const st = document.querySelector(`.m-state[data-key="${d.key}"]`);
  if (st) st.textContent = `${Math.round(dlState.get(d.key).pct || 0)}%`;
}
async function onModelDone(d) {
  if (d.deleted) {
    dlState.delete(d.key);
  } else {
    dlState.set(d.key, { ...dlState.get(d.key) || {}, pct: 100, done: true });
    setTimeout(() => {
      dlState.delete(d.key);
      renderDlList();
    }, 2500);
  }
  renderDlList();
  await refreshDownloaded();
  renderModelLists();
  updateWarning();
}
async function refreshDownloaded() {
  const { modelsDownloaded = {} } = await chrome.storage.local.get("modelsDownloaded");
  state.downloaded = modelsDownloaded;
}
function renderUiLangToggle() {
  const host = $("ui-lang-toggle");
  if (!host) return;
  const cur = state.settings.uiLang || "en";
  if (!host.dataset.ready) {
    host.innerHTML = "";
    for (const [code, label2] of UI_LANGS) {
      const opt = document.createElement("option");
      opt.value = code;
      opt.textContent = label2;
      host.appendChild(opt);
    }
    host.addEventListener("change", async () => {
      state.settings.uiLang = host.value;
      await saveSettings();
      await loadSettings();
      applyI18n();
      resyncPills(false);
      fillSelects();
      updateWarning();
      renderHistory();
      redrawHelperGuide?.();
      renderQaSampleBar();
      renderModelLists();
    });
    host.dataset.ready = "1";
  }
  host.value = cur;
}
var ENGINE_OPTIONS = [
  ["browser", "engineBrowser"],
  ["native", "engineNative"]
];
function renderEngineToggle() {
  const host = $("engine-toggle");
  if (!host) return;
  const cur = state.settings.engine || "browser";
  if (!host.dataset.ready) {
    host.innerHTML = "";
    for (const [value, i18nKey] of ENGINE_OPTIONS) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.dataset.i18nKey = i18nKey;
      host.appendChild(opt);
    }
    host.addEventListener("change", async () => {
      state.settings.engine = host.value;
      await saveSettings();
      await loadSettings();
      updateWarning();
      if (state.settings.engine === "native") {
        lastNativeAutoStartMs = 0;
        labEnsureAttempted = false;
        checkNative({ allowAutoStart: true });
        if (!$("settings-modal").classList.contains("hidden")) startNativePoll();
      } else {
        stopNativePoll();
      }
    });
    host.dataset.ready = "1";
  }
  for (const opt of host.options) {
    if (opt.dataset.i18nKey) opt.textContent = t(opt.dataset.i18nKey);
  }
  host.value = ENGINE_OPTIONS.some(([v]) => v === cur) ? cur : "browser";
}
function renderQaSampleBar() {
  const bar = $("qa-sample-bar");
  const sel = $("qa-sample-select");
  if (!bar || !sel) return;
  const samples = state.qaCatalog?.samples || [];
  const show = state.mode === "offline" && samples.length > 0;
  showPanel("qa-sample-bar", show);
  if (!samples.length) return;
  const prev = sel.value;
  sel.innerHTML = samples.map(
    (s) => `<option value="${s.id}">${s.label || s.id} (${Math.round(s.durationHint || 0)}s)</option>`
  ).join("");
  if (prev && samples.some((s) => s.id === prev)) sel.value = prev;
}
async function runQaSample(sample, { autoStart = true } = {}) {
  if (!sample || !state.qaCatalog) {
    setStatus2(t("qaNoSample"), "error");
    return;
  }
  setMode("offline");
  setTask("translate");
  state.srcLang = sample.src;
  state.tgtLang = sample.tgt || "en";
  $("src-lang").value = state.srcLang;
  $("tgt-lang").value = state.tgtLang;
  updateWarning();
  persistLastConfig();
  setStatus2(t("qaLoadingSample"));
  try {
    const file = await fetchSampleFile(state.qaCatalog, sample);
    await pickFile(file);
    if (autoStart && state.offlineFile && !state.offlineStaging) {
      await onStart();
    }
  } catch (e) {
    setStatus2(String(e?.message || e), "error");
  }
}
var ASR_PRESETS = { fast: "whisper-tiny", balanced: "whisper-base", accurate: "whisper-small" };
function currentAsrPreset() {
  for (const [p, key] of Object.entries(ASR_PRESETS)) {
    if (key === state.settings.asrModel) return p;
  }
  return null;
}
function activeAsrLabel() {
  const m = ASR_MODELS[state.settings.asrModel];
  if (!m) return "";
  const device = state.settings.device === "auto" ? "Auto" : state.settings.device.toUpperCase();
  return `${m.label} \xB7 ${device}`;
}
function renderAsrPreset() {
  const host = $("asr-preset-toggle");
  if (!host) return;
  const cur = currentAsrPreset();
  host.querySelectorAll("button").forEach((b) => {
    b.classList.toggle("active", b.dataset.preset === cur);
  });
  syncPill("asr-preset-toggle");
  const hint = $("asr-preset-hint");
  if (hint) {
    if (cur) {
      const m = ASR_MODELS[ASR_PRESETS[cur]];
      const size = !m.webgpuOnly && state.settings.device === "wasm" ? m.sizeWasm : m.sizeWebgpu;
      hint.textContent = t("presetHint", m.label, size, m.note);
    } else {
      hint.textContent = t("presetCustom");
    }
  }
}
function renderModelLists() {
  renderAsrPreset();
  const asrHost = $("asr-models");
  asrHost.innerHTML = "";
  for (const [key, m] of Object.entries(ASR_MODELS)) {
    const size = m.webgpuOnly ? m.sizeWebgpu : `${m.sizeWasm} / ${m.sizeWebgpu}`;
    asrHost.appendChild(modelRow(key, m.label, `${size} \xB7 ${m.note}`));
  }
  const mtHost = $("mt-models");
  mtHost.innerHTML = "";
  for (const [key, p] of Object.entries(MT_PAIRS)) {
    mtHost.appendChild(modelRow(key, pairLabel(key), `${key} \xB7 Opus-MT \xB7 ${p.size}`, { mtPair: key }));
  }
  const q = $("settings-search")?.value;
  if (q) filterSettings(q);
}
function modelRow(key, name, sub, { mtPair = null } = {}) {
  const div = document.createElement("div");
  div.className = "m-item";
  const isDl = !!state.downloaded[key];
  const isActive = key === state.settings.asrModel && ASR_MODELS[key];
  const dl = dlState.get(key);
  const downloading = dl && !dl.done;
  const canTest = mtPair && state.qaCatalog && firstSampleForPair(state.qaCatalog, mtPair);
  div.innerHTML = `
    <div class="m-meta">
      <div class="m-name">${name}${isActive ? " \u2713" : ""}</div>
      <div class="m-sub">${sub}</div>
    </div>
    <span class="m-state ${isDl ? "done" : ""}" data-key="${key}">${downloading ? Math.round(dl.pct || 0) + "%" : isDl ? "\u2705" : ""}</span>
    ${canTest ? `<button class="mini-btn test-btn" data-pair="${mtPair}" title="${t("qaSamplesHint")}">${t("qaTest")}</button>` : ""}
    ${ASR_MODELS[key] && !isActive ? `<button class="mini-btn use-btn" data-key="${key}">Use</button>` : ""}
    <button class="mini-btn act-btn" data-key="${key}" ${downloading ? "disabled" : ""}>${downloading ? "\u2026" : isDl ? t("delete") : "\u2B07 " + t("download")}</button>
  `;
  div.querySelector(".act-btn").addEventListener("click", () => {
    if (state.downloaded[key]) {
      toOffscreen("model-delete", { key });
    } else {
      startDownload(key);
    }
  });
  div.querySelector(".use-btn")?.addEventListener("click", async () => {
    state.settings.asrModel = key;
    await saveSettings();
    renderModelLists();
    updateWarning();
  });
  div.querySelector(".test-btn")?.addEventListener("click", async () => {
    const pair = div.querySelector(".test-btn").dataset.pair;
    const sample = firstSampleForPair(state.qaCatalog, pair);
    $("settings-modal").classList.add("hidden");
    stopNativePoll();
    syncBottomNav();
    await runQaSample(sample, { autoStart: true });
  });
  return div;
}
function applyTheme() {
  const theme = state.settings.theme || "auto";
  document.documentElement.classList.remove("theme-light", "theme-dark");
  if (theme === "light") document.documentElement.classList.add("theme-light");
  else if (theme === "dark") document.documentElement.classList.add("theme-dark");
  document.querySelectorAll("#theme-toggle button").forEach((b) => {
    b.classList.toggle("active", b.dataset.theme === theme);
  });
  syncPill("theme-toggle");
}
async function setTheme(theme) {
  const next = ["auto", "light", "dark"].includes(theme) ? theme : "auto";
  state.settings.theme = next;
  await saveSettings();
  applyTheme();
  pushUiPrefs();
}
function applyExternalSettings(next) {
  if (!next || typeof next !== "object") return;
  if (["auto", "light", "dark"].includes(next.theme) && next.theme !== state.settings.theme) {
    state.settings.theme = next.theme;
    applyTheme();
  }
  if (["yraverage", "coretax", "modern"].includes(next.reskin) && next.reskin !== state.settings.reskin) {
    state.settings.reskin = next.reskin;
    applyReskin();
  }
}
function applyReskin() {
  const reskin = ["yraverage", "coretax", "modern"].includes(state.settings.reskin) ? state.settings.reskin : "yraverage";
  document.documentElement.dataset.reskin = reskin;
  document.querySelectorAll("#reskin-toggle button").forEach((b) => {
    const active = b.dataset.reskin === reskin;
    b.classList.toggle("active", active);
    b.setAttribute("aria-checked", String(active));
  });
}
async function setReskin(reskin) {
  const next = ["yraverage", "coretax", "modern"].includes(reskin) ? reskin : "yraverage";
  state.settings.reskin = next;
  await saveSettings();
  applyReskin();
  pushUiPrefs();
}
function pushUiPrefs() {
  if (!nativeInfo) return;
  nativeSetUiPrefs(state.settings.nativeUrl || DEFAULT_NATIVE_URL, {
    theme: state.settings.theme,
    reskin: state.settings.reskin
  }).catch(() => {
  });
}
async function pullUiPrefs() {
  if (!nativeInfo) return;
  const res = await nativeGetUiPrefs(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  if (!res?.stored) return;
  let changed = false;
  if (["auto", "light", "dark"].includes(res.prefs?.theme) && res.prefs.theme !== state.settings.theme) {
    state.settings.theme = res.prefs.theme;
    changed = true;
  }
  if (["yraverage", "coretax", "modern"].includes(res.prefs?.reskin) && res.prefs.reskin !== state.settings.reskin) {
    state.settings.reskin = res.prefs.reskin;
    changed = true;
  }
  if (changed) {
    await saveSettings();
    applyTheme();
    applyReskin();
  }
}
async function loadSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  if (settings) Object.assign(state.settings, settings);
  if (!UI_LANGS.some(([c]) => c === state.settings.uiLang)) {
    state.settings.uiLang = "en";
  }
  state.settings.interpreter = normalizeInterpreter(state.settings, state.srcLang, state.tgtLang);
  if (state.settings.interpreter.mode === "consecutive") {
    state.srcLang = state.settings.interpreter.a;
    state.tgtLang = state.settings.interpreter.b;
  }
  renderUiLangToggle();
  renderEngineToggle();
  if (!["auto", "light", "dark"].includes(state.settings.theme)) {
    state.settings.theme = "auto";
  }
  applyTheme();
  if (!["yraverage", "coretax", "modern"].includes(state.settings.reskin)) {
    state.settings.reskin = "yraverage";
  }
  applyReskin();
  document.querySelectorAll("#mirror-toggle button").forEach(
    (b) => b.classList.toggle("active", b.dataset.mirror === state.settings.mirror)
  );
  document.querySelectorAll("#device-toggle button").forEach(
    (b) => b.classList.toggle("active", b.dataset.device === state.settings.device)
  );
  syncPill("mirror-toggle");
  syncPill("device-toggle");
  $("native-block").classList.toggle("hidden", state.settings.engine !== "native");
  syncPill("native-device-toggle", false);
  $("native-url").value = state.settings.nativeUrl || DEFAULT_NATIVE_URL;
  renderNativeDeviceUi();
  syncDualLineCheckboxes();
  syncRefineCheckboxes();
  $("font-size").value = state.settings.overlayFontSize;
  applyInterpreterUi();
  state.settings.exportOptions = exportOptions();
}
var EXPORT_OS = detectOs();
function exportOptions() {
  return normalizeExportOptions(state.settings.exportOptions, EXPORT_OS);
}
function currentExportSource() {
  const lines = state.mode === "offline" ? state.offlineLines : state.realtimeLines;
  if (!lines.length) return null;
  return {
    lines,
    count: lines.length,
    title: state.mode === "offline" ? state.offlineFile?.name || "subtitles" : state.currentTab?.title || "subtitles",
    url: state.mode === "realtime" ? state.currentTab?.url || "" : "",
    srcLang: state.srcLang,
    tgtLang: state.task === "translate" ? state.tgtLang : "",
    dualLine: state.settings.dualLine
  };
}
async function updateExportOptions(patch) {
  state.settings.exportOptions = normalizeExportOptions({ ...exportOptions(), ...patch }, EXPORT_OS);
  await saveSettings();
  redrawHelperStatus?.();
}
var nativeInfo = null;
var largeFileJob = null;
var redrawHelperStatus = null;
var redrawHelperGuide = null;
var nativeHostInstalled = null;
var nativePollTimer = null;
var nativeBusy = false;
var lastNativeAutoStartMs = 0;
var NATIVE_AUTO_START_COOLDOWN_MS = 3e4;
var labEnsureAttempted = false;
var nativeHostConn = null;
var nativeHostProbePending = null;
function noteNativeHostResult(err) {
  if (!err) {
    nativeHostInstalled = true;
    nativeHostConn = { state: "connected", connected: true, hostInstalled: true, error: null };
    return;
  }
  const state2 = classifyNativeHostError(err);
  nativeHostInstalled = hostInstalledFromState(state2);
  nativeHostConn = { state: state2, connected: false, hostInstalled: nativeHostInstalled, error: String(err?.message || err) };
}
async function probeNativeHost() {
  if (nativeHostProbePending) return nativeHostProbePending;
  nativeHostProbePending = (async () => {
    try {
      const r = await nativeHostConnection({ timeoutMs: 4e3 });
      nativeHostConn = r;
      nativeHostInstalled = r.hostInstalled;
      return r;
    } finally {
      nativeHostProbePending = null;
      redrawHelperGuide?.();
    }
  })();
  return nativeHostProbePending;
}
async function tryAutoStartNative() {
  if (nativeBusy || !nativeHostSupported()) return false;
  const now = Date.now();
  if (now - lastNativeAutoStartMs < NATIVE_AUTO_START_COOLDOWN_MS) return false;
  lastNativeAutoStartMs = now;
  try {
    const res = await nativeHostAction("start", { timeoutMs: 9e4 });
    noteNativeHostResult(null);
    return !!res?.ok;
  } catch (e) {
    noteNativeHostResult(e);
    console.warn("native auto-start failed", e);
    return false;
  }
}
async function tryEnsureLab() {
  if (labEnsureAttempted || nativeBusy || !nativeHostSupported() || !nativeInfo) return;
  labEnsureAttempted = true;
  try {
    await nativeHostAction("ensure_lab", { timeoutMs: 3e4 });
  } catch (e) {
    console.warn("lab ensure failed", e);
  }
}
function setNativeUi({ running, busy, detail }) {
  const dot = $("native-status-dot");
  const st = $("native-status");
  dot.className = "status-dot " + (busy ? "busy" : running ? "on" : "off");
  st.className = "native-status " + (busy ? "" : running ? "on" : "off");
  st.textContent = detail;
  $("btn-native-start").disabled = busy || running;
  $("btn-native-stop").disabled = busy || !running;
  $("btn-native-restart").disabled = busy;
}
async function checkNative({ allowAutoStart = false } = {}) {
  if (nativeBusy) return nativeInfo;
  setNativeUi({ running: !!nativeInfo, busy: true, detail: t("nativeChecking") });
  nativeInfo = await nativeHealth(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  if (!nativeInfo && allowAutoStart) {
    const started = await tryAutoStartNative();
    if (started) nativeInfo = await nativeHealth(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  }
  if (nativeInfo) {
    const stale = nativeInfo.translate && nativeInfo.features && nativeInfo.features.translate_refine === false;
    setNativeUi({
      running: true,
      busy: false,
      detail: stale ? t("nativeStale", "Helper running \u2014 click Restart to load latest features") : t(
        "nativeOnline",
        `${nativeInfo.engine} \xB7 ${nativeInfo.model}${nativeInfo.translate ? " \xB7 +LLM translate" : ""}${nativeInfo.ffmpeg ? "" : " \xB7 \u26A0 no ffmpeg"}`
      )
    });
    tryEnsureLab();
    if (!nativeDeviceInfo) refreshNativeDeviceInfo();
  } else {
    nativeDeviceInfo = null;
    setNativeUi({ running: false, busy: false, detail: t("nativeOffline") });
  }
  updateWarning();
  updateNativeHostHint();
  redrawHelperStatus?.();
  redrawHelperGuide?.();
  renderNativeModels();
  renderNativeDeviceUi();
  return nativeInfo;
}
var nativeDeviceInfo = null;
var nativeDeviceMsg = null;
function helperIsApple() {
  return (nativeInfo?.device || "").toLowerCase() === "apple-silicon" || nativeInfo?.engine === "mlx-whisper";
}
function renderNativeDeviceUi() {
  const row = $("native-device-row");
  if (!row) return;
  const want = HELPER_DEVICE_OPTIONS.includes(state.settings.nativeDevice) ? state.settings.nativeDevice : "auto";
  const apple = !!nativeInfo && helperIsApple();
  const active = (nativeInfo?.device || "").toLowerCase();
  const compute = nativeInfo?.compute || "";
  const cudaAvail = nativeDeviceInfo?.cuda_available;
  document.querySelectorAll("#native-device-toggle button").forEach((b) => {
    const d = b.dataset.hdevice;
    b.classList.toggle("active", apple ? d === "auto" : d === want);
    b.setAttribute("aria-checked", String(apple ? d === "auto" : d === want));
    b.disabled = apple;
    if (d === "cuda" && cudaAvail === false && !apple) b.title = t("helperDeviceNoCuda");
    else b.removeAttribute("title");
  });
  const pill = $("native-device-active");
  if (nativeInfo) {
    const label2 = active === "apple-silicon" ? "Apple Silicon \xB7 MLX" : active || "\u2014";
    pill.textContent = t("helperDeviceActive", label2, active === "apple-silicon" ? "" : compute);
    pill.className = `notes-pill ${active && active !== "cpu" ? "ready" : "idle"}`;
  } else {
    pill.textContent = t("helperDeviceOffline");
    pill.className = "notes-pill idle";
  }
  const hint = $("native-device-hint");
  let text = "";
  let warn = false;
  if (apple) {
    text = t("helperDeviceApple");
  } else if (nativeDeviceMsg) {
    text = nativeDeviceMsg.kind === "manual" ? t("helperDeviceManual", nativeDeviceMsg.device) : t("helperDeviceRestart");
    warn = true;
  } else if (nativeInfo && want !== "auto" && active && active !== want) {
    text = t("helperDeviceMismatch", want, active);
    warn = true;
  } else if (want === "cuda" && cudaAvail === false) {
    text = t("helperDeviceNoCuda");
    warn = true;
  } else {
    text = t(`helperDevice${want[0].toUpperCase()}${want.slice(1)}_hint`);
  }
  hint.textContent = text;
  hint.classList.toggle("warn", warn);
}
async function refreshNativeDeviceInfo() {
  if (!nativeInfo) {
    nativeDeviceInfo = null;
    return;
  }
  try {
    nativeDeviceInfo = await nativeGetDevice(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  } catch {
    nativeDeviceInfo = null;
  }
  renderNativeDeviceUi();
}
async function setNativeDevice(device) {
  if (!HELPER_DEVICE_OPTIONS.includes(device) || helperIsApple()) return;
  state.settings.nativeDevice = device;
  await saveSettings();
  nativeDeviceMsg = null;
  if (nativeInfo) {
    try {
      const res = await nativeSetDevice(state.settings.nativeUrl || DEFAULT_NATIVE_URL, device);
      nativeDeviceMsg = res.supported ? { kind: "restart", device } : { kind: "manual", device };
      if (res.supported) nativeDeviceInfo = { ...nativeDeviceInfo || {}, supported: true, device };
    } catch (e) {
      nativeDeviceMsg = { kind: "manual", device };
    }
  }
  renderNativeDeviceUi();
}
function fmtBytes(n) {
  if (!Number.isFinite(n) || n <= 0) return "\u2014";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let u = 0;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u += 1;
  }
  return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${units[u]}`;
}
async function renderNativeModels() {
  const host = $("native-models");
  if (!host) return;
  host.innerHTML = "";
  if (!nativeInfo) return;
  const res = await nativeGetModels(state.settings.nativeUrl || DEFAULT_NATIVE_URL);
  if (!res) return;
  const rows = [];
  for (const m of res.models || []) {
    rows.push({
      name: `${m.kind === "asr" ? "\u{1F399}" : m.kind === "draft" ? "\u26A1" : "\u{1F310}"} ${m.id || m.key}`,
      sub: `${m.engine || ""}${m.device ? ` \xB7 ${m.device}` : ""}`,
      state: m.available ? "done" : "",
      stateText: m.available ? "\u2705" : "\u2014"
    });
  }
  for (const c of res.cached || []) {
    rows.push({
      name: `\u{1F4BE} ${c.id}`,
      sub: `${fmtBytes(c.bytes)} \xB7 ${c.files} files${c.complete ? "" : " \xB7 incomplete"}`,
      state: c.complete ? "done" : "",
      stateText: c.complete ? "\u2705" : "\u2026"
    });
  }
  if (!rows.length) return;
  for (const r of rows) {
    const div = document.createElement("div");
    div.className = "m-item";
    const name = document.createElement("div");
    name.className = "m-meta";
    const t1 = document.createElement("div");
    t1.className = "m-name";
    t1.textContent = r.name;
    const t2 = document.createElement("div");
    t2.className = "m-sub";
    t2.textContent = r.sub;
    name.append(t1, t2);
    const st = document.createElement("span");
    st.className = `m-state ${r.state}`.trim();
    st.textContent = r.stateText;
    div.append(name, st);
    host.appendChild(div);
  }
}
function updateNativeHostHint() {
  const el = $("native-host-hint");
  if (!nativeHostSupported()) {
    el.classList.add("hidden");
    return;
  }
  el.textContent = t("nativeHostHint");
  el.classList.toggle("hidden", !!nativeInfo);
}
function startNativePoll() {
  stopNativePoll();
  nativePollTimer = setInterval(() => checkNative({ allowAutoStart: true }), 5e3);
}
function stopNativePoll() {
  if (nativePollTimer) {
    clearInterval(nativePollTimer);
    nativePollTimer = null;
  }
}
async function nativeControl(action) {
  if (nativeBusy) return;
  nativeBusy = true;
  const url = state.settings.nativeUrl || DEFAULT_NATIVE_URL;
  setNativeUi({
    running: !!nativeInfo,
    busy: true,
    detail: action === "start" ? t("nativeStarting") : action === "stop" ? t("nativeStopping") : t("nativeRestarting")
  });
  try {
    if (nativeHostSupported()) {
      let res;
      try {
        res = await nativeHostAction(action, { timeoutMs: 13e4 });
      } catch (e) {
        noteNativeHostResult(e);
        throw e;
      }
      noteNativeHostResult(null);
      if (!res?.ok) throw new Error(res?.error || "Native host failed");
      if (action !== "stop") {
        nativeDeviceMsg = null;
        nativeDeviceInfo = null;
      }
    } else if (action === "stop") {
      await nativeShutdown(url);
      await new Promise((r) => setTimeout(r, 400));
    } else {
      throw new Error(t("nativeHostMissing"));
    }
    await checkNative();
  } catch (e) {
    setNativeUi({ running: false, busy: false, detail: String(e.message || e) });
    updateNativeHostHint();
  } finally {
    nativeBusy = false;
  }
}
async function saveSettings() {
  await chrome.storage.local.set({ settings: state.settings });
}
function isLabHarness() {
  return typeof window !== "undefined" && !!window.__chromeMockStore;
}
var labMediaEl = null;
function releaseLabCapture() {
  try {
    const s = window.__ltsCaptureStream;
    if (s?.getTracks) {
      for (const track of s.getTracks()) {
        try {
          track.stop();
        } catch {
        }
      }
    }
  } catch {
  }
  window.__ltsCaptureStream = null;
  window.__ltsLabClock = null;
  if (labMediaEl) {
    try {
      labMediaEl.pause();
      labMediaEl.removeAttribute("src");
      labMediaEl.load();
      labMediaEl.remove();
    } catch {
    }
    labMediaEl = null;
  }
}
async function acquireLabDemoStream() {
  releaseLabCapture();
  let url = "/speech.wav";
  let title = "Lab demo \u2014 looping speech.wav";
  try {
    const cat = await loadSampleCatalog();
    const sample = firstSampleForPair(cat, `${state.srcLang}-${state.tgtLang}`) || firstSampleForPair(cat, `${state.srcLang}-en`) || cat?.samples?.[0];
    if (cat && sample?.file) {
      url = `${cat.base}${sample.file}`;
      title = sample.label || sample.file;
    }
  } catch {
  }
  const el = document.createElement("audio");
  el.src = url;
  el.loop = true;
  el.controls = true;
  el.crossOrigin = "anonymous";
  el.setAttribute("playsinline", "");
  el.style.cssText = "position:fixed;right:12px;bottom:12px;width:240px;z-index:40;border-radius:8px;background:#111";
  document.body.appendChild(el);
  labMediaEl = el;
  try {
    await el.play();
  } catch (e) {
    releaseLabCapture();
    throw new Error(`Lab demo audio blocked: ${e.message || e}. Click the page, then Start again.`);
  }
  const raw = typeof el.captureStream === "function" ? el.captureStream() : typeof el.mozCaptureStream === "function" ? el.mozCaptureStream() : null;
  const audioTracks = raw?.getAudioTracks?.() || [];
  if (!audioTracks.length) {
    releaseLabCapture();
    throw new Error("Could not capture audio from the lab demo clip (captureStream).");
  }
  const stream = new MediaStream(audioTracks);
  window.__ltsCaptureStream = stream;
  window.__ltsLabClock = () => labMediaEl && Number.isFinite(labMediaEl.currentTime) ? labMediaEl.currentTime : 0;
  state.currentTab = { id: 1, title, url, favIconUrl: "" };
  $("tab-title").textContent = title;
  $("tab-url").textContent = url;
  $("tab-favicon").src = chrome.runtime.getURL("icons/icon16.png");
  updateButtons();
  return stream;
}
async function acquireLabDisplayStream() {
  releaseLabCapture();
  if (!navigator.mediaDevices?.getDisplayMedia) {
    throw new Error("getDisplayMedia is unavailable in this browser.");
  }
  const display = await navigator.mediaDevices.getDisplayMedia({
    video: true,
    audio: true
  });
  const audioTracks = display.getAudioTracks();
  if (!audioTracks.length) {
    for (const track of display.getTracks()) track.stop();
    throw new Error(t("noAudioShared"));
  }
  for (const track of display.getVideoTracks()) track.stop();
  const stream = new MediaStream(audioTracks);
  const t0 = performance.now();
  window.__ltsCaptureStream = stream;
  window.__ltsLabClock = () => (performance.now() - t0) / 1e3;
  audioTracks[0].addEventListener("ended", () => {
    if (state.running) onStop();
  });
  state.currentTab = {
    id: 1,
    title: "Shared tab / window (getDisplayMedia)",
    url: location.href,
    favIconUrl: ""
  };
  $("tab-title").textContent = state.currentTab.title;
  $("tab-url").textContent = "Pick \u2192 share a tab and enable audio";
  $("tab-favicon").src = chrome.runtime.getURL("icons/icon16.png");
  updateButtons();
  return stream;
}
function renderTargetCard(tab, { live = false, elsewhere = false } = {}) {
  const fallbackIcon = chrome.runtime.getURL("icons/icon16.png");
  if (tab) {
    $("tab-title").textContent = tab.title || tab.url;
    $("tab-url").textContent = tab.url || "";
    $("tab-favicon").src = tab.favIconUrl || fallbackIcon;
  } else {
    $("tab-title").textContent = t("noTab");
    $("tab-url").textContent = "";
    $("tab-favicon").src = fallbackIcon;
  }
  const card = $("rt-target");
  card.classList.toggle("live", live);
  card.classList.toggle("elsewhere", live && elsewhere);
  const tag = $("target-tag");
  tag.classList.toggle("live", live);
  tag.textContent = live ? elsewhere ? t("liveOtherTab") : t("liveThisTab") : t("currentPage");
  $("btn-goto-session-tab").classList.toggle("hidden", !(live && elsewhere));
  $("session-tab-hint").classList.toggle("hidden", !(live && elsewhere));
}
async function refreshTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const usable2 = tab && /^https?:/.test(tab.url || "") ? tab : null;
  state.currentTab = usable2;
  if (state.mode === "realtime" && state.running && state.sessionTab) {
    const elsewhere = !tab || tab.id !== state.sessionTab.id;
    if (!elsewhere && usable2) state.sessionTab = { ...state.sessionTab, ...usable2 };
    renderTargetCard(state.sessionTab, { live: true, elsewhere });
  } else {
    renderTargetCard(usable2);
  }
  updateButtons();
}
async function rememberSessionTab(tabId) {
  if (tabId == null) {
    state.sessionTab = state.currentTab;
    return;
  }
  try {
    state.sessionTab = await chrome.tabs.get(tabId);
  } catch {
    state.sessionTab = state.currentTab;
  }
}
function gotoSessionTab() {
  const tab = state.sessionTab;
  if (!tab) return;
  chrome.tabs.update?.(tab.id, { active: true })?.catch?.(() => {
  });
  if (tab.windowId != null) chrome.windows?.update?.(tab.windowId, { focused: true })?.catch?.(() => {
  });
}
function updateButtons() {
  const running = state.mode === "realtime" ? state.running : state.offlineRunning;
  $("btn-start").disabled = running || state.offlineStaging || (state.mode === "realtime" ? !state.currentTab : !state.offlineFile);
  $("btn-stop").disabled = !running;
  $("btn-stop").textContent = state.mode === "offline" ? t("cancelTask") : t("endTask");
}
function setStatus2(text, cls = "") {
  const el = $("status-line");
  el.className = "status-line " + cls;
  $("status-text").textContent = text;
  const dot = $("status-dot");
  dot.classList.toggle("hidden", !text);
  dot.className = "status-dot " + (!text ? "hidden" : cls === "ok" ? "on" : cls === "error" ? "error" : "busy");
}
function flashStatusDot() {
  const dot = $("status-dot");
  if (!dot || dot.classList.contains("hidden")) return;
  dot.classList.remove("flash");
  void dot.offsetWidth;
  dot.classList.add("flash");
}
var START_STEPS = ["capture", "models", "warmup", "listening"];
function setStartStep(key, { failed = false } = {}) {
  const host = $("start-steps");
  if (!host) return;
  if (!key) {
    host.classList.add("hidden");
    host.querySelectorAll("li").forEach((li) => li.className = "");
    return;
  }
  host.classList.remove("hidden");
  const idx = START_STEPS.indexOf(key);
  host.querySelectorAll("li").forEach((li, i) => {
    li.className = i < idx ? "done" : i === idx ? failed ? "failed" : "current" : "";
    if (i === idx && key === "listening" && !failed) li.className = "done current";
  });
}
function showError(raw, { statusText } = {}) {
  const { key, action, detail } = classifyError(raw);
  const title = t(errTitleKey(key));
  const hint = t(errHintKey(key));
  setStatus2(statusText ?? title, key === "cancelled" ? "" : "error");
  const box = $("error-box");
  if (!box) return;
  if (key === "cancelled") {
    hideError();
    return;
  }
  $("error-title").textContent = title;
  $("error-hint").textContent = hint;
  const showDetail = detail && detail !== title && key !== "captureBlocked";
  $("error-detail-wrap").classList.toggle("hidden", !showDetail);
  $("error-detail-wrap").open = false;
  $("error-detail").textContent = detail;
  const btn = $("btn-error-action");
  btn.classList.toggle("hidden", !action);
  btn.dataset.action = action || "";
  btn.textContent = action === "pick" ? t("errActionPick") : action === "settings" ? t("errActionSettings") : t("errActionRetry");
  box.classList.remove("hidden");
}
function hideError() {
  $("error-box")?.classList.add("hidden");
}
function onErrorAction() {
  const action = $("btn-error-action").dataset.action;
  hideError();
  if (action === "pick") onPickManually();
  else if (action === "settings") $("btn-settings").click();
  else if (action === "retry") onStart();
}
function showToast(msg, kind = "ok") {
  const stack = $("toast-stack");
  if (!stack || !msg) return;
  const el = document.createElement("div");
  el.className = "toast " + (kind === "error" ? "error" : "ok");
  el.setAttribute("role", kind === "error" ? "alert" : "status");
  const body = document.createElement("span");
  body.className = "toast-msg";
  body.textContent = msg;
  const close = document.createElement("button");
  close.className = "toast-close";
  close.type = "button";
  close.setAttribute("aria-label", "\u2715");
  close.textContent = "\u2715";
  const dismiss = () => {
    el.classList.add("leaving");
    setTimeout(() => el.remove(), 220);
  };
  close.addEventListener("click", dismiss);
  el.append(body, close);
  stack.appendChild(el);
  while (stack.children.length > 3) stack.firstChild.remove();
  setTimeout(() => {
    if (el.isConnected) dismiss();
  }, 5e3);
}
if (typeof window !== "undefined") window.__ltsToast = showToast;
async function startWithStream(streamId, captureType) {
  setStatus2(t("loadingModels"));
  setStartStep("models");
  state.realtimeLines = [];
  clearLivePreview();
  $("live-preview").classList.remove("hidden");
  const res = await toBG("panel-start-realtime", {
    ...currentConfig(),
    streamId,
    captureType,
    tabTitle: state.currentTab?.title,
    tabUrl: state.currentTab?.url
  });
  if (res?.ok) {
    state.running = true;
    state.sessionTab = state.currentTab;
    syncCaptureStamp();
    $("pick-hint").classList.add("hidden");
    updateButtons();
    refreshTab();
  } else if (res?.error) {
    if (isLabHarness()) releaseLabCapture();
    showCaptureError(res.error);
  }
}
function showCaptureError(message) {
  const blocked = /invoked|activeTab|not been invoked/i.test(message);
  showError(message, { statusText: blocked ? t("needInvoke") : void 0 });
  setStartStep("capture", { failed: true });
  if (blocked) {
    $("pick-hint").textContent = t("pickHint");
    $("pick-hint").classList.remove("hidden");
  }
}
function onPickManually() {
  if (isLabHarness()) {
    void (async () => {
      $("pick-hint").textContent = t("pickHintLab");
      $("pick-hint").classList.remove("hidden");
      try {
        setStatus2(t("pickHintLab"));
        await acquireLabDisplayStream();
        await startWithStream(null, "media");
      } catch (e) {
        if (e?.name === "NotAllowedError" || /Permission denied|dismissed/i.test(String(e?.message || e))) {
          setStatus2(t("cancelled"));
        } else {
          setStatus2(String(e?.message || e), "error");
        }
      }
    })();
    return;
  }
  if (!chrome.desktopCapture?.chooseDesktopMedia) {
    setStatus2("desktopCapture API unavailable in this browser.", "error");
    return;
  }
  $("pick-hint").textContent = t("pickHint");
  $("pick-hint").classList.remove("hidden");
  chrome.desktopCapture.chooseDesktopMedia(["tab", "window", "screen", "audio"], (streamId, opts) => {
    if (!streamId) {
      setStatus2(t("cancelled"));
      return;
    }
    if (opts && opts.canRequestAudioTrack === false) {
      setStatus2(t("noAudioShared"), "error");
      return;
    }
    startWithStream(streamId, "desktop");
  });
}
async function onStart() {
  if (state.mode === "realtime") {
    persistLastConfig();
    if (isLabHarness()) {
      try {
        setStatus2(t("loadingModels"));
        clearLivePreview();
        $("live-preview").classList.remove("hidden");
        await acquireLabDemoStream();
        await startWithStream(null, "media");
      } catch (e) {
        releaseLabCapture();
        setStatus2(String(e?.message || e), "error");
      }
      return;
    }
    if (!state.currentTab) return;
    hideError();
    setStatus2(t("requestingCapture"));
    setStartStep("capture");
    let streamId = null;
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({
        targetTabId: state.currentTab.id
      });
    } catch (e) {
      const m = String(e?.message || e);
      if (/invoked|activeTab/i.test(m)) {
        showCaptureError(m);
        onPickManually();
        return;
      }
    }
    await startWithStream(streamId, "tab");
  } else {
    if (state.offlineStaging) {
      setStatus2(t("stagingFile"));
      return;
    }
    if (!state.offlineFile) {
      setStatus2(t("pickFile"), "error");
      return;
    }
    setStatus2(t("processing"));
    state.offlineLines = [];
    $("off-lines").innerHTML = "";
    $("off-results").classList.remove("hidden");
    $("off-progress-text").textContent = "\u2026";
    try {
      await toBG("ensure-offscreen", {});
      toOffscreen("offline-process", {
        name: state.offlineFile.name,
        size: state.offlineFile.size,
        config: currentConfig()
      });
      state.offlineRunning = true;
      syncCaptureStamp();
      updateButtons();
    } catch (e) {
      setStatus2(String(e?.message || e), "error");
    }
  }
}
async function onStop() {
  if (state.mode === "realtime") {
    await toBG("panel-stop", {});
    state.running = false;
    state.sessionTab = null;
    syncCaptureStamp();
    if (isLabHarness()) releaseLabCapture();
    setStatus2("");
    setStartStep(null);
    hideError();
    updateButtons();
    refreshTab();
  } else {
    toOffscreen("offline-cancel", {});
  }
}
function wireDropzone() {
  const dz = $("off-drop");
  const input = $("off-file");
  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", () => pickFile(input.files[0]));
  dz.addEventListener("dragover", (e) => {
    e.preventDefault();
    dz.classList.add("dragover");
  });
  dz.addEventListener("dragleave", () => dz.classList.remove("dragover"));
  dz.addEventListener("drop", (e) => {
    e.preventDefault();
    dz.classList.remove("dragover");
    if (e.dataTransfer.files?.[0]) pickFile(e.dataTransfer.files[0]);
  });
}
async function stageOfflineFile(file) {
  await stageFileToOpfs(file, (loaded, total) => {
    if (!total) return;
    const pct = Math.min(100, Math.round(loaded / total * 100));
    const sizeMb = (file.size / 1024 / 1024).toFixed(1);
    $("off-filename").textContent = `${file.name} (${sizeMb} MB) \u2014 ${t("stagingFilePct", pct)}`;
  });
}
async function pickFile(file) {
  if (!file) return;
  state.offlineFile = null;
  state.offlineStaging = true;
  largeFileJob = null;
  redrawHelperStatus?.();
  const sizeMb = (file.size / 1024 / 1024).toFixed(1);
  $("off-filename").textContent = `${file.name} (${sizeMb} MB) \u2014 ${t("stagingFile")}`;
  updateButtons();
  try {
    await stageOfflineFile(file);
    state.offlineFile = { name: file.name, size: file.size };
    $("off-filename").textContent = `${file.name} (${sizeMb} MB)`;
    if (needsNativeFilePath(file.size)) {
      setStatus2(t("fileTooLarge"), "error");
    } else {
      setStatus2("");
    }
  } catch (e) {
    state.offlineFile = null;
    const msg = String(e?.message || e);
    setStatus2(/could not be read|NotReadableError/i.test(msg) ? t("fileReadError") : msg, "error");
    $("off-filename").textContent = t("dropHint");
  } finally {
    state.offlineStaging = false;
    updateButtons();
  }
}
function appendLiveLine(host, text, tag = "") {
  if (!text) return;
  const div = document.createElement("div");
  div.className = "line";
  if (tag) {
    const badge = document.createElement("span");
    badge.className = "dir-tag";
    badge.textContent = tag;
    div.appendChild(badge);
  }
  div.appendChild(document.createTextNode(text));
  host.appendChild(div);
  while (host.children.length > 30) host.firstChild.remove();
  host.scrollTop = host.scrollHeight;
}
function setLiveInterim(host, text) {
  if (!text) {
    delete host.dataset.interim;
    const existing = host.querySelector(".line.interim");
    if (existing) existing.remove();
    return;
  }
  let div = host.querySelector(".line.interim");
  if (!div) {
    div = document.createElement("div");
    div.className = "line interim";
    host.appendChild(div);
  }
  div.textContent = text;
  host.dataset.interim = "1";
  host.scrollTop = host.scrollHeight;
}
function pushLive({ source, translation, rawSource, rawTranslation, t0, t1, interim, partial, dir }) {
  if (interim && partial) {
    if (source) setLiveInterim($("live-src-lines"), source);
    if (translation) setLiveInterim($("live-tgt-lines"), translation);
    return;
  }
  if (interim) return;
  setLiveInterim($("live-src-lines"), "");
  setLiveInterim($("live-tgt-lines"), "");
  const srcTag = dir?.src ? dir.src.toUpperCase() : "";
  const dirTag = dir?.src && dir?.tgt ? `${dir.src.toUpperCase()} \u2192 ${dir.tgt.toUpperCase()}` : "";
  if (source) appendLiveLine($("live-src-lines"), source, srcTag);
  if (translation) appendLiveLine($("live-tgt-lines"), translation, dirTag);
  if ((source || translation) && (t0 != null || t1 != null)) {
    state.realtimeLines.push({
      t0: t0 ?? 0,
      t1: t1 ?? (t0 ?? 0) + 3,
      src: rawSource ?? source ?? "",
      tgt: rawTranslation ?? translation ?? ""
    });
    redrawHelperStatus?.();
  }
}
function fmtTs(sec, srtStyle = false) {
  const ms = Math.max(0, Math.round(sec * 1e3));
  const h = String(Math.floor(ms / 36e5)).padStart(2, "0");
  const m = String(Math.floor(ms % 36e5 / 6e4)).padStart(2, "0");
  const s = String(Math.floor(ms % 6e4 / 1e3)).padStart(2, "0");
  const f = String(ms % 1e3).padStart(3, "0");
  return srtStyle ? `${h}:${m}:${s},${f}` : `${h}:${m}:${s}.${f}`;
}
function pushOfflineLine({ line, idx, total }) {
  state.offlineLines.push(line);
  redrawHelperStatus?.();
  const host = $("off-lines");
  const div = document.createElement("div");
  div.innerHTML = `<div class="ts">${fmtTs(line.t0)} \u2192 ${fmtTs(line.t1)}</div>`;
  if (line.src) {
    const s = document.createElement("div");
    s.className = "l-src";
    s.textContent = line.src;
    div.appendChild(s);
  }
  const tt = document.createElement("div");
  tt.className = "l-tgt";
  tt.textContent = line.tgt || line.src;
  div.appendChild(tt);
  host.appendChild(div);
  host.scrollTop = host.scrollHeight;
  $("off-progress-text").textContent = `${idx} / ${total}`;
}
function exportLines(kind) {
  const lines = state.offlineLines;
  if (!lines.length) return;
  exportSession({ lines, title: state.offlineFile?.name, url: "", kind });
}
async function exportSession({ lines, title, url, kind, dualLine, srcLang, tgtLang }) {
  const meta = { url: url || "", title: title || "subtitles", dualLine: dualLine ?? state.settings.dualLine };
  const norm2 = (lines || []).map((l) => ({
    t0: l.t0 ?? 0,
    t1: l.t1 ?? l.t0 + 3,
    src: l.src || l.source || "",
    tgt: l.tgt || l.translation || ""
  }));
  let out = "";
  if (kind === "srt") out = formatSrt(norm2, meta);
  else if (kind === "vtt") out = formatVtt(norm2, meta);
  else if (kind === "md") out = formatMarkdown(norm2, { ...meta, dualLine: meta.dualLine });
  else if (kind === "csv") out = formatCsv(norm2, meta);
  else if (kind === "json") out = formatJson(norm2, { ...meta, srcLang: state.srcLang, tgtLang: state.tgtLang });
  else out = formatTxt(norm2, meta);
  const opts = exportOptions();
  out = applyExportOptions(out, opts);
  const name = exportFilename(title || "subtitles", kind, {
    srcLang: srcLang ?? state.srcLang,
    tgtLang: tgtLang ?? (meta.dualLine || state.task === "translate" ? state.tgtLang : ""),
    langSuffix: opts.langSuffix
  });
  try {
    const res = await saveExportFile(name, out);
    const msg = res.saved ? t("savedTo", res.path) : t("downloadedTo", name);
    setStatus2(msg, "ok");
    showToast(msg, "ok");
  } catch (e) {
    const msg = t("exportFailed", String(e?.message || e));
    setStatus2(msg, "error");
    showToast(msg, "error");
  }
}
async function renderHistory() {
  const { history = [] } = await chrome.storage.local.get("history");
  const host = $("history-list");
  host.innerHTML = "";
  if (!history.length) {
    host.innerHTML = `<div class="empty">${t("noHistory")}</div>`;
    return;
  }
  const query = $("history-search")?.value || "";
  const shown = searchSessions(history, query);
  if (!shown.length) {
    host.innerHTML = `<div class="empty">${t("historyNoMatch", query.trim())}</div>`;
    return;
  }
  if (query.trim()) {
    const count = document.createElement("div");
    count.className = "h-meta";
    count.textContent = t("historyMatchCount", shown.length, history.length);
    host.appendChild(count);
  }
  for (const h of shown) {
    const div = document.createElement("div");
    div.className = "h-item";
    const when = new Date(h.ts).toLocaleString();
    const maxT = h.lines?.length ? Math.max(...h.lines.map((l) => l.t1 ?? (l.t ?? 0) / 1e3)) : 0;
    div.innerHTML = `
      <div class="h-title"></div>
      <div class="h-url"></div>
      <div class="h-meta">
        <span>${h.mode === "realtime" ? "\u{1F534}" : "\u{1F4C1}"} ${when}</span>
        <span>${h.srcLang || ""}${h.tgtLang ? " \u2192 " + h.tgtLang : ""}</span>
        <span>${h.lines?.length || 0} ${t("lines")}${maxT ? ` \xB7 ${fmtTs(maxT)}` : ""}</span>
      </div>
      <div class="h-actions">
        <button class="mini-btn h-open" data-i18n="historyOpen">Open</button>
        <button class="mini-btn h-txt">TXT</button>
        <button class="mini-btn h-srt">SRT</button>
        <button class="mini-btn h-vtt">VTT</button>
        <button class="mini-btn h-del">\u{1F5D1}</button>
      </div>`;
    div.querySelector(".h-title").textContent = h.title || "(untitled)";
    const urlEl = div.querySelector(".h-url");
    if (h.url) {
      urlEl.textContent = h.url;
    } else {
      urlEl.remove();
    }
    for (const hit of matchingLines(h, query)) {
      const snip = document.createElement("div");
      snip.className = "h-snippet";
      snip.textContent = `\u201C${hit.tgt || hit.src || ""}\u201D`;
      div.appendChild(snip);
    }
    div.querySelector(".h-open").addEventListener("click", (e) => {
      e.stopPropagation();
      loadHistorySession(h);
    });
    div.querySelector(".h-txt").addEventListener("click", (e) => {
      e.stopPropagation();
      exportHistory(h, "txt");
    });
    div.querySelector(".h-srt").addEventListener("click", (e) => {
      e.stopPropagation();
      exportHistory(h, "srt");
    });
    div.querySelector(".h-vtt").addEventListener("click", (e) => {
      e.stopPropagation();
      exportHistory(h, "vtt");
    });
    div.querySelector(".h-del").addEventListener("click", async (e) => {
      e.stopPropagation();
      await toBG("delete-history", { id: h.id, cacheKey: h.id });
      renderHistory();
    });
    host.appendChild(div);
  }
}
function loadHistorySession(h) {
  const lines = (h?.lines || []).map((l) => ({
    t0: l.t0 ?? (l.t ?? 0) / 1e3,
    t1: l.t1 != null && l.t1 > 1e3 ? l.t1 / 1e3 : l.t1 ?? (l.t ?? 0) / 1e3 + 3,
    src: l.src || l.source || "",
    tgt: l.tgt || l.translation || ""
  }));
  if (!lines.length) {
    setStatus2(t("exportNoSource"), "error");
    return;
  }
  setMode("offline");
  state.offlineLines = [];
  $("off-lines").innerHTML = "";
  $("off-results").classList.remove("hidden");
  for (const line of lines) pushOfflineLine({ line });
  state.offlineFile = { name: h.title || "session" };
  const lastAt = fmtTs(lines[lines.length - 1].t1);
  $("off-progress-text").textContent = `${lines.length} ${t("lines")}`;
  setStatus2(t("historyLoaded", lines.length, lastAt), "ok");
  if (h.url) showToast(t("historyResume", h.url), "ok");
  redrawHelperStatus?.();
}
function exportHistory(h, kind) {
  exportSession({
    lines: h.lines || [],
    title: h.title,
    url: h.url,
    kind,
    srcLang: h.srcLang,
    tgtLang: h.tgtLang
  });
}
async function refreshExportFolderUi() {
  await loadExportDir();
  const label2 = exportDirLabel();
  $("export-folder-label").textContent = label2 ? `${t("exportFolderSet")}: ${label2}` : t("exportFolderNone");
  $("btn-clear-export-folder").classList.toggle("hidden", !label2);
  const dest = $("export-dest-text");
  if (dest) dest.textContent = label2 ? t("exportDestFolder", label2) : t("exportDestDownloads");
  redrawHelperStatus?.();
}
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.target !== "panel") return;
  switch (msg.type) {
    case "state":
      state.running = !!msg.data.active;
      syncCaptureStamp();
      updateButtons();
      if (!state.running && state.mode === "realtime") {
        state.sessionTab = null;
        setStatus2("");
        setStartStep(null);
        refreshTab();
      } else if (state.running && msg.data.tabId != null && state.sessionTab?.id !== msg.data.tabId) {
        rememberSessionTab(msg.data.tabId).then(refreshTab);
      }
      break;
    case "subtitle":
      pushLive(msg.data);
      if (!msg.data?.interim) flashStatusDot();
      break;
    case "perf-sample":
      perfPanel?.push(msg.data);
      break;
    case "pipeline-status": {
      const s = msg.data?.state;
      if (s === "loading") {
        const d = msg.data?.detail;
        setStatus2(d === "asr" ? t("loadingAsr") : d === "translator" ? t("loadingTranslator") : t("loadingModels"));
        setStartStep("models");
      } else if (s === "warmup") {
        setStatus2(t("warmingUp"));
        setStartStep("warmup");
      } else if (s === "listening") {
        setStatus2(`${t("listening")} \u2014 ${activeAsrLabel()} (${msg.data.device || ""})`, "ok");
        setStartStep("listening");
      }
      break;
    }
    case "error":
      showError(msg.data?.message || "Error");
      if (state.mode === "realtime") {
        const li = $("start-steps")?.querySelector("li.current");
        setStartStep(li?.dataset?.step || "models", { failed: true });
      }
      state.running = false;
      syncCaptureStamp();
      updateButtons();
      break;
    case "model-progress":
      onModelProgress(msg.data);
      break;
    case "model-done":
      onModelDone(msg.data);
      break;
    case "model-error":
      dlState.delete(msg.data?.key);
      renderDlList();
      renderModelLists();
      showError(`Model: ${msg.data?.message || "download failed"}`);
      break;
    case "offline-line":
      pushOfflineLine(msg.data);
      break;
    case "offline-progress": {
      const d = msg.data;
      if (d.large) {
        const pct = Math.max(0, Math.min(100, Math.round(d.pct || 0)));
        largeFileJob = {
          name: d.name || state.offlineFile?.name || "",
          sizeBytes: d.sizeBytes || state.offlineFile?.size || 0,
          progress: pct / 100,
          status: d.stage === "cancelling" ? "cancelling" : "running",
          stage: d.stage,
          jobId: d.jobId || largeFileJob?.jobId || null,
          loaded: d.loaded,
          total: d.total,
          idx: d.idx,
          count: d.total && d.idx != null ? d.total : void 0,
          elapsedS: d.elapsedS,
          cancellable: d.stage !== "cancelling"
        };
        const stageLabel = t(`lfStage_${d.stage}`, d.stage);
        setStatus2(`${activeAsrLabel()} \xB7 ${stageLabel} ${pct}%`);
        $("off-progress-text").textContent = d.stage === "upload" && d.total ? `${stageLabel} ${pct}% \xB7 ${fmtBytes(d.loaded || 0)} / ${fmtBytes(d.total)}` : d.total && d.idx != null ? `${stageLabel} \xB7 ${d.idx} / ${d.total}` : `${stageLabel} ${pct}%`;
        redrawHelperStatus?.();
        break;
      }
      if (d.stage === "transcribe" && d.total) {
        setStatus2(`${activeAsrLabel()} \xB7 ${t("processing")} ${d.idx || 0}/${d.total}`);
        $("off-progress-text").textContent = `${activeAsrLabel()} \xB7 ${d.idx || 0} / ${d.total}`;
      } else {
        setStatus2(`${activeAsrLabel()} \xB7 ${t("processing")} (${d.stage})`);
      }
      break;
    }
    case "offline-done":
      state.offlineRunning = false;
      syncCaptureStamp();
      if (largeFileJob) {
        largeFileJob = { ...largeFileJob, progress: 1, status: "done", stage: "done", cancellable: false };
        redrawHelperStatus?.();
      }
      setStatus2(t("done"), "ok");
      updateButtons();
      renderHistory();
      break;
    case "offline-error":
      state.offlineRunning = false;
      syncCaptureStamp();
      if (largeFileJob) {
        largeFileJob = {
          ...largeFileJob,
          status: msg.data?.cancelled ? "cancelled" : "error",
          stage: msg.data?.cancelled ? "cancelled" : "error",
          error: msg.data?.cancelled ? "" : msg.data?.message || "Error",
          cancellable: false
        };
        redrawHelperStatus?.();
      }
      if (msg.data?.cancelled) {
        setStatus2(t("cancelled"));
        hideError();
      } else {
        showError(msg.data?.message || "Error");
      }
      updateButtons();
      break;
    case "history-updated":
      renderHistory();
      break;
    case "cache-resume":
      setStatus2(t("cacheResume", fmtTs(msg.data?.cacheMaxTime || 0), msg.data?.lineCount || 0), "ok");
      break;
  }
});
function wire() {
  mountPills();
  mountPanels();
  window.addEventListener("resize", () => resyncPills(false));
  document.querySelectorAll("#view-tabs button").forEach(
    (b) => b.addEventListener("click", () => setView(b.dataset.view))
  );
  document.querySelectorAll("#density-toggle [data-density-mode]").forEach(
    (b) => b.addEventListener("click", () => applyDensity(b.dataset.densityMode))
  );
  document.querySelectorAll(".bottom-nav-item").forEach(
    (b) => b.addEventListener("click", () => {
      if (b.dataset.view === "settings") {
        openSettings();
      } else {
        setView(b.dataset.view);
      }
      syncBottomNav();
    })
  );
  document.addEventListener("keydown", (e) => {
    if (e.repeat || e.isComposing) return;
    const mod = /^Mac/i.test(navigator.platform || "") ? e.metaKey : e.ctrlKey;
    if (!mod || !e.shiftKey || e.altKey || (e.key || "").toLowerCase() !== "f") return;
    if (state.view !== "notes" || !getCapture().running) return;
    const btn = $("btn-flag-moment");
    if (!btn || btn.disabled) return;
    e.preventDefault();
    btn.click();
  });
  document.querySelectorAll("#mode-toggle button").forEach(
    (b) => b.addEventListener("click", () => setMode(b.dataset.mode))
  );
  document.querySelectorAll("#task-toggle button").forEach(
    (b) => b.addEventListener("click", () => setTask(b.dataset.task))
  );
  document.querySelectorAll("#theme-toggle button").forEach(
    (b) => b.addEventListener("click", () => setTheme(b.dataset.theme))
  );
  document.querySelectorAll("#reskin-toggle button").forEach(
    (b) => b.addEventListener("click", () => setReskin(b.dataset.reskin))
  );
  document.querySelectorAll("#asr-preset-toggle button").forEach(
    (b) => b.addEventListener("click", async () => {
      const key = ASR_PRESETS[b.dataset.preset];
      if (!key || !ASR_MODELS[key]) return;
      state.settings.asrModel = key;
      await saveSettings();
      renderModelLists();
      updateWarning();
    })
  );
  chrome.storage.onChanged?.addListener((changes, area) => {
    if (area && area !== "local") return;
    applyExternalSettings(changes.settings?.newValue);
  });
  $("btn-reskin-reset")?.addEventListener("click", () => setReskin("yraverage"));
  $("src-lang").addEventListener("change", (e) => {
    state.srcLang = e.target.value;
    renderInterpreterUi();
    updateWarning();
    persistLastConfig();
    redrawHelperStatus?.();
  });
  $("tgt-lang").addEventListener("change", (e) => {
    state.tgtLang = e.target.value;
    renderInterpreterUi();
    updateWarning();
    persistLastConfig();
    redrawHelperStatus?.();
  });
  $("btn-interpreter").addEventListener("click", openInterpreterModal);
  $("btn-close-interpreter").addEventListener(
    "click",
    () => $("interpreter-modal").classList.add("hidden")
  );
  $("btn-interp-cancel").addEventListener(
    "click",
    () => $("interpreter-modal").classList.add("hidden")
  );
  $("btn-interp-apply").addEventListener("click", applyInterpreterChoice);
  document.querySelectorAll(".interp-card").forEach((card) => {
    card.addEventListener("click", () => selectInterpreterCard(card.dataset.mode));
    card.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      e.preventDefault();
      selectInterpreterCard(card.dataset.mode);
    });
  });
  $("btn-start").addEventListener("click", onStart);
  $("btn-stop").addEventListener("click", onStop);
  $("btn-pick").addEventListener("click", onPickManually);
  $("btn-error-action").addEventListener("click", onErrorAction);
  $("btn-export-dest-change").addEventListener("click", () => $("btn-settings").click());
  $("btn-goto-session-tab").addEventListener("click", gotoSessionTab);
  const settingsSearch = $("settings-search");
  settingsSearch.addEventListener("input", () => filterSettings(settingsSearch.value));
  settingsSearch.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape" && settingsSearch.value) {
      ev.stopPropagation();
      settingsSearch.value = "";
      filterSettings("");
    }
  });
  $("btn-error-dismiss").addEventListener("click", hideError);
  $("btn-paste-generate")?.addEventListener("click", () => void generateMinutesFromPaste());
  $("history-search")?.addEventListener("input", () => {
    void renderHistory();
  });
  $("btn-srt").addEventListener("click", () => exportLines("srt"));
  $("btn-vtt").addEventListener("click", () => exportLines("vtt"));
  $("btn-txt").addEventListener("click", () => exportLines("txt"));
  $("btn-pick-export-folder").addEventListener("click", async () => {
    try {
      await pickExportDir();
      await refreshExportFolderUi();
    } catch (e) {
      setStatus2(String(e.message || e), "error");
    }
  });
  $("btn-clear-export-folder").addEventListener("click", async () => {
    await clearExportDir();
    await refreshExportFolderUi();
  });
  $("btn-settings").addEventListener("click", () => openSettings());
  $("btn-close-settings").addEventListener("click", () => {
    $("settings-modal").classList.add("hidden");
    stopNativePoll();
    syncBottomNav();
  });
  $("btn-about").addEventListener("click", () => openSettings({ about: true }));
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape" || e.isComposing) return;
    let closed = false;
    if (!$("settings-modal").classList.contains("hidden")) {
      $("settings-modal").classList.add("hidden");
      stopNativePoll();
      closed = true;
    }
    if (!$("interpreter-modal").classList.contains("hidden")) {
      $("interpreter-modal").classList.add("hidden");
      closed = true;
    }
    if (closed) syncBottomNav();
  });
  document.querySelectorAll("#mirror-toggle button").forEach(
    (b) => b.addEventListener("click", async () => {
      state.settings.mirror = b.dataset.mirror;
      await saveSettings();
      await loadSettings();
    })
  );
  document.querySelectorAll("#native-device-toggle button").forEach(
    (b) => b.addEventListener("click", () => setNativeDevice(b.dataset.hdevice))
  );
  document.querySelectorAll("#device-toggle button").forEach(
    (b) => b.addEventListener("click", async () => {
      state.settings.device = b.dataset.device;
      await saveSettings();
      await loadSettings();
      updateWarning();
    })
  );
  $("native-url").addEventListener("change", async (e) => {
    state.settings.nativeUrl = e.target.value.trim() || DEFAULT_NATIVE_URL;
    await saveSettings();
    checkNative();
  });
  $("btn-native-check").addEventListener("click", checkNative);
  $("btn-native-start").addEventListener("click", () => nativeControl("start"));
  $("btn-native-stop").addEventListener("click", () => nativeControl("stop"));
  $("btn-native-restart").addEventListener("click", () => nativeControl("restart"));
  $("dual-line-main").addEventListener("change", (e) => setDualLine(e.target.checked));
  $("dual-line").addEventListener("change", (e) => setDualLine(e.target.checked));
  $("refine-main").addEventListener("change", (e) => setRefineTranslation(e.target.checked));
  $("refine").addEventListener("change", (e) => setRefineTranslation(e.target.checked));
  $("font-size").addEventListener("change", async (e) => {
    state.settings.overlayFontSize = Number(e.target.value);
    await saveSettings();
  });
  wireDropzone();
  $("btn-qa-run")?.addEventListener("click", async () => {
    const id3 = $("qa-sample-select")?.value;
    const sample = state.qaCatalog?.samples?.find((s) => s.id === id3);
    await runQaSample(sample, { autoStart: true });
  });
  chrome.tabs.onActivated.addListener(refreshTab);
  chrome.tabs.onUpdated.addListener((id3, info) => {
    if (info.status === "complete" || info.title) refreshTab();
  });
}
function populateMockData() {
  const mockHistory = [
    {
      id: "mock-1",
      ts: Date.now() - 36e5,
      mode: "realtime",
      title: "Team Standup Meeting",
      url: "https://meet.google.com/abc-defg-hij",
      srcLang: "en",
      tgtLang: "id",
      lines: [
        { t0: 0, t1: 5.2, src: "Good morning everyone", tgt: "Selamat pagi semuanya" },
        { t0: 5.2, t1: 12.8, src: "Let me share the updates from yesterday", tgt: "Izinkan saya berbagi update kemarin" },
        { t0: 12.8, t1: 20.1, src: "We completed the API integration", tgt: "Kami sudah selesaikan integrasi API" }
      ]
    },
    {
      id: "mock-2",
      ts: Date.now() - 72e5,
      mode: "offline",
      title: "Product Demo Recording",
      url: "",
      srcLang: "zh",
      tgtLang: "en",
      lines: [
        { t0: 0, t1: 3.5, src: "\u3053\u3093\u306B\u3061\u306F\u3001\u7686\u3055\u3093", tgt: "Hello everyone" },
        { t0: 3.5, t1: 9.2, src: "\u4ECA\u65E5\u306F\u65B0\u3057\u3044\u6A5F\u80FD\u3092\u7D39\u4ECB\u3057\u307E\u3059", tgt: "Today I'll introduce new features" }
      ]
    },
    {
      id: "mock-3",
      ts: Date.now() - 108e5,
      mode: "realtime",
      title: "Client Call - Project Review",
      url: "https://zoom.us/j/123456789",
      srcLang: "id",
      tgtLang: "en",
      lines: [
        { t0: 0, t1: 4.1, src: "Terima kasih sudah bergabung", tgt: "Thank you for joining" },
        { t0: 4.1, t1: 11.3, src: "Proyek ini sudah 80 persen selesai", tgt: "This project is 80 percent complete" }
      ]
    }
  ];
  chrome.storage.local.get("history", (result) => {
    if (!result.history || result.history.length === 0) {
      chrome.storage.local.set({ history: mockHistory });
    }
  });
  const mockLiveLines = [
    { src: "This is a sample transcription", tgt: "Ini adalah contoh transkripsi" },
    { src: "The system is working correctly", tgt: "Sistem berfungsi dengan benar" },
    { src: "Real-time translation is active", tgt: "Terjemahan real-time sedang aktif" }
  ];
  setTimeout(() => {
    if (!state.running && !state.offlineRunning) {
      const srcHost = $("live-src-lines");
      const tgtHost = $("live-tgt-lines");
      if (srcHost && tgtHost && srcHost.children.length === 0 && tgtHost.children.length === 0) {
        mockLiveLines.forEach((line, i) => {
          setTimeout(() => {
            appendLiveLine(srcHost, line.src);
            appendLiveLine(tgtHost, line.tgt);
          }, i * 400);
        });
      }
    }
  }, 800);
}
async function init() {
  await loadSettings();
  wire();
  applyI18n();
  const uiPrefs = await restoreUiPrefs();
  resyncPills(false);
  fillSelects();
  setView("captions");
  await restoreDensity();
  state.qaCatalog = await loadSampleCatalog();
  renderQaSampleBar();
  setMode(uiPrefs.mode);
  setTask(uiPrefs.task);
  await refreshDownloaded();
  renderModelLists();
  populateMockData();
  await renderHistory();
  updateWarning();
  if (state.settings.engine === "native" || state.mode === "offline") {
    await checkNative({ allowAutoStart: true });
    updateNativeHostHint();
    await pullUiPrefs();
  }
  await refreshTab();
  await refreshExportFolderUi();
  const notesMount = $("notes-mount");
  if (notesMount) {
    await mountNotesPanel(notesMount, notesMountOptions());
    notesMount.dataset.mounted = "1";
    const notesBody = $("notes-body");
    if (notesBody && !notesBody.dataset.resizable) {
      notesBody.dataset.resizable = "1";
      await makeResizable(notesBody, {
        storageKey: "notesPanelSize",
        min: 180,
        max: 1400,
        label: t("notesResize")
      });
    }
  }
  const helperMount = $("helper-status-mount");
  if (helperMount) {
    perfPanel = mountPerfPanel($("view-perf"), {
      lang: () => state.settings.uiLang === "id" ? "id" : "en",
      toast: (m) => showToast(m, "ok")
    });
    document.querySelectorAll("#captions-subtabs [data-subview]").forEach(
      (b) => b.addEventListener("click", () => setSubview(b.dataset.subview))
    );
    initCollapsibles();
    try {
      if (localStorage.getItem("captionsSubview") === "perf") setSubview("perf");
    } catch {
    }
    redrawHelperStatus = mountHelperStatusCard(helperMount, () => ({
      online: !!nativeInfo,
      health: nativeInfo,
      engine: state.settings.engine || "browser",
      task: state.task,
      mode: state.mode,
      lang: state.settings.uiLang || "en",
      largeFile: largeFileJob,
      exportOptions: exportOptions(),
      exportSource: currentExportSource(),
      exportFolder: exportDirLabel(),
      onExportOptionChange: updateExportOptions,
      onExport: (kind) => {
        const source = currentExportSource();
        if (source) void exportSession({ ...source, kind });
      },
      onCancelLargeFile: () => {
        if (largeFileJob && largeFileJob.status === "running") {
          largeFileJob = { ...largeFileJob, status: "cancelling", stage: "cancelling", cancellable: false };
          redrawHelperStatus?.();
        }
        toOffscreen("offline-cancel", {});
      }
    }));
  }
  const guideMount = $("helper-guide-mount");
  if (guideMount) {
    redrawHelperGuide = mountHelperGuide(guideMount, () => ({
      lang: state.settings.uiLang || "en",
      health: nativeInfo,
      engine: state.settings.engine || "browser",
      nativeHostSupported: nativeHostSupported(),
      hostInstalled: nativeHostInstalled,
      hostConnection: nativeHostConn,
      onRecheck: () => {
        probeNativeHost();
        return checkNative({ allowAutoStart: false });
      }
    }));
    probeNativeHost();
  }
  const s = await toBG("get-state", {});
  if (s?.active) {
    state.running = true;
    syncCaptureStamp();
    if (s.config) {
      state.srcLang = s.config.srcLang;
      state.tgtLang = s.config.tgtLang;
      state.settings.dualLine = s.config.dualLine ?? state.settings.dualLine;
      state.settings.refineTranslation = s.config.refineTranslation ?? state.settings.refineTranslation;
      $("src-lang").value = state.srcLang;
      $("tgt-lang").value = state.tgtLang;
      syncDualLineCheckboxes();
      syncRefineCheckboxes();
    }
    $("live-preview").classList.remove("hidden");
    setStatus2(`${t("listening")} \u2014 ${activeAsrLabel()}`, "ok");
    updateButtons();
  }
  await toBG("ensure-offscreen", {});
}
init();
