var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/lib/notes-schema.js
function rnd() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID().slice(0, 8);
  return Math.random().toString(36).slice(2, 10);
}
function toTimecode(sec) {
  const s = Math.max(0, Math.floor(num(sec, 0)));
  const h = String(Math.floor(s / 3600)).padStart(2, "0");
  const m = String(Math.floor(s % 3600 / 60)).padStart(2, "0");
  const r = String(s % 60).padStart(2, "0");
  return `${h}:${m}:${r}`;
}
function normalizeText(value, locale = "en") {
  if (value == null) return {};
  if (typeof value === "string") return value.trim() ? { [locale]: value.trim() } : {};
  const out = {};
  for (const [k, v] of Object.entries(value)) {
    const t = str(v).trim();
    if (t) out[k] = t;
  }
  return out;
}
function pickText(text, lang, fallbackLocale = "en") {
  if (!text) return "";
  return text[lang] || text[fallbackLocale] || text.en || Object.values(text)[0] || "";
}
function createProvenance(partial) {
  if (!partial) return null;
  const t0 = num(partial.t0, 0);
  return {
    t0,
    t1: num(partial.t1, t0),
    tc: partial.tc ? str(partial.tc) : toTimecode(t0),
    speaker: strOrNull(partial.speaker),
    lang: str(partial.lang || "auto"),
    orig: str(partial.orig),
    tr: str(partial.tr),
    segmentIds: Array.isArray(partial.segmentIds) ? partial.segmentIds.map(String) : [],
    meetingId: strOrNull(partial.meetingId)
  };
}
function createMetric(partial) {
  if (!partial) return null;
  const value = num(partial.value, NaN);
  if (!Number.isFinite(value)) return null;
  const baseline = partial.baseline == null ? null : num(partial.baseline, NaN);
  const hasBaseline = baseline != null && Number.isFinite(baseline);
  return {
    measure: str(partial.measure || "unnamed"),
    value,
    baseline: hasBaseline ? baseline : null,
    variance: partial.variance != null && Number.isFinite(Number(partial.variance)) ? Number(partial.variance) : hasBaseline ? Number((value - baseline).toFixed(6)) : null,
    unit: str(partial.unit || ""),
    asOf: strOrNull(partial.asOf),
    sourceDoc: strOrNull(partial.sourceDoc)
  };
}
function createCorrection(partial) {
  if (!partial || typeof partial !== "object") return null;
  const from = str(partial.from).trim();
  const to = str(partial.to).trim();
  if (!from || !to || from === to) return null;
  return { from, to, origPhrase: strOrNull(partial.origPhrase) };
}
function createMinuteItem(partial = {}, { locale = "en" } = {}) {
  const type = oneOf(partial.type, ITEM_TYPES, "info");
  return {
    ref: str(partial.ref || `TMP-${rnd()}`),
    type,
    topic: str(partial.topic || "general"),
    agenda: strOrNull(partial.agenda),
    text: normalizeText(partial.text, locale),
    owner: strOrNull(partial.owner),
    org: strOrNull(partial.org),
    due: strOrNull(partial.due),
    status: oneOf(partial.status, ITEM_STATUSES, type === "info" ? "closed" : "open"),
    priority: oneOf(partial.priority, ["high", "med", "low"], "med"),
    likelihood: oneOf(partial.likelihood, LIKELIHOODS, "possible"),
    review: oneOf(partial.review, REVIEW_STATES, "ai"),
    confidence: Math.min(1, Math.max(0, num(partial.confidence, 1))),
    src: createProvenance(partial.src),
    metric: type === "metric" ? createMetric(partial.metric) : null,
    correction: createCorrection(partial.correction),
    carriedFrom: strOrNull(partial.carriedFrom),
    openedAt: strOrNull(partial.openedAt),
    links: Array.isArray(partial.links) ? partial.links.map(String) : [],
    history: Array.isArray(partial.history) ? partial.history.map(createRevision) : []
  };
}
function createRevision(partial = {}) {
  return {
    at: str(partial.at || (/* @__PURE__ */ new Date()).toISOString()),
    by: str(partial.by || "local"),
    field: str(partial.field || ""),
    from: partial.from ?? null,
    to: partial.to ?? null
  };
}
function createMeeting(partial = {}) {
  const locale = str(partial.locale || "en");
  const date = str(partial.date || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
  return {
    id: str(partial.id || `MOM-${rnd()}`),
    seriesId: str(partial.seriesId || "default"),
    seq: num(partial.seq, 1),
    title: str(partial.title || "Untitled meeting").trim(),
    date,
    start: strOrNull(partial.start),
    end: strOrNull(partial.end),
    tz: str(partial.tz || "local"),
    chair: strOrNull(partial.chair),
    attendees: (Array.isArray(partial.attendees) ? partial.attendees : []).map((a) => ({
      name: str(a?.name),
      org: strOrNull(a?.org),
      speakerLabel: strOrNull(a?.speakerLabel)
    })).filter((a) => a.name),
    agenda: (Array.isArray(partial.agenda) ? partial.agenda : []).map((a) => ({
      ref: str(a?.ref),
      title: normalizeText(a?.title, locale),
      covered: !!a?.covered
    })).filter((a) => a.ref),
    topics: partial.topics && typeof partial.topics === "object" ? partial.topics : {},
    summary: normalizeText(partial.summary, locale),
    items: (Array.isArray(partial.items) ? partial.items : []).map(
      (i) => createMinuteItem(i, { locale })
    ),
    engine: partial.engine ? {
      asr: str(partial.engine.asr),
      mt: strOrNull(partial.engine.mt),
      extractor: strOrNull(partial.engine.extractor),
      segments: num(partial.engine.segments, 0),
      durationSec: partial.engine.durationSec == null ? null : num(partial.engine.durationSec, 0)
    } : null,
    generatedAt: str(partial.generatedAt || (/* @__PURE__ */ new Date()).toISOString()),
    issuedAt: strOrNull(partial.issuedAt),
    locale,
    schemaVersion: NOTE_SCHEMA_VERSION
  };
}
function nextRef(meeting, prefix) {
  const p = prefix || `W${String(meeting.seq).padStart(2, "0")}`;
  let max = 0;
  for (const it of meeting.items) {
    const m = /^(.+)-(\d+)$/.exec(it.ref);
    if (m && m[1] === p) max = Math.max(max, Number(m[2]));
  }
  return `${p}-${String(max + 1).padStart(3, "0")}`;
}
function assertMeeting(meeting) {
  if (!meeting || typeof meeting !== "object") throw new Error("meeting harus objek");
  const m = (
    /** @type {Record<string, unknown>} */
    meeting
  );
  if (typeof m.id !== "string" || !m.id) throw new Error("meeting.id wajib string");
  if (typeof m.seriesId !== "string" || !m.seriesId) throw new Error("meeting.seriesId wajib");
  if (!Array.isArray(m.items)) throw new Error("meeting.items wajib array");
  for (const it of m.items) {
    if (!it || typeof it !== "object") throw new Error("item invalid");
    const i = (
      /** @type {Record<string, unknown>} */
      it
    );
    if (typeof i.ref !== "string" || !i.ref) throw new Error("item.ref wajib");
    if (!ITEM_TYPES.includes(
      /** @type {any} */
      i.type
    )) {
      throw new Error(`item.type tidak dikenal: ${String(i.type)}`);
    }
    if (!i.text || typeof i.text !== "object") throw new Error(`item ${i.ref}: text wajib objek`);
  }
  return createMeeting(m);
}
function wrapMeetingStore(meetings) {
  return {
    schemaVersion: NOTE_SCHEMA_VERSION,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    meetings: meetings.map((m) => assertMeeting(m))
  };
}
function meetingStats(meeting, today2 = /* @__PURE__ */ new Date()) {
  const items = meeting.items || [];
  const actions = items.filter((i) => i.type === "action");
  const isOpen = (i) => i.status !== "closed";
  const daysTo2 = (iso) => iso ? Math.round((/* @__PURE__ */ new Date(`${iso}T00:00:00Z`) - startOfDayUTC(today2)) / 864e5) : null;
  const overdue = items.filter((i) => isOpen(i) && i.due && daysTo2(i.due) < 0);
  const covered = (meeting.agenda || []).filter((a) => a.covered).length;
  const agendaTotal = (meeting.agenda || []).length;
  const progress = items.find(
    (i) => i.type === "metric" && i.metric && i.metric.measure === "cumulative_progress"
  );
  return {
    total: items.length,
    actionsOpen: actions.filter(isOpen).length,
    actionsTotal: actions.length,
    overdue: overdue.length,
    decisions: items.filter((i) => i.type === "decision").length,
    questionsOpen: items.filter((i) => i.type === "question" && isOpen(i)).length,
    unreviewed: items.filter((i) => i.review === "ai").length,
    lowConfidence: items.filter((i) => i.confidence < LOW_CONFIDENCE).length,
    carried: items.filter((i) => i.carriedFrom).length,
    agendaCovered: covered,
    agendaTotal,
    agendaPct: agendaTotal ? Math.round(covered / agendaTotal * 100) : 0,
    variance: progress?.metric?.variance ?? null,
    varianceUnit: progress?.metric?.unit ?? ""
  };
}
function startOfDayUTC(d) {
  const x = new Date(d);
  return new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), x.getUTCDate()));
}
function itemAgeDays(item, today2 = /* @__PURE__ */ new Date()) {
  if (!item.openedAt) return null;
  return Math.round((startOfDayUTC(today2) - /* @__PURE__ */ new Date(`${item.openedAt}T00:00:00Z`)) / 864e5);
}
var NOTE_SCHEMA_VERSION, ITEM_TYPES, ITEM_STATUSES, REVIEW_STATES, LIKELIHOODS, TYPE_COLOR, LOW_CONFIDENCE, oneOf, str, strOrNull, num;
var init_notes_schema = __esm({
  "src/lib/notes-schema.js"() {
    NOTE_SCHEMA_VERSION = 2;
    ITEM_TYPES = /** @type {const} */
    [
      "decision",
      "action",
      "question",
      "risk",
      "metric",
      "info"
    ];
    ITEM_STATUSES = /** @type {const} */
    ["open", "progress", "closed", "carried"];
    REVIEW_STATES = /** @type {const} */
    ["ai", "accepted", "edited"];
    LIKELIHOODS = /** @type {const} */
    ["certain", "likely", "possible", "unlikely"];
    TYPE_COLOR = {
      decision: "#7fb3d5",
      action: "#e0b05c",
      question: "#b79ce0",
      risk: "#e06c75",
      metric: "#4fb8c9",
      info: "#9a9a9a"
    };
    LOW_CONFIDENCE = 0.7;
    oneOf = (v, list, fallback) => list.includes(v) ? v : fallback;
    str = (v) => v == null ? "" : String(v);
    strOrNull = (v) => v == null || v === "" ? null : String(v);
    num = (v, d = 0) => Number.isFinite(Number(v)) ? Number(v) : d;
  }
});

// src/lib/notes-migrate.js
function migrateNoteV1(v1) {
  const locale = String(v1?.locale || "id");
  const date = String(v1?.generatedAt || (/* @__PURE__ */ new Date()).toISOString()).slice(0, 10);
  const seq = 1;
  const prefix = "V1";
  const items = [];
  let n = 0;
  const ref = () => `${prefix}-${String(++n).padStart(3, "0")}`;
  if (v1?.summary) {
    items.push(
      createMinuteItem(
        {
          ref: ref(),
          type: "info",
          topic: "summary",
          text: { [locale]: String(v1.summary) },
          status: "closed",
          review: "ai",
          confidence: 0,
          src: NO_SOURCE
        },
        { locale }
      )
    );
  }
  for (const d of Array.isArray(v1?.decisions) ? v1.decisions : []) {
    if (!String(d || "").trim()) continue;
    items.push(
      createMinuteItem(
        {
          ref: ref(),
          type: "decision",
          topic: "general",
          text: { [locale]: String(d) },
          status: "closed",
          review: "ai",
          confidence: 0,
          src: NO_SOURCE
        },
        { locale }
      )
    );
  }
  for (const a of Array.isArray(v1?.actions) ? v1.actions : []) {
    if (!a || !String(a.text || "").trim()) continue;
    items.push(
      createMinuteItem(
        {
          ref: ref(),
          type: "action",
          topic: "general",
          text: { [locale]: String(a.text) },
          owner: a.owner ?? null,
          due: a.due ?? null,
          status: a.status === "done" ? "closed" : "open",
          openedAt: date,
          review: "ai",
          confidence: 0,
          src: NO_SOURCE
        },
        { locale }
      )
    );
  }
  const meeting = createMeeting({
    id: String(v1?.id || `MOM-${date}`),
    seriesId: "imported-v1",
    seq,
    title: String(v1?.title || "Imported meeting"),
    date,
    generatedAt: v1?.generatedAt,
    locale,
    items,
    topics: {
      summary: { en: "Summary", id: "Ringkasan" },
      general: { en: "General", id: "Umum" }
    }
  });
  meeting.legacyPreview = String(v1?.transcriptPreview || "");
  meeting.legacySource = String(v1?.source || "");
  return meeting;
}
function migrateStore(raw) {
  if (!raw || typeof raw !== "object") {
    return { schemaVersion: NOTE_SCHEMA_VERSION, updatedAt: null, meetings: [], migrated: 0 };
  }
  if (Number(raw.schemaVersion) >= NOTE_SCHEMA_VERSION && Array.isArray(raw.meetings)) {
    return {
      schemaVersion: NOTE_SCHEMA_VERSION,
      updatedAt: raw.updatedAt ?? null,
      meetings: raw.meetings,
      migrated: 0
    };
  }
  const legacy = Array.isArray(raw.notes) ? raw.notes : [];
  const meetings = legacy.map((n) => migrateNoteV1(n));
  return {
    schemaVersion: NOTE_SCHEMA_VERSION,
    updatedAt: raw.updatedAt ?? null,
    meetings,
    migrated: meetings.length
  };
}
var NO_SOURCE;
var init_notes_migrate = __esm({
  "src/lib/notes-migrate.js"() {
    init_notes_schema();
    NO_SOURCE = null;
  }
});

// src/lib/notes-store.js
var notes_store_exports = {};
__export(notes_store_exports, {
  __resetForTests: () => __resetForTests,
  backendName: () => backendName,
  deleteMeeting: () => deleteMeeting,
  getMeeting: () => getMeeting,
  listMeetings: () => listMeetings,
  listOpenItems: () => listOpenItems,
  listSeries: () => listSeries,
  saveMeeting: () => saveMeeting,
  searchItems: () => searchItems,
  setBackend: () => setBackend
});
function detectBackend() {
  if (typeof chrome !== "undefined" && chrome?.storage?.local) return chromeBackend;
  if (typeof localStorage !== "undefined") return localBackend;
  return memoryBackend;
}
function setBackend(next) {
  const prev = backend;
  backend = next || detectBackend();
  return prev;
}
function backendName() {
  return backend.name;
}
async function readStore() {
  let raw = await backend.get(KEY);
  let fromLegacy = false;
  if (!raw) {
    const legacy = await backend.get(LEGACY_KEY);
    if (legacy) {
      raw = legacy;
      fromLegacy = true;
    }
  }
  const upgraded = migrateStore(raw);
  if (upgraded.migrated > 0 || fromLegacy) {
    await backend.set(KEY, wrapMeetingStore(upgraded.meetings.map((m) => createMeeting(m))));
  }
  return upgraded;
}
async function writeStore(meetings) {
  const env = wrapMeetingStore(meetings.slice(0, MAX_MEETINGS));
  await backend.set(KEY, env);
  return env;
}
async function listMeetings() {
  const { meetings } = await readStore();
  return meetings.map((m) => createMeeting(m)).sort((a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : b.seq - a.seq);
}
async function getMeeting(id2) {
  const all = await listMeetings();
  return all.find((m) => m.id === id2) || null;
}
async function saveMeeting(partial) {
  const meeting = assertMeeting(createMeeting(partial));
  const prev = await listMeetings();
  const next = [meeting, ...prev.filter((m) => m.id !== meeting.id)];
  await writeStore(next);
  return meeting;
}
async function deleteMeeting(id2) {
  const prev = await listMeetings();
  const next = prev.filter((m) => m.id !== id2);
  await writeStore(next);
  return next.length;
}
async function listSeries(seriesId) {
  const all = await listMeetings();
  return all.filter((m) => m.seriesId === seriesId).sort((a, b) => a.seq - b.seq);
}
async function listOpenItems(seriesId) {
  const meetings = await listSeries(seriesId);
  const rows = [];
  for (const meeting of meetings) {
    for (const item of meeting.items) {
      if (item.status === "closed") continue;
      if (item.type === "info" || item.type === "metric") continue;
      rows.push({ item, meeting });
    }
  }
  return rows;
}
async function searchItems(query, { seriesId = null } = {}) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return [];
  const meetings = seriesId ? await listSeries(seriesId) : await listMeetings();
  const hits = [];
  for (const meeting of meetings) {
    for (const item of meeting.items) {
      const hay = [
        item.ref,
        item.owner || "",
        ...Object.values(item.text || {}),
        item.src?.orig || "",
        item.src?.tr || "",
        item.src?.speaker || ""
      ].join(" ").toLowerCase();
      if (hay.includes(q)) hits.push({ item, meeting });
    }
  }
  return hits;
}
async function __resetForTests() {
  memory.clear();
  await backend.set(KEY, null);
}
var KEY, LEGACY_KEY, MAX_MEETINGS, memory, memoryBackend, chromeBackend, localBackend, backend;
var init_notes_store = __esm({
  "src/lib/notes-store.js"() {
    init_notes_schema();
    init_notes_migrate();
    KEY = "minutesRegister";
    LEGACY_KEY = "meetingNotes";
    MAX_MEETINGS = 500;
    memory = /* @__PURE__ */ new Map();
    memoryBackend = {
      name: "memory",
      async get(key) {
        return memory.get(key) ?? null;
      },
      async set(key, value) {
        memory.set(key, value);
      }
    };
    chromeBackend = {
      name: "chrome.storage.local",
      async get(key) {
        const out = await chrome.storage.local.get(key);
        return out?.[key] ?? null;
      },
      async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
      }
    };
    localBackend = {
      name: "localStorage",
      async get(key) {
        try {
          const raw = localStorage.getItem(key);
          return raw ? JSON.parse(raw) : null;
        } catch {
          return null;
        }
      },
      async set(key, value) {
        try {
          localStorage.setItem(key, JSON.stringify(value));
        } catch {
          memory.set(key, value);
        }
      }
    };
    backend = detectBackend();
  }
});

// src/minutes.js
init_notes_schema();

// src/lib/notes-i18n.js
var en = {
  /* chrome */
  minutes: "Minutes",
  register: "Minutes register",
  openRegister: "Open minutes register",
  registerHint: "The register opens in a full tab \u2014 a table does not belong in a 400px rail.",
  onDevice: "On-device",
  export: "Export",
  issue: "Issue MoM",
  issued: "Issued",
  startNext: "Start next meeting",
  exportStanding: "Export standing register",
  /* meeting facts */
  date: "Date",
  time: "Time",
  chair: "Chair",
  present: "Present",
  mom: "MoM",
  series: "Series",
  nth: (n) => `meeting ${n}`,
  cadence: "Cadence",
  span: "Span",
  meetings: "Meetings",
  next: "Next",
  preparedBy: "Prepared by",
  distribution: "Distribution",
  /* provenance band */
  draftedOnDevice: "Drafted on this Mac",
  pipeline: (asr, seg, items) => `${asr} \u2192 ${seg} segments \u2192 ${items} register items`,
  needReview: "need review",
  lowConfFlag: "low-confidence flag",
  nothingLeft: "No audio, transcript or text left this device.",
  noSource: "No source \u2014 imported from v1",
  /* views */
  vRegister: "Register",
  vTopic: "By topic",
  vDoc: "Minutes",
  vCarry: "Carry-forward",
  vSeries: "Series",
  /* columns */
  cRef: "Ref",
  cType: "Type",
  cTopic: "Topic",
  cItem: "Item",
  cOwner: "Owner",
  cDue: "Due",
  cStatus: "Status",
  cSource: "Source",
  cAge: "Age",
  cRaised: "Raised",
  /* types */
  decision: "Decision",
  action: "Action",
  question: "Open question",
  risk: "Risk",
  metric: "Metric",
  info: "Note",
  /* statuses */
  open: "Open",
  progress: "In progress",
  closed: "Closed",
  carried: "Carried",
  /* review states */
  ai: "AI draft",
  accepted: "Accepted",
  edited: "Edited",
  /* stats */
  sItems: "Register items",
  sActions: "Actions open",
  sOverdue: "Overdue",
  sDecisions: "Decisions",
  sQuestions: "Open questions",
  sUnreviewed: "Unreviewed",
  sCoverage: "Agenda covered",
  sVariance: "Progress vs baseline",
  sMeanAge: "Mean age, open",
  sOldest: "Oldest open item",
  /* fields / drawer */
  dText: "Item text",
  dOwner: "Owner",
  dDue: "Due date",
  dStatus: "Status",
  dTopic: "Topic",
  dAgenda: "Agenda ref",
  dProvenance: "Where this came from",
  dLinked: "Linked in this register",
  dHistory: "History",
  asSpoken: "As spoken",
  machineTranslation: "Machine translation",
  citedSpan: "cited span",
  lowConfWords: "low-confidence words",
  /* actions */
  accept: "Accept",
  saveEdit: "Save edit",
  discard: "Discard",
  playFrom: "Play from here",
  addItem: "Add item",
  carryIn: "Carry in",
  close: "Close",
  applyCorrection: "Apply correction",
  keepAsHeard: "Keep as heard",
  addToGlossary: "Add to glossary",
  /* toolbar */
  search: "Search items, owners, quotes\u2026",
  mine: "Mine",
  dual: "Dual text",
  groupBy: "Group",
  groupNone: "none",
  needsReviewOnly: "Needs review only",
  showing: (n, total) => `Showing ${n} of ${total}`,
  /* low confidence banner */
  asrUnsure: (pct2) => `Speech recognition was unsure here \u2014 ${pct2}%`,
  extractorWrote: "The extractor wrote",
  audioSays: "The audio says",
  /* carry-forward */
  carryIntro: "Open items inherited from the previous meeting. Anything still open is re-numbered into this register and keeps its original age.",
  openFor: "open for",
  days: "d",
  today: "today",
  overdue: "overdue",
  dueIn: "in",
  noOwner: "Unassigned",
  noDue: "No date",
  noneYet: "Nothing here yet",
  raisedAgain: "Raised again this week",
  consecutive: (n) => `open question in ${n} consecutive meetings`,
  /* doc view */
  docSummary: "Summary",
  docDecisions: "Decisions",
  docActions: "Action register",
  docQuestions: "Open questions",
  docRisks: "Risks",
  docMetrics: "Progress",
  docNotes: "Discussion notes",
  /* messages */
  msgAccepted: "Item accepted \u2014 locked into the MoM",
  msgCarried: "Carried into this register",
  msgIssued: "MoM issued",
  msgBlocked: (n) => `${n} items still need review \u2014 issue anyway?`,
  msgIssuedFrozen: "This MoM is issued and read-only. Create an amendment to correct it.",
  msgMigrated: (n) => `${n} meeting(s) upgraded from the old notes format`,
  msgItemAdded: "Item added to the register",
  msgAmended: (id2) => `Amendment created \u2014 ${id2}`,
  msgSeeking: "Seeking transcript to",
  msgEmpty: "No items match the current filters.",
  msgNoMeeting: "No meeting selected.",
  /* app bar / header (design canvas: Main artboard) */
  presentN: (n) => `${n}`,
  seriesNth: (n) => `meeting ${n}`,
  lowAsr: "Low ASR confidence",
  aiDraftPct: (pct2) => `AI draft \xB7 ${pct2}%`,
  reported: "reported",
  ahead: "ahead",
  behind: "behind",
  vsBaseline: "baseline",
  /* footer */
  kbdMove: "move",
  kbdAccept: "accept",
  kbdOwner: "owner",
  kbdDate: "date",
  kbdSearch: "search",
  kbdClose: "close",
  lastSaved: (t, backend2) => `Last saved ${t} \xB7 ${backend2}`,
  notSavedYet: (backend2) => `Not saved yet \xB7 ${backend2}`,
  /* drawer (Provenance artboard) */
  agendaRef: (a) => `agenda ${a}`,
  translationHint: (other) => `${other} text is kept separately \u2014 switch language to edit it`,
  dPriority: "Priority",
  prHigh: "High",
  prMed: "Medium",
  prLow: "Low",
  dSevLik: "Severity \xD7 likelihood",
  lkCertain: "Certain",
  lkLikely: "Likely",
  lkPossible: "Possible",
  lkUnlikely: "Unlikely",
  segRange: (a, b) => a === b ? `seg ${a}` : `seg ${a}\u2013${b}`,
  asr: "ASR",
  correctionApplied: "Correction applied \u2014 item marked as edited",
  keptAsHeard: "Kept as heard \u2014 item accepted",
  glossaryAdded: (t) => `\u201C${t}\u201D added to the local glossary`,
  extractedBy: (by) => `created by ${by}`,
  flaggedLow: (pct2) => `flagged low confidence \xB7 ${pct2}% < 70%`,
  /* metric detail (Progress artboard) */
  mActual: "Actual",
  mBaseline: "Baseline",
  mVariance: "Variance",
  mAhead: "ahead of baseline",
  mBehind: "behind baseline",
  mOnBaseline: "on baseline",
  mChart: "Cumulative progress against baseline",
  mChartNote: "Only figures stated in this series are plotted \u2014 nothing is interpolated",
  mWhereFrom: "Where the figure came from",
  mAheadNotSafe: "Ahead, but not safe",
  mAheadNotSafeBody: (n) => `${n} open risk item(s) share this agenda line \u2014 read them together.`,
  mSingle: "One data point so far \u2014 the curve starts next meeting",
  mTypedNote: "Three numbers were extracted from one sentence and typed as a measure, not prose \u2014 so next week's figure lands on the same axis instead of in a new paragraph.",
  /* series (Series artboard) */
  seriesLabel: "Meeting series",
  standingRegister: "Standing action register",
  openAcross: (n, m) => `${n} open across ${m} meeting(s)`,
  sortedByAge: "Sorted by age \u2014 the number that goes on the progress report",
  flowTitle: "Items opened and closed, per meeting",
  flowNote: (up, total, net) => `Opened outpaced closed in ${up} of ${total} meeting(s) \u2014 net ${net >= 0 ? "+" : ""}${net} over the series.`,
  opened: "Opened",
  byParty: "Open items by party",
  showAll: "Show all",
  showLess: "Show less",
  moreOpen: (n) => `+ ${n} more open item(s)`,
  raisedAgainBody: (text, n) => `\u201C${text}\u201D has been open in ${n} consecutive meetings without an owner. Assign it or close it.`,
  raisedAgainOwned: (text, n, owner) => `\u201C${text}\u201D has been carried through ${n} consecutive meetings (owner: ${owner}). Close it or re-plan it.`,
  raisedAgainNone: "Nothing has been carried more than once \u2014 the register is clean.",
  startW: (n) => `Start W${n}`,
  nOpen: (n) => `${n} open`,
  cadenceWeekly: "Weekly",
  cadenceBiweekly: "Every two weeks",
  cadenceDays: (d) => `Every ${d} days`,
  cadenceNA: "\u2014",
  consecutivePill: (n) => `raised in ${n} consecutive meetings`,
  /* issued document (MoM artboard) */
  momTitle: "MINUTES OF MEETING",
  rev: "Rev",
  draftWatermark: "DRAFT \u2014 not yet issued",
  docMeeting: "Meeting",
  docProject: "Project",
  docNo: (n) => `no. ${n}`,
  docAccountable: "Accountable",
  docReferredTo: "Referred to",
  docBy: "By",
  docAction: "Action",
  docQuestion: "Question",
  docRisk: "Risk",
  docDecision: "Decision",
  docCarriedFrom: (id2, d) => `Carried from ${id2}, open ${d} days.`,
  docFootAi: (n) => `${n} item(s) marked \u2021 were drafted by on-device speech recognition and accepted without amendment by the minute-taker.`,
  docFootAllReviewed: "Every item was reviewed by a human before issue.",
  docFootCorrected: (ref, from, to, tc) => `${ref} was corrected against the recording before issue: \u201C${from}\u201D \u2192 \u201C${to}\u201D, verified at ${tc}.`,
  docFootEngine: (asr, seg) => `Transcribed and drafted on the minute-taker's own machine \u2014 ${asr}, ${seg} segments. No audio, transcript or minute text was sent to any external service.`,
  docFootTrace: "Every entry above is traceable to a timestamped segment of the recording kept on this device.",
  minutedBy: "Minuted by",
  docSevLik: "Sev \xD7 Lik",
  docRaisedRepeatedly: (n) => `Raised in ${n} consecutive meetings; no owner assigned.`,
  docRaisedRepeatedlyOwned: (n) => `Raised in ${n} consecutive meetings.`,
  saveSummary: "Save summary",
  msgSummarySaved: "Summary saved \u2014 this is what \xA71 says from now on",
  summaryPlaceholder: "Write the summary in your own words \u2014 what opened the meeting, what it turned on, what it closed with.",
  summaryGenerated: "Until you write one, the document uses the figures below.",
  printPdf: "Print / PDF",
  /* side panel (SidePanel artboard) */
  capturedSoFar: "Captured so far",
  latest: "Latest",
  secSummary: "Summary",
  secDecisions: "Decisions",
  secActions: "Action items",
  autoSummary: "Generate auto summary",
  draftCancel: "Discard draft",
  saveShort: "Save",
  ownerLabel: "Owner",
  panelHint: "The register opens in a full tab \u2014 a table does not belong in a 400px rail.",
  recording: "Recording",
  idle: "Idle",
  endAndDraft: "End & draft",
  flagMoment: "Flag this moment",
  flagNeedsRecording: "Start a capture task first \u2014 a flag is a timecode, and there is no clock yet.",
  flagRefusedIssued: "This MoM is issued \u2014 flags go to an amendment or the next meeting",
  flaggedAt: (tc) => `Flagged at ${tc} \u2014 review this moment`,
  untitledMeeting: "Untitled meeting"
};
var id = {
  minutes: "Notulen",
  register: "Register notulen",
  openRegister: "Buka register notulen",
  registerHint: "Register terbuka di tab penuh \u2014 tabel tidak muat di rel 400px.",
  onDevice: "Di perangkat",
  export: "Ekspor",
  issue: "Terbitkan Notulen",
  issued: "Terbit",
  startNext: "Mulai rapat berikutnya",
  exportStanding: "Ekspor register berjalan",
  date: "Tanggal",
  time: "Waktu",
  chair: "Pimpinan",
  present: "Hadir",
  mom: "Notulen",
  series: "Seri",
  nth: (n) => `rapat ke-${n}`,
  cadence: "Irama",
  span: "Rentang",
  meetings: "Rapat",
  next: "Berikutnya",
  preparedBy: "Disusun oleh",
  distribution: "Distribusi",
  draftedOnDevice: "Disusun di perangkat ini",
  pipeline: (asr, seg, items) => `${asr} \u2192 ${seg} segmen \u2192 ${items} butir register`,
  needReview: "perlu ditinjau",
  lowConfFlag: "tanda keyakinan rendah",
  nothingLeft: "Tidak ada audio, transkrip, atau teks yang keluar dari perangkat ini.",
  noSource: "Tanpa sumber \u2014 impor dari v1",
  vRegister: "Register",
  vTopic: "Per topik",
  vDoc: "Notulen",
  vCarry: "Bawaan",
  vSeries: "Seri",
  cRef: "Ref",
  cType: "Jenis",
  cTopic: "Topik",
  cItem: "Butir",
  cOwner: "Penanggung jawab",
  cDue: "Tenggat",
  cStatus: "Status",
  cSource: "Sumber",
  cAge: "Umur",
  cRaised: "Diangkat",
  decision: "Keputusan",
  action: "Tindak lanjut",
  question: "Pertanyaan terbuka",
  risk: "Risiko",
  metric: "Metrik",
  info: "Catatan",
  open: "Terbuka",
  progress: "Berjalan",
  closed: "Selesai",
  carried: "Dibawa",
  ai: "Draf AI",
  accepted: "Disetujui",
  edited: "Disunting",
  sItems: "Butir register",
  sActions: "Tindak lanjut terbuka",
  sOverdue: "Lewat tenggat",
  sDecisions: "Keputusan",
  sQuestions: "Pertanyaan terbuka",
  sUnreviewed: "Belum ditinjau",
  sCoverage: "Agenda terbahas",
  sVariance: "Progres vs baseline",
  sMeanAge: "Umur rata-rata",
  sOldest: "Butir tertua",
  dText: "Teks butir",
  dOwner: "Penanggung jawab",
  dDue: "Tenggat",
  dStatus: "Status",
  dTopic: "Topik",
  dAgenda: "Ref agenda",
  dProvenance: "Asal butir ini",
  dLinked: "Terkait di register ini",
  dHistory: "Riwayat",
  asSpoken: "Sesuai ucapan",
  machineTranslation: "Terjemahan mesin",
  citedSpan: "rentang dikutip",
  lowConfWords: "kata keyakinan rendah",
  accept: "Setujui",
  saveEdit: "Simpan suntingan",
  discard: "Buang",
  playFrom: "Putar dari sini",
  addItem: "Tambah butir",
  carryIn: "Bawa masuk",
  close: "Tutup",
  applyCorrection: "Terapkan koreksi",
  keepAsHeard: "Biarkan sesuai terdengar",
  addToGlossary: "Tambah ke glosarium",
  search: "Cari butir, penanggung jawab, kutipan\u2026",
  mine: "Milik saya",
  dual: "Dua bahasa",
  groupBy: "Kelompok",
  groupNone: "tidak",
  needsReviewOnly: "Hanya yang perlu ditinjau",
  showing: (n, total) => `Menampilkan ${n} dari ${total}`,
  asrUnsure: (pct2) => `Pengenalan suara ragu di sini \u2014 ${pct2}%`,
  extractorWrote: "Ekstraktor menulis",
  audioSays: "Audionya berbunyi",
  carryIntro: "Butir terbuka warisan rapat sebelumnya. Yang masih terbuka dinomori ulang ke register ini dan mempertahankan umurnya.",
  openFor: "terbuka",
  days: "h",
  today: "hari ini",
  overdue: "lewat",
  dueIn: "dalam",
  noOwner: "Belum ditugaskan",
  noDue: "Tanpa tenggat",
  noneYet: "Belum ada apa-apa",
  raisedAgain: "Diangkat lagi minggu ini",
  consecutive: (n) => `pertanyaan terbuka di ${n} rapat berturut-turut`,
  docSummary: "Ringkasan",
  docDecisions: "Poin keputusan",
  docActions: "Register tindak lanjut",
  docQuestions: "Pertanyaan terbuka",
  docRisks: "Risiko",
  docMetrics: "Progres",
  docNotes: "Catatan pembahasan",
  msgAccepted: "Butir disetujui \u2014 terkunci di notulen",
  msgCarried: "Dibawa ke register ini",
  msgIssued: "Notulen diterbitkan",
  msgBlocked: (n) => `${n} butir belum ditinjau \u2014 tetap terbitkan?`,
  msgIssuedFrozen: "Notulen ini sudah terbit dan hanya-baca. Buat amandemen untuk mengoreksi.",
  msgMigrated: (n) => `${n} rapat dinaikkan dari format notulen lama`,
  msgItemAdded: "Butir ditambahkan ke register",
  msgAmended: (id2) => `Amandemen dibuat \u2014 ${id2}`,
  msgSeeking: "Menggeser transkrip ke",
  msgEmpty: "Tidak ada butir yang cocok dengan filter.",
  msgNoMeeting: "Belum ada rapat yang dipilih.",
  presentN: (n) => `${n}`,
  seriesNth: (n) => `rapat ke-${n}`,
  lowAsr: "Keyakinan ASR rendah",
  aiDraftPct: (pct2) => `Draf AI \xB7 ${pct2}%`,
  reported: "dilaporkan",
  ahead: "di depan",
  behind: "di belakang",
  vsBaseline: "baseline",
  kbdMove: "pindah",
  kbdAccept: "setujui",
  kbdOwner: "penanggung jawab",
  kbdDate: "tenggat",
  kbdSearch: "cari",
  kbdClose: "tutup",
  lastSaved: (t, backend2) => `Tersimpan ${t} \xB7 ${backend2}`,
  notSavedYet: (backend2) => `Belum tersimpan \xB7 ${backend2}`,
  agendaRef: (a) => `agenda ${a}`,
  translationHint: (other) => `Teks ${other} disimpan terpisah \u2014 ganti bahasa untuk menyuntingnya`,
  dPriority: "Prioritas",
  prHigh: "Tinggi",
  prMed: "Sedang",
  prLow: "Rendah",
  dSevLik: "Keparahan \xD7 kemungkinan",
  lkCertain: "Pasti",
  lkLikely: "Besar",
  lkPossible: "Mungkin",
  lkUnlikely: "Kecil",
  segRange: (a, b) => a === b ? `seg ${a}` : `seg ${a}\u2013${b}`,
  asr: "ASR",
  correctionApplied: "Koreksi diterapkan \u2014 butir ditandai disunting",
  keptAsHeard: "Dibiarkan sesuai terdengar \u2014 butir disetujui",
  glossaryAdded: (t) => `\u201C${t}\u201D ditambahkan ke glosarium lokal`,
  extractedBy: (by) => `dibuat oleh ${by}`,
  flaggedLow: (pct2) => `ditandai keyakinan rendah \xB7 ${pct2}% < 70%`,
  mActual: "Aktual",
  mBaseline: "Baseline",
  mVariance: "Selisih",
  mAhead: "di depan baseline",
  mBehind: "di belakang baseline",
  mOnBaseline: "sesuai baseline",
  mChart: "Progres kumulatif terhadap baseline",
  mChartNote: "Hanya angka yang disebut dalam seri ini yang digambar \u2014 tidak ada interpolasi",
  mWhereFrom: "Asal angka ini",
  mAheadNotSafe: "Di depan, tapi belum aman",
  mAheadNotSafeBody: (n) => `${n} risiko terbuka ada di baris agenda yang sama \u2014 baca bersama.`,
  mSingle: "Baru satu titik data \u2014 kurvanya mulai di rapat berikutnya",
  mTypedNote: "Tiga angka diambil dari satu kalimat dan dijadikan tipe ukuran, bukan prosa \u2014 sehingga angka minggu depan jatuh di sumbu yang sama, bukan di paragraf baru.",
  seriesLabel: "Seri rapat",
  standingRegister: "Register tindak lanjut berjalan",
  openAcross: (n, m) => `${n} terbuka dari ${m} rapat`,
  sortedByAge: "Diurutkan berdasarkan umur \u2014 angka yang masuk laporan progres",
  flowTitle: "Butir dibuka dan ditutup, per rapat",
  flowNote: (up, total, net) => `Yang dibuka melebihi yang ditutup di ${up} dari ${total} rapat \u2014 bersih ${net >= 0 ? "+" : ""}${net} sepanjang seri.`,
  opened: "Dibuka",
  byParty: "Butir terbuka per pihak",
  showAll: "Tampilkan semua",
  showLess: "Tampilkan lebih sedikit",
  moreOpen: (n) => `+ ${n} butir terbuka lainnya`,
  raisedAgainBody: (text, n) => `\u201C${text}\u201D sudah terbuka di ${n} rapat berturut-turut tanpa penanggung jawab. Tugaskan atau tutup.`,
  raisedAgainOwned: (text, n, owner) => `\u201C${text}\u201D sudah dibawa melewati ${n} rapat berturut-turut (penanggung jawab: ${owner}). Tutup atau rencanakan ulang.`,
  raisedAgainNone: "Belum ada yang dibawa lebih dari sekali \u2014 register bersih.",
  startW: (n) => `Mulai W${n}`,
  nOpen: (n) => `${n} terbuka`,
  cadenceWeekly: "Mingguan",
  cadenceBiweekly: "Dua mingguan",
  cadenceDays: (d) => `Setiap ${d} hari`,
  cadenceNA: "\u2014",
  consecutivePill: (n) => `diangkat di ${n} rapat berturut-turut`,
  momTitle: "NOTULEN RAPAT",
  rev: "Rev",
  draftWatermark: "DRAF \u2014 belum diterbitkan",
  docMeeting: "Rapat",
  docProject: "Proyek",
  docNo: (n) => `ke-${n}`,
  docAccountable: "Bertanggung jawab",
  docReferredTo: "Dirujuk ke",
  docBy: "Batas",
  docAction: "Tindak lanjut",
  docQuestion: "Pertanyaan",
  docRisk: "Risiko",
  docDecision: "Keputusan",
  docCarriedFrom: (id2, d) => `Dibawa dari ${id2}, terbuka ${d} hari.`,
  docFootAi: (n) => `${n} butir bertanda \u2021 disusun oleh pengenalan suara di perangkat dan disetujui tanpa perubahan oleh notulis.`,
  docFootAllReviewed: "Setiap butir ditinjau manusia sebelum diterbitkan.",
  docFootCorrected: (ref, from, to, tc) => `${ref} dikoreksi terhadap rekaman sebelum terbit: \u201C${from}\u201D \u2192 \u201C${to}\u201D, diverifikasi pada ${tc}.`,
  docFootEngine: (asr, seg) => `Ditranskripsi dan disusun di mesin notulis sendiri \u2014 ${asr}, ${seg} segmen. Tidak ada audio, transkrip, atau teks notulen yang dikirim ke layanan eksternal.`,
  docFootTrace: "Setiap entri di atas dapat ditelusuri ke segmen rekaman bercap waktu yang tersimpan di perangkat ini.",
  minutedBy: "Dicatat oleh",
  docSevLik: "Parah \xD7 Kemungkinan",
  docRaisedRepeatedly: (n) => `Diangkat di ${n} rapat berturut-turut; belum ada penanggung jawab.`,
  docRaisedRepeatedlyOwned: (n) => `Diangkat di ${n} rapat berturut-turut.`,
  saveSummary: "Simpan ringkasan",
  msgSummarySaved: "Ringkasan tersimpan \u2014 inilah isi \xA71 mulai sekarang",
  summaryPlaceholder: "Tulis ringkasan dengan kata-kata Anda sendiri \u2014 apa yang membuka rapat, apa yang menjadi pokoknya, dan apa penutupnya.",
  summaryGenerated: "Selama belum ditulis, dokumen memakai angka-angka di bawah ini.",
  printPdf: "Cetak / PDF",
  capturedSoFar: "Tertangkap sejauh ini",
  latest: "Terbaru",
  secSummary: "Ringkasan",
  secDecisions: "Keputusan",
  secActions: "Tindak lanjut",
  autoSummary: "Buat ringkasan otomatis",
  draftCancel: "Buang draf",
  saveShort: "Simpan",
  ownerLabel: "Pemilik",
  panelHint: "Register terbuka di tab penuh \u2014 tabel tidak muat di rel 400px.",
  recording: "Merekam",
  idle: "Siaga",
  endAndDraft: "Akhiri & buat draf",
  flagMoment: "Tandai momen ini",
  flagNeedsRecording: "Mulai tugas perekaman dulu \u2014 tanda itu sebuah timecode, dan jamnya belum berjalan.",
  flagRefusedIssued: "Notulen ini sudah terbit \u2014 tanda masuk lewat amandemen atau rapat berikutnya",
  flaggedAt: (tc) => `Ditandai pada ${tc} \u2014 tinjau momen ini`,
  untitledMeeting: "Rapat tanpa judul"
};
var NOTES_I18N = { en, id: { ...en, ...id } };
function notesStrings(lang) {
  return NOTES_I18N[lang] || NOTES_I18N.en;
}
function makeT(lang) {
  const dict = notesStrings(lang);
  return function T2(key, ...args) {
    const v = dict[key] ?? NOTES_I18N.en[key] ?? key;
    return typeof v === "function" ? v(...args) : v;
  };
}

// src/minutes.js
init_notes_store();

// src/lib/notes-actions.js
init_notes_schema();
init_notes_store();
var clone = (m) => JSON.parse(JSON.stringify(m));
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var RegisterError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "RegisterError";
  }
};
function assertEditable(meeting) {
  if (meeting.issuedAt) {
    throw new RegisterError(
      "issued",
      `${meeting.id} sudah diterbitkan ${meeting.issuedAt}. Buat amandemen, jangan ubah catatannya.`
    );
  }
}
function findIndex(meeting, ref) {
  const i = meeting.items.findIndex((x) => x.ref === ref);
  if (i < 0) throw new RegisterError("not_found", `item ${ref} tidak ada di ${meeting.id}`);
  return i;
}
function withHistory(item, changes, by = "local") {
  const at = (/* @__PURE__ */ new Date()).toISOString();
  const history = [...item.history || []];
  for (const [field, [from, to]] of Object.entries(changes)) {
    history.push(createRevision({ at, by, field, from, to }));
  }
  return history;
}
function acceptItem(meeting, ref, { by = "local" } = {}) {
  assertEditable(meeting);
  const next = clone(meeting);
  const i = findIndex(next, ref);
  const item = next.items[i];
  if (item.review === "accepted" && !item.correction) return next;
  const changes = {};
  if (item.review !== "accepted") changes.review = [item.review, "accepted"];
  if (item.correction) changes.correction = [item.correction, null];
  next.items[i] = {
    ...item,
    review: "accepted",
    correction: null,
    history: withHistory(item, changes, by)
  };
  return next;
}
function applyCorrection(meeting, ref, { by = "local" } = {}) {
  const item = meeting.items[findIndex(meeting, ref)];
  if (!item.correction) throw new RegisterError("no_correction", `${ref} tidak punya saran koreksi`);
  const { from, to } = item.correction;
  const text = {};
  const pattern = new RegExp(from.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  for (const [lang, t] of Object.entries(item.text || {})) {
    text[lang] = t.replace(pattern, (hit) => hit[0] === hit[0].toUpperCase() && hit.slice(1) === hit.slice(1).toLowerCase() ? to[0].toUpperCase() + to.slice(1) : to);
  }
  return editItem(meeting, ref, { text, correction: null }, { by });
}
function carryChain(meetings, meeting, item) {
  const byId = new Map(meetings.map((m2) => [m2.id, m2]));
  let n = 1;
  let cur = item;
  let m = meeting;
  const seen = /* @__PURE__ */ new Set();
  while (cur && cur.carriedFrom && cur.links?.[0] && !seen.has(`${m.id}:${cur.ref}`)) {
    seen.add(`${m.id}:${cur.ref}`);
    const prev = byId.get(cur.carriedFrom);
    if (!prev) break;
    const prevItem = prev.items.find((x) => x.ref === cur.links[0]);
    if (!prevItem) break;
    n += 1;
    cur = prevItem;
    m = prev;
  }
  return n;
}
function linkedItems(meetings, meeting, item) {
  const out = [];
  const candidates = [meeting, ...meetings.filter((m) => m.id !== meeting.id)];
  for (const ref of item.links || []) {
    for (const m of candidates) {
      const hit = m.items.find((x) => x.ref === ref);
      if (hit) {
        out.push({ item: hit, meeting: m });
        break;
      }
    }
  }
  for (const other of meeting.items) {
    if (other.ref !== item.ref && (other.links || []).includes(item.ref) && !out.some((o) => o.item.ref === other.ref)) {
      out.push({ item: other, meeting });
    }
  }
  return out;
}
function seriesFlow(meetings) {
  const tracked = (i) => i.type === "action" || i.type === "question" || i.type === "risk";
  return [...meetings].sort((a, b) => a.seq - b.seq).map((m) => ({
    meetingId: m.id,
    seq: m.seq,
    date: m.date,
    opened: m.items.filter((i) => tracked(i) && !i.carriedFrom).length,
    closed: m.items.filter((i) => tracked(i) && i.status === "closed").length,
    open: m.items.filter((i) => tracked(i) && i.status !== "closed").length
  }));
}
function editItem(meeting, ref, patch = {}, { by = "local" } = {}) {
  assertEditable(meeting);
  const next = clone(meeting);
  const i = findIndex(next, ref);
  const item = next.items[i];
  const changes = {};
  const merged = { ...item };
  for (const [k, v] of Object.entries(patch)) {
    if (k === "ref" || k === "history" || k === "src") continue;
    if (k === "text") {
      const before = { ...item.text || {} };
      const after = { ...before, ...v || {} };
      for (const lang of Object.keys(after)) {
        if (before[lang] !== after[lang]) changes[`text.${lang}`] = [before[lang] ?? null, after[lang]];
      }
      merged.text = after;
      continue;
    }
    if (JSON.stringify(item[k]) !== JSON.stringify(v)) {
      changes[k] = [item[k], v];
      merged[k] = v;
    }
  }
  if (!Object.keys(changes).length) return next;
  merged.review = "edited";
  if (item.review !== "edited") changes.review = [item.review, "edited"];
  merged.history = withHistory(item, changes, by);
  next.items[i] = createMinuteItem(merged, { locale: next.locale });
  return next;
}
function addItem(meeting, partial = {}, { by = "local" } = {}) {
  assertEditable(meeting);
  const next = clone(meeting);
  const item = createMinuteItem(
    {
      openedAt: partial.status && partial.status !== "closed" ? today() : null,
      ...partial,
      ref: partial.ref || nextRef(next),
      review: partial.review || "edited",
      // ditulis manusia
      confidence: partial.confidence ?? 1
    },
    { locale: next.locale }
  );
  item.history = [createRevision({ by, field: "created", to: item.ref })];
  next.items.push(item);
  return next;
}
function flagMoment(meeting, { tc, t0 = 0, text, by = "local" } = {}) {
  assertEditable(meeting);
  if (!text) {
    throw new RegisterError("no_text", 'flagMoment butuh teks jadi dari pemanggil: T("flaggedAt", tc)');
  }
  const stamp = tc || toTimecode(t0);
  return addItem(
    meeting,
    {
      type: "info",
      topic: "flag",
      text: { [meeting.locale || "en"]: String(text) },
      review: "edited",
      src: { t0, t1: t0, tc: stamp, lang: "auto", orig: "", tr: "" }
    },
    { by }
  );
}
function setSummary(meeting, lang, text) {
  assertEditable(meeting);
  const next = clone(meeting);
  const key = String(lang || next.locale || "en");
  const value = String(text ?? "").trim();
  next.summary = { ...next.summary || {} };
  if (value) next.summary[key] = value;
  else delete next.summary[key];
  return next;
}
function setStatus(meeting, ref, status, opts = {}) {
  return editItem(meeting, ref, { status }, opts);
}
function removeItem(meeting, ref) {
  assertEditable(meeting);
  const next = clone(meeting);
  findIndex(next, ref);
  next.items = next.items.filter((x) => x.ref !== ref);
  return next;
}
function carryCandidates(source) {
  return (source.items || []).filter(
    (i) => i.status !== "closed" && i.type !== "info" && i.type !== "metric"
  );
}
function carryForward(target, source, { refs = null, by = "local" } = {}) {
  assertEditable(target);
  const next = clone(target);
  const wanted = carryCandidates(source).filter((i) => !refs || refs.includes(i.ref));
  const already = new Set(next.items.map((i) => i.carriedFrom && i.links[0]).filter(Boolean));
  for (const item of wanted) {
    if (already.has(item.ref)) continue;
    const carried = createMinuteItem(
      {
        ...item,
        ref: nextRef(next),
        status: item.status === "carried" ? "open" : item.status,
        carriedFrom: source.id,
        openedAt: item.openedAt || source.date,
        links: [item.ref, ...item.links || []],
        src: item.src ? { ...item.src, meetingId: item.src.meetingId || source.id } : null
      },
      { locale: next.locale }
    );
    carried.history = [
      ...item.history || [],
      createRevision({ by, field: "carriedFrom", from: item.ref, to: carried.ref })
    ];
    next.items.push(carried);
  }
  return next;
}
function startNextMeeting(source, partial = {}) {
  const seq = Number(source.seq || 0) + 1;
  const blank = createMeeting({
    seriesId: source.seriesId,
    seq,
    title: source.title,
    tz: source.tz,
    // A standing series keeps its slot, so the START time carries over unless
    // the caller says otherwise. The END time does NOT: when the next meeting
    // finishes is a measurement nobody has made yet.
    start: source.start,
    chair: source.chair,
    attendees: source.attendees,
    topics: source.topics,
    locale: source.locale,
    date: partial.date || today(),
    id: partial.id || `${source.seriesId}-W${String(seq).padStart(2, "0")}`,
    ...partial
  });
  return carryForward(blank, source);
}
function blockingItems(meeting) {
  return (meeting.items || []).filter(
    (i) => i.review === "ai" || i.confidence < LOW_CONFIDENCE
  );
}
function issueMeeting(meeting, { force = false, by = "local" } = {}) {
  if (meeting.issuedAt) throw new RegisterError("issued", `${meeting.id} sudah diterbitkan.`);
  const blocking = blockingItems(meeting);
  if (blocking.length && !force) {
    throw new RegisterError(
      "unreviewed",
      `${blocking.length} butir belum ditelaah: ${blocking.map((i) => i.ref).join(", ")}`
    );
  }
  const next = clone(meeting);
  next.issuedAt = (/* @__PURE__ */ new Date()).toISOString();
  next.issuedBy = by;
  next.issuedWithUnreviewed = blocking.map((i) => i.ref);
  return next;
}
function createAmendment(issued, { by = "local" } = {}) {
  if (!issued.issuedAt) throw new RegisterError("not_issued", `${issued.id} belum diterbitkan.`);
  const n = Number(/-A(\d+)$/.exec(issued.id)?.[1] || 0) + 1;
  const baseId = issued.id.replace(/-A\d+$/, "");
  const next = createMeeting({ ...clone(issued), id: `${baseId}-A${n}`, issuedAt: null });
  next.amends = baseId;
  next.amendedBy = by;
  return next;
}
function seriesSummary(meetings, now = /* @__PURE__ */ new Date()) {
  const superseded = /* @__PURE__ */ new Set();
  for (const m of meetings) {
    for (const i of m.items) {
      if (i.carriedFrom && i.links?.[0]) superseded.add(`${i.carriedFrom}:${i.links[0]}`);
    }
  }
  const open = [];
  for (const m of meetings) {
    for (const i of m.items) {
      if (i.status === "closed" || i.type === "info" || i.type === "metric") continue;
      if (superseded.has(`${m.id}:${i.ref}`)) continue;
      open.push({ item: i, meeting: m, age: itemAgeDays(i, now), chain: carryChain(meetings, m, i) });
    }
  }
  open.sort((a, b) => (b.age ?? -1) - (a.age ?? -1));
  const ages = open.map((r) => r.age).filter((a) => a != null);
  const byOrg = {};
  for (const r of open) {
    const k = r.item.org || "unassigned";
    byOrg[k] = (byOrg[k] || 0) + 1;
  }
  return {
    meetings: meetings.length,
    open: open.length,
    oldest: ages.length ? Math.max(...ages) : null,
    meanAge: ages.length ? Math.round(ages.reduce((a, b) => a + b, 0) / ages.length) : null,
    byOrg,
    rows: open
  };
}
function metricSeries(meetings, measure) {
  const points = [];
  for (const m of meetings) {
    for (const i of m.items) {
      if (i.type !== "metric" || !i.metric || i.metric.measure !== measure) continue;
      points.push({
        meetingId: m.id,
        seq: m.seq,
        asOf: i.metric.asOf || m.date,
        value: i.metric.value,
        baseline: i.metric.baseline,
        variance: i.metric.variance,
        unit: i.metric.unit,
        ref: i.ref
      });
    }
  }
  return points.sort((a, b) => a.asOf < b.asOf ? -1 : a.asOf > b.asOf ? 1 : a.seq - b.seq);
}
var persist = (fn) => async (meeting, ...args) => saveMeeting(fn(meeting, ...args));
var acceptItemAndSave = persist(acceptItem);
var applyCorrectionAndSave = persist(applyCorrection);
var editItemAndSave = persist(editItem);
var addItemAndSave = persist(addItem);
var flagMomentAndSave = persist(flagMoment);
var setStatusAndSave = persist(setStatus);
var setSummaryAndSave = persist(setSummary);
var removeItemAndSave = persist(removeItem);
var carryForwardAndSave = persist(carryForward);
var issueMeetingAndSave = persist(issueMeeting);

// src/lib/notes-fixture.js
init_notes_schema();
var SAMPLE_SERIES_ID = "CPOC7-WEEKLY";
var ATTENDEES = [
  { name: "Nasmee Samang", org: "GZS" },
  { name: "Lai Kong Teng", org: "COMPANY" },
  { name: "Riza", org: "GZS" },
  { name: "Jagdeep", org: "MWS" },
  { name: "Huimin", org: "GZS" },
  { name: "QA/QC", org: "GZS" },
  { name: "CVL", org: "SUBCON" }
];
function buildW35() {
  let m = createMeeting({
    id: "MOM-CPOC7-W35",
    seriesId: SAMPLE_SERIES_ID,
    seq: 35,
    title: "CPOC Phase 7 \u2014 GZS Weekly Progress Meeting",
    date: "2026-08-19",
    start: "10:00",
    end: "12:00",
    tz: "GMT+8",
    chair: "Nasmee Samang",
    attendees: ATTENDEES,
    locale: "en",
    agenda: [
      { ref: "A2", title: { en: "Dropped-object controls", id: "Kendali dropped object" }, covered: true },
      { ref: "A3", title: { en: "Document review status (MDR/GMDR)", id: "Status tinjauan dokumen (MDR/GMDR)" }, covered: true },
      { ref: "A5", title: { en: "HSE performance & yard audits", id: "Kinerja K3 & audit yard" }, covered: true },
      { ref: "A6", title: { en: "Vessel selection (C900)", id: "Pemilihan kapal (C900)" }, covered: false }
    ],
    engine: { asr: "Whisper large-v3-turbo (MLX)", mt: "local NMT", extractor: "heuristic v1", segments: 196, durationSec: 6900 }
  });
  const items = [
    {
      type: "decision",
      topic: "controls",
      agenda: "A2",
      owner: "Lai Kong Teng",
      org: "COMPANY",
      text: {
        en: "Cranes are to be inspected and secured before operation and before transport \u2014 not operation alone.",
        id: "Crane wajib diperiksa dan diamankan sebelum operasi dan sebelum transportasi \u2014 bukan hanya saat operasi."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.91,
      src: {
        t0: 698,
        speaker: "Lai Kong Teng",
        lang: "zh",
        orig: "\u8D77\u91CD\u673A\u7684\u62A4\u680F\u548C\u6F5C\u5728\u5760\u7269\u4E0D\u4EC5\u8981\u5728\u4F5C\u4E1A\u65F6\u68C0\u67E5\uFF0C\u6E2F\u53E3\u52A8\u5458\u548C\u8FD0\u8F93\u5230\u73B0\u573A\u65F6\u4E5F\u8981\u68C0\u67E5\u3002",
        tr: "Crane handrails and potential dropped objects need inspection not only during operation but also during port-side mobilisation and transport to field."
      }
    },
    {
      type: "decision",
      topic: "perf",
      agenda: "A5",
      owner: "QA/QC",
      org: "GZS",
      text: {
        en: "CUL onshore fabrication yard prefabrication audits confirmed for 21\u201322 September, run jointly with QA/QC.",
        id: "Audit prefabrikasi di yard fabrikasi onshore CUL dikonfirmasi 21\u201322 September, dijalankan bersama QA/QC."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.92,
      src: {
        t0: 2332,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "CUL \u9646\u4E0A\u9884\u5236\u573A\u7684\u9884\u5236\u5BA1\u6838\u5B89\u6392\u5728 9 \u6708 21 \u5230 22 \u65E5\uFF0C\u4E0E QAQC \u4E00\u8D77\u8FDB\u884C\u3002",
        tr: "Prefabrication audits at the CUL onshore fabrication yard were planned for September 21\u201322 in conjunction with QAQC."
      }
    },
    {
      type: "info",
      topic: "perf",
      agenda: "A5",
      text: {
        en: "35,000+ accumulated man-hours; lagging KPI indicators positive; zero HSE incidents recorded this period.",
        id: "Lebih dari 35.000 jam kerja terakumulasi; indikator KPI lagging positif; nol insiden K3 pada periode ini."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.95
    },
    {
      type: "metric",
      topic: "progress",
      agenda: "A5",
      text: { en: "Cumulative actual progress, week 35" },
      status: "closed",
      review: "accepted",
      confidence: 0.93,
      metric: { measure: "cumulative_progress", value: 9.78, baseline: 9, unit: "%", asOf: "2026-08-21" }
    },
    {
      type: "action",
      topic: "marine",
      agenda: "A6",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-08-29",
      text: {
        en: "Obtain written C900 availability window from the vessel owner.",
        id: "Peroleh jendela ketersediaan C900 tertulis dari pemilik kapal."
      },
      status: "open",
      review: "accepted",
      confidence: 0.9,
      openedAt: "2026-08-19",
      src: {
        t0: 2642,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u9700\u8981\u8239\u4E1C\u4E66\u9762\u786E\u8BA4 C900 \u7684\u53EF\u7528\u7A97\u53E3\u3002",
        tr: "Written confirmation of the C900 availability window is needed from the vessel owner."
      }
    },
    {
      type: "action",
      topic: "docs",
      agenda: "A3",
      owner: "Riza",
      org: "GZS",
      due: "2026-08-26",
      text: {
        en: "Issue GMDR rev.3 to COMPANY with the revised submission priority list.",
        id: "Terbitkan GMDR rev.3 ke COMPANY dengan daftar prioritas penyerahan yang direvisi."
      },
      status: "open",
      review: "accepted",
      confidence: 0.88,
      openedAt: "2026-08-12",
      src: {
        t0: 1795,
        speaker: "Riza",
        lang: "zh",
        orig: "GMDR \u7B2C\u4E09\u7248\u8981\u8FDE\u540C\u4FEE\u8BA2\u540E\u7684\u63D0\u4EA4\u4F18\u5148\u7EA7\u6E05\u5355\u4E00\u8D77\u53D1\u7ED9\u516C\u53F8\u3002",
        tr: "GMDR rev.3 to be issued to COMPANY together with the revised submission priority list."
      }
    },
    {
      type: "risk",
      topic: "mob",
      agenda: "A6",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-09-15",
      text: {
        en: "OSP approval slipping into the mobilisation window would delay sail-away; no float remains on the marine spread.",
        id: "Persetujuan OSP yang bergeser ke jendela mobilisasi akan menunda sail-away; tidak ada float tersisa pada marine spread."
      },
      status: "open",
      review: "edited",
      confidence: 0.84,
      openedAt: "2026-08-19",
      priority: "high",
      likelihood: "possible",
      src: {
        t0: 2020,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u5982\u679C OSP \u6279\u51C6\u62D6\u5230\u52A8\u5458\u7A97\u53E3\uFF0C\u8D77\u822A\u4F1A\u88AB\u63A8\u8FDF\u3002",
        tr: "If OSP approval slips into the mobilisation window, sail-away will be delayed."
      }
    }
  ];
  for (const it of items) m = addItem(m, it, { by: "seed" });
  return m;
}
function buildW36(w35) {
  let m = startNextMeeting(w35, {
    id: "MOM-CPOC7-W36",
    date: "2026-09-02",
    end: "12:00",
    summary: {
      en: "The meeting opened on the dropped-object incident during conductor installation and closed on yard-audit readiness. Crane inspection and securement were agreed as standing requirements covering transport as well as operation. Document review is progressing under MDR/GMDR priority with no issues flagged; one MWS signature remains outstanding. Cumulative actual progress reached 10.89%, 1.11% ahead of baseline, offset by a delay risk on bending and coating for the DNS shipment. Seven items remain open, two of them carried from week 35, and the prefab audit checklist is now the standing template \u2014 the series is audit-ready.",
      id: "Rapat dibuka dengan insiden dropped object saat pemasangan conductor dan ditutup dengan kesiapan audit yard. Inspeksi dan pengamanan crane disepakati sebagai syarat tetap yang mencakup transportasi, bukan hanya operasi. Tinjauan dokumen berjalan sesuai prioritas MDR/GMDR tanpa temuan; satu tanda tangan MWS masih tertunda. Progres aktual kumulatif mencapai 10,89%, 1,11% di depan baseline, tetapi diimbangi risiko keterlambatan bending dan coating untuk pengiriman DNS. Tujuh butir masih terbuka, dua di antaranya bawaan dari minggu 35, dan checklist audit prefab kini menjadi templat tetap \u2014 seri ini siap diaudit."
    },
    agenda: [
      { ref: "A1", title: { en: "Safety moment & incident review", id: "Momen keselamatan & tinjauan insiden" }, covered: true },
      { ref: "A2", title: { en: "Dropped-object controls", id: "Kendali dropped object" }, covered: true },
      { ref: "A3", title: { en: "Document review status (MDR/GMDR)", id: "Status tinjauan dokumen (MDR/GMDR)" }, covered: true },
      { ref: "A5", title: { en: "HSE performance & yard audits", id: "Kinerja K3 & audit yard" }, covered: true },
      { ref: "A6", title: { en: "Vessel selection (C900)", id: "Pemilihan kapal (C900)" }, covered: true },
      { ref: "A7", title: { en: "Marine budget & pipeline cargo", id: "Anggaran marine & kargo pipa" }, covered: false },
      { ref: "A8", title: { en: "Look-ahead: 3-week plan", id: "Look-ahead: rencana 3 minggu" }, covered: false }
    ],
    engine: { asr: "Whisper large-v3-turbo (MLX)", mt: "local NMT", extractor: "heuristic v1", segments: 214, durationSec: 7320 }
  });
  const items = [
    {
      type: "info",
      topic: "hse",
      agenda: "A1",
      text: {
        en: "Grating fell from the HLV main-boom walkway onto the jacket sea deck and struck a portable fire extinguisher; a second object later fell from the main crane into the sea. Personnel on the sea deck were evacuated to the barge \u2014 no injuries.",
        id: "Grating jatuh dari walkway main-boom HLV ke sea deck jacket dan menghantam APAR portabel; benda kedua kemudian jatuh dari main crane ke laut. Personel di sea deck dievakuasi ke barge \u2014 tidak ada cedera."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.94,
      src: {
        t0: 252,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u540A\u81C2\u8D70\u9053\u4E0A\u7684\u683C\u6805\u6389\u843D\u5230\u5BFC\u7BA1\u67B6\u7532\u677F\u4E0A\uFF0C\u7838\u5230\u4E00\u4E2A\u624B\u63D0\u706D\u706B\u5668\u3002\u4EBA\u5458\u5DF2\u64A4\u5230\u9A73\u8239\uFF0C\u4E4B\u540E\u53C8\u6709\u7269\u4EF6\u6389\u5165\u6D77\u4E2D\uFF0C\u65E0\u4EBA\u53D7\u4F24\u3002",
        tr: "A grating from the boom walkway fell onto the jacket deck and hit a portable extinguisher. Personnel were moved to the barge; another object then fell into the sea. No injuries."
      }
    },
    {
      type: "action",
      topic: "controls",
      agenda: "A2",
      owner: "Lai Kong Teng",
      org: "COMPANY",
      due: "2026-09-08",
      text: {
        en: "Issue a crane inspection checklist covering greasing, fast-line block inspection and a boom-walkway sweep for loose items.",
        id: "Terbitkan checklist inspeksi crane mencakup greasing, inspeksi fast-line block, dan penyisiran walkway boom untuk barang lepas."
      },
      status: "open",
      review: "ai",
      confidence: 0.88,
      openedAt: "2026-09-02",
      src: {
        t0: 545,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u4E8B\u6545\u590D\u76D8\u5EFA\u8BAE\u5EFA\u7ACB\u8D77\u91CD\u673A\u68C0\u67E5\u6E05\u5355\uFF0C\u5305\u62EC\u6DA6\u6ED1\u3001\u5FEB\u7EF3\u6ED1\u8F66\u68C0\u67E5\uFF0C\u4EE5\u53CA\u68C0\u67E5\u540A\u81C2\u8D70\u9053\u6709\u65E0\u677E\u6563\u7269\u4EF6\u3002",
        tr: "The incident review recommended establishing a crane inspection checklist, including greasing, fast-line block inspection, and checking the crane-boom walkway for loose items."
      }
    },
    {
      type: "action",
      topic: "docs",
      agenda: "A3",
      owner: "Riza",
      org: "GZS",
      due: "2026-09-05",
      text: {
        en: "Obtain Mr. Huimin's signature on the SCI MWS draft before submission to COMPANY.",
        id: "Peroleh tanda tangan Bapak Huimin pada draf SCI MWS sebelum penyerahan ke COMPANY."
      },
      status: "progress",
      review: "ai",
      confidence: 0.85,
      openedAt: "2026-09-02",
      src: {
        t0: 1541,
        speaker: "Riza",
        lang: "zh",
        orig: "SCI \u7684 MWS \u8349\u7A3F\u5DF2\u7ECF\u53D1\u7ED9\u516C\u53F8\uFF0C\u6B63\u5728\u7B49\u60E0\u6C11\u5148\u751F\u7B7E\u5B57\u540E\u518D\u6B63\u5F0F\u63D0\u4EA4\u3002",
        tr: "The SCI MWS draft had been shared with the company and was awaiting Mr. Huimin\u2019s signature before submission."
      }
    },
    {
      type: "question",
      topic: "marine",
      agenda: "A6",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-09-09",
      text: {
        en: "Which vessel is selected? Pending evaluation of C900 capability and availability window.",
        id: "Kapal mana yang dipilih? Menunggu evaluasi kapabilitas dan jendela ketersediaan C900."
      },
      status: "open",
      review: "ai",
      confidence: 0.81,
      openedAt: "2026-09-02",
      src: {
        t0: 2842,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u8239\u7684\u9009\u62E9\u8981\u7B49\u8BC4\u4F30\u5B8C C900 \u7684\u80FD\u529B\u548C\u53EF\u7528\u6027\u518D\u5B9A\u3002",
        tr: "Vessel selection to be resolved after evaluating C900 capability and availability."
      }
    },
    {
      type: "decision",
      topic: "perf",
      agenda: "A5",
      owner: "QA/QC",
      org: "GZS",
      text: {
        en: "Adopt the prefab audit checklist as the standing template for future GZS yard audits.",
        id: "Jadikan checklist audit prefab sebagai templat tetap untuk audit yard GZS berikutnya."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.9,
      src: {
        t0: 2410,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u68C0\u67E5\u6E05\u5355\u5DF2\u7ECF\u53D1\u7ED9 CVL\uFF0C\u6548\u679C\u4E0D\u9519\uFF0C\u4EE5\u540E\u5C31\u7528\u8FD9\u4EFD\u6A21\u677F\u3002",
        tr: "The checklist had already been shared with CVL and worked well \u2014 use this template going forward."
      }
    },
    // W36-009 — the figure below cites this line, so it has to exist as its own
    // register item rather than living inside the metric's sentence.
    {
      type: "info",
      topic: "progress",
      agenda: "A8",
      text: {
        en: "Land-pack manufacturing complete for all batches, ready for shipment.",
        id: "Manufaktur land-pack selesai untuk semua batch, siap dikirim."
      },
      status: "closed",
      review: "accepted",
      confidence: 0.93,
      src: {
        t0: 3372,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u9646\u4E0A\u7BA1\u6BB5\u7684\u5236\u9020\u5DF2\u7ECF\u5168\u90E8\u5B8C\u6210\uFF0C\u5404\u6279\u6B21\u90FD\u53EF\u4EE5\u53D1\u8FD0\u4E86\u3002",
        tr: "Land-pack manufacturing is complete for all batches and ready for shipment."
      }
    },
    // W36-010 — links back to the metric (W36-011): being ahead of baseline does
    // not absorb this risk, and the drawer says so.
    {
      type: "risk",
      topic: "schedule",
      agenda: "A8",
      owner: "Nasmee Samang",
      org: "GZS",
      due: "2026-09-09",
      text: {
        en: "Delay risk on Ben and Coding activities for DNS shipment.",
        id: "Risiko keterlambatan pada aktivitas Ben and Coding untuk pengiriman DNS."
      },
      status: "open",
      review: "ai",
      confidence: 0.61,
      openedAt: "2026-09-02",
      priority: "high",
      likelihood: "possible",
      links: ["W36-011"],
      correction: { from: "Ben and Coding", to: "bending and coating", origPhrase: "\u5F2F\u7BA1\u548C\u6D82\u6577" },
      src: {
        t0: 3738,
        t1: 3761,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "\u672C\u5468\u867D\u7136\u8FDB\u5EA6\u9886\u5148\uFF0C\u4F46\u5F2F\u7BA1\u548C\u6D82\u6577\u7684\u6D3B\u52A8\u6709\u660E\u663E\u7684\u5EF6\u8BEF\u98CE\u9669\uFF0C\u7279\u522B\u662F\u8981\u53D1\u5F80 DNS \u7684\u90E8\u5206\u3002",
        tr: "Although progress is ahead this week, there is a significant delay risk on the bending and coating activities, particularly the part to be shipped to DNS.",
        segmentIds: ["s1284", "s1287"]
      }
    },
    // W36-011 — cites the land-pack note (W36-009) and the delay risk (W36-010).
    {
      type: "metric",
      topic: "progress",
      agenda: "A8",
      text: { en: "Cumulative actual progress, week 36", id: "Progres aktual kumulatif, minggu 36" },
      status: "closed",
      review: "accepted",
      confidence: 0.94,
      links: ["W36-009", "W36-010"],
      metric: { measure: "cumulative_progress", value: 10.89, baseline: 9.78, unit: "%", asOf: "2026-08-28" },
      src: {
        t0: 3390,
        t1: 3421,
        speaker: "Nasmee Samang",
        lang: "zh",
        orig: "8 \u6708 28 \u65E5\u7684\u8FDB\u5EA6\u62A5\u544A\u4F5C\u4E3A WPR \u7684\u9884\u57FA\u51C6\u7248\u672C\u53D1\u5E03\uFF0C\u6743\u91CD\u6309\u6700\u65B0\u4FE1\u606F\u66F4\u65B0\u3002\u9646\u4E0A\u7BA1\u6BB5\u5404\u6279\u6B21\u5236\u9020\u5B8C\u6210\u3001\u53EF\u4EE5\u53D1\u8FD0\uFF0C\u6240\u4EE5\u7D2F\u8BA1\u5B9E\u9645\u8FDB\u5EA6\u662F 10.89%\uFF0C\u6BD4\u57FA\u51C6\u8D85\u524D 1.11%\u3002",
        tr: "The 28 August progress report was issued as the pre-baseline version for the WPR, with weightage updated according to the latest information. Land-pack manufacturing is complete for all batches and ready for shipment, so cumulative actual progress is 10.89% \u2014 1.11% ahead of baseline.",
        segmentIds: ["s1198", "s1204"]
      }
    },
    {
      type: "metric",
      topic: "perf",
      agenda: "A5",
      text: { en: "Accumulated man-hours", id: "Jam kerja terakumulasi" },
      status: "closed",
      review: "accepted",
      confidence: 0.95,
      metric: { measure: "man_hours", value: 35e3, unit: "", asOf: "2026-09-02" }
    },
    {
      type: "metric",
      topic: "perf",
      agenda: "A5",
      text: { en: "HSE incidents this period", id: "Insiden K3 pada periode ini" },
      status: "closed",
      review: "accepted",
      confidence: 0.95,
      metric: { measure: "hse_incidents", value: 0, unit: "" }
    }
  ];
  for (const it of items) m = addItem(m, it, { by: "seed" });
  return m;
}
function buildSampleSeries() {
  const w35 = buildW35();
  const w36 = buildW36(w35);
  return [w35, w36];
}
async function seedSampleData() {
  const { saveMeeting: saveMeeting2 } = await Promise.resolve().then(() => (init_notes_store(), notes_store_exports));
  const [w35, w36] = buildSampleSeries();
  await saveMeeting2(w35);
  await saveMeeting2(w36);
  return [w35, w36];
}

// src/lib/notes-export.js
init_notes_schema();
var DOC_SECTIONS = [
  ["decision", "docDecisions", "Decisions"],
  ["action", "docActions", "Action register"],
  ["question", "docQuestions", "Open questions"],
  ["risk", "docRisks", "Risks"],
  ["metric", "docMetrics", "Progress"],
  ["info", "docNotes", "Discussion notes"]
];
function label(T2, key, fallback) {
  if (!T2) return fallback;
  const v = T2(key);
  return v === key ? fallback : v;
}
function serializeMeetingMarkdown(meeting, lang = meeting.locale || "en", T2 = null) {
  const stats = meetingStats(meeting);
  const lines = [
    `# ${meeting.title}`,
    "",
    `_${meeting.id}_ \xB7 ${meeting.date}${meeting.start ? ` \xB7 ${meeting.start}${meeting.end ? `\u2013${meeting.end}` : ""}${meeting.tz ? ` ${meeting.tz}` : ""}` : ""}${meeting.chair ? ` \xB7 ${label(T2, "chair", "Chair")}: ${meeting.chair}` : ""}`,
    meeting.issuedAt ? `_${label(T2, "issued", "Issued")}: ${meeting.issuedAt}_` : "_Draft \u2014 not yet issued_",
    "",
    `${stats.total} items \xB7 ${stats.actionsOpen}/${stats.actionsTotal} actions open \xB7 ${stats.decisions} decisions \xB7 ${stats.questionsOpen} open questions \xB7 agenda ${stats.agendaPct}% covered`,
    ""
  ];
  if (meeting.agenda?.length) {
    lines.push(`## Agenda`, "");
    for (const a of meeting.agenda) {
      lines.push(`- [${a.covered ? "x" : " "}] ${a.ref} \u2014 ${pickText(a.title, lang)}`);
    }
    lines.push("");
  }
  for (const [type, key, fallback] of DOC_SECTIONS) {
    const rows = meeting.items.filter((i) => i.type === type);
    if (!rows.length) continue;
    lines.push(`## ${label(T2, key, fallback)}`, "");
    for (const it of rows) {
      const meta = [];
      if (it.owner) meta.push(it.owner);
      if (it.due) meta.push(`due ${it.due}`);
      if (it.status && it.status !== "open") meta.push(it.status);
      if (it.type === "metric" && it.metric) {
        meta.push(`${it.metric.value}${it.metric.unit}${it.metric.baseline != null ? ` (baseline ${it.metric.baseline}${it.metric.unit})` : ""}`);
      }
      const suffix = meta.length ? ` \u2014 ${meta.join(" \xB7 ")}` : "";
      const flag = it.review === "ai" ? " \u2021" : "";
      lines.push(`- **${it.ref}** ${pickText(it.text, lang)}${suffix}${flag}`);
    }
    lines.push("");
  }
  const unreviewed = meeting.items.filter((i) => i.review === "ai");
  lines.push(
    "---",
    unreviewed.length ? `\u2021 ${unreviewed.length} item(s) still AI-drafted, not yet reviewed by a human.` : "Every item has been reviewed by a human.",
    `Drafted on-device${meeting.engine ? ` \u2014 ${meeting.engine.asr}` : ""}. Nothing left this machine.`,
    ""
  );
  return lines.join("\n");
}
function serializeMeetingCsv(meeting, lang = meeting.locale || "en") {
  const cols = ["ref", "type", "topic", "text", "owner", "due", "status", "review", "confidence"];
  const esc2 = (v) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows = meeting.items.map((it) => [
    it.ref,
    it.type,
    it.topic,
    pickText(it.text, lang),
    it.owner || "",
    it.due || "",
    it.status,
    it.review,
    it.confidence
  ]);
  return [cols.join(","), ...rows.map((r) => r.map(esc2).join(","))].join("\n");
}

// src/minutes.js
var $ = (s, root = document) => root.querySelector(s);
var esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
var LS_LANG = "ltsMinutesLang";
var LS_NAME = "ltsMinutesMe";
var LS_GLOSSARY = "ltsGlossary";
var state = {
  meetings: (
    /** @type {any[]} */
    []
  ),
  activeId: (
    /** @type {string|null} */
    null
  ),
  view: "table",
  q: "",
  types: /* @__PURE__ */ new Set(),
  mine: false,
  dual: false,
  reviewOnly: false,
  seriesAll: false,
  sort: { key: "ref", dir: 1 },
  group: "none",
  sel: (
    /** @type {string|null} */
    null
  ),
  adding: false,
  // ?lang= from the side panel wins once, then the toggle is remembered.
  lang: (() => {
    const q = new URLSearchParams(globalThis.location?.search || "").get("lang");
    if (q === "en" || q === "id") {
      localStorage.setItem(LS_LANG, q);
      return q;
    }
    return localStorage.getItem(LS_LANG) || "en";
  })(),
  me: localStorage.getItem(LS_NAME) || "",
  lastSaved: (
    /** @type {Date|null} */
    null
  )
};
var T = makeT(state.lang);
function activeMeeting() {
  return state.meetings.find((m) => m.id === state.activeId) || null;
}
function seriesOf(m) {
  return state.meetings.filter((x) => x.seriesId === m.seriesId).sort((a, b) => a.seq - b.seq);
}
function replaceActive(meeting) {
  const i = state.meetings.findIndex((m) => m.id === meeting.id);
  if (i >= 0) state.meetings[i] = meeting;
  else state.meetings.unshift(meeting);
  state.activeId = meeting.id;
  state.lastSaved = /* @__PURE__ */ new Date();
}
async function reloadAll(keepActive = true) {
  state.meetings = await listMeetings();
  if (!keepActive || !state.meetings.some((m) => m.id === state.activeId)) {
    state.activeId = state.meetings[0]?.id || null;
  }
}
function daysTo(iso, today2) {
  if (!iso) return null;
  return Math.round((/* @__PURE__ */ new Date(`${iso}T00:00:00Z`) - today2) / 864e5);
}
function todayUTC() {
  const d = /* @__PURE__ */ new Date();
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}
function dueClass(it) {
  if (!it.due || it.status === "closed") return "";
  const d = daysTo(it.due, todayUTC());
  if (d < 0) return "over";
  if (d <= 3) return "soon";
  return "";
}
function relLabel(it) {
  if (!it.due || it.status === "closed") return "";
  const d = daysTo(it.due, todayUTC());
  if (d === 0) return T("today");
  if (d < 0) return `${Math.abs(d)}${T("days")} ${T("overdue")}`;
  return `${T("dueIn")} ${d}${T("days")}`;
}
function initials(n) {
  return String(n || "").split(/[\s/]+/).filter(Boolean).map((w) => w[0]).join("").slice(0, 2).toUpperCase() || "?";
}
function ownerColor(name) {
  let h = 0;
  for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${h} 45% 45%)`;
}
function confColor(c) {
  return c >= 0.9 ? "var(--accent)" : c >= LOW_CONFIDENCE ? "var(--warn-text)" : "var(--danger)";
}
function pct(c) {
  return Math.round((Number(c) || 0) * 100);
}
function isLow(it) {
  return it.confidence < LOW_CONFIDENCE;
}
function itemText(it) {
  return pickText(it.text, state.lang);
}
function itemAltText(it) {
  const other = state.lang === "en" ? "id" : "en";
  return it.text?.[other] || "";
}
var MONTHS = {
  en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
  id: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
};
function fmtDate(iso, withYear = true) {
  if (!iso) return "\u2014";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) return iso;
  const mon = (MONTHS[state.lang] || MONTHS.en)[Number(m[2]) - 1] || m[2];
  return `${m[3]} ${mon}${withYear ? ` ${m[1]}` : ""}`;
}
function fmtShortDate(iso) {
  return fmtDate(iso, false);
}
function fmtClock(d) {
  return d ? d.toTimeString().slice(0, 5) : "";
}
function weekLabel(m) {
  return `W${String(m.seq).padStart(2, "0")}`;
}
function segLabel(src) {
  const ids = src.segmentIds || [];
  if (!ids.length) return "";
  const n = (s) => String(s).replace(/^\D+/, "");
  return T("segRange", n(ids[0]), n(ids[ids.length - 1]));
}
function tcRange(src) {
  if (!src) return "";
  if (src.t1 != null && src.t1 > src.t0) return `${src.tc} \u2013 ${toTc(src.t1)}`;
  return src.tc;
}
function toTc(sec) {
  const s = Math.max(0, Math.floor(sec));
  return `${String(Math.floor(s / 3600)).padStart(2, "0")}:${String(Math.floor(s % 3600 / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
function sign(n) {
  return n == null ? "" : n >= 0 ? "+" : "";
}
function fmtNum(n) {
  return Number.isFinite(n) ? String(Number(n.toFixed(2))) : "\u2014";
}
function fmtMeasure(n) {
  if (!Number.isFinite(n)) return "\u2014";
  if (Math.abs(n) < 1e3) return fmtNum(n);
  return new Intl.NumberFormat(state.lang === "id" ? "id-ID" : "en-US").format(Number(n.toFixed(2)));
}
function textWithFlag(it) {
  const t = itemText(it);
  if (!it.correction) return esc(t);
  const idx = t.toLowerCase().indexOf(it.correction.from.toLowerCase());
  if (idx < 0) return esc(t);
  return `${esc(t.slice(0, idx))}<span class="flagword">${esc(t.slice(idx, idx + it.correction.from.length))}</span>${esc(t.slice(idx + it.correction.from.length))}`;
}
function textWithMark(text, phrase) {
  if (!text) return "";
  if (!phrase) return esc(text);
  const idx = text.toLowerCase().indexOf(phrase.toLowerCase());
  if (idx < 0) return esc(text);
  return `${esc(text.slice(0, idx))}<mark>${esc(text.slice(idx, idx + phrase.length))}</mark>${esc(text.slice(idx + phrase.length))}`;
}
function filteredItems() {
  const m = activeMeeting();
  if (!m) return [];
  const q = state.q.trim().toLowerCase();
  return m.items.filter((it) => {
    if (state.types.size && !state.types.has(it.type)) return false;
    if (state.mine && state.me && it.owner !== state.me) return false;
    if (state.reviewOnly && !(it.review === "ai" || isLow(it))) return false;
    if (q) {
      const hay = [it.ref, itemText(it), itemAltText(it), it.owner, it.src?.speaker, it.src?.tr, it.src?.orig, it.topic].join(" ").toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}
function sortedItems(rows) {
  const { key, dir } = state.sort;
  const val = (it) => {
    if (key === "due") return it.due || "9999-99-99";
    if (key === "type") return it.type;
    if (key === "owner") return it.owner || "zzz";
    if (key === "status") return it.status;
    if (key === "topic") return it.topic;
    return it.ref;
  };
  return [...rows].sort((a, b) => (val(a) > val(b) ? 1 : val(a) < val(b) ? -1 : 0) * dir);
}
var visibleRefs = (
  /** @type {string[]} */
  []
);
function cellType(it) {
  return `<span class="type" data-type="${it.type}"><i></i>${esc(T(it.type))}</span>`;
}
function cellRef(it) {
  return `<span class="ref">${esc(it.ref)}${it.carriedFrom ? ` <span class="carry" title="${esc(it.carriedFrom)}">\u21A9</span>` : ""}</span>`;
}
function cellOwner(it) {
  if (!it.owner) return `<span class="owner none"><span class="nm">${esc(T("noOwner"))}</span></span>`;
  return `<span class="owner">
    <span class="av" style="background:${ownerColor(it.owner)}">${esc(initials(it.owner))}</span>
    <span style="min-width:0"><span class="nm">${esc(it.owner)}</span>
    ${it.org ? `<span class="org">${esc(it.org)}</span>` : ""}</span></span>`;
}
function cellDue(it) {
  if (it.type === "metric" && it.metric?.asOf) {
    return `<span class="due">${esc(it.metric.asOf.slice(5))}<span class="rel">${esc(T("reported"))}</span></span>`;
  }
  if (!it.due) return `<span class="due none">\u2014</span>`;
  return `<span class="due ${dueClass(it)}">${esc(it.due.slice(5))}<span class="rel">${esc(relLabel(it))}</span></span>`;
}
function cellStatus(it) {
  return `<span class="status" data-s="${it.status}"><span class="sd"></span>${esc(T(it.status))}</span>`;
}
function cellSrc(it) {
  if (!it.src) return `<span class="src none">${esc(T("noSource"))}</span>`;
  const low = isLow(it);
  const revLabel = it.review === "ai" && low ? T("aiDraftPct", pct(it.confidence)) : T(it.review);
  return `<span class="src ${low ? "lit" : ""}" data-play="${esc(it.src.tc)}">\u25B6 ${esc(it.src.tc)}</span>
    <span class="conf" title="${esc(T("asr"))} ${pct(it.confidence)}%"><i style="width:${pct(it.confidence)}%;background:${confColor(it.confidence)}"></i></span>
    <span class="rev ${low ? "low" : ""}" data-r="${it.review}">${esc(revLabel)}</span>`;
}
function cellItem(it) {
  const alt = state.dual && itemAltText(it) ? `<span class="alt">${esc(itemAltText(it))}</span>` : "";
  const flag = isLow(it) ? `<span class="pill-warn">${flagIcon(11)} ${esc(T("lowAsr"))}</span>` : "";
  return `<span class="itemtext">${it.agenda ? `<span class="agenda">${esc(it.agenda)}</span>` : ""}${textWithFlag(it)}${flag}${it.type === "metric" && it.metric ? metricLine(it) : ""}${alt}</span>`;
}
function metricLine(it) {
  const mt = it.metric;
  const v = mt.variance;
  const m = activeMeeting();
  const pts = metricSeries(seriesOf(m), mt.measure).slice(-6);
  const max = Math.max(...pts.map((p) => Math.abs(p.value)), 1);
  const spark = pts.length > 1 ? `<span class="spark" aria-hidden="true">${pts.map((p) => `<i class="${p.variance == null ? "" : p.variance >= 0 ? "lit" : "neg"}" style="height:${Math.max(4, Math.round(Math.abs(p.value) / max * 19))}px"></i>`).join("")}</span>` : "";
  return `<span class="metricline">
    <span class="big">${esc(fmtMeasure(mt.value))}${esc(mt.unit)}</span>
    ${mt.baseline != null ? `<span class="base">${esc(T("vsBaseline"))} <span class="mono">${esc(fmtMeasure(mt.baseline))}${esc(mt.unit)}</span></span>` : ""}
    ${v != null ? `<span class="var ${v >= 0 ? "up" : "down"}">${sign(v)}${esc(fmtMeasure(v))}${esc(mt.unit)} ${esc(T(v >= 0 ? "ahead" : "behind"))}</span>` : ""}
    ${spark}
    ${mt.asOf ? `<span class="note">${esc(fmtShortDate(mt.asOf))} ${esc(T("reported"))}${mt.sourceDoc ? ` \xB7 ${esc(mt.sourceDoc)}` : ""}</span>` : ""}
  </span>`;
}
function flagIcon(size = 12) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 20V5.5"/><path d="M5 6h11l-2 3.2 2 3.3H5"/></svg>`;
}
function alertIcon(size = 14) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 8v5"/><path d="M12 16.5h.01"/><circle cx="12" cy="12" r="8.5"/></svg>`;
}
function playIcon(size = 10) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 4.5 19 12 7 19.5z"/></svg>`;
}
function checkIcon(size = 13) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5 10 17.5 19 7"/></svg>`;
}
function viewTable(rows) {
  if (!rows.length) return `<p class="empty">${esc(T("msgEmpty"))}</p>`;
  const th = (k, cls, label2) => {
    const active = state.sort.key === k;
    return `<th class="${cls}" data-sort="${k}">${esc(label2)}${active ? `<span class="sort">${state.sort.dir > 0 ? "\u25B2" : "\u25BC"}</span>` : ""}</th>`;
  };
  return `<table>
    <thead><tr>
      ${th("ref", "c-ref", T("cRef"))}
      ${th("type", "c-type", T("cType"))}
      ${th("topic", "c-topic", T("cTopic"))}
      <th class="c-item">${esc(T("cItem"))}</th>
      ${th("owner", "c-owner", T("cOwner"))}
      ${th("due", "c-due", T("cDue"))}
      ${th("status", "c-status", T("cStatus"))}
      <th class="c-src">${esc(T("cSource"))}</th>
    </tr></thead>
    <tbody>${groupRows(rows).map(({ label: label2, count, items }) => `
      ${label2 == null ? "" : `<tr class="ghead"><td colspan="8">${esc(label2)}<span class="cnt">${count}</span></td></tr>`}
      ${items.map((it) => `
      <tr data-ref="${esc(it.ref)}" aria-selected="${state.sel === it.ref}">
        <td class="c-ref">${cellRef(it)}</td>
        <td class="c-type">${cellType(it)}</td>
        <td class="c-topic"><span class="topic">${esc(topicLabel(it.topic))}</span></td>
        <td class="c-item">${cellItem(it)}</td>
        <td class="c-owner">${cellOwner(it)}</td>
        <td class="c-due">${cellDue(it)}</td>
        <td class="c-status">${cellStatus(it)}</td>
        <td class="c-src">${cellSrc(it)}</td>
      </tr>`).join("")}`).join("")}</tbody>
  </table>`;
}
function groupRows(rows) {
  if (state.group === "none") return [{ label: null, count: rows.length, items: rows }];
  const key = (it) => {
    if (state.group === "owner") return it.owner || T("noOwner");
    if (state.group === "status") return T(it.status);
    return topicLabel(it.topic);
  };
  const out = [];
  const byLabel = /* @__PURE__ */ new Map();
  for (const it of rows) {
    const label2 = key(it);
    if (!byLabel.has(label2)) {
      const g2 = { label: label2, count: 0, items: [] };
      byLabel.set(label2, g2);
      out.push(g2);
    }
    const g = byLabel.get(label2);
    g.items.push(it);
    g.count += 1;
  }
  return out;
}
function topicLabel(key) {
  const m = activeMeeting();
  const t = m?.topics?.[key];
  return t ? pickText(t, state.lang) : key;
}
function viewTopic(rows) {
  const keys = [...new Set(rows.map((r) => r.topic))].sort();
  if (!keys.length) return `<p class="empty">${esc(T("msgEmpty"))}</p>`;
  return `<div class="grp">${keys.map((k) => {
    const rs = rows.filter((r) => r.topic === k);
    const openN = rs.filter((r) => r.status !== "closed").length;
    return `<h2>${esc(topicLabel(k))}<span class="cnt">${rs.length}</span>
      <span class="cov" style="color:${openN ? "var(--warn-text)" : "var(--accent)"}">${esc(T("nOpen", openN))}</span></h2>
      ${rs.map((it) => `
        <div class="gcard" data-ref="${esc(it.ref)}" aria-selected="${state.sel === it.ref}">
          <div>${cellType(it)}<div style="margin-top:4px">${cellRef(it)}</div></div>
          <div>${cellItem(it)}<div style="margin-top:6px">${cellOwner(it)}</div></div>
          <div class="gmeta">${cellStatus(it)}${cellDue(it)}</div>
        </div>`).join("")}`;
  }).join("")}</div>`;
}
function viewDoc() {
  const m = activeMeeting();
  const today2 = todayUTC();
  const stats = meetingStats(m, today2);
  const items = m.items;
  const byType = (t) => items.filter((i) => i.type === t);
  const mark = (it) => `${esc(it.ref)}${it.carriedFrom ? " \u21A9" : ""}${it.review === "ai" ? " \u2021" : ""}`;
  const carriedNote = (it) => it.carriedFrom ? ` <span class="sub">${esc(T("docCarriedFrom", it.carriedFrom, itemAgeDays(it, today2) ?? 0))}</span>` : "";
  const statusCell = (it) => {
    if (it.status === "closed") return `<td class="green">${esc(T("closed"))}</td>`;
    if (dueClass(it) === "over") return `<td class="red">${esc(T("overdue"))}</td>`;
    return `<td>${esc(T(it.status))}</td>`;
  };
  const dueCell = (it) => `<td class="mono ${dueClass(it) === "over" ? "red b" : ""}">${it.due ? esc(it.due.slice(5)) : "\u2014"}</td>`;
  const ownerCell = (it) => `<td>${it.owner ? `${esc(it.owner)}${it.org ? `<br><span class="sub">${esc(it.org)}</span>` : ""}` : `<span class="red">${esc(T("noOwner"))}</span>`}</td>`;
  const progressPt = byType("metric").find((i) => i.metric?.measure === "cumulative_progress");
  const series = seriesOf(m);
  const next = series.find((x) => x.seq > m.seq);
  const [project, seriesName] = splitTitle(m.title);
  const corrected = items.flatMap((it) => (it.history || []).filter((h) => h.field === "correction" && h.from && !h.to).map((h) => ({ ref: it.ref, from: h.from.from, to: h.from.to, tc: it.src?.tc || "\u2014", applied: it.review === "edited" }))).filter((c) => c.applied);
  const aiN = stats.unreviewed;
  const dateLine = `${m.date}${m.start ? `, ${m.start}${m.end ? `\u2013${m.end}` : ""}` : ""}${m.tz && m.tz !== "local" ? ` ${m.tz}` : ""}`;
  const noteGroups = [...new Set(byType("info").map((i) => i.topic))];
  const infoByTopic = noteGroups.map((k, idx) => `<div class="note"><h3>7.${idx + 1} ${esc(topicLabel(k))}</h3>${byType("info").filter((i) => i.topic === k).map((i) => `<p>${esc(itemText(i))}</p>`).join("")}</div>`).join("");
  const generatedSummary = state.lang === "id" ? `${stats.decisions} keputusan, ${stats.actionsOpen} dari ${stats.actionsTotal} tindak lanjut masih terbuka, ${stats.questionsOpen} pertanyaan terbuka, ${stats.carried} butir bawaan dari rapat sebelumnya. Agenda terbahas ${stats.agendaPct}% (${stats.agendaCovered}/${stats.agendaTotal}).${progressPt?.metric ? ` Progres aktual kumulatif ${fmtNum(progressPt.metric.value)}${progressPt.metric.unit}${progressPt.metric.variance != null ? `, ${sign(progressPt.metric.variance)}${fmtNum(progressPt.metric.variance)}${progressPt.metric.unit} terhadap baseline` : ""}.` : ""}` : `${stats.decisions} decision(s), ${stats.actionsOpen} of ${stats.actionsTotal} actions still open, ${stats.questionsOpen} open question(s), ${stats.carried} item(s) carried from the previous meeting. Agenda covered ${stats.agendaPct}% (${stats.agendaCovered}/${stats.agendaTotal}).${progressPt?.metric ? ` Cumulative actual progress ${fmtNum(progressPt.metric.value)}${progressPt.metric.unit}${progressPt.metric.variance != null ? `, ${sign(progressPt.metric.variance)}${fmtNum(progressPt.metric.variance)}${progressPt.metric.unit} against baseline` : ""}.` : ""}`;
  const authored = m.summary?.[state.lang] || "";
  const summaryBlock = m.issuedAt ? `<p>${esc(pickText(m.summary, state.lang) || generatedSummary)}</p>` : `<div class="sumedit">
        <p contenteditable="true" id="doc-summary" spellcheck="false"
           data-placeholder="${esc(T("summaryPlaceholder"))}">${esc(authored)}</p>
        <button type="button" class="btn xs" id="btn-save-summary">${esc(T("saveSummary"))}</button>
        ${authored ? "" : `<p class="genfallback"><span class="lead">${esc(T("summaryGenerated"))}</span> ${esc(generatedSummary)}</p>`}
      </div>`;
  const rev = /-A(\d+)$/.exec(m.id)?.[1] || "0";
  const chairOrg = m.attendees.find((a) => a.name === m.chair)?.org || "";
  const distribution = [...new Set(m.attendees.map((a) => a.org).filter(Boolean))].join(" \xB7 ");
  let n = 0;
  const sec = (title, body) => body ? `<section><h2>${++n} \xB7 ${esc(title)}</h2>${body}</section>` : "";
  const table = (heads, rowsHtml) => rowsHtml ? `<table><thead><tr>${heads.map(([h, w]) => `<th${w ? ` style="width:${w}"` : ""}>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rowsHtml}</tbody></table>` : "";
  const decisions = table(
    [[T("cRef"), "76px"], [T("docDecision")], [T("docAccountable"), "150px"]],
    byType("decision").map((it) => `<tr data-ref="${esc(it.ref)}"><td class="mref">${mark(it)}</td><td>${esc(itemText(it))}</td>${ownerCell(it)}</tr>`).join("")
  );
  const actions = table(
    [[T("cRef"), "76px"], [T("docAction")], [T("cOwner"), "118px"], [T("cDue"), "76px"], [T("cStatus"), "84px"]],
    byType("action").map((it) => `<tr data-ref="${esc(it.ref)}"><td class="mref">${mark(it)}</td><td>${esc(itemText(it))}${carriedNote(it)}</td>${ownerCell(it)}${dueCell(it)}${statusCell(it)}</tr>`).join("")
  );
  const repeatNote = (it) => {
    const chain = carryChain(series, m, it);
    if (chain < 2) return "";
    return ` <b>${esc(it.owner ? T("docRaisedRepeatedlyOwned", chain) : T("docRaisedRepeatedly", chain))}</b>`;
  };
  const questions = table(
    [[T("cRef"), "76px"], [T("docQuestion")], [T("docReferredTo"), "118px"], [T("docBy"), "76px"]],
    byType("question").map((it) => `<tr data-ref="${esc(it.ref)}"><td class="mref">${mark(it)}</td><td>${esc(itemText(it))}${repeatNote(it)}${carriedNote(it)}</td>${ownerCell(it)}${dueCell(it)}</tr>`).join("")
  );
  const risks = table(
    [[T("cRef"), "76px"], [T("docRisk")], [T("cOwner"), "118px"], [T("docSevLik"), "100px"]],
    byType("risk").map((it) => `<tr data-ref="${esc(it.ref)}"><td class="mref">${mark(it)}</td><td>${esc(itemText(it))}${carriedNote(it)}</td>${ownerCell(it)}<td>${esc(sevLikLabel(it))}</td></tr>`).join("")
  );
  const metrics = byType("metric");
  const progress = metrics.length ? `<div class="kpi">${metrics.map((it) => {
    const mt = it.metric;
    if (!mt) return "";
    return `<div><small>${esc(itemText(it))}</small><b>${esc(fmtMeasure(mt.value))}${esc(mt.unit)}</b></div>
      ${mt.baseline != null ? `<div><small>${esc(T("mBaseline"))}</small><b class="base">${esc(fmtMeasure(mt.baseline))}${esc(mt.unit)}</b></div>` : ""}
      ${mt.variance != null ? `<div><small>${esc(T("mVariance"))}</small><b class="${mt.variance >= 0 ? "up" : "down"}">${sign(mt.variance)}${esc(fmtMeasure(mt.variance))}${esc(mt.unit)}</b></div>` : ""}`;
  }).join("")}</div>${metrics.map((it) => it.src?.tr ? `<p>${esc(it.src.tr)}</p>` : "").join("")}` : "";
  return `<div class="docwrap"><div class="paper">
    <div class="lh">
      <div class="org">
        <svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true"><rect x="1.2" y="1.2" width="29.6" height="29.6" rx="5" stroke="#1c1c1a" stroke-width="2"/><path d="M8 21.5c2.6 0 2.6-3 5.2-3s2.6 3 5.2 3 2.6-3 5.2-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M9 12h14" stroke="#1c1c1a" stroke-width="2" stroke-linecap="round"/><path d="M9 16.5h8" stroke="#1c1c1a" stroke-width="2" stroke-linecap="round"/></svg>
        <div><b>${esc(chairOrg || project)}</b><small>${esc(project)}</small></div>
      </div>
      <div class="ttl">
        <b>${esc(T("momTitle"))}</b>
        <span>${esc(m.id)} \xB7 ${esc(T("rev"))} ${esc(rev)}${m.issuedAt ? ` \xB7 ${esc(T("issued"))} ${esc(m.issuedAt.slice(0, 10))}` : ""}</span>
        ${m.issuedAt ? "" : `<span class="draft">${esc(T("draftWatermark"))}</span>`}
      </div>
    </div>
    <div class="meta">
      <div><span>${esc(T("docProject"))}</span><span>${esc(project)}</span></div>
      <div><span>${esc(T("docMeeting"))}</span><span>${esc(seriesName || project)} \u2014 ${esc(T("docNo", m.seq))}</span></div>
      <div><span>${esc(T("date"))}</span><span class="mono">${esc(dateLine)}</span></div>
      <div><span>${esc(T("chair"))}</span><span>${esc(m.chair || "\u2014")}</span></div>
      <div><span>${esc(T("present"))}</span><span>${m.attendees.length ? esc(m.attendees.map((a) => a.name).join(", ")) : "\u2014"}</span></div>
      <div><span>${esc(T("next"))}</span><span class="mono">${next ? esc(meetingWhen(next)) : "\u2014"}</span></div>
    </div>
    ${sec(T("docSummary"), summaryBlock)}
    ${sec(T("docDecisions"), decisions)}
    ${sec(T("docActions"), actions)}
    ${sec(T("docQuestions"), questions)}
    ${sec(T("docRisks"), risks)}
    ${sec(T("docMetrics"), progress)}
    ${sec(T("docNotes"), infoByTopic)}
    <div class="pfoot">
      <div class="row">
        <div class="txt">
          ${aiN ? `<b>\u2021</b> ${esc(T("docFootAi", aiN))}` : esc(T("docFootAllReviewed"))}
          ${corrected.map((c) => `<br>${esc(T("docFootCorrected", c.ref, c.from, c.to, c.tc))}`).join("")}
          ${m.engine ? `<br>${esc(T("docFootEngine", m.engine.asr, m.engine.segments))}` : ""}
          <br>${esc(T("docFootTrace"))}
        </div>
        <div class="sig">
          <small>${esc(T("minutedBy"))}</small>
          <div class="line"></div>
          <b>${esc(m.chair || state.me || "\u2014")}</b>
          <span>${esc(chairOrg)}</span>
        </div>
      </div>
      <div class="dist">
        <span class="mono">${esc(m.id)} \xB7 ${esc(T("rev"))} ${esc(rev)}</span>
        ${distribution ? `<span>${esc(T("distribution"))}: ${esc(distribution)}</span>` : ""}
        <span>${esc(T("preparedBy"))}: Local TransSub \xB7 ${esc(T("onDevice"))}</span>
      </div>
    </div>
  </div></div>`;
}
function cssEscape(v) {
  return typeof CSS !== "undefined" && CSS.escape ? CSS.escape(v) : String(v).replace(/["\\]/g, "\\$&");
}
function cap(s) {
  return s ? s[0].toUpperCase() + s.slice(1) : "";
}
function sevLikLabel(it) {
  return `${T(`pr${cap(it.priority)}`)} \xD7 ${T(`lk${cap(it.likelihood)}`)}`;
}
function meetingWhen(m) {
  return `${m.date}${m.start ? `, ${m.start}` : ""}${m.tz && m.tz !== "local" ? ` ${m.tz}` : ""}`;
}
function splitTitle(title) {
  const parts = String(title || "").split(/\s+[—–-]\s+/);
  if (parts.length >= 2) return [parts[0], parts.slice(1).join(" \u2014 ")];
  return [title, ""];
}
function viewCarry() {
  const m = activeMeeting();
  const carriedIn = m.items.filter((i) => i.carriedFrom);
  const eligible = carryCandidates(m);
  const today2 = todayUTC();
  const row = (it, actions) => {
    const age = itemAgeDays(it, today2) ?? 0;
    return `<div class="cfrow ${age > 14 ? "hot" : ""}" data-ref="${esc(it.ref)}">
      <span class="rail"></span>
      <div class="cfmain">
        <div class="t">${cellType(it)} ${esc(itemText(it))}</div>
        <div class="m">${esc(it.ref)}${it.carriedFrom ? ` \xB7 \u21A9 ${esc(it.carriedFrom)}` : ""} \xB7 ${esc(T("openFor"))} ${age}${esc(T("days"))} \xB7 ${esc(it.owner || T("noOwner"))}</div>
      </div>
      <div class="cfact">${actions}</div>
    </div>`;
  };
  return `<div class="pad">
    <p class="intro">${esc(T("carryIntro"))}</p>
    <h2 style="margin:14px 0 8px">${esc(T("vCarry"))} \u2014 ${esc(weekLabel(m))}</h2>
    ${carriedIn.length ? carriedIn.map((it) => row(it, `<button class="btn" data-close="${esc(it.ref)}">${checkIcon(12)} ${esc(T("close"))}</button>`)).join("") : `<p class="empty">${esc(T("noneYet"))}</p>`}
    <h2 style="margin:18px 0 8px">${esc(T("vCarry"))} \u2192 ${esc(T("next"))}</h2>
    <div class="cfrow" style="border-style:dashed">
      <span class="rail" style="background:var(--accent)"></span>
      <div class="cfmain"><div class="t">${esc(T("startNext"))}</div><div class="m">${esc(T("nOpen", eligible.length))}</div></div>
      <div class="cfact"><button class="btn primary" id="btn-start-next">\u21B3 ${esc(T("startW", m.seq + 1))}</button></div>
    </div>
    ${eligible.length ? eligible.map((it) => row(it, `<span class="muted" style="font-size:11.5px">${esc(T("carryIn"))}</span>`)).join("") : `<p class="empty">${esc(T("noneYet"))}</p>`}
  </div>`;
}
function cadenceLabel(series) {
  if (series.length < 2) return T("cadenceNA");
  const gaps = [];
  for (let i = 1; i < series.length; i++) gaps.push(daysTo(series[i].date, /* @__PURE__ */ new Date(`${series[i - 1].date}T00:00:00Z`)));
  gaps.sort((a, b) => a - b);
  const med = gaps[Math.floor(gaps.length / 2)];
  if (med === 7) return T("cadenceWeekly");
  if (med === 14) return T("cadenceBiweekly");
  return T("cadenceDays", med);
}
function viewSeries() {
  const m = activeMeeting();
  const series = seriesOf(m);
  const today2 = todayUTC();
  const summary = seriesSummary(series, today2);
  const flow = seriesFlow(series);
  const [project, seriesName] = splitTitle(m.title);
  const rows = summary.rows;
  const shown = state.seriesAll ? rows : rows.slice(0, 8);
  const maxAge = Math.max(...rows.map((r) => r.age ?? 0), 1);
  const maxOpen = Math.max(...flow.map((f) => f.open), 1);
  const maxFlow = Math.max(...flow.map((f) => Math.max(f.opened, f.closed)), 1);
  const maxOpened = Math.max(...flow.map((f) => f.opened), 0);
  const maxClosed = Math.max(...flow.map((f) => f.closed), 0);
  const upN = flow.filter((f) => f.opened > f.closed).length;
  const net = flow.reduce((a, f) => a + f.opened - f.closed, 0);
  const orgRows = Object.entries(summary.byOrg).sort((a, b) => b[1] - a[1]);
  const orgMax = Math.max(...orgRows.map((r) => r[1]), 1);
  const orgColor = ["var(--accent)", "var(--t-decision)", "var(--t-info)", "var(--t-question)"];
  const repeat = rows.filter((r) => r.chain >= 2 && !r.item.owner).sort((a, b) => b.chain - a.chain)[0] || rows.filter((r) => r.chain >= 2).sort((a, b) => b.chain - a.chain)[0];
  const ageCell = (r) => {
    const age = r.age ?? 0;
    const hot = age > 14;
    return `<span class="age ${hot ? "hot" : ""}">${age}${esc(T("days"))}</span><span class="agebar"><i class="${hot ? "hot" : ""}" style="width:${Math.round(age / maxAge * 100)}%"></i></span>`;
  };
  const dueCell = (it) => {
    if (!it.due) return `<span class="due none">\u2014</span>`;
    return `<span class="due ${dueClass(it)}">${esc(it.due.slice(5))}${dueClass(it) === "over" ? `<span class="rel">${esc(relLabel(it))}</span>` : ""}</span>`;
  };
  return `<div class="series">
    <div class="shead">
      <div class="top">
        <div style="flex:1;min-width:240px">
          <div class="lbl">${esc(T("seriesLabel"))}</div>
          <h1>${esc(project)}${seriesName ? ` \u2014 ${esc(seriesName)}` : ""}</h1>
          <div class="facts">
            <span><span class="k">${esc(T("meetings"))}</span> <span class="v mono">${series.length}</span></span>
            <span><span class="k">${esc(T("span"))}</span> <span class="v mono">${esc(series[0].date)} \u2192 ${esc(series[series.length - 1].date)}</span></span>
            <span><span class="k">${esc(T("cadence"))}</span> <span class="v">${esc(cadenceLabel(series))}${m.start ? `, ${esc(m.start)}${m.tz && m.tz !== "local" ? ` ${esc(m.tz)}` : ""}` : ""}</span></span>
            <span><span class="k">${esc(T("chair"))}</span> <span class="v">${esc(m.chair || "\u2014")}</span></span>
          </div>
        </div>
        <div class="acts">
          <button class="btn" id="btn-export-standing">${esc(T("exportStanding"))}</button>
          <button class="btn primary" id="btn-start-next">${esc(T("startW", series[series.length - 1].seq + 1))}</button>
        </div>
      </div>
      <div class="mstrip">${flow.map((f) => `
        <div class="mcard ${f.meetingId === m.id ? "cur" : ""}" data-meeting="${esc(f.meetingId)}">
          <div class="d">${esc(fmtShortDate(f.date))}${f.meetingId === m.id ? ` \xB7 W${f.seq}` : ""}</div>
          <span class="t"><i style="width:${Math.round(f.open / maxOpen * 100)}%"></i></span>
          <div class="o">${esc(T("nOpen", f.open))}</div>
        </div>`).join("")}</div>
    </div>
    <div class="sbody">
      <div class="smain">
        <div class="sttl">
          <b>${esc(T("standingRegister"))}</b>
          <span class="cnt">${esc(T("openAcross", summary.open, series.length))}</span>
          <span class="hint">${esc(T("sortedByAge"))}</span>
        </div>
        ${rows.length ? `<table>
          <thead><tr>
            <th class="c-ref">${esc(T("cRef"))}</th><th class="c-type" style="width:98px">${esc(T("cType"))}</th><th>${esc(T("cItem"))}</th>
            <th style="width:146px">${esc(T("cOwner"))}</th><th class="c-raised">${esc(T("cRaised"))}</th><th class="c-age">${esc(T("cAge"))}</th><th class="c-due">${esc(T("cDue"))}</th>
          </tr></thead>
          <tbody>${shown.map((r) => `
            <tr data-ref="${esc(r.item.ref)}" data-meeting="${esc(r.meeting.id)}">
              <td class="c-ref">${cellRef(r.item)}</td>
              <td class="c-type">${cellType(r.item)}</td>
              <td><span class="itemtext">${esc(pickText(r.item.text, state.lang))}${r.chain >= 2 && r.item.type === "question" ? `<span class="pill-amber">${esc(T("consecutivePill", r.chain))}</span>` : ""}</span></td>
              <td>${r.item.owner ? `<span style="font-size:12px;color:var(--text2)">${esc(r.item.owner)}</span>${r.item.org ? `<span style="display:block;font-size:10px;color:var(--muted2)">${esc(r.item.org)}</span>` : ""}` : `<span class="muted2" style="font-size:12px">${esc(T("noOwner"))}</span>`}</td>
              <td class="c-raised"><span class="mono" style="font-size:11.5px;color:var(--muted)">${esc(fmtShortDate(r.item.openedAt || r.meeting.date))}</span></td>
              <td class="c-age">${ageCell(r)}</td>
              <td class="c-due">${dueCell(r.item)}</td>
            </tr>`).join("")}</tbody>
        </table>
        ${rows.length > 8 ? `<div class="smore">${state.seriesAll ? "" : `${esc(T("moreOpen", rows.length - 8))} \xB7 `}<button id="btn-series-all">${esc(T(state.seriesAll ? "showLess" : "showAll"))}</button></div>` : ""}` : `<p class="empty">${esc(T("noneYet"))}</p>`}
      </div>
      <div class="srail">
        <div class="cards">
          <div class="mini"><span class="n">${summary.meanAge ?? "\u2014"}<span class="unit">${summary.meanAge != null ? esc(T("days")) : ""}</span></span><span class="l">${esc(T("sMeanAge"))}</span></div>
          <div class="mini ${summary.oldest > 14 ? "alert" : ""}"><span class="n">${summary.oldest ?? "\u2014"}<span class="unit">${summary.oldest != null ? esc(T("days")) : ""}</span></span><span class="l">${esc(T("sOldest"))}</span></div>
        </div>
        <div class="card">
          <h3>${esc(T("flowTitle"))}</h3>
          <div class="sub">${esc(T("flowNote", upN, flow.length, net))}</div>
          <div class="legend"><span><i style="background:var(--down-bar)"></i>${esc(T("opened"))}</span><span><i style="background:var(--up)"></i>${esc(T("closed"))}</span></div>
          <div class="flow">
            <div class="gl" style="top:0"></div><div class="gl" style="top:37px"></div><div class="gl" style="top:73px"></div>
            <div class="bars">${flow.map((f) => `<span><i class="o" style="height:${Math.round(f.opened / maxFlow * 110)}px" title="${f.opened}"></i><i class="c" style="height:${Math.round(f.closed / maxFlow * 110)}px" title="${f.closed}"></i></span>`).join("")}</div>
            ${[["o", maxOpened], ["c", maxClosed]].filter(([, val]) => val > 0).map(([cls, val]) => `<span class="ymax ${cls}" style="bottom:${Math.round(val / maxFlow * 110)}px">${val}</span>`).join("")}
          </div>
          <div class="flowx">${flow.map((f) => `<span class="${f.meetingId === m.id ? "cur" : ""}">W${f.seq}</span>`).join("")}</div>
        </div>
        <div class="card">
          <h3 style="margin-bottom:11px">${esc(T("byParty"))}</h3>
          ${orgRows.length ? `<div class="orgbar">${orgRows.map(([org, n], i) => `<div>
            <div class="row"><span>${esc(org === "unassigned" ? T("noOwner") : org)}</span><span class="mono">${n}</span></div>
            <div class="track"><i style="width:${Math.round(n / orgMax * 100)}%;background:${orgColor[i % orgColor.length]}"></i></div>
          </div>`).join("")}</div>` : `<p class="empty" style="padding:8px 0">${esc(T("noneYet"))}</p>`}
        </div>
        <div class="card amber">
          <h3><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12a8 8 0 0 1 13.7-5.6L20 8.7"/><path d="M20 4v4.7h-4.7"/><path d="M20 12a8 8 0 0 1-13.7 5.6L4 15.3"/><path d="M4 20v-4.7h4.7"/></svg>${esc(T("raisedAgain"))}</h3>
          <p>${repeat ? esc(repeat.item.owner ? T("raisedAgainOwned", pickText(repeat.item.text, state.lang), repeat.chain, repeat.owner || repeat.item.owner) : T("raisedAgainBody", pickText(repeat.item.text, state.lang), repeat.chain)) : esc(T("raisedAgainNone"))}</p>
        </div>
      </div>
    </div>
  </div>`;
}
function paintHeader() {
  const m = activeMeeting();
  if (!m) return;
  const stats = meetingStats(m, todayUTC());
  const series = seriesOf(m);
  const [project, seriesName] = splitTitle(m.title);
  $("#crumbs").innerHTML = `<span>${esc(project)}</span>${seriesName ? `<span class="sep">/</span><span>${esc(seriesName)}</span>` : ""}<span class="sep">/</span><span class="now mono">${esc(weekLabel(m))} \xB7 ${esc(fmtDate(m.date))}</span>`;
  $("#m-title").textContent = m.title;
  $("#m-date").textContent = m.date;
  $("#m-time").textContent = [m.start, m.end].filter(Boolean).join("\u2013") + (m.tz && m.tz !== "local" ? ` ${m.tz}` : "");
  $("#m-chair").textContent = m.chair || "\u2014";
  $("#m-present").textContent = m.attendees.length ? T("presentN", m.attendees.length) : "\u2014";
  $("#m-mom").textContent = m.id;
  $("#m-series").textContent = T("seriesNth", series.findIndex((x) => x.id === m.id) + 1);
  $("#prov-line").textContent = m.engine ? T("pipeline", m.engine.asr, m.engine.segments, m.items.length) : T("noSource");
  $("#prov-unreviewed").textContent = String(stats.unreviewed);
  $("#prov-low").textContent = String(stats.lowConfidence);
  $("#prov-low-wrap").hidden = !stats.lowConfidence;
  $("#prov-low-sep").hidden = !stats.lowConfidence;
  $("#btn-issue").hidden = !!m.issuedAt;
  $("#issued-badge").classList.toggle("hidden", !m.issuedAt);
  $("#issued-badge").textContent = m.issuedAt ? `${T("issued")} \u2014 ${m.issuedAt.slice(0, 10)}` : "";
  $("#btn-amend").hidden = !m.issuedAt;
  $("#btn-add-item").hidden = !!m.issuedAt;
  const v = stats.variance;
  const cells = [
    { n: stats.total, l: T("sItems") },
    { n: `${stats.actionsOpen}<span class="sub">/${stats.actionsTotal}</span>`, l: T("sActions"), raw: true },
    { n: stats.overdue, l: T("sOverdue"), cls: stats.overdue ? "is-alert" : "" },
    { n: stats.questionsOpen, l: T("sQuestions") },
    { n: stats.unreviewed, l: T("sUnreviewed"), cls: stats.unreviewed ? "is-warn" : "is-ok" },
    v != null ? { n: `${sign(v)}${esc(fmtNum(v))}<span class="unit">${esc(stats.varianceUnit)}</span>`, l: T("sVariance"), cls: v >= 0 ? "is-up" : "is-alert", raw: true } : { n: stats.decisions, l: T("sDecisions") },
    { n: `${stats.agendaPct}<span class="unit">%</span>`, l: T("sCoverage"), bar: stats.agendaPct, raw: true }
  ];
  $("#strip").innerHTML = cells.map((c) => `
    <div class="stat ${c.cls || ""}">
      <span class="n">${c.raw ? c.n : esc(c.n)}</span>
      <span class="l">${esc(c.l)}</span>
      ${c.bar != null ? `<span class="bar"><i style="width:${c.bar}%"></i></span>` : ""}
    </div>`).join("");
}
function paintChips() {
  const m = activeMeeting();
  $("#chips").innerHTML = ITEM_TYPES.map((t) => {
    const n = m ? m.items.filter((i) => i.type === t).length : 0;
    const on = state.types.has(t);
    return `<button class="chip" data-type="${t}" aria-pressed="${on}" style="--dot:${TYPE_COLOR[t]}">
      <span class="dot"></span>${esc(T(t))}<span class="ct">${n}</span></button>`;
  }).join("");
  $("#btn-review-only").setAttribute("aria-pressed", String(state.reviewOnly));
}
function paintSwitcher() {
  const sel = $("#m-switch");
  sel.innerHTML = state.meetings.map((m) => `<option value="${esc(m.id)}" ${m.id === state.activeId ? "selected" : ""}>${esc(m.date)} \u2014 ${esc(weekLabel(m))}${m.issuedAt ? " \u2713" : ""}</option>`).join("");
}
function paintFooter(rows) {
  const m = activeMeeting();
  $("#showing").innerHTML = m ? esc(T("showing", rows.length, m.items.length)) : "";
  $("#kbd-hints").innerHTML = [
    `<kbd>j</kbd>/<kbd>k</kbd> ${esc(T("kbdMove"))}`,
    `<kbd>a</kbd> ${esc(T("kbdAccept"))}`,
    `<kbd>o</kbd> ${esc(T("kbdOwner"))}`,
    `<kbd>d</kbd> ${esc(T("kbdDate"))}`,
    `<kbd>/</kbd> ${esc(T("kbdSearch"))}`,
    `<kbd>Esc</kbd> ${esc(T("kbdClose"))}`
  ].join(" \xB7 ");
  $("#saved-line").textContent = state.lastSaved ? T("lastSaved", fmtClock(state.lastSaved), backendName()) : T("notSavedYet", backendName());
}
function activeItem() {
  const m = activeMeeting();
  return m ? m.items.find((i) => i.ref === state.sel) : null;
}
function waveform(it) {
  const src = it.src;
  let seed = (src.t0 * 9301 + 49297) % 233280;
  const rnd2 = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  const N = 24;
  const inStart = 7;
  const inEnd = 17;
  const low = isLow(it);
  return `<div class="wave" aria-hidden="true">${Array.from({ length: N }, (_, i) => {
    const h = 20 + Math.round(rnd2() * 76);
    const inside = i >= inStart && i <= inEnd;
    const bad = low && inside && i >= 12 && i <= 14;
    return `<i class="${bad ? "bad" : inside ? "in" : ""}" style="height:${h}%"></i>`;
  }).join("")}</div>
  <div class="wlegend"><span><i style="background:var(--accent)"></i>${esc(T("citedSpan"))}</span>${low ? `<span><i style="background:var(--danger)"></i>${esc(T("lowConfWords"))}</span>` : ""}</div>`;
}
function provenanceBlock(it, m) {
  if (!it.src) return `<p class="empty" style="padding:0;text-align:left">${esc(T("noSource"))}</p>`;
  const src = it.src;
  const to = it.correction?.to || null;
  const origMark = it.correction?.origPhrase || null;
  return `<div class="fld">
    <label>${esc(T("dProvenance"))}</label>
    <div class="quote">
      <div class="qh">
        <span class="tc" data-play="${esc(src.tc)}">${playIcon()}${esc(tcRange(src))}</span>
        ${src.speaker ? `<span class="sep">\xB7</span><span class="spk">${esc(src.speaker)}</span>` : ""}
        ${segLabel(src) ? `<span class="sep">\xB7</span><span class="mono">${esc(segLabel(src))}</span>` : ""}
        ${src.meetingId && src.meetingId !== m.id ? `<span class="sep">\xB7</span><span class="mono">${esc(src.meetingId)}</span>` : ""}
        <span class="asr" style="color:${confColor(it.confidence)}">${esc(T("asr"))} ${pct(it.confidence)}%</span>
      </div>
      ${src.orig ? `<div class="qt orig"><span class="lbl">${esc(T("asSpoken"))}${src.lang && src.lang !== "auto" ? ` \xB7 ${esc(src.lang)}` : ""}</span>${textWithMark(src.orig, origMark)}</div>` : ""}
      ${src.tr ? `<div class="qt"><span class="lbl">${esc(T("machineTranslation"))} \xB7 en</span>${textWithMark(src.tr, to)}</div>` : ""}
      ${waveform(it)}
    </div>
  </div>`;
}
function linkedBlock(it, m, variant = "fld") {
  const links = linkedItems(state.meetings, m, it);
  if (!links.length) return "";
  return `<div class="${variant === "card" ? "pcard" : "fld"}">
    <label class="lbl">${esc(T("dLinked"))}</label>
    <div class="linkrows">${links.map(({ item, meeting }) => `
      <div class="linkrow" data-link="${esc(item.ref)}" data-meeting="${esc(meeting.id)}">
        <span class="bar" style="background:${TYPE_COLOR[item.type]}"></span>
        <span class="r">${esc(item.ref)}</span>
        <span class="t">${esc(pickText(item.text, state.lang))}${item.type === "metric" && item.metric ? ` \xB7 ${esc(fmtNum(item.metric.value))}${esc(item.metric.unit)}` : ""}</span>
      </div>`).join("")}</div>
  </div>`;
}
function historyBlock(it) {
  const rows = [];
  const first = it.history?.[0];
  const created = first?.at || null;
  rows.push(`<div><span class="at">${created ? esc(created.slice(11, 16)) : "\u2014"}</span> \xB7 ${esc(T("extractedBy", first?.by || "local"))} \xB7 <span class="ai">${esc(T("ai"))}</span></div>`);
  if (isLow(it)) rows.push(`<div><span class="at">${created ? esc(created.slice(11, 16)) : "\u2014"}</span> \xB7 ${esc(T("flaggedLow", pct(it.confidence)))}</div>`);
  for (const h of (it.history || []).slice().reverse()) {
    if (h.field === "created" || h.field === "carriedFrom") {
      if (h.field === "carriedFrom") rows.push(`<div><span class="at">${esc(h.at.slice(11, 16))}</span> \xB7 \u21A9 ${esc(h.from)} \u2192 ${esc(h.to)} <span class="muted2">(${esc(h.by)})</span></div>`);
      continue;
    }
    const fmt = (v) => v == null ? "\u2205" : typeof v === "object" ? esc(JSON.stringify(v)) : esc(String(v));
    rows.push(`<div><span class="at">${esc(h.at.slice(11, 16))}</span> \xB7 ${esc(h.field)}: ${fmt(h.from)} \u2192 ${fmt(h.to)} <span class="muted2">(${esc(h.by)})</span></div>`);
  }
  return `<div class="fld"><label>${esc(T("dHistory"))}</label><div class="hist">${rows.join("")}</div></div>`;
}
function correctionBanner(it) {
  if (!it.correction || !isLow(it) && it.review !== "ai") return "";
  const c = it.correction;
  return `<div class="lowconf">
    <div class="h">${alertIcon(15)}<b>${esc(T("asrUnsure", pct(it.confidence)))}</b></div>
    <div class="b">${esc(T("extractorWrote"))} <code class="bad">${esc(c.from)}</code>. ${esc(T("audioSays"))}${it.src ? ` <span class="tc">${esc(it.src.tc)}</span>` : ""} <code class="good">${esc(c.to)}</code>.</div>
    <div class="acts">
      <button class="btn xs primary" id="d-apply">${esc(T("applyCorrection"))}</button>
      <button class="btn xs" id="d-keep">${esc(T("keepAsHeard"))}</button>
      <button class="btn xs" id="d-glossary" data-term="${esc(c.to)}">${esc(T("addToGlossary"))}</button>
    </div>
  </div>`;
}
function metricDetail(it, m) {
  const mt = it.metric;
  if (!mt) return "";
  const pts = metricSeries(seriesOf(m), mt.measure);
  const v = mt.variance;
  const dir = v == null ? "mOnBaseline" : v > 0 ? "mAhead" : v < 0 ? "mBehind" : "mOnBaseline";
  const risks = m.items.filter((i) => i.type === "risk" && i.status !== "closed" && (i.agenda && i.agenda === it.agenda || (it.links || []).includes(i.ref)));
  const callout = risks.length && v != null && v > 0 ? `<div class="callout"><div class="h">${alertIcon(14)}${esc(T("mAheadNotSafe"))}</div><p>${esc(T("mAheadNotSafeBody", risks.length))}</p></div>` : "";
  const side = `${linkedBlock(it, m, "card")}${callout}`;
  return `
    <div class="mcards">
      <div class="mc"><span class="lbl">${esc(T("mActual"))}</span><span class="n">${esc(fmtMeasure(mt.value))}<span class="unit">${esc(mt.unit)}</span></span></div>
      <div class="mc base"><span class="lbl">${esc(T("mBaseline"))}</span><span class="n">${mt.baseline != null ? `${esc(fmtMeasure(mt.baseline))}<span class="unit">${esc(mt.unit)}</span>` : "\u2014"}</span></div>
      <div class="mc var ${v != null && v < 0 ? "down" : ""}"><span class="lbl">${esc(T("mVariance"))}</span><span class="n">${v != null ? `${sign(v)}${esc(fmtMeasure(v))}<span class="unit">${esc(mt.unit)}</span>` : "\u2014"}</span><small>${esc(T(dir))}</small></div>
    </div>
    <div class="chart">
      <div class="ch"><b>${esc(T("mChart"))}</b>
        <div class="legend"><span><i class="line" style="background:var(--up)"></i>${esc(T("mActual"))}</span><span><i class="dash"></i>${esc(T("mBaseline"))}</span></div></div>
      <div class="sub">${esc(pts.length > 1 ? T("mChartNote") : T("mSingle"))}</div>
      ${metricChart(pts, mt.unit)}
    </div>
    <div class="mgrid">
      <div class="mprov">${metricSource(it)}</div>
      ${side ? `<div class="mside">${side}</div>` : ""}
    </div>`;
}
function metricSource(it) {
  const src = it.src;
  const mt = it.metric;
  const typed = !!src && !!mt && (mt.baseline != null || mt.variance != null);
  return `<div class="pcard">
    <span class="lbl">${esc(T("mWhereFrom"))}</span>
    ${src ? `<div class="qh">
      <span class="tc" data-play="${esc(src.tc)}">${playIcon()}${esc(tcRange(src))}</span>
      ${src.speaker ? `<span class="sep">\xB7</span><span class="spk">${esc(src.speaker)}</span>` : ""}
      ${segLabel(src) ? `<span class="sep">\xB7</span><span class="mono">${esc(segLabel(src))}</span>` : ""}
      <span class="asr" style="color:${confColor(it.confidence)}">${esc(T("asr"))} ${pct(it.confidence)}%</span>
    </div>
    <blockquote>${esc(src.tr || src.orig)}</blockquote>` : `<p class="empty" style="padding:0;text-align:left">${esc(T("noSource"))}</p>`}
    ${typed ? `<p class="mnote">${esc(T("mTypedNote"))}</p>` : ""}
  </div>`;
}
function metricChart(pts, unit) {
  const W = 620;
  const H = 196;
  const L = 40;
  const R = 12;
  const TOP = 20;
  const BOT = 170;
  const vals = pts.flatMap((p) => [p.value, p.baseline]).filter((x2) => x2 != null);
  const max = Math.max(...vals, 1) * 1.15;
  const x = (i) => pts.length === 1 ? (L + W - R) / 2 : L + i * (W - R - L) / (pts.length - 1);
  const y = (v) => BOT - v / max * (BOT - TOP);
  const ticks = 4;
  const grid = Array.from({ length: ticks + 1 }, (_, i) => {
    const v = max / ticks * i;
    const yy = y(v);
    return `<line x1="${L}" y1="${yy.toFixed(1)}" x2="${W - R}" y2="${yy.toFixed(1)}" stroke="${i === 0 ? "#3a3a3a" : "#242424"}"/><text x="${L - 8}" y="${(yy + 4).toFixed(1)}" text-anchor="end" fill="#8a8a8a" font-size="10" font-family="ui-monospace, Menlo, monospace">${fmtNum(v)}</text>`;
  }).join("");
  const line = (key, color, dash) => {
    const p = pts.map((pt, i) => pt[key] == null ? null : `${x(i).toFixed(1)},${y(pt[key]).toFixed(1)}`).filter(Boolean);
    if (!p.length) return "";
    return `<polyline fill="none" stroke="${color}" stroke-width="2" ${dash ? 'stroke-dasharray="5 4"' : ""} stroke-linecap="round" stroke-linejoin="round" points="${p.join(" ")}"/>`;
  };
  const last = pts[pts.length - 1];
  const li = pts.length - 1;
  const ends = last ? `
    ${last.baseline != null ? `<circle cx="${x(li).toFixed(1)}" cy="${y(last.baseline).toFixed(1)}" r="4" fill="#8a8a8a" stroke="#1f1f1f" stroke-width="2"/>` : ""}
    <circle cx="${x(li).toFixed(1)}" cy="${y(last.value).toFixed(1)}" r="5" fill="#199e70" stroke="#1f1f1f" stroke-width="2"/>
    <text x="${(x(li) - 10).toFixed(1)}" y="${(y(last.value) - 8).toFixed(1)}" text-anchor="end" fill="#199e70" font-size="11" font-weight="600" font-family="ui-monospace, Menlo, monospace">${fmtNum(last.value)}${esc(unit)}</text>
    ${last.baseline != null ? `<text x="${(x(li) - 10).toFixed(1)}" y="${(y(last.baseline) + 14).toFixed(1)}" text-anchor="end" fill="#b4b4b4" font-size="11" font-family="ui-monospace, Menlo, monospace">${fmtNum(last.baseline)}${esc(unit)}</text>` : ""}` : "";
  const xl = pts.map((p, i) => `<text x="${x(i).toFixed(1)}" y="190" text-anchor="middle" fill="${i === li ? "#e8e8e8" : "#8a8a8a"}" font-size="10" font-family="ui-monospace, Menlo, monospace">W${p.seq}</text>`).join("");
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(T("mChart"))}">${grid}${line("baseline", "#8a8a8a", true)}${line("value", "#199e70", false)}${ends}${xl}</svg>`;
}
function paintDrawer() {
  const dr = $("#drawer");
  const m = activeMeeting();
  if (state.adding) return paintDrawerAdd();
  const it = m ? activeItem() : null;
  if (!it) {
    dr.hidden = true;
    return;
  }
  dr.hidden = false;
  const locked = !!m.issuedAt;
  const other = state.lang === "en" ? "ID" : "EN";
  const isMetric = it.type === "metric";
  dr.classList.toggle("wide", isMetric);
  const refChip = `<span class="mono">${esc(it.ref)}</span>${it.carriedFrom ? ` <span style="color:var(--warn-text)">\u21A9 ${esc(it.carriedFrom)}</span>` : ""}`;
  const metaChips = `${cellType(it)}<span class="topic">${esc(topicLabel(it.topic))}</span>${it.agenda ? `<span class="mono muted2" style="font-size:10.5px">${esc(T("agendaRef", it.agenda))}</span>` : ""}${it.review !== "ai" ? `<span class="rev" data-r="${it.review}" style="margin:0">${esc(T(it.review))}</span>` : ""}`;
  $("#d-id").innerHTML = isMetric ? "" : refChip;
  $("#d-type").innerHTML = isMetric ? `<span class="dref">${refChip}</span>${metaChips}<h1 class="dtitle">${esc(itemText(it))}</h1>` : metaChips;
  $("#d-body").innerHTML = `
    ${locked ? "" : correctionBanner(it)}
    ${it.type === "metric" ? metricDetail(it, m) : ""}
    <div class="fld">
      <label>${esc(T("dText"))}</label>
      <textarea rows="4" id="f-text" ${locked ? "disabled" : ""}>${esc(itemText(it))}</textarea>
      <div class="hint"><span class="ldot"><i></i>${esc(state.lang.toUpperCase())}</span><span style="color:#4a4a4a">\xB7</span><span>${esc(T("translationHint", other))}</span></div>
    </div>
    <div class="two">
      <div class="fld"><label>${esc(T("dOwner"))}</label>
        <input id="f-owner" list="dl-owners" value="${esc(it.owner || "")}" ${locked ? "disabled" : ""} /></div>
      <div class="fld"><label>${esc(T("dDue"))}</label>
        <input type="date" id="f-due" value="${esc(it.due || "")}" ${locked ? "disabled" : ""} /></div>
      <div class="fld"><label>${esc(T("dStatus"))}</label>
        <select id="f-status" ${locked ? "disabled" : ""}>
          ${["open", "progress", "closed", "carried"].map((s) => `<option value="${s}" ${s === it.status ? "selected" : ""}>${esc(T(s))}</option>`).join("")}
        </select></div>
      ${it.type === "risk" ? `<div class="fld"><label>${esc(T("dSevLik"))}</label>
        <div class="sevlik">
          <select id="f-priority" ${locked ? "disabled" : ""} aria-label="${esc(T("dPriority"))}">
            ${["high", "med", "low"].map((p) => `<option value="${p}" ${p === it.priority ? "selected" : ""}>${esc(T(`pr${cap(p)}`))}</option>`).join("")}
          </select>
          <select id="f-likelihood" ${locked ? "disabled" : ""} aria-label="${esc(T("dSevLik"))}">
            ${LIKELIHOODS.map((l) => `<option value="${l}" ${l === it.likelihood ? "selected" : ""}>${esc(T(`lk${cap(l)}`))}</option>`).join("")}
          </select>
        </div></div>` : it.type === "action" ? `<div class="fld"><label>${esc(T("dPriority"))}</label>
        <select id="f-priority" ${locked ? "disabled" : ""}>
          ${["high", "med", "low"].map((p) => `<option value="${p}" ${p === it.priority ? "selected" : ""}>${esc(T(`pr${cap(p)}`))}</option>`).join("")}
        </select></div>` : `<div class="fld"><label>${esc(T("dTopic"))}</label>
        <input id="f-topic" list="dl-topics" value="${esc(it.topic)}" ${locked ? "disabled" : ""} /></div>`}
    </div>
    ${it.type === "risk" || it.type === "action" ? `<div class="fld"><label>${esc(T("dTopic"))}</label><input id="f-topic" list="dl-topics" value="${esc(it.topic)}" ${locked ? "disabled" : ""} /></div>` : ""}
    ${isMetric ? "" : provenanceBlock(it, m)}
    ${isMetric ? "" : linkedBlock(it, m)}
    ${historyBlock(it)}
    <datalist id="dl-owners">${(m.attendees || []).map((a) => `<option value="${esc(a.name)}">`).join("")}</datalist>
    <datalist id="dl-topics">${[...new Set(m.items.map((i) => i.topic))].map((t) => `<option value="${esc(t)}">`).join("")}</datalist>
  `;
  $("#d-foot").innerHTML = locked ? `<span class="muted">${esc(T("msgIssuedFrozen"))}</span>` : `<button class="btn primary" id="d-save">${checkIcon(13)} ${esc(T(it.review === "ai" ? "accept" : "saveEdit"))}</button>
       ${it.src ? `<button class="btn" id="d-play">${playIcon(12)} ${esc(T("playFrom"))}</button>` : ""}
       <span class="spacer"></span>
       <button class="btn danger" id="d-discard">${esc(T("discard"))}</button>`;
}
function paintDrawerAdd() {
  const dr = $("#drawer");
  dr.hidden = false;
  dr.classList.remove("wide");
  $("#d-id").textContent = T("addItem");
  $("#d-type").innerHTML = "";
  $("#d-body").innerHTML = `
    <div class="fld"><label>${esc(T("cType"))}</label>
      <select id="f-type">${ITEM_TYPES.map((t) => `<option value="${t}">${esc(T(t))}</option>`).join("")}</select></div>
    <div class="fld"><label>${esc(T("dText"))}</label><textarea rows="3" id="f-text"></textarea></div>
    <div class="two">
      <div class="fld"><label>${esc(T("dOwner"))}</label><input id="f-owner" /></div>
      <div class="fld"><label>${esc(T("dDue"))}</label><input type="date" id="f-due" /></div>
    </div>
    <div class="fld"><label>${esc(T("dTopic"))}</label><input id="f-topic" value="general" /></div>
  `;
  $("#d-foot").innerHTML = `<button class="btn primary" id="d-save">\uFF0B ${esc(T("addItem"))}</button><span class="spacer"></span><button class="btn" id="d-discard">${esc(T("discard"))}</button>`;
}
function paint() {
  document.documentElement.lang = state.lang;
  const m = activeMeeting();
  $("#empty-state").hidden = !!m;
  $("#workspace").hidden = !m;
  if (!m) return;
  paintHeader();
  paintChips();
  paintSwitcher();
  const rows = sortedItems(filteredItems());
  visibleRefs = rows.map((r) => r.ref);
  $(".main").classList.toggle("overlay", state.view === "series" || state.view === "doc");
  const pane = $("#pane");
  pane.innerHTML = state.view === "table" ? viewTable(rows) : state.view === "topic" ? viewTopic(rows) : state.view === "doc" ? viewDoc() : state.view === "series" ? viewSeries() : viewCarry();
  $("#q").value = state.q;
  paintFooter(rows);
  paintDrawer();
  const selRow = state.sel ? pane.querySelector(`[data-ref="${cssEscape(state.sel)}"]`) : null;
  if (selRow && typeof selRow.scrollIntoView === "function") selRow.scrollIntoView({ block: "nearest" });
}
var toastTimer;
function toast(msg, bad = false) {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.toggle("bad", bad);
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2400);
}
async function saveDrawer() {
  const m = activeMeeting();
  if (state.adding) {
    const type = $("#f-type").value;
    const text = $("#f-text").value.trim();
    if (!text) return;
    const meeting2 = await addItemAndSave(m, {
      type,
      topic: $("#f-topic").value.trim() || "general",
      text: { [state.lang]: text },
      owner: $("#f-owner").value.trim() || null,
      due: $("#f-due").value || null
    }, { by: state.me || "local" });
    replaceActive(meeting2);
    state.adding = false;
    state.sel = meeting2.items[meeting2.items.length - 1]?.ref || null;
    toast(T("msgItemAdded"));
    paint();
    return;
  }
  const it = activeItem();
  if (!it) return;
  const patch = {
    text: { ...it.text, [state.lang]: $("#f-text").value },
    owner: $("#f-owner").value.trim() || null,
    due: $("#f-due").value || null,
    status: $("#f-status").value,
    topic: $("#f-topic")?.value.trim() || it.topic
  };
  if ($("#f-priority")) patch.priority = $("#f-priority").value;
  if ($("#f-likelihood")) patch.likelihood = $("#f-likelihood").value;
  const changed = Object.keys(patch).some((k) => JSON.stringify(patch[k]) !== JSON.stringify(it[k]));
  let meeting;
  if (!changed && it.review === "ai") {
    meeting = await acceptItemAndSave(m, it.ref, { by: state.me || "local" });
  } else if (changed) {
    meeting = await editItemAndSave(m, it.ref, patch, { by: state.me || "local" });
  } else {
    return;
  }
  replaceActive(meeting);
  toast(T("msgAccepted"));
  paint();
}
async function doSaveSummary() {
  const m = activeMeeting();
  const box = $("#doc-summary");
  if (!m || !box) return;
  try {
    replaceActive(await setSummaryAndSave(m, state.lang, box.textContent));
    toast(T("msgSummarySaved"));
    paint();
  } catch (e) {
    toast(e && e.message ? e.message : String(e), true);
  }
}
async function acceptSelected() {
  const m = activeMeeting();
  const it = activeItem();
  if (!m || !it || m.issuedAt || it.review !== "ai") return;
  replaceActive(await acceptItemAndSave(m, it.ref, { by: state.me || "local" }));
  toast(T("msgAccepted"));
  paint();
}
async function discardDrawer() {
  if (state.adding) {
    state.adding = false;
    paint();
    return;
  }
  const it = activeItem();
  if (!it) return;
  if (!confirm(`${T("discard")}: ${it.ref}?`)) return;
  const meeting = await removeItemAndSave(activeMeeting(), it.ref);
  replaceActive(meeting);
  state.sel = null;
  paint();
}
async function doApplyCorrection() {
  const m = activeMeeting();
  const it = activeItem();
  if (!m || !it?.correction) return;
  replaceActive(await applyCorrectionAndSave(m, it.ref, { by: state.me || "local" }));
  toast(T("correctionApplied"));
  paint();
}
async function doKeepAsHeard() {
  const m = activeMeeting();
  const it = activeItem();
  if (!m || !it) return;
  replaceActive(await acceptItemAndSave(m, it.ref, { by: state.me || "local" }));
  toast(T("keptAsHeard"));
  paint();
}
function doAddGlossary(term) {
  let list = [];
  try {
    list = JSON.parse(localStorage.getItem(LS_GLOSSARY) || "[]");
  } catch {
    list = [];
  }
  if (!list.includes(term)) list.push(term);
  try {
    localStorage.setItem(LS_GLOSSARY, JSON.stringify(list));
  } catch {
  }
  toast(T("glossaryAdded", term));
}
async function doIssue(force = false) {
  const m = activeMeeting();
  try {
    const meeting = await issueMeetingAndSave(m, { force, by: state.me || "local" });
    replaceActive(meeting);
    toast(T("msgIssued"));
    state.view = "doc";
    syncTabs();
    paint();
  } catch (e) {
    if (e instanceof RegisterError && e.code === "unreviewed" && !force) {
      const blocked = blockingItems(m);
      if (confirm(T("msgBlocked", blocked.length))) await doIssue(true);
      return;
    }
    toast(e && e.message ? e.message : String(e), true);
  }
}
async function doAmend() {
  const m = activeMeeting();
  const amended = createAmendment(m, { by: state.me || "local" });
  const saved = await saveMeeting(amended);
  await reloadAll(false);
  state.activeId = saved.id;
  state.lastSaved = /* @__PURE__ */ new Date();
  toast(T("msgAmended", saved.id));
  paint();
}
async function doStartNext() {
  const m = activeMeeting();
  const series = seriesOf(m);
  const last = series[series.length - 1];
  const nextDate = prompt(T("date"), addDaysISO(last.date, 7));
  if (!nextDate) return;
  const next = startNextMeeting(last, { date: nextDate });
  const saved = await saveMeeting(next);
  await reloadAll(false);
  state.activeId = saved.id;
  state.lastSaved = /* @__PURE__ */ new Date();
  state.view = "table";
  syncTabs();
  toast(T("msgCarried"));
  paint();
}
function addDaysISO(iso, n) {
  const d = /* @__PURE__ */ new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function downloadText(filename, text) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
function doExport(format) {
  const m = activeMeeting();
  const safe = (m.id || "meeting").replace(/[^\w.-]+/g, "_");
  if (format === "print") {
    state.view = "doc";
    syncTabs();
    paint();
    setTimeout(() => window.print(), 50);
    return;
  }
  if (format === "json") downloadText(`${safe}.json`, JSON.stringify(m, null, 2));
  else if (format === "csv") downloadText(`${safe}.csv`, serializeMeetingCsv(m, state.lang));
  else downloadText(`${safe}.md`, serializeMeetingMarkdown(m, state.lang, T));
}
function doExportStanding() {
  const m = activeMeeting();
  const series = seriesOf(m);
  const rows = seriesSummary(series, todayUTC()).rows;
  const escCsv = (v) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = [
    ["ref", "meeting", "type", "text", "owner", "org", "raised", "age_days", "due", "status", "consecutive_meetings"].join(","),
    ...rows.map((r) => [r.item.ref, r.meeting.id, r.item.type, pickText(r.item.text, state.lang), r.item.owner || "", r.item.org || "", r.item.openedAt || r.meeting.date, r.age ?? "", r.item.due || "", r.item.status, r.chain].map(escCsv).join(","))
  ].join("\n");
  downloadText(`${m.seriesId.replace(/[^\w.-]+/g, "_")}-standing-register.csv`, csv);
}
function syncTabs() {
  [...$("#tabs").children].forEach((x) => x.setAttribute("aria-selected", String(x.dataset.view === state.view)));
}
function selectRef(ref, meetingId = null) {
  if (meetingId && meetingId !== state.activeId && state.meetings.some((m) => m.id === meetingId)) {
    state.activeId = meetingId;
    state.view = "table";
    syncTabs();
  }
  state.adding = false;
  state.sel = ref;
  paint();
}
function moveSel(delta) {
  if (!visibleRefs.length) return;
  const i = visibleRefs.indexOf(state.sel);
  const next = i < 0 ? delta > 0 ? 0 : visibleRefs.length - 1 : Math.min(visibleRefs.length - 1, Math.max(0, i + delta));
  state.adding = false;
  state.sel = visibleRefs[next];
  paint();
}
function wireEvents() {
  $("#tabs").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-view]");
    if (!b) return;
    state.view = b.dataset.view;
    syncTabs();
    paint();
  });
  $("#chips").addEventListener("click", (e) => {
    const c = e.target.closest(".chip");
    if (!c) return;
    const t = c.dataset.type;
    if (state.types.has(t)) state.types.delete(t);
    else state.types.add(t);
    paint();
  });
  $("#btn-review-only").addEventListener("click", () => {
    state.reviewOnly = !state.reviewOnly;
    paint();
  });
  $("#q").addEventListener("input", (e) => {
    state.q = e.target.value;
    paint();
  });
  $("#group-by").addEventListener("change", (e) => {
    state.group = e.target.value;
    paint();
  });
  $("#btn-mine").addEventListener("click", (e) => {
    if (!state.me) {
      const name = prompt(T("mine"));
      if (!name) return;
      state.me = name;
      localStorage.setItem(LS_NAME, name);
    }
    state.mine = !state.mine;
    e.currentTarget.setAttribute("aria-pressed", String(state.mine));
    paint();
  });
  $("#btn-dual").addEventListener("click", (e) => {
    state.dual = !state.dual;
    e.currentTarget.setAttribute("aria-pressed", String(state.dual));
    paint();
  });
  $(".langsw").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-lang]");
    if (!b) return;
    state.lang = b.dataset.lang;
    localStorage.setItem(LS_LANG, state.lang);
    T = makeT(state.lang);
    [...b.parentNode.children].forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
    paintStaticStrings();
    paint();
  });
  $("#m-switch").addEventListener("change", (e) => {
    state.activeId = e.target.value;
    state.sel = null;
    state.adding = false;
    paint();
  });
  $("#pane").addEventListener("click", (e) => {
    if (e.target.closest("#btn-save-summary")) {
      doSaveSummary();
      return;
    }
    const play = e.target.closest("[data-play]");
    if (play) {
      e.stopPropagation();
      toast(`${T("msgSeeking")} ${play.dataset.play}`);
      return;
    }
    const closeBtn = e.target.closest("[data-close]");
    if (closeBtn) {
      editItemAndSave(activeMeeting(), closeBtn.dataset.close, { status: "closed" }, { by: state.me || "local" }).then((meeting) => {
        replaceActive(meeting);
        paint();
      });
      return;
    }
    const th = e.target.closest("th[data-sort]");
    if (th) {
      const k = th.dataset.sort;
      state.sort = { key: k, dir: state.sort.key === k ? -state.sort.dir : 1 };
      paint();
      return;
    }
    if (e.target.closest("#btn-start-next")) {
      doStartNext();
      return;
    }
    if (e.target.closest("#btn-export-standing")) {
      doExportStanding();
      return;
    }
    if (e.target.closest("#btn-series-all")) {
      state.seriesAll = !state.seriesAll;
      paint();
      return;
    }
    const mcard = e.target.closest(".mcard[data-meeting]");
    if (mcard) {
      state.activeId = mcard.dataset.meeting;
      state.sel = null;
      paint();
      return;
    }
    const row = e.target.closest("[data-ref]");
    if (row) selectRef(row.dataset.ref, row.dataset.meeting || null);
  });
  $("#d-close").addEventListener("click", () => {
    state.sel = null;
    state.adding = false;
    $("#drawer").hidden = true;
    paint();
  });
  $("#drawer").addEventListener("click", (e) => {
    if (e.target.closest("#d-save")) {
      saveDrawer();
      return;
    }
    if (e.target.closest("#d-discard")) {
      discardDrawer();
      return;
    }
    if (e.target.closest("#d-apply")) {
      doApplyCorrection();
      return;
    }
    if (e.target.closest("#d-keep")) {
      doKeepAsHeard();
      return;
    }
    const gl = e.target.closest("#d-glossary");
    if (gl) {
      doAddGlossary(gl.dataset.term);
      return;
    }
    const link = e.target.closest("[data-link]");
    if (link) {
      selectRef(link.dataset.link, link.dataset.meeting);
      return;
    }
    const play = e.target.closest("[data-play]");
    if (play) {
      toast(`${T("msgSeeking")} ${play.dataset.play}`);
      return;
    }
    if (e.target.closest("#d-play")) {
      const it = activeItem();
      if (it?.src) toast(`${T("msgSeeking")} ${it.src.tc}`);
    }
  });
  $("#btn-add-item").addEventListener("click", () => {
    state.sel = null;
    state.adding = true;
    paint();
    $("#f-text")?.focus();
  });
  $("#btn-issue").addEventListener("click", () => doIssue(false));
  $("#btn-amend").addEventListener("click", () => doAmend());
  $("#btn-export").addEventListener("click", () => {
    const menu = $("#export-menu");
    menu.hidden = !menu.hidden;
  });
  $("#export-menu").addEventListener("click", (e) => {
    const b = e.target.closest("[data-export]");
    if (!b) return;
    doExport(b.dataset.export);
    $("#export-menu").hidden = true;
  });
  document.addEventListener("click", (e) => {
    if (!e.target.closest("#btn-export") && !e.target.closest("#export-menu")) $("#export-menu").hidden = true;
  });
  $("#btn-load-sample").addEventListener("click", async () => {
    $("#btn-load-sample").disabled = true;
    await seedSampleData();
    await reloadAll(false);
    state.lastSaved = /* @__PURE__ */ new Date();
    toast(T("msgMigrated", 2));
    paint();
  });
  document.addEventListener("keydown", (e) => {
    const tag = e.target && e.target.tagName || "";
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(tag) || e.target?.isContentEditable;
    if (e.key === "Escape") {
      if (typing && e.target !== $("#q")) {
        e.target.blur();
        return;
      }
      if (state.sel || state.adding) {
        state.sel = null;
        state.adding = false;
        $("#drawer").hidden = true;
        paint();
      }
      return;
    }
    if (typing) return;
    if (e.key === "/") {
      e.preventDefault();
      $("#q").focus();
      return;
    }
    if (!activeMeeting()) return;
    if (e.key === "j") {
      e.preventDefault();
      moveSel(1);
      return;
    }
    if (e.key === "k") {
      e.preventDefault();
      moveSel(-1);
      return;
    }
    if (e.key === "a") {
      e.preventDefault();
      acceptSelected();
      return;
    }
    if (e.key === "o") {
      e.preventDefault();
      $("#f-owner")?.focus();
      return;
    }
    if (e.key === "d") {
      e.preventDefault();
      $("#f-due")?.focus();
    }
  });
}
function paintStaticStrings() {
  document.querySelectorAll("[data-t]").forEach((el) => {
    el.textContent = T(el.dataset.t);
  });
  $("#q").placeholder = T("search");
}
async function boot() {
  document.querySelector(`.langsw button[data-lang="${state.lang}"]`)?.setAttribute("aria-pressed", "true");
  document.querySelector(`.langsw button[data-lang="${state.lang === "en" ? "id" : "en"}"]`)?.setAttribute("aria-pressed", "false");
  wireEvents();
  paintStaticStrings();
  await reloadAll(false);
  paint();
}
boot();
